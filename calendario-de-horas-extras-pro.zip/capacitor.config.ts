import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.elenildon.calendariohorasextras",
  appName: "Calendário de Horas Extras",
  webDir: "dist",
  backgroundColor: "#070b18",
  android: {
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
  },
};

export default config;

