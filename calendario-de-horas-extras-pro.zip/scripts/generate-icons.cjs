const fs = require("fs");
const path = require("path");
const { Resvg } = require("@resvg/resvg-js");

// Detailed SVG mimicking ic_launcher.png with electric neon blue glow
const createSvg = () => `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <!-- Background Gradient for Badge -->
    <radialGradient id="badgeGrad" cx="50%" cy="42%" r="58%">
      <stop offset="0%" stop-color="#282f42"/>
      <stop offset="55%" stop-color="#1b202e"/>
      <stop offset="90%" stop-color="#11151f"/>
      <stop offset="100%" stop-color="#0a0d14"/>
    </radialGradient>

    <!-- Deep 3D rim for badge -->
    <linearGradient id="badgeRim" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#3b445c"/>
      <stop offset="50%" stop-color="#1e2332"/>
      <stop offset="100%" stop-color="#080a0f"/>
    </linearGradient>

    <!-- Neon Glow Filter (Intense Electric Blue & Cyan) -->
    <filter id="electricGlow" x="-30%" y="-30%" width="160%" height="160%" filterUnits="userSpaceOnUse">
      <feGaussianBlur stdDeviation="4" result="coloredBlur1"/>
      <feGaussianBlur stdDeviation="10" result="coloredBlur2"/>
      <feGaussianBlur stdDeviation="18" result="coloredBlur3"/>
      <feMerge>
        <feMergeNode in="coloredBlur3"/>
        <feMergeNode in="coloredBlur2"/>
        <feMergeNode in="coloredBlur1"/>
        <feMergeNode in="SourceGraphic"/>
      </feMerge>
    </filter>

    <!-- Wider Soft Neon Ambient Aura -->
    <filter id="ambientNeon" x="-40%" y="-40%" width="180%" height="180%" filterUnits="userSpaceOnUse">
      <feGaussianBlur stdDeviation="16" result="blur"/>
    </filter>

    <!-- Subtle Drop Shadow for elements -->
    <filter id="cardShadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="14" flood-color="#000000" flood-opacity="0.6"/>
    </filter>

    <!-- Arrow Gradient -->
    <linearGradient id="arrowGrad" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#00b4d8"/>
      <stop offset="50%" stop-color="#00f5d4"/>
      <stop offset="100%" stop-color="#38bdf8"/>
    </linearGradient>

    <!-- Coin Gradients -->
    <radialGradient id="coinFace" cx="45%" cy="40%" r="55%">
      <stop offset="0%" stop-color="#f97316"/>
      <stop offset="70%" stop-color="#ea580c"/>
      <stop offset="100%" stop-color="#c2410c"/>
    </radialGradient>

    <linearGradient id="coinBorder" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fed7aa"/>
      <stop offset="40%" stop-color="#fb923c"/>
      <stop offset="100%" stop-color="#7c2d12"/>
    </linearGradient>

    <!-- Stopwatch Face Gradient -->
    <radialGradient id="dialFace" cx="50%" cy="45%" r="55%">
      <stop offset="0%" stop-color="#1f2638"/>
      <stop offset="85%" stop-color="#111622"/>
      <stop offset="100%" stop-color="#0b0e17"/>
    </radialGradient>
  </defs>

  <!-- ==================== 1. BADGE BASE ==================== -->
  <!-- Outer drop shadow of circular icon -->
  <circle cx="256" cy="262" r="236" fill="#030508" opacity="0.5" filter="url(#ambientNeon)"/>
  
  <!-- Outer Badge Body -->
  <circle cx="256" cy="256" r="236" fill="url(#badgeGrad)"/>
  <circle cx="256" cy="256" r="235" fill="none" stroke="url(#badgeRim)" stroke-width="2.5"/>

  <!-- Subtle bottom highlight / bevel on the circular badge -->
  <path d="M 38 280 A 236 236 0 0 0 474 280 A 236 234 0 0 1 38 280" fill="#000000" opacity="0.45"/>

  <!-- ==================== 2. NEON BACKLIGHT LAYER ==================== -->
  <!-- Behind calendar & stopwatch: Ambient luminous cyan/blue glow -->
  <g opacity="0.85">
    <!-- Calendar Neon Aura -->
    <rect x="110" y="125" width="270" height="262" rx="42" fill="none" stroke="#00d4ff" stroke-width="16" filter="url(#ambientNeon)"/>
    <!-- Stopwatch Neon Aura -->
    <circle cx="342" cy="188" r="68" fill="none" stroke="#0099ff" stroke-width="16" filter="url(#ambientNeon)"/>
  </g>

  <!-- ==================== 3. CALENDAR PAD ==================== -->
  <g filter="url(#cardShadow)">
    <!-- Electric Blue Neon Outer Outline of Calendar -->
    <rect x="115" y="130" width="260" height="252" rx="38" fill="none" stroke="#00f0ff" stroke-width="6" filter="url(#electricGlow)"/>

    <!-- Calendar Body (White/Light Slate Solid Pad) -->
    <rect x="118" y="133" width="254" height="246" rx="35" fill="#f8fafc" stroke="#0f172a" stroke-width="6"/>

    <!-- Top Binder Ring Left -->
    <g>
      <!-- Ring glow -->
      <rect x="162" y="112" width="22" height="42" rx="10" fill="none" stroke="#00e5ff" stroke-width="4" filter="url(#electricGlow)"/>
      <rect x="164" y="114" width="18" height="38" rx="9" fill="#e2e8f0" stroke="#1e293b" stroke-width="4"/>
      <rect x="168" y="118" width="10" height="14" rx="4" fill="#ffffff"/>
    </g>

    <!-- Top Binder Ring Right -->
    <g>
      <rect x="226" y="112" width="22" height="42" rx="10" fill="none" stroke="#00e5ff" stroke-width="4" filter="url(#electricGlow)"/>
      <rect x="228" y="114" width="18" height="38" rx="9" fill="#e2e8f0" stroke="#1e293b" stroke-width="4"/>
      <rect x="232" y="118" width="10" height="14" rx="4" fill="#ffffff"/>
    </g>

    <!-- Calendar Inner Recessed Screen / Grid Base -->
    <rect x="138" y="196" width="214" height="162" rx="16" fill="#1e2536" stroke="#0f172a" stroke-width="4"/>

    <!-- Grid Lines (Calendar Days / Horas Extras Matrix) -->
    <!-- Horizontal lines -->
    <line x1="138" y1="237" x2="352" y2="237" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
    <line x1="138" y1="277" x2="352" y2="277" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
    <line x1="138" y1="317" x2="352" y2="317" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>

    <!-- Vertical lines -->
    <line x1="172" y1="196" x2="172" y2="358" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
    <line x1="206" y1="196" x2="206" y2="358" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
    <line x1="240" y1="196" x2="240" y2="358" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
    <line x1="274" y1="196" x2="274" y2="358" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
    <line x1="308" y1="196" x2="308" y2="358" stroke="#64748b" stroke-width="4" stroke-linecap="round"/>
  </g>

  <!-- ==================== 4. STOPWATCH (CRONÔMETRO) ==================== -->
  <g filter="url(#cardShadow)">
    <!-- Stopwatch Pusher Buttons (Top & Angled) -->
    <!-- Top stem & crown -->
    <rect x="337" y="104" width="16" height="18" rx="3" fill="#94a3b8" stroke="#0f172a" stroke-width="3"/>
    <rect x="332" y="98" width="26" height="9" rx="3" fill="#cbd5e1" stroke="#0f172a" stroke-width="3"/>

    <!-- Right button (at ~2 o'clock) -->
    <g transform="rotate(38 345 188)">
      <rect x="340" y="106" width="14" height="14" rx="3" fill="#cbd5e1" stroke="#0f172a" stroke-width="3"/>
    </g>

    <!-- Left button (at ~10 o'clock) -->
    <g transform="rotate(-38 345 188)">
      <rect x="336" y="106" width="14" height="14" rx="3" fill="#cbd5e1" stroke="#0f172a" stroke-width="3"/>
    </g>

    <!-- Stopwatch Outer Neon Glow Ring -->
    <circle cx="345" cy="188" r="69" fill="none" stroke="#00f0ff" stroke-width="6" filter="url(#electricGlow)"/>

    <!-- Stopwatch White Outer Bezel -->
    <circle cx="345" cy="188" r="67" fill="#f8fafc" stroke="#0f172a" stroke-width="6"/>

    <!-- Stopwatch Inner Dial (Dark Navy Screen) -->
    <circle cx="345" cy="188" r="53" fill="url(#dialFace)" stroke="#1e293b" stroke-width="3"/>

    <!-- Stopwatch Dial Tick Marks -->
    <!-- 12 o'clock -->
    <line x1="345" y1="141" x2="345" y2="149" stroke="#38bdf8" stroke-width="3.5" stroke-linecap="round"/>
    <!-- 6 o'clock -->
    <line x1="345" y1="227" x2="345" y2="235" stroke="#38bdf8" stroke-width="3.5" stroke-linecap="round"/>
    <!-- 3 o'clock -->
    <line x1="389" y1="188" x2="397" y2="188" stroke="#38bdf8" stroke-width="3.5" stroke-linecap="round"/>
    <!-- 9 o'clock -->
    <line x1="293" y1="188" x2="301" y2="188" stroke="#38bdf8" stroke-width="3.5" stroke-linecap="round"/>

    <!-- Intermediate Hour Ticks -->
    <circle cx="378" cy="155" r="2" fill="#94a3b8"/>
    <circle cx="378" cy="221" r="2" fill="#94a3b8"/>
    <circle cx="312" cy="221" r="2" fill="#94a3b8"/>
    <circle cx="312" cy="155" r="2" fill="#94a3b8"/>

    <!-- Stopwatch Hands -->
    <!-- Short Hour Hand pointing to 10:30 -->
    <line x1="345" y1="188" x2="323" y2="164" stroke="#ffffff" stroke-width="5" stroke-linecap="round"/>
    <!-- Long Minute Hand pointing towards upper-right (2 o'clock) -->
    <line x1="345" y1="188" x2="371" y2="152" stroke="#ffffff" stroke-width="4.5" stroke-linecap="round"/>

    <!-- Center Pivot Dot -->
    <circle cx="345" cy="188" r="6" fill="#00e5ff" stroke="#ffffff" stroke-width="2"/>
  </g>

  <!-- ==================== 5. UPWARD GROWTH TREND ARROW ==================== -->
  <!-- Blue Neon Aura underneath the Arrow -->
  <path d="M 148 358 L 222 288 L 254 316 L 356 214"
        fill="none"
        stroke="#00d4ff"
        stroke-width="24"
        stroke-linecap="round"
        stroke-linejoin="round"
        filter="url(#ambientNeon)"
        opacity="0.8"/>

  <!-- Arrow Shaft with Electric Neon Glow -->
  <path d="M 148 358 L 222 288 L 254 316 L 356 214"
        fill="none"
        stroke="#00e5ff"
        stroke-width="14"
        stroke-linecap="round"
        stroke-linejoin="round"
        filter="url(#electricGlow)"/>

  <!-- Dark border for high contrast separation -->
  <path d="M 148 358 L 222 288 L 254 316 L 356 214"
        fill="none"
        stroke="#061224"
        stroke-width="13"
        stroke-linecap="round"
        stroke-linejoin="round"/>

  <!-- Inner Vibrant Blue/Cyan Stroke -->
  <path d="M 148 358 L 222 288 L 254 316 L 356 214"
        fill="none"
        stroke="url(#arrowGrad)"
        stroke-width="7"
        stroke-linecap="round"
        stroke-linejoin="round"/>

  <!-- Luminous Arrowhead Pointing Up-Right -->
  <g filter="url(#electricGlow)">
    <polygon points="340,192 388,206 374,254 360,232 328,218"
             fill="#00f5d4"
             stroke="#00d4ff"
             stroke-width="3"/>
  </g>
  <polygon points="340,192 388,206 374,254 360,232 328,218"
           fill="#ffffff"
           opacity="0.85"/>

  <!-- ==================== 6. OVERTIME COIN (MOEDA $) ==================== -->
  <g filter="url(#cardShadow)">
    <!-- Coin Outer Glow (Warm Gold) -->
    <circle cx="256" cy="346" r="50" fill="#f97316" opacity="0.25" filter="url(#ambientNeon)"/>

    <!-- Coin Black Outer Bezel / Rim -->
    <circle cx="256" cy="346" r="48" fill="#141824" stroke="#000000" stroke-width="4"/>

    <!-- Coin Gold Rim Outer -->
    <circle cx="256" cy="346" r="44" fill="url(#coinBorder)"/>

    <!-- Coin Main Face (Vibrant Orange / Amber) -->
    <circle cx="256" cy="346" r="39" fill="url(#coinFace)"/>

    <!-- Inner Grooved Ring on Coin -->
    <circle cx="256" cy="346" r="33" fill="none" stroke="#fed7aa" stroke-width="2.5" opacity="0.6"/>

    <!-- Dollar Sign Symbol ($) Centered -->
    <text x="256" y="361"
          font-family="system-ui, -apple-system, sans-serif"
          font-size="44"
          font-weight="900"
          text-anchor="middle"
          fill="#ffffff"
          stroke="#7c2d12"
          stroke-width="2"
          paint-order="stroke fill">$</text>
  </g>
</svg>
`;

const exportIcons = () => {
  const svgContent = createSvg().trim();

  // 1. Save Vector SVG
  const svgPath = path.resolve("public/icons/icon.svg");
  fs.writeFileSync(svgPath, svgContent, "utf8");
  console.log("Written:", svgPath);

  // Helper to render and write PNG
  const renderPng = (size, destRelPath) => {
    const resvg = new Resvg(svgContent, {
      fitTo: { mode: "width", value: size },
      shapeRendering: 2, // GeometricPrecision
      textRendering: 1,  // GeometricPrecision
      imageRendering: 0, // OptimizeQuality
    });
    const pngData = resvg.render();
    const destPath = path.resolve(destRelPath);
    fs.mkdirSync(path.dirname(destPath), { recursive: true });
    fs.writeFileSync(destPath, pngData.asPng());
    console.log(`Rendered PNG [${size}x${size}]: ${destRelPath}`);
  };

  // Render all target icon dimensions
  renderPng(1024, "src/assets/icon.png");
  renderPng(512, "public/icons/icon-512.png");
  renderPng(192, "public/icons/icon-192.png");
  renderPng(512, "public/pwa-512x512.png");
  renderPng(192, "public/pwa-192x192.png");
  renderPng(180, "public/apple-touch-icon.png");
};

exportIcons();
