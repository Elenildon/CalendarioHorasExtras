import fs from "fs";
import path from "path";

// Cria buffers de áudio WAV 44.1kHz 16-bit mono
function createWavBuffer(sampleRate, samples) {
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = samples.length * 2;
  const buffer = Buffer.alloc(44 + dataSize);

  // RIFF header
  buffer.write("RIFF", 0);
  buffer.writeUInt32LE(36 + dataSize, 4);
  buffer.write("WAVE", 8);

  // fmt subchunk
  buffer.write("fmt ", 12);
  buffer.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
  buffer.writeUInt16LE(1, 20);  // AudioFormat (1 for PCM)
  buffer.writeUInt16LE(numChannels, 22);
  buffer.writeUInt32LE(sampleRate, 24);
  buffer.writeUInt32LE(byteRate, 28);
  buffer.writeUInt16LE(blockAlign, 32);
  buffer.writeUInt16LE(bitsPerSample, 34);

  // data subchunk
  buffer.write("data", 36);
  buffer.writeUInt32LE(dataSize, 40);

  // Preencher amostras de 16-bit com clamp
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    const intSample = s < 0 ? s * 0x8000 : s * 0x7FFF;
    buffer.writeInt16LE(Math.floor(intSample), 44 + i * 2);
  }

  return buffer;
}

const sampleRate = 44100;

// Gerador de tom com envelope ADSR
function generateTone(freq, duration, type = "sine", volume = 0.5) {
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);
  const attack = Math.min(0.02, duration * 0.1) * sampleRate;
  const release = Math.min(0.08, duration * 0.3) * sampleRate;

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let wave = 0;
    if (type === "sine") {
      wave = Math.sin(2 * Math.PI * freq * t);
    } else if (type === "triangle") {
      wave = 2 * Math.abs(2 * (t * freq - Math.floor(t * freq + 0.5))) - 1;
    } else if (type === "square") {
      wave = Math.sin(2 * Math.PI * freq * t) >= 0 ? 0.7 : -0.7;
    } else if (type === "sawtooth") {
      wave = 2 * (t * freq - Math.floor(t * freq + 0.5));
    }

    // Envelope
    let env = 1;
    if (i < attack) {
      env = i / attack;
    } else if (i > numSamples - release) {
      env = (numSamples - i) / release;
    }

    samples[i] = wave * env * volume;
  }
  return samples;
}

function concatenateSamples(chunks) {
  let totalLen = 0;
  for (const c of chunks) totalLen += c.length;
  const result = new Float32Array(totalLen);
  let offset = 0;
  for (const c of chunks) {
    result.set(c, offset);
    offset += c.length;
  }
  return result;
}

function silence(duration) {
  return new Float32Array(Math.floor(sampleRate * duration));
}

// 10 Presets Originais
const presetsGenerators = {
  // 01 — Pulse Rise: Pulso eletrônico progressivo
  pulse_rise: () => {
    return concatenateSamples([
      generateTone(440, 0.12, "sine", 0.4),
      silence(0.04),
      generateTone(587.33, 0.14, "sine", 0.45),
      silence(0.04),
      generateTone(739.99, 0.16, "sine", 0.5),
      silence(0.04),
      generateTone(880, 0.35, "sine", 0.55),
    ]);
  },

  // 02 — Digital Wake: Sequência de bipes digitais rápidos e limpos
  digital_wake: () => {
    return concatenateSamples([
      generateTone(1046.5, 0.08, "square", 0.35),
      silence(0.05),
      generateTone(1318.51, 0.08, "square", 0.35),
      silence(0.05),
      generateTone(1567.98, 0.18, "square", 0.4),
    ]);
  },

  // 03 — Soft Morning: Melodia curta, agradável e progressiva
  soft_morning: () => {
    return concatenateSamples([
      generateTone(523.25, 0.22, "sine", 0.35),
      silence(0.03),
      generateTone(659.25, 0.22, "sine", 0.4),
      silence(0.03),
      generateTone(783.99, 0.25, "sine", 0.45),
      silence(0.03),
      generateTone(1046.5, 0.5, "sine", 0.5),
    ]);
  },

  // 04 — Crystal Bell: Toques cristalinos modernos
  crystal_bell: () => {
    const bell1 = generateTone(1760, 0.45, "sine", 0.4);
    const bell2 = generateTone(2640, 0.35, "triangle", 0.25);
    // Mistura harmônica
    const mix = new Float32Array(bell1.length);
    for (let i = 0; i < bell1.length; i++) {
      mix[i] = bell1[i] + (i < bell2.length ? bell2[i] : 0);
    }
    return concatenateSamples([
      mix,
      silence(0.08),
      generateTone(2217.46, 0.55, "sine", 0.45),
    ]);
  },

  // 05 — Neon Pulse: Pulsos eletrônicos modernos com grave moderado
  neon_pulse: () => {
    return concatenateSamples([
      generateTone(180, 0.15, "triangle", 0.5),
      silence(0.02),
      generateTone(740, 0.18, "sawtooth", 0.35),
      silence(0.03),
      generateTone(987.77, 0.35, "sawtooth", 0.4),
    ]);
  },

  // 06 — Focus Alert: Alerta curto, limpo e objetivo
  focus_alert: () => {
    return concatenateSamples([
      generateTone(880, 0.18, "sine", 0.45),
      silence(0.05),
      generateTone(1174.66, 0.45, "sine", 0.5),
    ]);
  },

  // 07 — Deep Alarm: Grave moderado combinado com pulsos de alerta
  deep_alarm: () => {
    return concatenateSamples([
      generateTone(220, 0.2, "triangle", 0.5),
      silence(0.03),
      generateTone(440, 0.15, "square", 0.35),
      silence(0.03),
      generateTone(659.25, 0.35, "square", 0.4),
    ]);
  },

  // 08 — Smart Chime: Sino eletrônico moderno
  smart_chime: () => {
    return concatenateSamples([
      generateTone(587.33, 0.2, "sine", 0.4),
      silence(0.04),
      generateTone(880, 0.25, "sine", 0.45),
      silence(0.04),
      generateTone(1174.66, 0.55, "sine", 0.5),
    ]);
  },

  // 09 — Rapid Wake: Sequência rápida para chamar atenção
  rapid_wake: () => {
    return concatenateSamples([
      generateTone(880, 0.08, "square", 0.35),
      silence(0.04),
      generateTone(1046.5, 0.08, "square", 0.4),
      silence(0.04),
      generateTone(880, 0.08, "square", 0.35),
      silence(0.04),
      generateTone(1318.51, 0.25, "square", 0.45),
    ]);
  },

  // 10 — Extreme Wake: Alarme forte, progressivo e de alta atenção
  extreme_wake: () => {
    return concatenateSamples([
      generateTone(587.33, 0.15, "sawtooth", 0.35),
      silence(0.03),
      generateTone(739.99, 0.18, "sawtooth", 0.4),
      silence(0.03),
      generateTone(932.33, 0.2, "sawtooth", 0.45),
      silence(0.03),
      generateTone(1174.66, 0.45, "sawtooth", 0.55),
    ]);
  },
};

const outputDir = path.resolve("public/assets/audio/alarms");
fs.mkdirSync(outputDir, { recursive: true });

const filesMap = {
  pulse_rise: "alarm_01_pulse_rise.mp3",
  digital_wake: "alarm_02_digital_wake.mp3",
  soft_morning: "alarm_03_soft_morning.mp3",
  crystal_bell: "alarm_04_crystal_bell.mp3",
  neon_pulse: "alarm_05_neon_pulse.mp3",
  focus_alert: "alarm_06_focus_alert.mp3",
  deep_alarm: "alarm_07_deep_alarm.mp3",
  smart_chime: "alarm_08_smart_chime.mp3",
  rapid_wake: "alarm_09_rapid_wake.mp3",
  extreme_wake: "alarm_10_extreme_wake.mp3",
};

for (const [presetId, fileName] of Object.entries(filesMap)) {
  const gen = presetsGenerators[presetId];
  if (gen) {
    const samples = gen();
    const buffer = createWavBuffer(sampleRate, samples);
    const dest = path.join(outputDir, fileName);
    fs.writeFileSync(dest, buffer);
    console.log(`Gerado com sucesso: ${fileName} (${buffer.length} bytes)`);
  }
}

console.log("Todos os 10 arquivos de áudio originais foram gerados!");
