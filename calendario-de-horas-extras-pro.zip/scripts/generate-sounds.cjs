const fs = require('fs');
const path = require('path');

const sampleRate = 44100;

function createWavBuffer(samples) {
  const numSamples = samples.length;
  const buffer = Buffer.alloc(44 + numSamples * 2);

  // RIFF identifier
  buffer.write('RIFF', 0);
  // file length minus 8
  buffer.writeUInt32LE(36 + numSamples * 2, 4);
  // RIFF type
  buffer.write('WAVE', 8);
  // format chunk identifier
  buffer.write('fmt ', 12);
  // format chunk length
  buffer.writeUInt32LE(16, 16);
  // sample format (1 = PCM)
  buffer.writeUInt16LE(1, 20);
  // channel count (1 = mono)
  buffer.writeUInt16LE(1, 22);
  // sample rate
  buffer.writeUInt32LE(sampleRate, 24);
  // byte rate (sample rate * channels * bytes per sample)
  buffer.writeUInt32LE(sampleRate * 2, 28);
  // block align (channels * bytes per sample)
  buffer.writeUInt16LE(2, 32);
  // bits per sample
  buffer.writeUInt16LE(16, 34);
  // data chunk identifier
  buffer.write('data', 36);
  // data chunk length
  buffer.writeUInt32LE(numSamples * 2, 40);

  // write samples with gentle limiting
  for (let i = 0; i < numSamples; i++) {
    let s = Math.max(-0.95, Math.min(0.95, samples[i]));
    let val = s < 0 ? s * 32768 : s * 32767;
    buffer.writeInt16LE(Math.floor(val), 44 + i * 2);
  }

  return buffer;
}

// ==========================================
// 🍎 GRUPO 1 — 5 SONS ESTILO iOS
// ==========================================

// 01 — Crystal Alert: Som cristalino, curto, elegante e tecnológico
function generateCrystalAlert() {
  const duration = 0.95;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Notas cristalinas: fundamental 1760 Hz (A6) com harmônicos puros e sub-tons suaves
  const notes = [
    { start: 0.0, end: 0.85, freq: 1760, amp: 0.55 },
    { start: 0.0, end: 0.70, freq: 2640, amp: 0.28 },
    { start: 0.0, end: 0.55, freq: 3520, amp: 0.15 },
    { start: 0.08, end: 0.92, freq: 2217.46, amp: 0.35 }, // C#7
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const n of notes) {
      if (t >= n.start && t <= n.end) {
        const elapsed = t - n.start;
        const dur = n.end - n.start;
        // Ataque percussivo ultrarrápido (2ms) seguido de decaimento suave exponencial
        const attack = Math.min(1, elapsed / 0.003);
        const decay = Math.exp(-elapsed * 6.5);
        const env = attack * decay * n.amp;
        const wave = Math.sin(2 * Math.PI * n.freq * t) + 0.12 * Math.sin(4 * Math.PI * n.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 02 — Pure Chime: Notas digitais suaves, claras e sofisticadas
function generatePureChime() {
  const duration = 1.1;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Duas notas ascendentes puras: E5 (659.25 Hz) -> B5 (987.77 Hz)
  const notes = [
    { start: 0.00, end: 0.55, freq: 659.25, amp: 0.55 },
    { start: 0.16, end: 1.05, freq: 987.77, amp: 0.65 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const n of notes) {
      if (t >= n.start && t <= n.end) {
        const elapsed = t - n.start;
        const attack = Math.min(1, elapsed / 0.008);
        const decay = Math.exp(-elapsed * 4.2);
        const env = attack * decay * n.amp;
        // Senóide limpa com toque de calor acústico
        const wave = Math.sin(2 * Math.PI * n.freq * t) + 0.08 * Math.sin(4 * Math.PI * n.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 03 — Soft Digital: Tons digitais modernos com pequena subida de frequência
function generateSoftDigital() {
  const duration = 0.95;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // 3 tons digitais suaves encadeados: G5 (784) -> C6 (1046) -> E6 (1318)
  const blips = [
    { start: 0.00, end: 0.28, freq: 783.99, amp: 0.50 },
    { start: 0.12, end: 0.45, freq: 1046.50, amp: 0.58 },
    { start: 0.24, end: 0.90, freq: 1318.51, amp: 0.65 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const b of blips) {
      if (t >= b.start && t <= b.end) {
        const elapsed = t - b.start;
        const attack = Math.min(1, elapsed / 0.006);
        const decay = Math.exp(-elapsed * 5.0);
        const env = attack * decay * b.amp;
        // Suave chirp / subida de 15 Hz no ataque
        const sweep = 15 * Math.exp(-elapsed * 20);
        const wave = Math.sin(2 * Math.PI * (b.freq + sweep) * t) + 0.05 * Math.sin(6 * Math.PI * b.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 04 — Premium Wake: Sequência melódica curta, suave no início e progressiva
function generatePremiumWake() {
  const duration = 1.25;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Sequência melódica refinada estilo premium: D5 (587.33), F#5 (739.99), A5 (880), D6 (1174.66)
  const notes = [
    { start: 0.00, end: 0.35, freq: 587.33, amp: 0.38 },
    { start: 0.14, end: 0.52, freq: 739.99, amp: 0.48 },
    { start: 0.28, end: 0.70, freq: 880.00, amp: 0.58 },
    { start: 0.44, end: 1.20, freq: 1174.66, amp: 0.70 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const n of notes) {
      if (t >= n.start && t <= n.end) {
        const elapsed = t - n.start;
        const attack = Math.min(1, elapsed / 0.012);
        const decay = Math.exp(-elapsed * 3.8);
        const env = attack * decay * n.amp;
        const wave = 0.8 * Math.sin(2 * Math.PI * n.freq * t) + 0.2 * Math.sin(4 * Math.PI * n.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 05 — Smart Alert: Alerta eletrônico limpo, moderno e facilmente audível
function generateSmartAlert() {
  const duration = 0.85;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Dois pulsos sincronizados em intervalo de quinta pura: 880 Hz (A5) -> 1320 Hz (E6)
  const pulses = [
    { start: 0.00, end: 0.24, freq: 880.0, amp: 0.65 },
    { start: 0.11, end: 0.80, freq: 1320.0, amp: 0.75 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const p of pulses) {
      if (t >= p.start && t <= p.end) {
        const elapsed = t - p.start;
        const attack = Math.min(1, elapsed / 0.004);
        const decay = Math.exp(-elapsed * 5.8);
        const env = attack * decay * p.amp;
        const wave = Math.sin(2 * Math.PI * p.freq * t) + 0.15 * Math.sin(4 * Math.PI * p.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// ==========================================
// 🤖 GRUPO 2 — 5 SONS ESTILO ANDROID DESPERTADOR
// ==========================================

// 06 — Android Classic: Estética de despertador Android clássico, com sequência clara e repetitiva
function generateAndroidClassic() {
  const duration = 1.3;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Par duplo de beeps clássicos (bip-bip ... bip-bip) a 880 Hz e 1046 Hz
  const beeps = [
    { start: 0.00, end: 0.13, freq: 880, amp: 0.7 },
    { start: 0.16, end: 0.29, freq: 1046.5, amp: 0.8 },
    { start: 0.48, end: 0.61, freq: 880, amp: 0.75 },
    { start: 0.64, end: 0.77, freq: 1046.5, amp: 0.85 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const b of beeps) {
      if (t >= b.start && t <= b.end) {
        const elapsed = t - b.start;
        const dur = b.end - b.start;
        const env = Math.sin((elapsed / dur) * Math.PI) * b.amp;
        // Harmônicos eletrônicos marcantes (onda senoidal + 3º harmônico quadrado)
        const wave = 0.8 * Math.sin(2 * Math.PI * b.freq * t) + 0.2 * Math.sin(6 * Math.PI * b.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 07 — Android Digital: Tons digitais rápidos, tecnológicos e progressivos
function generateAndroidDigital() {
  const duration = 1.2;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Sequência digital rápida de despertador: 659 Hz, 784 Hz, 988 Hz, 1318 Hz
  const chirps = [
    { start: 0.00, end: 0.14, freq: 659.25, amp: 0.55 },
    { start: 0.12, end: 0.26, freq: 783.99, amp: 0.62 },
    { start: 0.24, end: 0.40, freq: 987.77, amp: 0.70 },
    { start: 0.38, end: 0.85, freq: 1318.51, amp: 0.80 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const c of chirps) {
      if (t >= c.start && t <= c.end) {
        const elapsed = t - c.start;
        const attack = Math.min(1, elapsed / 0.005);
        const decay = Math.exp(-elapsed * 6.0);
        const env = attack * decay * c.amp;
        const wave = 0.75 * Math.sin(2 * Math.PI * c.freq * t) + 0.25 * Math.sin(4 * Math.PI * c.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 08 — Android Morning: Som de despertador mais suave, porém claramente perceptível
function generateAndroidMorning() {
  const duration = 1.4;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Toques suaves estilo marimba matinal: C5 (523), E5 (659), G5 (784), C6 (1046)
  const notes = [
    { start: 0.00, end: 0.40, freq: 523.25, amp: 0.45 },
    { start: 0.20, end: 0.65, freq: 659.25, amp: 0.55 },
    { start: 0.40, end: 0.85, freq: 783.99, amp: 0.65 },
    { start: 0.60, end: 1.35, freq: 1046.50, amp: 0.75 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const n of notes) {
      if (t >= n.start && t <= n.end) {
        const elapsed = t - n.start;
        const attack = Math.min(1, elapsed / 0.015);
        const decay = Math.exp(-elapsed * 3.5);
        const env = attack * decay * n.amp;
        // Timbre quente com harmônico oitavado suave
        const wave = 0.85 * Math.sin(2 * Math.PI * n.freq * t) + 0.15 * Math.sin(4 * Math.PI * n.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 09 — Android Pulse: Pulsos eletrônicos ritmados e fortes, adequados para despertar
function generateAndroidPulse() {
  const duration = 1.25;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // 3 pulsos ritmados fortes a 740 Hz e 988 Hz
  const pulses = [
    { start: 0.00, end: 0.18, freq: 740.0, amp: 0.7 },
    { start: 0.22, end: 0.40, freq: 740.0, amp: 0.75 },
    { start: 0.44, end: 0.85, freq: 987.77, amp: 0.85 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const p of pulses) {
      if (t >= p.start && t <= p.end) {
        const elapsed = t - p.start;
        const attack = Math.min(1, elapsed / 0.008);
        const decay = Math.exp(-elapsed * 4.5);
        const env = attack * decay * p.amp;
        const wave = 0.7 * Math.sin(2 * Math.PI * p.freq * t) + 0.3 * Math.sin(4 * Math.PI * p.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// 10 — Android Wake Up: Alerta progressivo, começando suave e aumentando a intensidade
function generateAndroidWakeUp() {
  const duration = 1.45;
  const numSamples = Math.floor(sampleRate * duration);
  const samples = new Float32Array(numSamples);

  // Crescendo progressivo de 4 notas ascendentes com ganho crescente
  const notes = [
    { start: 0.00, end: 0.30, freq: 587.33, amp: 0.35 },
    { start: 0.20, end: 0.55, freq: 739.99, amp: 0.50 },
    { start: 0.42, end: 0.80, freq: 932.33, amp: 0.68 },
    { start: 0.65, end: 1.40, freq: 1174.66, amp: 0.88 },
  ];

  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    let s = 0;
    for (const n of notes) {
      if (t >= n.start && t <= n.end) {
        const elapsed = t - n.start;
        const attack = Math.min(1, elapsed / 0.02);
        const decay = Math.exp(-elapsed * 3.2);
        const env = attack * decay * n.amp;
        const wave = 0.8 * Math.sin(2 * Math.PI * n.freq * t) + 0.2 * Math.sin(4 * Math.PI * n.freq * t);
        s += wave * env;
      }
    }
    samples[i] = s;
  }
  return samples;
}

// ==========================================
// GRAVAÇÃO DOS 10 ARQUIVOS .WAV
// ==========================================
const soundGenerators = [
  // 🍎 GRUPO 1 — 5 SONS ESTILO iOS
  { file: 'ios-crystal-alert.wav', gen: generateCrystalAlert },
  { file: 'ios-pure-chime.wav', gen: generatePureChime },
  { file: 'ios-soft-digital.wav', gen: generateSoftDigital },
  { file: 'ios-premium-wake.wav', gen: generatePremiumWake },
  { file: 'ios-smart-alert.wav', gen: generateSmartAlert },

  // 🤖 GRUPO 2 — 5 SONS ESTILO ANDROID DESPERTADOR
  { file: 'android-classic-alarm.wav', gen: generateAndroidClassic },
  { file: 'android-digital-alarm.wav', gen: generateAndroidDigital },
  { file: 'android-morning-alarm.wav', gen: generateAndroidMorning },
  { file: 'android-pulse-alarm.wav', gen: generateAndroidPulse },
  { file: 'android-wake-up-alarm.wav', gen: generateAndroidWakeUp },
];

const targetDirs = [
  path.join(__dirname, '..', 'public', 'sounds'),
];

targetDirs.forEach((dir) => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

soundGenerators.forEach(({ file, gen }) => {
  const samples = gen();
  const wavBuffer = createWavBuffer(samples);
  targetDirs.forEach((dir) => {
    const dest = path.join(dir, file);
    fs.writeFileSync(dest, wavBuffer);
    console.log(`✓ Gerado som: ${dest} (${wavBuffer.length} bytes)`);
  });
});

console.log('✅ Todos os 10 sons gerados com sucesso!');
