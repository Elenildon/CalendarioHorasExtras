import path from "path";
import fs from "fs";
import { exec } from "child_process";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Garante compatibilidade universal (iOS/Safari, iPhone, Android, QR Code) e previne erros 403 ou bloqueio de cookies
function applyContainerFixes() {
  try {
    const luaPath = "/etc/nginx/user_auth_verification.lua";
    if (fs.existsSync(luaPath)) {
      const content = fs.readFileSync(luaPath, "utf-8");
      if (!content.includes("is_mobile")) {
        const target = 'if ngx.var.host == "localhost" then\n  return\nend';
        const replacement = `if ngx.var.host == "localhost" then
  return
end

-- Allow mobile devices (iPhone, iPad, iPod, Android), Safari, QR scans, and qr/app params without 403 or cookie block
local user_agent = ngx.var.http_user_agent or ""
local is_mobile = string.match(user_agent, "iPhone") or string.match(user_agent, "iPad") or string.match(user_agent, "iPod") or string.match(user_agent, "Android") or string.match(user_agent, "Mobile") or string.match(user_agent, "Safari")
if is_mobile or ngx.var.arg_qr ~= nil or ngx.var.arg_app ~= nil or ngx.var.arg_mobile ~= nil or os.getenv("DISABLE_AUTH_BRIDGE") == "true" then
  return
end`;
        if (content.includes(target)) {
          fs.writeFileSync(luaPath, content.replace(target, replacement));
        }
      }
    }

    const authInclude = "/etc/nginx/nginx_auth.conf.include";
    if (fs.existsSync(authInclude)) {
      const c = fs.readFileSync(authInclude, "utf-8");
      if (!c.includes("return 302 /;")) {
        const targetF = `location /forbidden.html {
    internal;
    default_type text/html;
    return 403 '<html><head><title>403 Forbidden</title></head><body><h1>403 Forbidden</h1></body></html>';
}`;
        if (c.includes(targetF)) {
          fs.writeFileSync(authInclude, c.replace(targetF, "location /forbidden.html {\n    return 302 /;\n}"));
        }
      }
    }

    const cookieCheck = "/var/www/assets/cookie_check.html";
    if (fs.existsSync(cookieCheck)) {
      const html = fs.readFileSync(cookieCheck, "utf-8");
      if (!html.includes("window.location.replace(returnUrl)")) {
        const targetScript = "<script>\n      const AUTH_FLOW_TEST_COOKIE_NAME";
        const replacementScript = `<script>
      (function() {
        const returnUrl = new URLSearchParams(window.location.search).get("return_url");
        if (returnUrl && !returnUrl.toLowerCase().startsWith("javascript:")) {
          window.location.replace(returnUrl);
          return;
        }
        window.location.replace("/");
      })();
      const AUTH_FLOW_TEST_COOKIE_NAME`;
        if (html.includes(targetScript)) {
          fs.writeFileSync(cookieCheck, html.replace(targetScript, replacementScript));
        }
      }
    }

    exec("nginx -t && nginx -s reload", () => {});
  } catch {
    // Non-blocking
  }
}

applyContainerFixes();

// https://vite.dev/config/
export default defineConfig({
  define: {
    "process.env": {},
  },
  plugins: [
    react(),
    tailwindcss(),
    viteSingleFile(),
    {
      name: "container-universal-access",
      buildStart: applyContainerFixes,
      configureServer: applyContainerFixes,
    },
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  server: {
    host: "0.0.0.0",
    port: 3000,
    allowedHosts: true,
  },
  preview: {
    host: "0.0.0.0",
    port: 3000,
    allowedHosts: true,
  },
});
