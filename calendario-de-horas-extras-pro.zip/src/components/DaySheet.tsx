import { useEffect, useState } from "react";
import { BadgeCheck, Moon, Trash2, X, Fingerprint, Sparkles } from "lucide-react";
import {
  SEMANA_LONGA,
  holidaysOn,
  dayPercent,
  bandColor,
  bandForDow,
  DOT_CLASS,
  DOT_BY_KIND,
  KIND_META,
  type DayEntry,
  type DotColor,
  type Settings,
} from "../lib/calc";
import { getPontoBiometrico, calculateWorkedAndOvertime, clearPontoRecordsForDate } from "../lib/pontoStorage";
import { NotepadObservationField } from "./NotepadObservationField";
import { cn } from "../utils/cn";

export default function DaySheet({
  date,
  entry,
  settings,
  onClose,
  onSave,
  onDelete,
}: {
  date: { y: number; m: number; d: number } | null;
  entry?: DayEntry;
  settings: Settings;
  onClose: () => void;
  onSave: (payload: DayEntry) => void;
  onDelete: () => void;
}) {
  const [horas, setHoras] = useState("");
  const [minutos, setMinutos] = useState("");
  const [noturno, setNoturno] = useState(false);
  const [note, setNote] = useState("");
  const [pontoBio, setPontoBio] = useState<ReturnType<typeof getPontoBiometrico>>(() => {
    if (!date) return null;
    try {
      const k = `${date.y}-${String(date.m + 1).padStart(2, "0")}-${String(date.d).padStart(2, "0")}`;
      return getPontoBiometrico(k);
    } catch {
      return null;
    }
  });

  const dateKeyStr = date
    ? `${date.y}-${String(date.m + 1).padStart(2, "0")}-${String(date.d).padStart(2, "0")}`
    : "";

  useEffect(() => {
    if (date) {
      if (entry && ((entry.hours ?? 0) > 0 || (entry.minutes ?? 0) > 0)) {
        setHoras(String(entry.hours ?? 0));
        setMinutos(String(entry.minutes ?? 0));
      } else if (pontoBio && (pontoBio.entrada || pontoBio.saida)) {
        const calc = calculateWorkedAndOvertime({
          entrada: pontoBio.entrada,
          inicioIntervalo: pontoBio.inicioIntervalo,
          retornoIntervalo: pontoBio.retornoIntervalo,
          saida: pontoBio.saida,
        });
        if (calc.workedMinutes > 0) {
          const h = Math.floor(calc.workedMinutes / 60);
          const m = calc.workedMinutes % 60;
          setHoras(String(h));
          setMinutos(String(m));
        } else {
          setHoras("");
          setMinutos("");
        }
      } else {
        setHoras("");
        setMinutos("");
      }
      setNoturno(Boolean(entry?.noturno));
      setNote(entry?.note ?? "");
    } else {
      setHoras("");
      setMinutos("");
      setNoturno(false);
      setNote("");
    }
  }, [date, entry, pontoBio]);

  useEffect(() => {
    if (dateKeyStr) {
      try {
        setPontoBio(getPontoBiometrico(dateKeyStr));
      } catch (err) {
        console.error("Erro ao sincronizar ponto biométrico:", err);
        setPontoBio(null);
      }
    } else {
      setPontoBio(null);
    }
  }, [dateKeyStr]);

  if (!date) return null;
  const { y, m, d } = date;
  const dow = new Date(y, m, d).getDay();
  const key = dateKeyStr;
  const hols = holidaysOn(key, { state: settings?.state ?? "SP", city: settings?.city ?? "São Paulo" });
  const auto = dayPercent(key, dow, settings);
  const main = auto.holiday ?? hols[0];
  const meta = main ? KIND_META[main.kind] : null;
  const hasManualHours = (Number(horas) || 0) > 0 || (Number(minutos) || 0) > 0;
  const exists = Boolean(
    entry &&
      ((entry.hours ?? 0) > 0 ||
        (entry.minutes ?? 0) > 0 ||
        (entry.note ?? "").trim() !== "")
  );

  const handleZerarPonto = () => {
    try {
      clearPontoRecordsForDate(key);
    } catch (err) {
      console.error("Erro ao zerar registros de ponto:", err);
    }
    setPontoBio(null);
    setHoras("");
    setMinutos("");
  };

  const workedBio = calculateWorkedAndOvertime({
    entrada: pontoBio?.entrada,
    inicioIntervalo: pontoBio?.inicioIntervalo,
    retornoIntervalo: pontoBio?.retornoIntervalo,
    saida: pontoBio?.saida,
  });

  const save = () => {
    const dot: DotColor = main && DOT_BY_KIND[main.kind]
      ? DOT_BY_KIND[main.kind]
      : bandColor(bandForDow(dow));
    onSave({
      hours: Math.max(0, Number(horas) || 0),
      minutes: Math.min(59, Math.max(0, Number(minutos) || 0)),
      noturno,
      note,
      dot: entry?.dot ?? dot,
      savedAt: Date.now(),
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      <div
        className="backdrop-fade absolute inset-0 bg-black/65 backdrop-blur-[2px]"
        onClick={onClose}
      />
      <div className="sheet-panel relative max-h-[94vh] w-full max-w-[480px] overflow-y-auto rounded-t-[2rem] border-t border-slate-600/40 bg-[#0c1426] px-6 pb-9 pt-3 shadow-2xl no-scrollbar">
        <div className="mx-auto mb-5 h-1.5 w-24 rounded-full bg-slate-600/70" />

        <button
          type="button"
          onClick={onClose}
          className="absolute right-6 top-6 flex h-14 w-14 items-center justify-center rounded-2xl border border-slate-500/30 bg-slate-800/70 text-slate-300 active:scale-95"
          aria-label="fechar"
        >
          <X className="h-6 w-6" />
        </button>

        <p className="text-lg font-bold uppercase tracking-[0.14em] text-indigo-400">
          Anotações das horas extras
        </p>
        <h3 className="mt-2 text-4xl font-extrabold tracking-tight text-white">
          {String(d).padStart(2, "0")}/{String(m + 1).padStart(2, "0")}/{y}
        </h3>
        <p className="mt-1 flex flex-wrap items-center gap-x-2 text-xl text-slate-400">
          <span>{SEMANA_LONGA[dow]}</span>
          <span className="text-slate-600">·</span>
          <span>
            adicional{" "}
            <span
              className={cn(
                "num font-semibold",
                meta ? meta.text : "text-slate-300"
              )}
            >
              +{auto.pct}%
            </span>
          </span>
        </p>

        {/* feriado detectado automaticamente */}
        {meta && main && (
          <div
            className={cn(
              "mt-5 border-l-4 py-1 pl-4",
              meta.border
            )}
          >
            <span
              className={cn(
                "text-base font-extrabold uppercase tracking-wider",
                meta.text
              )}
            >
              {meta.label}
            </span>
            <p className="mt-0.5 text-2xl font-bold text-white">{main.name}</p>
            {auto.holiday && hasManualHours && (
              <p className="mt-1 flex items-center gap-1.5 text-base font-semibold text-emerald-400">
                <BadgeCheck className="h-4 w-4" />
                Reconhecido no cálculo: horas extras com adicional de +
                {auto.pct}%
              </p>
            )}
            {auto.holiday && !hasManualHours && (
              <p className="mt-1 text-sm font-semibold uppercase tracking-wide text-slate-500">
                Aguardando lançamento manual de horas
              </p>
            )}
            {!auto.holiday && (
              <p className="mt-1 text-sm font-semibold uppercase tracking-wide text-slate-500">
                Este dia não recebe adicional de feriado
              </p>
            )}
          </div>
        )}

        {/* Ponto Biométrico Registrado no Dia (Requisitos 3, 4 e 8) */}
        {pontoBio && (pontoBio.entrada || pontoBio.saida) && (
          <div className="mt-5 rounded-2xl border border-cyan-500/40 bg-gradient-to-br from-cyan-950/40 via-slate-900/90 to-slate-950 p-4 shadow-lg">
            <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2 mb-3">
              <div className="flex items-center gap-2">
                <Fingerprint className="h-5 w-5 text-cyan-400" />
                <span className="text-sm font-bold text-white">Ponto Biométrico Registrado</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-semibold text-cyan-300">
                  {pontoBio.origem === "manual" ? "Manual ✏️" : "Biometria Oficial ✓"}
                </span>
                <button
                  type="button"
                  id="btn-daysheet-zerar"
                  onClick={handleZerarPonto}
                  className="rounded-lg border border-rose-500/40 bg-rose-950/40 px-2 py-0.5 text-[11px] font-bold text-rose-300 hover:bg-rose-900/60 active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  title="Apagar registros de ponto deste dia (Lixeira)"
                >
                  <Trash2 className="h-3 w-3 text-rose-400" />
                  <span>Apagar</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex items-center justify-between rounded-xl bg-slate-950/80 px-3 py-2 border border-slate-800">
                <span className="text-slate-300 font-semibold">Entrada</span>
                <span className="font-mono text-sm font-bold text-emerald-400">
                  {pontoBio.entrada ? `— ${pontoBio.entrada}` : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-slate-950/80 px-3 py-2 border border-slate-800">
                <span className="text-slate-300 font-semibold">Intervalo</span>
                <span className="font-mono text-sm font-bold text-amber-400">
                  {pontoBio.inicioIntervalo ? `— ${pontoBio.inicioIntervalo}` : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-slate-950/80 px-3 py-2 border border-slate-800">
                <span className="text-slate-300 font-semibold">Retorno</span>
                <span className="font-mono text-sm font-bold text-cyan-400">
                  {pontoBio.retornoIntervalo ? `— ${pontoBio.retornoIntervalo}` : "—"}
                </span>
              </div>
              <div className="flex items-center justify-between rounded-xl bg-slate-950/80 px-3 py-2 border border-slate-800">
                <span className="text-slate-300 font-semibold">Saída</span>
                <span className="font-mono text-sm font-bold text-rose-400">
                  {pontoBio.saida ? `— ${pontoBio.saida}` : "—"}
                </span>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
              <span className="text-slate-300">
                Subtotal trabalhado: <strong className="text-white font-mono text-sm">{workedBio.workedFormatted}</strong>
              </span>
              <span className="text-slate-400">
                Saldo extra CLT: <strong className={workedBio.overtimeMinutes > 0 ? "text-emerald-400 font-mono text-sm" : "text-slate-400 font-mono"}>{workedBio.overtimeFormatted}</strong>
              </span>
            </div>

            {/* Alimentação automática da aba abaixo e do mês */}
            {workedBio.workedMinutes > 0 && (
              <div className="mt-3 space-y-2">
                <div className="flex items-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-2 text-xs font-semibold text-emerald-300">
                  <BadgeCheck className="h-4 w-4 shrink-0 text-emerald-400" />
                  <span>
                    Subtotal de {workedBio.workedFormatted} alimenta os campos abaixo e o Lançamento (+{auto.pct}%).
                  </span>
                </div>

                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      const h = Math.floor(workedBio.workedMinutes / 60);
                      const m = workedBio.workedMinutes % 60;
                      setHoras(String(h));
                      setMinutos(String(m));
                    }}
                    className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 rounded-xl bg-cyan-600/30 hover:bg-cyan-600/50 border border-cyan-400/50 py-2 px-2.5 text-xs font-bold text-cyan-200 transition active:scale-95 shadow"
                  >
                    <Sparkles className="h-3.5 w-3.5 text-cyan-300" />
                    <span>Usar Subtotal ({workedBio.workedFormatted})</span>
                  </button>

                  {workedBio.overtimeMinutes > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        const h = Math.floor(workedBio.overtimeMinutes / 60);
                        const m = workedBio.overtimeMinutes % 60;
                        setHoras(String(h));
                        setMinutos(String(m));
                      }}
                      className="flex-1 min-w-[140px] flex items-center justify-center gap-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-400/50 py-2 px-2.5 text-xs font-bold text-indigo-200 transition active:scale-95 shadow"
                    >
                      <Sparkles className="h-3.5 w-3.5 text-indigo-300" />
                      <span>Usar Saldo Extra ({workedBio.overtimeFormatted})</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* horas / minutos */}
        <div className="mt-7 grid grid-cols-[1fr_auto_1fr] items-end gap-3">
          <div>
            <label className="mb-2 block text-lg font-bold uppercase tracking-wide text-slate-400">
              Horas
            </label>
            <div className="field flex h-16 items-center px-4">
              <input
                autoFocus
                inputMode="numeric"
                value={horas}
                onChange={(e) => setHoras(e.target.value.replace(/\D/g, ""))}
                placeholder="Horas"
                className="w-full bg-transparent text-2xl font-semibold text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>
          <span className="pb-4 text-3xl font-light text-slate-500">:</span>
          <div>
            <label className="mb-2 block text-right text-lg font-bold uppercase tracking-wide text-slate-400">
              Minutos
            </label>
            <div className="field flex h-16 items-center px-4">
              <input
                inputMode="numeric"
                value={minutos}
                onChange={(e) => {
                  const clean = e.target.value.replace(/\D/g, "");
                  setMinutos(clean === "" ? "" : String(Math.min(59, Number(clean))));
                }}
                placeholder="0-59"
                className="num w-full bg-transparent text-right text-2xl font-semibold text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* noturno */}
        <button
          type="button"
          onClick={() => setNoturno((v) => !v)}
          className={cn(
            "mt-4 flex w-full items-center gap-3 rounded-2xl border px-5 py-4 text-left text-xl font-semibold transition",
            noturno
              ? "border-indigo-400/60 bg-indigo-500/15 text-indigo-200"
              : "border-slate-500/30 bg-[#18243c] text-slate-400"
          )}
        >
          <Moon className="h-6 w-6" />
          <span className="flex-1">Noturno (22h–5h)</span>
          <span className="text-xl font-bold">+{settings.noturnoPct}%</span>
        </button>

        {/* observação tipo bloco de notas multilinha */}
        <div className="mt-4">
          <NotepadObservationField
            value={note}
            onChange={setNote}
            placeholder="Digite anotações ou detalhes adicionais (ex: Finalização da produção, plantão emergencial...)"
            label="Observação"
            optionalText="(opcional)"
            theme="indigo"
          />
        </div>

        {/* ações */}
        <div className="mt-7 flex gap-3">
          <button
            type="button"
            onClick={save}
            className="h-16 flex-1 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 text-2xl font-extrabold text-white shadow-lg shadow-indigo-900/50 transition active:scale-[0.98]"
          >
            Salvar
          </button>
          {exists && (
            <button
              type="button"
              onClick={onDelete}
              className="flex h-16 w-32 items-center justify-center gap-2 rounded-2xl border border-rose-500/50 bg-rose-500/5 text-2xl font-bold text-rose-400 transition active:scale-[0.98]"
            >
              <Trash2 className="h-5 w-5" />
              Apagar
            </button>
          )}
        </div>

        <div className="mt-4 flex items-center justify-center gap-2 text-slate-500">
          <span
            className={cn(
              "h-2.5 w-2.5 rounded-full",
              DOT_CLASS[main ? DOT_BY_KIND[main.kind] : bandColor(bandForDow(dow))]
            )}
          />
          <span className="text-sm">
            {main
              ? `${meta?.label || "Feriado"} — adicional +${auto?.pct ?? 100}%`
              : `Lançamento com adicional de +${auto?.pct ?? 60}%`}
          </span>
        </div>
      </div>
    </div>
  );
}
