import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  Crosshair,
  Loader2,
  MapPin,
  Search,
  X,
} from "lucide-react";
import {
  UFS,
  detectCurrentPlace,
  fetchMunicipios,
  isValidUF,
  matchesQuery,
  norm,
  prefetchMunicipios,
  ufName,
  type Municipio,
} from "../lib/locations";
import { cn } from "../utils/cn";

export type PickerMode = "state" | "city";

const PRO_BTN =
  "inline-flex items-center gap-1.5 rounded-md bg-gradient-to-br from-amber-300 via-amber-400 to-amber-500 px-2.5 py-[5px] text-[13px] font-black uppercase tracking-[0.08em] text-amber-950 shadow-[0_0_12px_rgba(251,191,36,0.45)] ring-1 ring-amber-200/70 transition active:scale-95";

export function LocationButton({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
}) {
  return (
    <button type="button" onClick={onClick} aria-label={label} className={PRO_BTN}>
      <span className="max-w-[130px] truncate">{children}</span>
      <ChevronDown className="h-4 w-4 shrink-0" strokeWidth={3} />
    </button>
  );
}

export default function LocationPicker({
  initial,
  uf,
  city,
  onSelect,
  onClose,
}: {
  initial: PickerMode;
  uf: string;
  city: string;
  onSelect: (nextUf: string, nextCity: string) => void;
  onClose: () => void;
}) {
  const [step, setStep] = useState<"uf" | "city">(initial === "state" ? "uf" : "city");
  const [browseUf, setBrowseUf] = useState(uf.toUpperCase());
  const [query, setQuery] = useState("");
  const [cities, setCities] = useState<Municipio[]>([]);
  const [loadingCities, setLoadingCities] = useState(false);
  const [citiesError, setCitiesError] = useState<string | null>(null);
  const [geoState, setGeoState] = useState<"idle" | "loading" | "error">("idle");
  const [geoMsg, setGeoMsg] = useState<string | null>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    prefetchMunicipios(uf.toUpperCase());
  }, [uf]);

  useEffect(() => {
    searchRef.current?.focus();
  }, [step]);

  // carrega municípios da UF em navegação
  useEffect(() => {
    if (step !== "city") return;
    let cancelled = false;
    setLoadingCities(true);
    setCitiesError(null);
    fetchMunicipios(browseUf)
      .then((list) => {
        if (!cancelled) setCities(list);
      })
      .catch(() => {
        if (!cancelled) {
          setCities([]);
          setCitiesError("Sem conexão para carregar a lista completa. Verifique a internet.");
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingCities(false);
      });
    return () => {
      cancelled = true;
    };
  }, [step, browseUf]);

  const filteredUfs = useMemo(() => {
    const q = query.trim();
    if (!q) return UFS;
    return UFS.filter(
      (u) => matchesQuery(u.nome, q) || matchesQuery(u.sigla, q)
    );
  }, [query]);

  const filteredCities = useMemo(() => {
    const q = query.trim();
    if (!q) return cities;
    return cities.filter((c) => matchesQuery(c.nome, q));
  }, [cities, query]);

  const useCurrentLocation = async () => {
    setGeoState("loading");
    setGeoMsg(null);
    try {
      const place = await detectCurrentPlace();
      const list = await fetchMunicipios(place.uf);
      const found = list.find((m) => norm(m.nome) === norm(place.city));
      setBrowseUf(place.uf);
      setCities(list);
      onSelect(place.uf, found?.nome ?? place.city);
    } catch (err) {
      setGeoState("error");
      setGeoMsg(
        err instanceof Error
          ? err.message
          : "Não foi possível identificar sua cidade. Escolha manualmente abaixo."
      );
    } finally {
      setGeoState((s) => (s === "loading" ? "idle" : s));
    }
  };

  const pickUf = (sigla: string) => {
    setBrowseUf(sigla);
    setQuery("");
    setStep("city");
  };

  const pickCity = (nome: string) => {
    onSelect(browseUf, nome);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center">
      <div
        className="backdrop-fade absolute inset-0 bg-black/70 backdrop-blur-[2px]"
        onClick={onClose}
      />
      <div className="sheet-panel relative flex max-h-[92vh] w-full max-w-[480px] flex-col overflow-hidden rounded-t-[2rem] border-t border-slate-600/40 bg-[#0c1426] px-5 pb-6 pt-3 shadow-2xl">
        <div className="mx-auto mb-4 h-1.5 w-24 shrink-0 rounded-full bg-slate-600/70" />

        <button
          type="button"
          onClick={onClose}
          className="absolute right-5 top-5 flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-500/30 bg-slate-800/70 text-slate-300 active:scale-95"
          aria-label="fechar seleção"
        >
          <X className="h-5 w-5" />
        </button>

        <p className="flex items-center gap-2 text-base font-bold uppercase tracking-[0.14em] text-indigo-400">
          <MapPin className="h-4 w-4" />
          Local de utilização
        </p>
        <h3 className="mt-1.5 pr-14 text-3xl font-extrabold tracking-tight text-white">
          {step === "uf" ? "Escolha o estado" : `Município · ${browseUf}`}
        </h3>
        <p className="mt-1 text-lg text-slate-400">
          {step === "uf"
            ? "Estado → Município · digite para filtrar"
            : `${ufName(browseUf)} · somente municípios deste estado`}
        </p>

        {/* atalho: localização atual (opcional) */}
        <button
          type="button"
          onClick={useCurrentLocation}
          disabled={geoState === "loading"}
          className="mt-4 flex w-full items-center gap-3 rounded-2xl border border-emerald-400/40 bg-emerald-500/10 px-4 py-3.5 text-left transition active:scale-[0.99] disabled:opacity-70"
        >
          {geoState === "loading" ? (
            <Loader2 className="h-5 w-5 shrink-0 animate-spin text-emerald-300" />
          ) : (
            <Crosshair className="h-5 w-5 shrink-0 text-emerald-300" />
          )}
          <span className="flex-1">
            <span className="block text-lg font-bold text-emerald-200">
              {geoState === "loading"
                ? "Detectando localização (GPS/Rede)…"
                : "Usar minha localização atual (GPS)"}
            </span>
            <span className="block text-sm text-emerald-200/70">
              Detecção inteligente de Cidade e Estado (GPS do aparelho ou rede)
            </span>
          </span>
        </button>
        {geoMsg && <p className="mt-2 text-base text-rose-400">{geoMsg}</p>}

        {/* pesquisa inteligente */}
        <div className="field mt-3 flex h-14 shrink-0 items-center gap-3 px-4">
          <Search className="h-5 w-5 shrink-0 text-slate-500" />
          <input
            ref={searchRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={step === "uf" ? "Digite o estado ou a sigla… (ex.: mina, SP)" : "Digite parte do nome da cidade…"}
            className="w-full bg-transparent text-xl text-white placeholder-slate-500 outline-none"
          />
          {query && (
            <button type="button" onClick={() => setQuery("")} aria-label="limpar pesquisa">
              <X className="h-5 w-5 text-slate-500" />
            </button>
          )}
        </div>

        {step === "city" && (
          <button
            type="button"
            onClick={() => {
              setStep("uf");
              setQuery("");
            }}
            className="mt-3 flex shrink-0 items-center gap-2 self-start rounded-xl border border-slate-500/30 bg-slate-800/60 px-3.5 py-2 text-base font-bold text-slate-300 active:scale-95"
          >
            <ArrowLeft className="h-4 w-4" />
            Trocar estado ({browseUf})
          </button>
        )}

        {/* lista */}
        <div className="no-scrollbar mt-3 min-h-0 flex-1 overflow-y-auto pb-1">
          {step === "uf" ? (
            filteredUfs.length === 0 ? (
              <p className="px-1 py-6 text-center text-lg text-slate-500">
                Nenhum estado encontrado para “{query}”.
              </p>
            ) : (
              <ul className="space-y-2">
                {filteredUfs.map((u) => (
                  <li key={u.sigla}>
                    <button
                      type="button"
                      onClick={() => pickUf(u.sigla)}
                      onMouseEnter={() => prefetchMunicipios(u.sigla)}
                      onFocus={() => prefetchMunicipios(u.sigla)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-2xl border px-4 py-3.5 text-left transition active:scale-[0.99]",
                        browseUf === u.sigla && u.sigla === uf.toUpperCase()
                          ? "border-amber-400/60 bg-amber-500/10"
                          : "border-white/[0.07] bg-white/[0.03] hover:bg-white/[0.06]"
                      )}
                    >
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-300 via-amber-400 to-amber-500 text-base font-black text-amber-950 ring-1 ring-amber-200/70">
                        {u.sigla}
                      </span>
                      <span className="flex-1 text-xl font-semibold text-white">{u.nome}</span>
                      {u.sigla === uf.toUpperCase() && (
                        <Check className="h-5 w-5 shrink-0 text-amber-300" />
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            )
          ) : loadingCities ? (
            <div className="flex items-center justify-center gap-3 py-10 text-lg text-slate-400">
              <Loader2 className="h-6 w-6 animate-spin" />
              Carregando municípios de {browseUf}…
            </div>
          ) : citiesError && cities.length === 0 ? (
            <p className="px-1 py-6 text-center text-lg text-slate-500">{citiesError}</p>
          ) : filteredCities.length === 0 ? (
            <p className="px-1 py-6 text-center text-lg text-slate-500">
              Nenhum município de {browseUf} encontrado para “{query}”.
            </p>
          ) : (
            <ul className="space-y-2">
              {filteredCities.map((c) => {
                const active =
                  browseUf === uf.toUpperCase() && norm(c.nome) === norm(city);
                return (
                  <li key={`${c.id}-${c.nome}`}>
                    <button
                      type="button"
                      onClick={() => pickCity(c.nome)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-2xl border px-4 py-3 text-left transition active:scale-[0.99]",
                        active
                          ? "border-amber-400/60 bg-amber-500/10"
                          : "border-white/[0.07] bg-white/[0.03] hover:bg-white/[0.06]"
                      )}
                    >
                      <MapPin
                        className={cn(
                          "h-5 w-5 shrink-0",
                          active ? "text-amber-300" : "text-slate-500"
                        )}
                      />
                      <span className="flex-1 truncate text-xl font-semibold text-white">
                        {c.nome}
                      </span>
                      {active && <Check className="h-5 w-5 shrink-0 text-amber-300" />}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>

        <p className="mt-3 shrink-0 text-center text-sm text-slate-500">
          Base IBGE completa · {step === "uf" ? "27 estados" : `${cities.length || "…"} municípios de ${browseUf}`}
        </p>
      </div>
    </div>
  );
}

export { isValidUF };
