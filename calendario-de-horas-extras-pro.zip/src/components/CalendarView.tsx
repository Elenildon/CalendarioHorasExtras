import { useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Crosshair,
  Info,
  Loader2,
  MapPin,
  Fingerprint,
} from "lucide-react";
import LocationPicker, { type PickerMode } from "./LocationPicker";
import DetailedCalculationCard from "./DetailedCalculationCard";
import {
  MESES,
  SEMANA_CURTA,
  dateKey,
  daysInMonth,
  entryHours,
  holidaysOn,
  dayPercent,
  fmtBRL,
  fmtH,
  horaBase,
  computeMonth,
  KIND_META,
  DOT_CLASS,
  type DayEntry,
  type HolidayKind,
  type Settings,
} from "../lib/calc";
import { detectCurrentPlace, ufName } from "../lib/locations";
import {
  getAllPontoBiometricos,
  calculateWorkedAndOvertime,
  type PontoBiometrico,
} from "../lib/pontoStorage";
import { useLiveDay } from "../lib/dayRollover";
import { cn } from "../utils/cn";

function hoursLabel(e?: DayEntry, ponto?: PontoBiometrico) {
  const h = Number(e?.hours) || 0;
  const m = Number(e?.minutes) || 0;
  if (h > 0 || m > 0) {
    return `${h}h${String(m).padStart(2, "0")}`;
  }
  if (ponto && (ponto.entrada || ponto.saida)) {
    const calc = calculateWorkedAndOvertime(ponto);
    if (calc.workedMinutes > 0) {
      const ph = Math.floor(calc.workedMinutes / 60);
      const pm = calc.workedMinutes % 60;
      return `${ph}h${String(pm).padStart(2, "0")}`;
    }
  }
  return null;
}

const LEGEND: HolidayKind[] = ["nacional", "estadual", "municipal", "facultativo"];

export default function CalendarView({
  year,
  month,
  entries,
  settings,
  onUpdateSettings,
  onChangeMonth,
  onToday,
  onSelect,
  onBackToPanel,
}: {
  year: number;
  month: number;
  entries: Record<string, DayEntry>;
  settings: Settings;
  onUpdateSettings: (patch: Partial<Settings>) => void;
  onChangeMonth: (y: number, m: number) => void;
  onToday: () => void;
  onSelect: (y: number, m: number, d: number) => void;
  onBackToPanel?: () => void;
}) {
  const [picker, setPicker] = useState<PickerMode | null>(null);

  // Fecha o seletor de localização se comando de voltar for acionado
  useEffect(() => {
    const handleBackNav = (e: Event) => {
      if (picker) {
        e.preventDefault();
        setPicker(null);
      }
    };
    window.addEventListener("che:back-navigation", handleBackNav);
    return () => {
      window.removeEventListener("che:back-navigation", handleBackNav);
    };
  }, [picker]);
  const [locationExpanded, setLocationExpanded] = useState(false);
  const [launchesExpanded, setLaunchesExpanded] = useState(false);
  const [geoLoading, setGeoLoading] = useState(false);
  const [geoMsg, setGeoMsg] = useState<string | null>(null);

  // Mapeamento de registros do Ponto Biométrico (Requisito 3 e 16)
  const [pontoMap, setPontoMap] = useState<Record<string, PontoBiometrico>>(() =>
    getAllPontoBiometricos()
  );

  useEffect(() => {
    const handler = () => {
      setPontoMap(getAllPontoBiometricos());
    };
    window.addEventListener("che:ponto-updated", handler);
    window.addEventListener("storage", handler);
    return () => {
      window.removeEventListener("che:ponto-updated", handler);
      window.removeEventListener("storage", handler);
    };
  }, []);

  const loc = {
    state: (settings?.state || "SP").toUpperCase(),
    city: settings?.city || "",
  };

  const calendarStats = useMemo(() => {
    return computeMonth(entries, year, month, settings);
  }, [entries, year, month, settings]);

  // Hook reativo de data em tempo real com virada automática de dia
  const liveDay = useLiveDay();
  const firstDow = new Date(year, month, 1).getDay();
  const total = daysInMonth(year, month);
  const cells: Array<number | null> = [
    ...Array(firstDow).fill(null),
    ...Array.from({ length: total }, (_, i) => i + 1),
  ];
  while (cells.length % 7 !== 0) cells.push(null);

  // Primeira vez na função Calendário: obriga a selecionar Estado e Cidade primeiro!
  useEffect(() => {
    try {
      const setupDone = localStorage.getItem("che.calendar-location-setup-done");
      if (!setupDone) {
        setPicker("state");
      }
    } catch {
      // safe fallback
    }
  }, []);

  const handleGpsDetect = async () => {
    setGeoLoading(true);
    setGeoMsg(null);
    try {
      const place = await detectCurrentPlace();
      onUpdateSettings({ state: place.uf.toUpperCase(), city: place.city });
      try {
        localStorage.setItem("che.calendar-location-setup-done", "true");
      } catch {
        // safe fallback
      }
      const metodo = place.method === "gps" ? "GPS" : "Rede";
      setGeoMsg(`✓ Detectado (${metodo}): ${place.city} (${place.uf})`);
      setTimeout(() => setGeoMsg(null), 5000);
    } catch (err) {
      setGeoMsg(
        err instanceof Error
          ? err.message
          : "Não foi possível identificar sua cidade. Escolha na lista."
      );
      setTimeout(() => setGeoMsg(null), 5000);
    } finally {
      setGeoLoading(false);
    }
  };

  const isToday = (d: number) =>
    liveDay.year === year &&
    liveDay.month === month &&
    liveDay.day === d;

  // Lançamentos do mês automaticamente contabilizados por faixa de adicional e valores em R$
  const monthTotals = (() => {
    let h60 = 0;
    let h75 = 0;
    let h100 = 0;
    let val60 = 0;
    let val75 = 0;
    let val100 = 0;
    let count = 0;

    const vHora = horaBase(settings.salary, settings.jornada);
    const rate = (pct: number, noturno: boolean) => {
      let r = vHora * (1 + pct / 100);
      if (noturno && (settings.noturnoEnabled || noturno)) {
        r *= 1 + (settings.noturnoPct || 20) / 100;
      }
      return r;
    };

    for (let d = 1; d <= total; d += 1) {
      const k = dateKey(year, month, d);
      const e = entries[k];
      const p = pontoMap[k];

      let h = e ? entryHours(e) : 0;
      if (h <= 0 && p && (p.entrada || p.saida)) {
        const calc = calculateWorkedAndOvertime(p);
        if (calc.workedMinutes > 0) {
          h = calc.workedMinutes / 60;
        }
      }
      if (h <= 0) continue;
      count += 1;
      const dow = new Date(year, month, d).getDay();
      const pct = dayPercent(k, dow, settings).pct;
      const val = h * rate(pct, !!e?.noturno);

      if (pct >= 100) {
        h100 += h;
        val100 += val;
      } else if (pct >= 75) {
        h75 += h;
        val75 += val;
      } else {
        h60 += h;
        val60 += val;
      }
    }
    return {
      h60,
      h75,
      h100,
      val60,
      val75,
      val100,
      total: h60 + h75 + h100,
      totalVal: val60 + val75 + val100,
      count,
    };
  })();

  const launchRows = [
    { label: "Extras 60%", hours: monthTotals.h60, value: monthTotals.val60, color: "text-indigo-300" },
    { label: "Extras 75%", hours: monthTotals.h75, value: monthTotals.val75, color: "text-amber-300" },
    { label: "Extras 100%", hours: monthTotals.h100, value: monthTotals.val100, color: "text-rose-300" },
  ];

  return (
    <div className="px-4 pb-6 pt-2">
      {/* Botão de Navegação Rápida: Voltar ao Painel principal */}
      {onBackToPanel && (
        <div className="mb-3 flex items-center justify-between">
          <button
            type="button"
            onClick={onBackToPanel}
            className="inline-flex items-center gap-2 rounded-xl border border-slate-700/80 bg-slate-800/90 px-3.5 py-2 text-sm font-bold text-slate-200 shadow-md transition hover:bg-slate-700 active:scale-95 cursor-pointer"
            title="Voltar ao Painel principal"
          >
            <ArrowLeft className="h-4 w-4 text-cyan-400" />
            <span>Voltar ao Painel principal</span>
          </button>
          <span className="text-[11px] font-medium text-slate-400">
            Voltar no celular ou teclado
          </span>
        </div>
      )}

      {/* ============================================================ */}
      {/* 1º EM CIMA: Função Local de utilização do calendário          */}
      {/* ============================================================ */}
      {!locationExpanded ? (
        /* ABA MINIMIZADA (abre com um clique - TÍTULO DIAGRAMADO EM DESTAQUE E SEM CORTES) */
        <div
          id="card-localizacao-calendario-min"
          role="button"
          tabIndex={0}
          onClick={() => setLocationExpanded(true)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              setLocationExpanded(true);
            }
          }}
          className="group mb-3.5 flex cursor-pointer flex-col gap-2.5 rounded-2xl border border-amber-500/35 bg-gradient-to-r from-slate-900/95 via-slate-900/90 to-amber-950/25 p-3.5 shadow-xl shadow-black/30 backdrop-blur-sm transition-all duration-200 hover:border-amber-400/60 hover:bg-slate-900 active:scale-[0.99] sm:p-4"
          title="Clique para abrir e alterar o Local de utilização do calendário"
        >
          {/* Linha superior 1: Eyebrow badge contextual + Ações de GPS e Alterar */}
          <div className="flex items-center justify-between gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-400/10 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-amber-300 ring-1 ring-amber-400/25">
              <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
              Regionalização & Feriados
            </span>

            {/* Ação rápida de abrir ou detectar GPS */}
            <div className="flex shrink-0 items-center gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleGpsDetect();
                }}
                disabled={geoLoading}
                title="Detectar cidade atual via GPS"
                className="inline-flex items-center gap-1.5 rounded-xl border border-emerald-400/40 bg-emerald-500/15 px-2.5 py-1 text-xs font-bold text-emerald-300 transition hover:bg-emerald-500/25 active:scale-95 disabled:opacity-60 cursor-pointer shadow-sm"
              >
                {geoLoading ? (
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <Crosshair className="h-3.5 w-3.5 text-emerald-300" />
                )}
                <span>{geoLoading ? "Buscando..." : "GPS"}</span>
              </button>

              <div className="flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/15 px-2.5 py-1 text-xs font-bold text-amber-200 transition-all group-hover:border-amber-400/60 group-hover:bg-amber-500/25 group-hover:text-yellow-200 shadow-sm">
                <span>Alterar</span>
                <ChevronDown className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-y-0.5" />
              </div>
            </div>
          </div>

          {/* Linha 2: TÍTULO DIAGRAMADO EM DESTAQUE - INTEIRO E SEM CORTES */}
          <div className="flex items-center gap-3 py-1">
            <div className="flex h-10 w-10 sm:h-11 sm:w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-amber-400/30 via-amber-500/20 to-yellow-500/10 text-amber-300 ring-1 ring-amber-400/50 shadow-md shadow-amber-950/50 transition-transform group-hover:scale-105">
              <MapPin className="h-5 w-5 sm:h-6 sm:w-6 text-amber-300" />
            </div>

            <div className="flex-1 min-w-0">
              <h2
                id="nome-local-utilizacao-calendario"
                className="text-base sm:text-lg md:text-xl font-black tracking-tight text-amber-300 drop-shadow-sm leading-snug break-words"
              >
                Local de utilização do calendário
              </h2>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Feriados nacionais, estaduais e municipais automáticos pelo IBGE
              </p>
            </div>
          </div>

          {/* Linha inferior: Localização ativa, badges informativos */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.08] pt-2 sm:pt-2.5">
            <div className="flex min-w-0 items-center gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-lg border border-amber-400/30 bg-amber-400/10 px-2.5 py-1 text-xs font-black text-white shadow-sm sm:text-sm">
                <span className="h-2 w-2 rounded-full bg-emerald-400 ring-2 ring-emerald-500/40" />
                <span className="font-extrabold text-amber-300">{loc.state}</span>
                <span className="text-slate-400">·</span>
                <span className="truncate max-w-[150px] text-white sm:max-w-[240px]">
                  {loc.city || "Selecionar cidade"}
                </span>
              </span>
              <span className="hidden text-xs text-slate-400 sm:inline">
                ({ufName(loc.state)})
              </span>
            </div>

            {geoMsg ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-extrabold text-emerald-300 ring-1 ring-emerald-500/40 animate-in fade-in">
                {geoMsg}
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/15 px-2.5 py-0.5 text-[10px] font-extrabold text-emerald-400 ring-1 ring-emerald-500/30 sm:text-[11px]">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                Feriados ativos
              </span>
            )}
          </div>
        </div>
      ) : (
        /* ABA EXPANDIDA (TÍTULO DIAGRAMADO EM DESTAQUE E SEM CORTES) */
        <div
          id="card-localizacao-calendario-expanded"
          className="mb-3.5 space-y-4 rounded-2xl border border-amber-500/35 bg-slate-900/95 p-4 shadow-xl shadow-black/40 backdrop-blur-sm sm:p-5"
        >
          {/* Topo diagramado com título em forma grande, cor amarela moderna e botão Minimizar */}
          <div className="flex flex-col gap-2.5 pb-2 border-b border-amber-500/20">
            {/* Linha superior: Badge e botão Minimizar */}
            <div className="flex items-center justify-between gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-md bg-amber-400/10 px-2.5 py-0.5 text-[10px] font-black uppercase tracking-wider text-amber-300 ring-1 ring-amber-400/25">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-400 animate-pulse" />
                Configuração Regional & Feriados Oficiais
              </span>

              {/* Botão Minimizar com ChevronUp */}
              <button
                type="button"
                onClick={() => setLocationExpanded(false)}
                className="flex shrink-0 items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/15 px-3 py-1.5 text-xs font-bold text-amber-200 transition hover:border-amber-400/50 hover:bg-amber-500/25 hover:text-yellow-200 active:scale-95 cursor-pointer shadow-sm"
                title="Minimizar aba"
              >
                <span>Minimizar</span>
                <ChevronUp className="h-4 w-4" />
              </button>
            </div>

            {/* Bloco do Título diagramado em destaque - sem cortes */}
            <div className="flex items-center gap-3 sm:gap-3.5 pt-0.5">
              <div className="flex h-11 w-11 sm:h-12 sm:w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400/30 via-amber-500/20 to-yellow-500/10 text-amber-300 ring-1 ring-amber-400/50 shadow-lg shadow-amber-950/60">
                <MapPin className="h-6 w-6 text-amber-300" />
              </div>
              <div className="flex-1 min-w-0">
                <h2
                  id="nome-local-utilizacao-calendario-expanded"
                  className="text-lg sm:text-xl md:text-2xl font-black tracking-tight text-amber-300 drop-shadow-md leading-tight break-words"
                >
                  Local de utilização do calendário
                </h2>
                <p className="text-xs text-slate-300 mt-1">
                  Selecione seu Estado e Município para cálculo automático dos feriados pelo IBGE.
                </p>
              </div>
            </div>
          </div>

          {/* Grade diagramada com Estado e Cidade */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {/* Box Estado */}
            <div className="flex flex-col justify-between rounded-xl border border-white/10 bg-slate-950/50 p-3.5">
              <div>
                <span className="text-[11px] font-black uppercase tracking-[0.14em] text-slate-400">
                  Estado (UF)
                </span>
                <div className="mt-1.5 flex items-center gap-2">
                  <span className="inline-flex items-center justify-center rounded-lg bg-indigo-500/25 px-2.5 py-1 text-sm font-black text-indigo-300 ring-1 ring-indigo-500/40">
                    {loc.state}
                  </span>
                  <span className="truncate text-sm font-bold text-white">
                    {ufName(loc.state)}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPicker("state")}
                className="mt-3.5 inline-flex items-center justify-center gap-1.5 rounded-xl border border-indigo-400/40 bg-indigo-600/30 px-3 py-2 text-xs font-bold text-indigo-200 transition hover:bg-indigo-600/50 hover:text-white active:scale-95"
              >
                <span>Alterar Estado</span>
                <ChevronDown className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Box Cidade */}
            <div className="flex flex-col justify-between rounded-xl border border-white/10 bg-slate-950/50 p-3.5">
              <div>
                <span className="text-[11px] font-black uppercase tracking-[0.14em] text-slate-400">
                  Município / Cidade
                </span>
                <div className="mt-1.5 flex items-center gap-2">
                  <span className="truncate text-sm font-extrabold text-white sm:text-base">
                    {loc.city || "Nenhuma cidade selecionada"}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPicker("city")}
                className="mt-3.5 inline-flex items-center justify-center gap-1.5 rounded-xl border border-amber-400/40 bg-amber-500/20 px-3 py-2 text-xs font-bold text-amber-200 transition hover:bg-amber-500/30 hover:text-white active:scale-95"
              >
                <span>Alterar Cidade</span>
                <ChevronDown className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          {/* Atalho de GPS inteligente */}
          <div className="flex flex-wrap items-center justify-between gap-2.5 rounded-xl border border-emerald-500/20 bg-emerald-950/20 p-3">
            <button
              type="button"
              onClick={handleGpsDetect}
              disabled={geoLoading}
              className="inline-flex items-center gap-2 rounded-xl border border-emerald-400/40 bg-emerald-500/20 px-3.5 py-2 text-xs font-bold text-emerald-200 transition hover:bg-emerald-500/30 active:scale-95 disabled:opacity-60 shadow-sm"
            >
              {geoLoading ? (
                <Loader2 className="h-4 w-4 animate-spin text-emerald-300" />
              ) : (
                <Crosshair className="h-4 w-4 text-emerald-300" />
              )}
              <span>
                {geoLoading
                  ? "Detectando cidade atual (GPS/Rede)…"
                  : "Detectar cidade atual (GPS)"}
              </span>
            </button>

            {geoMsg ? (
              <span className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-400/30 bg-emerald-500/20 px-3 py-1 text-xs font-bold text-emerald-200 shadow-sm animate-in fade-in">
                {geoMsg}
              </span>
            ) : (
              <span className="text-[11px] text-emerald-300/70">
                Detecta automaticamente via GPS do aparelho ou rede IP
              </span>
            )}
          </div>

          {/* Resumo inteligente com botão de fechar */}
          <div className="flex flex-col justify-between gap-3 rounded-xl border border-indigo-400/20 bg-indigo-500/10 p-3.5 sm:flex-row sm:items-center">
            <div className="flex items-start gap-2.5">
              <Info className="mt-0.5 h-4 w-4 shrink-0 text-indigo-300" />
              <span className="text-xs leading-relaxed text-indigo-200">
                O calendário está aplicando os feriados de{" "}
                <strong>{ufName(loc.state)}</strong> e{" "}
                <strong>{loc.city || "seu município"}</strong> com base completa do IBGE.
              </span>
            </div>

            <button
              type="button"
              onClick={() => setLocationExpanded(false)}
              className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2 text-xs font-extrabold text-white shadow-md transition hover:from-indigo-500 hover:to-violet-500 active:scale-95"
            >
              <Check className="h-4 w-4" />
              <span>Concluir e Minimizar</span>
            </button>
          </div>
        </div>
      )}

      <div className="rounded-[1.8rem] border border-white/10 bg-slate-950/35 p-4 shadow-2xl shadow-indigo-950/40 backdrop-blur-sm sm:p-5">
        {/* cabeçalho do mês */}
        <div className="mb-4 grid grid-cols-[3.2rem_1fr_3.2rem] items-center gap-2">
          <button
            type="button"
            onClick={() =>
              onChangeMonth(month === 0 ? year - 1 : year, (month + 11) % 12)
            }
            className="flex h-16 w-16 items-center justify-center rounded-2xl border border-slate-400/20 bg-slate-900/60 text-slate-200 active:scale-95"
            aria-label="mês anterior"
          >
            <ChevronLeft className="h-7 w-7" />
          </button>
          <div className="text-center">
            <h2 className="text-[2.2rem] font-extrabold leading-tight tracking-tight text-white">
              {MESES[month]} {year}
            </h2>
            <div className="flex items-center justify-center gap-2 flex-wrap mt-1">
              <button
                type="button"
                onClick={onToday}
                className="text-base font-bold tracking-[0.18em] text-indigo-300 hover:text-indigo-200 transition active:scale-95 cursor-pointer"
              >
                IR PARA HOJE
              </button>
              <span
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-sm"
                title="Calendário atualizado automaticamente dia após dia"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Hoje: {liveDay.formattedBR}</span>
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={() =>
              onChangeMonth(month === 11 ? year + 1 : year, (month + 1) % 12)
            }
            className="flex h-16 w-16 items-center justify-center rounded-2xl border border-slate-400/20 bg-slate-900/60 text-slate-200 active:scale-95"
            aria-label="próximo mês"
          >
            <ChevronRight className="h-7 w-7" />
          </button>
        </div>

        {/* legenda diagramada em uma só linha: Nacional, MG, Extrema, Facultativo */}
        <div
          id="legenda-feriados-calendario"
          className="mb-3.5 grid grid-cols-4 gap-1.5 sm:gap-2 w-full"
        >
          {LEGEND.map((k) => {
            const label =
              k === "nacional"
                ? "Nacional"
                : k === "estadual"
                ? loc.state || "MG"
                : k === "municipal"
                ? loc.city || "Extrema"
                : "Facultativo";

            return (
              <div
                key={k}
                title={`Legenda: ${label}`}
                className={cn(
                  "flex items-center justify-center gap-1 sm:gap-1.5 rounded-full border px-1.5 sm:px-2.5 py-1 text-[10px] sm:text-[11px] md:text-xs font-black uppercase tracking-wider whitespace-nowrap overflow-hidden transition-all shadow-sm",
                  KIND_META[k].chip
                )}
              >
                <span className={cn("h-1.5 w-1.5 sm:h-2 sm:w-2 shrink-0 rounded-full", KIND_META[k].dot)} />
                <span className="truncate">{label}</span>
              </div>
            );
          })}
        </div>

        {/* dias da semana */}
        <div className="mb-2 grid grid-cols-7 gap-2">
          {SEMANA_CURTA.map((w) => (
            <div
              key={w}
              className="py-2 text-center text-lg font-bold tracking-wide text-slate-500"
            >
              {w}
            </div>
          ))}
        </div>

        {/* grade de dias */}
        <div className="grid grid-cols-7 gap-2">
          {cells.map((d, i) => {
            if (d === null)
              return <div key={`e-${i}`} className="min-h-[104px]" />;
            const k = dateKey(year, month, d);
            const e = entries[k];
            const hols = holidaysOn(k, loc);
            const main = hols.find((h) => h.kind !== "facultativo") ?? hols[0];
            const ponto = pontoMap[k];
            const hl = hoursLabel(e, ponto);
            const hasData = Boolean(
              (e && (entryHours(e) > 0 || (e.note ?? "").trim() !== "")) ||
              (ponto && (ponto.entrada || ponto.saida))
            );
            const meta = main ? KIND_META[main.kind] : null;

            return (
              <button
                type="button"
                key={k}
                onClick={() => {
                  try {
                    onSelect(year, month, d);
                  } catch (err) {
                    console.error("Erro ao selecionar dia:", err);
                  }
                }}
                title={main ? main.name : undefined}
                className={cn(
                  "relative flex min-h-[104px] flex-col items-start justify-between rounded-2xl border p-2 text-left transition active:scale-[0.97]",
                  meta
                    ? meta.cell
                    : "border-white/[0.07] bg-white/[0.035] hover:bg-white/[0.06]",
                  isToday(d) &&
                    "border-indigo-400/80 bg-indigo-500/20 shadow-[inset_0_0_18px_rgba(99,102,241,0.25)] ring-1 ring-indigo-400/60"
                )}
              >
                <div className="flex w-full items-center justify-between">
                  <span
                    className={cn(
                      "text-xl font-semibold",
                      meta ? meta.text : "text-slate-200"
                    )}
                  >
                    {d}
                  </span>
                  <div className="flex items-center gap-1">
                    {isToday(d) && (
                      <span className="rounded bg-indigo-500/30 px-1 py-0.2 text-[9px] font-black text-indigo-300 uppercase tracking-tight">
                        Hoje
                      </span>
                    )}
                    {ponto && (
                      <span title="Possui registro de ponto biométrico">
                        <Fingerprint className="h-3.5 w-3.5 text-cyan-400" />
                      </span>
                    )}
                  </div>
                </div>

                {meta && (
                  <span
                    className={cn(
                      "mt-0.5 line-clamp-2 text-[9px] font-bold uppercase leading-tight tracking-tight",
                      meta.soft
                    )}
                  >
                    {main?.kind === "municipal"
                      ? "Municipal"
                      : main?.kind === "estadual"
                      ? "Estadual"
                      : main?.kind === "facultativo"
                      ? "Facultativo"
                      : "Nacional"}
                  </span>
                )}

                {/* Exibição dos Horários do Ponto Biométrico no Dia (Requisito 3 e 16) */}
                {ponto && (ponto.entrada || ponto.saida) && (
                  <div className="my-1 flex w-full flex-col gap-0.5 rounded-lg bg-cyan-950/80 border border-cyan-500/40 p-1 text-[8px] font-mono leading-tight text-cyan-200">
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-300 font-bold">E: {ponto.entrada || "--:--"}</span>
                      <span className="text-rose-300 font-bold">S: {ponto.saida || "--:--"}</span>
                    </div>
                    {(ponto.inicioIntervalo || ponto.retornoIntervalo) && (
                      <div className="flex items-center justify-between text-[7px] text-slate-400 border-t border-cyan-900/40 pt-0.5 mt-0.5">
                        <span>Int: {ponto.inicioIntervalo || "--:--"}</span>
                        <span>Ret: {ponto.retornoIntervalo || "--:--"}</span>
                      </div>
                    )}
                  </div>
                )}

                <div className="mt-auto flex w-full items-end justify-between gap-1">
                  {hl && (
                    <span className="num text-lg font-extrabold leading-none text-emerald-400">
                      {hl}
                    </span>
                  )}
                  <span className="ml-auto flex items-center gap-1">
                    {hasData && (
                      <span
                        className={cn(
                          "h-2.5 w-2.5 rounded-full",
                          (e?.dot && e.dot in DOT_CLASS) ? DOT_CLASS[e.dot] : DOT_CLASS.sky
                        )}
                      />
                    )}
                    {hols.map((h) => (
                      <span
                        key={h.kind + h.name}
                        className={cn(
                          "h-1.5 w-1.5 rounded-full opacity-90",
                          KIND_META[h.kind]?.dot ?? "bg-slate-400"
                        )}
                      />
                    ))}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* dica */}
        <p className="mt-4 flex items-start gap-2 px-1 text-sm leading-snug text-slate-500">
          <Info className="mt-0.5 h-4 w-4 shrink-0" />
          Feriados nacionais, estaduais ({loc.state}) e municipais de {loc.city || "seu município"} ficam
          destacados pelas cores da legenda. Números e horas só aparecem
          depois de um lançamento manual; o calendário permanece intacto.
        </p>
      </div>

      {/* lançamentos do mês — contabilidade automática por faixa com valores em R$ */}
      {!launchesExpanded ? (
        /* ABA MINIMIZADA (abre com um clique) */
        <div
          id="card-lancamentos-mes-min"
          role="button"
          tabIndex={0}
          onClick={() => setLaunchesExpanded(true)}
          onKeyDown={(e) => {
            if (e.key === "Enter" || e.key === " ") {
              e.preventDefault();
              setLaunchesExpanded(true);
            }
          }}
          className="group mt-4 flex cursor-pointer items-center justify-between gap-3 rounded-2xl border border-white/10 bg-slate-900/85 p-3.5 shadow-lg shadow-black/25 backdrop-blur-sm transition-all duration-200 hover:border-indigo-400/40 hover:bg-slate-900 active:scale-[0.99] sm:p-4"
          title={`Clique para abrir os Lançamentos de ${MESES[month]}`}
        >
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500/20 to-violet-600/20 text-indigo-300 ring-1 ring-indigo-400/30">
              <span className="num text-sm font-black text-indigo-200">
                {monthTotals.count > 0 ? String(monthTotals.count).padStart(2, "0") : "—"}
              </span>
            </div>

            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-extrabold text-white truncate sm:text-base">
                  Lançamentos de {MESES[month]}
                </h3>
                <span className="rounded-full border border-indigo-400/30 bg-indigo-500/10 px-2 py-0.5 text-[10px] font-bold text-indigo-200 sm:text-xs">
                  {monthTotals.count > 0 ? `${monthTotals.count} ${monthTotals.count === 1 ? "dia" : "dias"}` : "Nenhum lançamento neste mês"}
                </span>
              </div>

              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs sm:text-sm">
                {monthTotals.count > 0 ? (
                  <>
                    <span className="num font-bold text-slate-300">
                      Total: <strong className="text-white">{fmtH(monthTotals.total)}</strong>
                    </span>
                    <span className="text-slate-500">·</span>
                    <span className="num font-black text-emerald-400">
                      {fmtBRL(monthTotals.totalVal)}
                    </span>
                  </>
                ) : (
                  <span className="text-xs text-slate-400">
                    Nenhum registro ainda · Toque em um dia no calendário para lançar
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-2">
            <span className="hidden text-xs font-bold text-slate-300 transition-colors group-hover:text-indigo-200 sm:inline">
              Abrir
            </span>
            <div className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-700/60 bg-slate-800/60 text-slate-300 transition-all group-hover:border-indigo-400/50 group-hover:bg-indigo-600/30 group-hover:text-white">
              <ChevronDown className="h-4 w-4 transition-transform duration-200 group-hover:translate-y-0.5" />
            </div>
          </div>
        </div>
      ) : (
        /* ABA EXPANDIDA */
        <div id="card-lancamentos-mes-expanded" className="card mt-4 p-4 sm:p-5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-extrabold text-white sm:text-xl">
                Lançamentos de {MESES[month]}
              </h3>
              <span className="rounded-full border border-indigo-400/30 bg-indigo-500/10 px-2.5 py-0.5 text-xs font-bold text-indigo-200">
                {monthTotals.count} {monthTotals.count === 1 ? "dia" : "dias"}
              </span>
            </div>

            <button
              type="button"
              onClick={() => setLaunchesExpanded(false)}
              className="flex shrink-0 items-center gap-1.5 rounded-xl border border-slate-700/60 bg-slate-800/70 px-3 py-1.5 text-xs font-bold text-slate-300 transition hover:bg-slate-700/70 hover:text-white active:scale-95"
              title="Minimizar aba"
            >
              <span>Minimizar</span>
              <ChevronUp className="h-4 w-4" />
            </button>
          </div>

          <ul className="mt-4 space-y-2.5">
            {launchRows.map((row) => (
              <li
                key={row.label}
                className="flex items-center justify-between gap-2.5 rounded-xl border border-white/[0.07] bg-white/[0.03] px-3.5 py-3 sm:px-4"
              >
                <span className={cn("text-base font-bold sm:text-lg", row.color)}>
                  {row.label}
                </span>
                <div className="flex items-center gap-2 sm:gap-3">
                  <span className="num text-base font-extrabold text-white sm:text-lg">
                    {fmtH(row.hours)}
                  </span>
                  <span className="inline-flex min-w-[76px] items-center justify-end rounded-lg border border-white/[0.08] bg-slate-900/60 px-2.5 py-1 num text-xs font-black text-emerald-400 shadow-sm sm:text-sm md:text-base">
                    {fmtBRL(row.value)}
                  </span>
                </div>
              </li>
            ))}
          </ul>

          <div className="mt-3 flex items-center justify-between gap-2.5 rounded-xl border border-emerald-400/30 bg-emerald-500/10 px-3.5 py-3.5 sm:px-4">
            <span className="text-base font-extrabold text-emerald-300 sm:text-lg">
              Total do mês
            </span>
            <div className="flex items-center gap-2 sm:gap-3">
              <span className="num text-lg font-bold text-emerald-200 sm:text-2xl">
                {fmtH(monthTotals.total)}
              </span>
              <span className="inline-flex min-w-[88px] items-center justify-end rounded-xl border border-emerald-400/40 bg-emerald-500/20 px-3 py-1 num text-base font-black text-emerald-300 shadow-sm sm:text-xl">
                {fmtBRL(monthTotals.totalVal)}
              </span>
            </div>
          </div>

          <p className="mt-3 text-sm leading-snug text-slate-500">
            Atualizado automaticamente: cada lançamento feito no calendário é
            somado na faixa correta com horas e valor exato em R$.
          </p>
        </div>
      )}

      {/* Cálculo Detalhado do Mês */}
      <DetailedCalculationCard
        month={month}
        year={year}
        settings={settings}
        stats={calendarStats}
        onUpdateSettings={onUpdateSettings}
        defaultExpanded={false}
        className="mt-4"
        sourceLabel={`Apontamentos e ponto biométrico de ${MESES[month]}/${year}`}
      />

      {picker && (
        <LocationPicker
          initial={picker}
          uf={loc.state}
          city={loc.city}
          onClose={() => setPicker(null)}
          onSelect={(nextUf, nextCity) => {
            onUpdateSettings({ state: nextUf.toUpperCase(), city: nextCity });
            try {
              localStorage.setItem("che.calendar-location-setup-done", "true");
            } catch {
              // safe fallback
            }
            setPicker(null);
            setLocationExpanded(false);
          }}
        />
      )}
    </div>
  );
}
