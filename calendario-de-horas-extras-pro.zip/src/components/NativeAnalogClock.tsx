import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { Clock } from "lucide-react";
import { cn } from "../utils/cn";

export interface NativeAnalogClockProps {
  value: string; // Formato "HH:MM", ex: "08:00"
  onChange: (timeString: string, hours: number, minutes: number) => void;
  accentColor?: "emerald" | "amber" | "cyan" | "rose" | "indigo";
  className?: string;
}

type PickerMode = "hours" | "minutes";

const OUTER_HOURS = [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
const INNER_HOURS = [0, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23];
const MINUTE_NUMBERS = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];

const CLOCK_RADIUS = 120; // 240px de diâmetro (otimizado para caber em qualquer celular)
const OUTER_RADIUS = 88;  // Anel externo
const INNER_RADIUS = 56;  // Anel interno (13h-23h e 00h)

function parseTime(val: string): { h: number; m: number } {
  if (val && typeof val === "string" && val.includes(":")) {
    const parts = val.trim().split(":");
    const h = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    if (!isNaN(h) && !isNaN(m)) {
      return {
        h: Math.min(23, Math.max(0, h)),
        m: Math.min(59, Math.max(0, m)),
      };
    }
  }
  return { h: 8, m: 0 };
}

export const NativeAnalogClock: React.FC<NativeAnalogClockProps> = ({
  value,
  onChange,
  accentColor = "amber",
  className,
}) => {
  const [mode, setMode] = useState<PickerMode>("hours");
  const { h: initialH, m: initialM } = useMemo(() => parseTime(value), [value]);

  const [selectedHour, setSelectedHour] = useState<number>(initialH);
  const [selectedMinute, setSelectedMinute] = useState<number>(initialM);
  const [isDragging, setIsDragging] = useState(false);
  const clockRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const p = parseTime(value);
    setSelectedHour(p.h);
    setSelectedMinute(p.m);
  }, [value]);

  const emitChange = useCallback(
    (h: number, m: number) => {
      const formatted = `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
      onChange(formatted, h, m);
    },
    [onChange]
  );

  const formattedHour = String(selectedHour).padStart(2, "0");
  const formattedMinute = String(selectedMinute).padStart(2, "0");
  const isInnerHour = selectedHour === 0 || (selectedHour >= 13 && selectedHour <= 23);

  const pointerAngle = useMemo(() => {
    if (mode === "hours") {
      const baseHour = selectedHour % 12;
      return baseHour * 30;
    }
    return selectedMinute * 6;
  }, [mode, selectedHour, selectedMinute]);

  const pointerRadius = useMemo(() => {
    if (mode === "hours") {
      return isInnerHour ? INNER_RADIUS : OUTER_RADIUS;
    }
    return OUTER_RADIUS;
  }, [mode, isInnerHour]);

  const colorStyles = useMemo(() => {
    switch (accentColor) {
      case "emerald":
        return {
          ring: "ring-emerald-400/50 border-emerald-400",
          bgActive: "bg-emerald-500/20 text-emerald-300",
          text: "text-emerald-400",
          pointerBg: "bg-emerald-400",
          pointerGrad: "from-emerald-400/50 to-emerald-300",
          selectedBadge: "bg-emerald-500 text-slate-950 font-black",
        };
      case "cyan":
        return {
          ring: "ring-cyan-400/50 border-cyan-400",
          bgActive: "bg-cyan-500/20 text-cyan-300",
          text: "text-cyan-400",
          pointerBg: "bg-cyan-400",
          pointerGrad: "from-cyan-400/50 to-cyan-300",
          selectedBadge: "bg-cyan-400 text-slate-950 font-black",
        };
      case "rose":
        return {
          ring: "ring-rose-400/50 border-rose-400",
          bgActive: "bg-rose-500/20 text-rose-300",
          text: "text-rose-400",
          pointerBg: "bg-rose-400",
          pointerGrad: "from-rose-400/50 to-rose-300",
          selectedBadge: "bg-rose-400 text-slate-950 font-black",
        };
      case "indigo":
        return {
          ring: "ring-indigo-400/50 border-indigo-400",
          bgActive: "bg-indigo-500/20 text-indigo-300",
          text: "text-indigo-400",
          pointerBg: "bg-indigo-400",
          pointerGrad: "from-indigo-400/50 to-indigo-300",
          selectedBadge: "bg-indigo-400 text-slate-950 font-black",
        };
      case "amber":
      default:
        return {
          ring: "ring-amber-400/50 border-amber-400",
          bgActive: "bg-amber-500/20 text-amber-300",
          text: "text-amber-400",
          pointerBg: "bg-amber-400",
          pointerGrad: "from-amber-400/50 to-amber-300",
          selectedBadge: "bg-amber-400 text-slate-950 font-black",
        };
    }
  }, [accentColor]);

  const handlePointerCalculation = useCallback(
    (clientX: number, clientY: number, autoAdvance = false) => {
      if (!clockRef.current) return;
      const rect = clockRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const dx = clientX - centerX;
      const dy = clientY - centerY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      let angle = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
      if (angle < 0) angle += 360;

      if (mode === "hours") {
        const hourIndex = Math.round(angle / 30) % 12;
        const isInner = dist < 72;

        let hourVal: number;
        if (isInner) {
          hourVal = hourIndex === 0 ? 0 : hourIndex + 12;
        } else {
          hourVal = hourIndex === 0 ? 12 : hourIndex;
        }

        setSelectedHour(hourVal);
        emitChange(hourVal, selectedMinute);

        if (autoAdvance) {
          setTimeout(() => setMode("minutes"), 180);
        }
      } else {
        const minuteVal = Math.round(angle / 6) % 60;
        setSelectedMinute(minuteVal);
        emitChange(selectedHour, minuteVal);
      }
    },
    [mode, selectedHour, selectedMinute, emitChange]
  );

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    handlePointerCalculation(e.clientX, e.clientY, true);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    handlePointerCalculation(e.clientX, e.clientY, false);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      setIsDragging(true);
      handlePointerCalculation(e.touches[0].clientX, e.touches[0].clientY, true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isDragging || e.touches.length !== 1) return;
    handlePointerCalculation(e.touches[0].clientX, e.touches[0].clientY, false);
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // Ajustes rápidos (+15, -15, Agora)
  const adjustMinutes = (delta: number) => {
    let total = selectedHour * 60 + selectedMinute + delta;
    if (total < 0) total += 24 * 60;
    total = total % (24 * 60);
    const newH = Math.floor(total / 60);
    const newM = total % 60;
    setSelectedHour(newH);
    setSelectedMinute(newM);
    emitChange(newH, newM);
  };

  const setNow = () => {
    const d = new Date();
    const newH = d.getHours();
    const newM = d.getMinutes();
    setSelectedHour(newH);
    setSelectedMinute(newM);
    emitChange(newH, newM);
  };

  return (
    <div className={cn("flex flex-col items-center select-none py-1", className)}>
      {/* Topo do Relógio: Mostrador Digital e Alternância Horas/Minutos */}
      <div className="flex items-center justify-center gap-2 mb-2">
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-slate-950/90 border border-slate-800 shadow-inner">
          <button
            type="button"
            onClick={() => setMode("hours")}
            className={cn(
              "px-3 py-1 rounded-xl font-mono text-2xl sm:text-3xl font-black transition cursor-pointer border",
              mode === "hours"
                ? `${colorStyles.bgActive} ${colorStyles.ring} shadow-sm`
                : "bg-transparent text-slate-400 border-transparent hover:text-slate-200"
            )}
            title="Alternar para seleção de horas (formato 24h)"
          >
            {formattedHour}
          </button>

          <span className="text-xl sm:text-2xl font-mono font-bold text-slate-400 animate-pulse">
            :
          </span>

          <button
            type="button"
            onClick={() => setMode("minutes")}
            className={cn(
              "px-3 py-1 rounded-xl font-mono text-2xl sm:text-3xl font-black transition cursor-pointer border",
              mode === "minutes"
                ? `${colorStyles.bgActive} ${colorStyles.ring} shadow-sm`
                : "bg-transparent text-slate-400 border-transparent hover:text-slate-200"
            )}
            title="Alternar para seleção de minutos (00 a 59)"
          >
            {formattedMinute}
          </button>
        </div>

        <div className="flex flex-col gap-1">
          <button
            type="button"
            onClick={() => setMode(mode === "hours" ? "minutes" : "hours")}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl border border-slate-700 bg-slate-800 text-[11px] font-bold text-slate-300 hover:bg-slate-700 active:scale-95 transition cursor-pointer"
          >
            <Clock className="h-3 w-3" />
            <span>{mode === "hours" ? "Mudar p/ Minutos" : "Mudar p/ Horas"}</span>
          </button>

          <button
            type="button"
            onClick={setNow}
            className="px-2.5 py-1 rounded-xl border border-slate-700/80 bg-slate-900 text-[10px] font-bold text-amber-300 hover:bg-slate-800 active:scale-95 transition cursor-pointer text-center"
            title="Definir horário atual"
          >
            Hora Atual
          </button>
        </div>
      </div>

      <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5 mb-2">
        <span className="px-2 py-0.5 rounded-md text-[10px] font-bold uppercase bg-slate-800/80 border border-slate-700 text-slate-300">
          {mode === "hours" ? "Relógio 24h (Horas)" : "Relógio (Minutos)"}
        </span>
        <span>·</span>
        <span className="text-slate-300">
          {mode === "hours" ? "Toque nas horas (00–23)" : "Toque nos minutos (00–59)"}
        </span>
      </div>

      {/* O Mostrador do Relógio Analógico Circular Nativo (Clock Face) */}
      <div
        ref={clockRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        className="relative select-none touch-none rounded-full border-2 border-slate-700/80 bg-slate-950 p-2 shadow-2xl shadow-black/80 transition-colors cursor-pointer"
        style={{
          width: `${CLOCK_RADIUS * 2}px`,
          height: `${CLOCK_RADIUS * 2}px`,
        }}
      >
        {/* Anel Guia / Marcação Estilizada */}
        <div className="absolute inset-2 rounded-full border border-slate-800 pointer-events-none" />
        {mode === "hours" && (
          <div className="absolute inset-14 rounded-full border border-slate-800/50 pointer-events-none" />
        )}

        {/* Pino Central */}
        <div
          className={cn(
            "absolute left-1/2 top-1/2 -ml-2 -mt-2 h-4 w-4 rounded-full shadow-md z-20 pointer-events-none border border-slate-950",
            colorStyles.pointerBg
          )}
        />

        {/* Ponteiro Analógico (Hand) */}
        <div
          className="absolute left-1/2 top-1/2 z-10 origin-bottom pointer-events-none transition-transform duration-75"
          style={{
            width: "2px",
            height: `${pointerRadius}px`,
            transform: `translate(-50%, -100%) rotate(${pointerAngle}deg)`,
          }}
        >
          {/* Haste do ponteiro */}
          <div className={cn("h-full w-full bg-gradient-to-t", colorStyles.pointerGrad)} />
          {/* Esfera indicadora na ponta do ponteiro */}
          <div
            className={cn(
              "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full border-2 border-white/70 backdrop-blur-sm shadow-md",
              mode === "hours" && isInnerHour ? "h-5 w-5 -top-2.5" : "h-6 w-6 -top-3",
              colorStyles.pointerBg
            )}
          />
        </div>

        {/* MODO HORAS (24h com dois anéis concêntricos) */}
        {mode === "hours" && (
          <>
            {/* Anel Externo: 12, 1, 2, ..., 11 */}
            {OUTER_HOURS.map((h, i) => {
              const angleRad = ((i * 30 - 90) * Math.PI) / 180;
              const x = CLOCK_RADIUS + OUTER_RADIUS * Math.cos(angleRad);
              const y = CLOCK_RADIUS + OUTER_RADIUS * Math.sin(angleRad);
              const isSelected = selectedHour === h;

              return (
                <button
                  key={`outer-${h}`}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedHour(h);
                    emitChange(h, selectedMinute);
                    setTimeout(() => setMode("minutes"), 180);
                  }}
                  className={cn(
                    "absolute flex h-6 w-6 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-mono text-xs font-bold transition-all z-20 cursor-pointer",
                    isSelected
                      ? colorStyles.selectedBadge
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  )}
                  style={{ left: `${x}px`, top: `${y}px` }}
                >
                  {h}
                </button>
              );
            })}

            {/* Anel Interno: 00, 13, 14, ..., 23 */}
            {INNER_HOURS.map((h, i) => {
              const angleRad = ((i * 30 - 90) * Math.PI) / 180;
              const x = CLOCK_RADIUS + INNER_RADIUS * Math.cos(angleRad);
              const y = CLOCK_RADIUS + INNER_RADIUS * Math.sin(angleRad);
              const isSelected = selectedHour === h;

              return (
                <button
                  key={`inner-${h}`}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedHour(h);
                    emitChange(h, selectedMinute);
                    setTimeout(() => setMode("minutes"), 180);
                  }}
                  className={cn(
                    "absolute flex h-5 w-5 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-mono text-[10px] font-bold transition-all z-20 cursor-pointer",
                    isSelected
                      ? colorStyles.selectedBadge
                      : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
                  )}
                  style={{ left: `${x}px`, top: `${y}px` }}
                >
                  {String(h).padStart(2, "0")}
                </button>
              );
            })}
          </>
        )}

        {/* MODO MINUTOS (Mostrador de 0 a 59 em intervalos de 5) */}
        {mode === "minutes" && (
          <>
            {MINUTE_NUMBERS.map((m, i) => {
              const angleRad = ((i * 30 - 90) * Math.PI) / 180;
              const x = CLOCK_RADIUS + OUTER_RADIUS * Math.cos(angleRad);
              const y = CLOCK_RADIUS + OUTER_RADIUS * Math.sin(angleRad);
              const isSelected = selectedMinute === m;

              return (
                <button
                  key={`minute-${m}`}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedMinute(m);
                    emitChange(selectedHour, m);
                  }}
                  className={cn(
                    "absolute flex h-6 w-6 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-mono text-xs font-bold transition-all z-20 cursor-pointer",
                    isSelected
                      ? colorStyles.selectedBadge
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  )}
                  style={{ left: `${x}px`, top: `${y}px` }}
                >
                  {String(m).padStart(2, "0")}
                </button>
              );
            })}
          </>
        )}
      </div>

      {/* Ajustes Rápidos de Minutos */}
      <div className="flex items-center gap-1.5 mt-2.5 pt-1 border-t border-slate-800/80">
        <button
          type="button"
          onClick={() => adjustMinutes(-15)}
          className="px-2 py-0.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300 hover:bg-slate-700 active:scale-95 transition"
        >
          -15m
        </button>
        <button
          type="button"
          onClick={() => adjustMinutes(-5)}
          className="px-2 py-0.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300 hover:bg-slate-700 active:scale-95 transition"
        >
          -5m
        </button>
        <span className="font-mono text-xs font-black px-2 py-0.5 text-slate-200">
          {formattedHour}:{formattedMinute}
        </span>
        <button
          type="button"
          onClick={() => adjustMinutes(5)}
          className="px-2 py-0.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300 hover:bg-slate-700 active:scale-95 transition"
        >
          +5m
        </button>
        <button
          type="button"
          onClick={() => adjustMinutes(15)}
          className="px-2 py-0.5 rounded-lg bg-slate-800 text-[10px] font-bold text-slate-300 hover:bg-slate-700 active:scale-95 transition"
        >
          +15m
        </button>
      </div>
    </div>
  );
};
