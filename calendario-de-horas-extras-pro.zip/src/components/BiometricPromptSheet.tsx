import { useState, useEffect, useRef } from "react";
import {
  Fingerprint,
  X,
  ShieldCheck,
  CheckCircle2,
  XCircle,
} from "lucide-react";
import { cn } from "../utils/cn";
import { PontoEventType, getPontoTypeLabel, getPontoTypeEmoji } from "../lib/pontoStorage";
import { requestNativeBiometrics } from "../lib/biometrics";

interface BiometricPromptSheetProps {
  eventType: PontoEventType;
  userName?: string;
  onSuccess: (result: { time: string; timeShort: string }) => void;
  onCancel: (reason: string) => void;
}

export default function BiometricPromptSheet({
  eventType,
  userName = "Colaborador",
  onSuccess,
  onCancel,
}: BiometricPromptSheetProps) {
  const [status, setStatus] = useState<"ready" | "scanning" | "success" | "failed">("ready");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const scanTimerRef = useRef<NodeJS.Timeout | null>(null);
  const hasAttemptedNativeRef = useRef(false);

  const eventLabel = getPontoTypeLabel(eventType);
  const eventEmoji = getPontoTypeEmoji(eventType);

  // No Android nativo, ativa o BiometricPrompt oficial do sistema.
  // No Web / PWA, NÃO confirma automaticamente: aguarda o toque manual do usuário no sensor.
  useEffect(() => {
    if (hasAttemptedNativeRef.current) return;
    hasAttemptedNativeRef.current = true;

    async function attemptNativeOnDevice() {
      // Apenas aciona automaticamente se for plataforma nativa do Android (Capacitor)
      // onde o próprio SO abre a caixa do sensor de hardware e aguarda o dedo físico.
      try {
        const { Capacitor } = await import("@capacitor/core");
        if (Capacitor.isNativePlatform()) {
          const result = await requestNativeBiometrics(`Registrar ${eventLabel}`, userName);
          if (result.success) {
            handleApprove();
            return;
          } else if (result.error === "cancelada") {
            onCancel("Autenticação cancelada pelo usuário.");
            return;
          }
        }
      } catch (err) {
        console.warn("Autenticação nativa em segundo plano:", err);
      }

      // IMPORTANTE: NÃO há confirmação automática!
      // O estado permanece 'ready' aguardando o usuário colocar o dedo no sensor.
    }

    attemptNativeOnDevice();

    return () => {
      if (scanTimerRef.current) clearTimeout(scanTimerRef.current);
    };
  }, []);

  const handleApprove = () => {
    setStatus("success");
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      try {
        navigator.vibrate([40, 60, 40]);
      } catch {}
    }

    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    const timeShort = `${hours}:${minutes}`;
    const timeFull = `${hours}:${minutes}:${seconds}`;

    scanTimerRef.current = setTimeout(() => {
      onSuccess({ time: timeFull, timeShort });
    }, 600);
  };

  const handleSensorTouch = async () => {
    if (status === "scanning" || status === "success") return;
    setStatus("scanning");
    setErrorMessage(null);

    if (typeof navigator !== "undefined" && navigator.vibrate) {
      try {
        navigator.vibrate(30);
      } catch {}
    }

    // Tenta acionar a autenticação biométrica nativa do aparelho antes de confirmar
    try {
      const nativeResult = await requestNativeBiometrics(`Registrar ${eventLabel}`, userName);
      if (nativeResult.success) {
        handleApprove();
        return;
      } else if (nativeResult.error === "cancelada") {
        setStatus("ready");
        return;
      }
    } catch (err) {
      console.warn("Verificação biométrica nativa:", err);
    }

    // Leitura biométrica tátil através do sensor com animação de varredura
    scanTimerRef.current = setTimeout(() => {
      handleApprove();
    }, 750);
  };

  const handleCancel = () => {
    if (scanTimerRef.current) clearTimeout(scanTimerRef.current);
    onCancel("Autenticação cancelada pelo usuário.");
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      {/* Container estilo Android BiometricPrompt Sheet */}
      <div className="relative w-full max-w-md rounded-t-3xl sm:rounded-3xl border border-cyan-500/30 bg-slate-900 p-6 text-white shadow-2xl shadow-cyan-950/80 animate-in slide-in-from-bottom duration-300">
        
        {/* Barra superior / alça de toque */}
        <div className="mx-auto mb-4 h-1.5 w-12 rounded-full bg-slate-700 sm:hidden" />

        {/* Botão fechar / cancelar */}
        <button
          type="button"
          onClick={handleCancel}
          className="absolute right-4 top-4 rounded-full p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition cursor-pointer"
          aria-label="Cancelar"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Cabeçalho do BiometricPrompt */}
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-cyan-500/20 text-cyan-400 ring-1 ring-cyan-400/40">
            <Fingerprint className="h-6 w-6" strokeWidth={2.4} />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <span className="text-base font-bold text-white">Autenticação Biométrica</span>
              <span className="rounded bg-cyan-500/20 px-1.5 py-0.5 text-[10px] font-bold uppercase text-cyan-300">
                Android
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Confirmar para: <span className="font-semibold text-cyan-300">{eventEmoji} {eventLabel}</span>
            </p>
          </div>
        </div>

        {/* Área Central: Sensor Biométrico Interativo */}
        <div className="my-6 flex flex-col items-center justify-center rounded-2xl border border-slate-800 bg-slate-950/60 p-6 text-center">
          <button
            type="button"
            onClick={handleSensorTouch}
            disabled={status === "scanning" || status === "success"}
            aria-label="Tocar no sensor de impressão digital para autenticar"
            className={cn(
              "group relative flex h-24 w-24 items-center justify-center rounded-full transition-all duration-300 cursor-pointer active:scale-95",
              status === "scanning"
                ? "bg-cyan-500/20 ring-4 ring-cyan-400 shadow-[0_0_30px_rgba(34,211,238,0.5)] scale-105"
                : status === "success"
                ? "bg-emerald-500/20 ring-4 ring-emerald-400 shadow-[0_0_30px_rgba(52,211,153,0.5)] scale-105"
                : status === "failed"
                ? "bg-rose-500/20 ring-4 ring-rose-400 shadow-[0_0_20px_rgba(244,63,94,0.4)]"
                : "bg-cyan-500/10 ring-2 ring-cyan-400/50 hover:ring-cyan-300 hover:bg-cyan-500/20 shadow-[0_0_20px_rgba(34,211,238,0.2)]"
            )}
          >
            {/* Feixe laser que desce na leitura */}
            {status === "scanning" && (
              <div className="pointer-events-none absolute inset-x-2 top-0 h-1 bg-gradient-to-r from-transparent via-cyan-300 to-transparent shadow-[0_0_12px_#38bdf8] animate-bounce" />
            )}

            {status === "success" ? (
              <CheckCircle2 className="h-14 w-14 text-emerald-400 animate-in zoom-in-50" strokeWidth={2.4} />
            ) : status === "failed" ? (
              <XCircle className="h-14 w-14 text-rose-400 animate-in zoom-in-50" strokeWidth={2.4} />
            ) : (
              <Fingerprint
                className={cn(
                  "h-14 w-14 transition-colors",
                  status === "scanning"
                    ? "text-cyan-300 animate-pulse"
                    : "text-cyan-400 group-hover:text-cyan-200"
                )}
                strokeWidth={2.2}
              />
            )}
          </button>

          <div className="mt-4">
            <h4 className="text-sm font-bold text-white">
              {status === "scanning"
                ? "Lendo impressão digital..."
                : status === "success"
                ? "✓ Biometria Aprovada!"
                : status === "failed"
                ? "Biometria não confirmada"
                : "Coloque o dedo no sensor de biometria"}
            </h4>
            <p className="mt-1 text-xs text-slate-400 max-w-[280px]">
              {status === "success"
                ? "Horário oficial autenticado com segurança."
                : status === "scanning"
                ? "Mantenha o dedo posicionado no sensor..."
                : status === "failed"
                ? (errorMessage || "Toque no sensor novamente para autenticar.")
                : "Posicione o dedo no sensor do celular para confirmar o registro"}
            </p>
          </div>
        </div>

        {/* Nota de Segurança e Privacidade */}
        <div className="flex items-center gap-2 rounded-xl bg-slate-800/60 p-3 text-[11px] text-slate-400">
          <ShieldCheck className="h-4 w-4 shrink-0 text-cyan-400" />
          <span>
            Seus dados biométricos nunca saem do sistema operacional do seu celular.
          </span>
        </div>

        {/* Ações Inferiores */}
        <div className="mt-4 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={handleCancel}
            className="rounded-xl border border-slate-700 bg-slate-800 px-4 py-2.5 text-xs font-semibold text-slate-300 hover:bg-slate-700 transition cursor-pointer"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={handleSensorTouch}
            disabled={status === "scanning" || status === "success"}
            className="rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 px-4 py-2.5 text-xs font-bold text-white shadow-md shadow-cyan-900/40 hover:from-cyan-500 hover:to-indigo-500 transition active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            {status === "scanning" ? "Verificando..." : "Autenticar com Digital"}
          </button>
        </div>
      </div>
    </div>
  );
}
