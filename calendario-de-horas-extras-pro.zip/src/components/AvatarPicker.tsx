import { useMemo, useState, useRef } from "react";
import {
  Camera,
  Check,
  Image as ImageIcon,
  Shuffle,
  Trash2,
  Upload,
  UserRound,
  X,
} from "lucide-react";
import {
  AVATAR_FILTERS,
  AVATARS,
  filterAvatars,
  randomAvatarId,
  type AvatarFilter,
} from "../lib/avatars";
import { cn } from "../utils/cn";
import AvatarFace from "./AvatarFace";

// Amostras de fotos de perfil para teste rápido
const SAMPLE_PHOTOS = [
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80",
];

// Comprime imagem do usuário para armazenamento leve no localStorage e Firestore
export function compressImage(
  file: File,
  maxWidth = 360,
  maxHeight = 360,
  quality = 0.85
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = event.target?.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function AvatarPicker({
  selectedId,
  photoURL,
  onSelect,
  onSelectPhoto,
  onRemovePhoto,
  onClose,
}: {
  selectedId: string;
  photoURL?: string;
  onSelect: (id: string) => void;
  onSelectPhoto?: (url: string) => void;
  onRemovePhoto?: () => void;
  onClose: () => void;
}) {
  // Se já tiver foto pessoal, inicia direto no Modo Galeria; caso contrário, avatares
  const [tab, setTab] = useState<"galeria" | "avatares">(
    photoURL ? "galeria" : "galeria"
  );
  const [filter, setFilter] = useState<AvatarFilter>("todos");
  const [current, setCurrent] = useState(selectedId);
  const [previewPhoto, setPreviewPhoto] = useState<string | null>(photoURL || null);
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const list = useMemo(() => filterAvatars(AVATARS, filter), [filter]);

  const pickAvatar = (id: string) => {
    setCurrent(id);
    onSelect(id);
    // Se selecionou avatar ilustrado, remove foto pessoal para dar prioridade ao avatar
    if (onRemovePhoto && previewPhoto) {
      setPreviewPhoto(null);
      onRemovePhoto();
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };

  const processFile = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("Por favor, selecione um arquivo de imagem válido (PNG, JPEG, etc.).");
      return;
    }
    setIsProcessing(true);
    try {
      const compressed = await compressImage(file);
      setPreviewPhoto(compressed);
      if (onSelectPhoto) {
        onSelectPhoto(compressed);
      }
    } catch (err) {
      console.error("Erro ao carregar foto:", err);
      alert("Não foi possível processar a foto. Tente outra imagem.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processFile(file);
    }
  };

  const handleRemovePhoto = () => {
    setPreviewPhoto(null);
    if (onRemovePhoto) {
      onRemovePhoto();
    }
  };

  const handlePickSample = (url: string) => {
    setPreviewPhoto(url);
    if (onSelectPhoto) {
      onSelectPhoto(url);
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center">
      <div
        className="backdrop-fade absolute inset-0 bg-black/70 backdrop-blur-[2px]"
        onClick={onClose}
      />
      <div className="sheet-panel relative flex max-h-[92vh] w-full max-w-[480px] flex-col overflow-hidden rounded-t-[2rem] border-t border-slate-600/40 bg-[#0c1426] px-5 pb-7 pt-3 shadow-2xl">
        <div className="mx-auto mb-4 h-1.5 w-24 shrink-0 rounded-full bg-slate-600/70" />

        <button
          type="button"
          onClick={onClose}
          className="absolute right-5 top-5 flex h-12 w-12 items-center justify-center rounded-2xl border border-slate-500/30 bg-slate-800/70 text-slate-300 active:scale-95"
          aria-label="fechar avatares"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Cabeçalho */}
        <p className="flex items-center gap-2 text-base font-bold uppercase tracking-[0.14em] text-indigo-400">
          <Camera className="h-4 w-4" />
          Foto & Avatar
        </p>
        <h3 className="mt-1.5 pr-14 text-[1.6rem] font-extrabold leading-tight tracking-tight text-white">
          Personalize sua foto de perfil
        </h3>

        {/* Abas: Modo Galeria vs Avatares Ilustrados */}
        <div className="mt-4 grid grid-cols-2 gap-1.5 rounded-2xl bg-slate-800/70 p-1 border border-slate-700/60">
          <button
            type="button"
            onClick={() => setTab("galeria")}
            className={cn(
              "flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-black transition",
              tab === "galeria"
                ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow"
                : "text-slate-400 hover:text-white"
            )}
          >
            <ImageIcon className="h-4 w-4" />
            Modo Galeria
          </button>
          <button
            type="button"
            onClick={() => setTab("avatares")}
            className={cn(
              "flex items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-black transition",
              tab === "avatares"
                ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow"
                : "text-slate-400 hover:text-white"
            )}
          >
            <UserRound className="h-4 w-4" />
            Avatares Ilustrados
          </button>
        </div>

        {tab === "galeria" ? (
          /* Conteúdo do MODO GALERIA (Foto Pessoal) */
          <div className="no-scrollbar mt-4 min-h-0 flex-1 overflow-y-auto pb-2">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />

            {/* Foto Atual / Preview */}
            <div className="flex flex-col items-center justify-center py-3">
              <div className="relative">
                <div className="absolute -inset-2 rounded-full bg-gradient-to-r from-indigo-500 to-violet-600 opacity-75 blur-md" />
                <div className="relative flex h-32 w-32 items-center justify-center overflow-hidden rounded-full border-4 border-indigo-400/80 bg-slate-900 shadow-xl ring-4 ring-black/40">
                  {previewPhoto ? (
                    <img
                      src={previewPhoto}
                      alt="Foto de perfil pessoal"
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <div className="flex flex-col items-center justify-center text-slate-400 p-2 text-center">
                      <Camera className="h-9 w-9 text-indigo-400 mb-1" />
                      <span className="text-[11px] font-bold">Sem foto pessoal</span>
                    </div>
                  )}
                </div>

                {previewPhoto && (
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    title="Remover foto pessoal"
                    className="absolute bottom-0 right-0 flex h-9 w-9 items-center justify-center rounded-full bg-rose-600 text-white shadow-lg ring-2 ring-slate-900 transition hover:bg-rose-500 active:scale-95"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                )}
              </div>

              <p className="mt-3 text-sm font-semibold text-slate-300">
                {previewPhoto ? "Foto pessoal ativa" : "Nenhuma foto pessoal selecionada"}
              </p>
              <p className="text-xs text-slate-400 text-center max-w-xs mt-0.5">
                {previewPhoto
                  ? "Sua foto aparecerá no cabeçalho e em todo o aplicativo."
                  : "Carregue uma foto da sua galeria ou escolha da câmera."}
              </p>
            </div>

            {/* Área de Seleção / Upload da Galeria */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              className={cn(
                "mt-3 flex flex-col items-center justify-center rounded-2xl border-2 border-dashed p-5 text-center transition cursor-pointer",
                isDragging
                  ? "border-indigo-400 bg-indigo-500/20"
                  : "border-slate-700 bg-slate-800/40 hover:border-indigo-400/60 hover:bg-slate-800/70"
              )}
              onClick={() => fileInputRef.current?.click()}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 mb-2">
                <Upload className="h-6 w-6" />
              </div>
              <span className="text-sm font-black text-white">
                {isProcessing ? "Processando foto..." : "Escolher foto da Galeria"}
              </span>
              <span className="text-xs text-slate-400 mt-1">
                Toque para abrir a galeria do celular ou fotos do computador
              </span>
              <span className="mt-2.5 inline-flex items-center gap-1.5 rounded-xl bg-indigo-600 px-4 py-2 text-xs font-bold text-white shadow transition hover:bg-indigo-500">
                <Camera className="h-3.5 w-3.5" />
                {previewPhoto ? "Trocar Foto da Galeria" : "Abrir Galeria"}
              </span>
            </div>

            {/* Amostras Rápidas */}
            <div className="mt-4 pt-3 border-t border-slate-700/60">
              <span className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
                Ou teste com uma foto de exemplo:
              </span>
              <div className="grid grid-cols-4 gap-2">
                {SAMPLE_PHOTOS.map((url, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => handlePickSample(url)}
                    className={cn(
                      "relative aspect-square overflow-hidden rounded-xl border-2 transition active:scale-95",
                      previewPhoto === url
                        ? "border-indigo-400 ring-2 ring-indigo-400 shadow-lg"
                        : "border-transparent opacity-75 hover:opacity-100"
                    )}
                  >
                    <img
                      src={url}
                      alt={`Foto exemplo ${i + 1}`}
                      className="h-full w-full object-cover"
                    />
                    {previewPhoto === url && (
                      <span className="absolute right-1 top-1 flex h-5 w-5 items-center justify-center rounded-full bg-indigo-600 text-white">
                        <Check className="h-3 w-3" strokeWidth={3} />
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : (
          /* Conteúdo dos AVATARES ILUSTRADOS */
          <>
            <div className="no-scrollbar mt-4 flex shrink-0 gap-2 overflow-x-auto pb-1">
              {AVATAR_FILTERS.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setFilter(f.id)}
                  className={cn(
                    "shrink-0 rounded-full border px-3.5 py-2 text-sm font-bold transition active:scale-95",
                    filter === f.id
                      ? "border-violet-400 bg-violet-600 text-white"
                      : "border-slate-500/30 bg-slate-800/60 text-slate-300"
                  )}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="no-scrollbar mt-4 min-h-0 flex-1 overflow-y-auto pb-2">
              {list.length === 0 ? (
                <p className="py-10 text-center text-lg text-slate-500">
                  Nenhum avatar neste filtro.
                </p>
              ) : (
                <div className="grid grid-cols-4 gap-2.5">
                  {list.map((spec) => {
                    const active = !previewPhoto && current === spec.id;
                    return (
                      <button
                        key={spec.id}
                        type="button"
                        onClick={() => pickAvatar(spec.id)}
                        aria-pressed={active}
                        aria-label={`Avatar ${spec.id}`}
                        className={cn(
                          "relative aspect-square overflow-hidden rounded-2xl transition active:scale-95",
                          active ? "avatar-selected" : "ring-1 ring-white/10"
                        )}
                      >
                        <AvatarFace spec={spec} className="h-full w-full" />
                        {active && (
                          <span className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-violet-600 text-white shadow">
                            <Check className="h-4 w-4" strokeWidth={3} />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </>
        )}

        {/* Rodapé com Ações */}
        <div className="mt-4 flex shrink-0 gap-3">
          {tab === "avatares" && (
            <button
              type="button"
              onClick={() => pickAvatar(randomAvatarId(current))}
              className="avatar-shuffle flex h-14 flex-1 items-center justify-center gap-2 rounded-2xl border border-violet-400/40 bg-violet-600/20 text-lg font-extrabold text-violet-200 active:scale-[0.98]"
            >
              <Shuffle className="h-5 w-5" />
              Sortear
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="h-14 flex-1 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 text-lg font-extrabold text-white active:scale-[0.98]"
          >
            Pronto
          </button>
        </div>
      </div>
    </div>
  );
}
