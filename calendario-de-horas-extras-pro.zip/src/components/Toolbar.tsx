import { Fingerprint, LogOut, Menu, Moon, Share2, Sun } from "lucide-react";
import AvatarFace from "./AvatarFace";
import { getAvatar } from "../lib/avatars";
import iconUrl from "../assets/icon.png";

export default function Toolbar({
  initials,
  avatarId,
  photoURL,
  userPhotoURL,
  userLoggedIn,
  whiteMode,
  smartMode,
  onToggleSmart,
  onToggleColor,
  onLogout,
  onOpenAccount,
  onOpenShare,
  onOpenInstall,
  onOpenMenu,
  onOpenBiometria,
}: {
  initials: string;
  avatarId?: string;
  photoURL?: string;
  userPhotoURL?: string;
  userLoggedIn?: boolean;
  whiteMode: boolean;
  smartMode: boolean;
  onToggleSmart: () => void;
  onToggleColor: () => void;
  onLogout: () => void;
  onOpenAccount?: () => void;
  onOpenShare?: () => void;
  onOpenInstall?: (tab?: "auto" | "ios" | "android" | "qr") => void;
  onOpenMenu?: () => void;
  onOpenBiometria?: () => void;
}) {
  const avatar = getAvatar(avatarId);
  const displayPhoto = photoURL || userPhotoURL;

  return (
    <header className="px-3 pt-3 pb-1">
      <div className="relative overflow-hidden rounded-2xl border border-slate-700/60 bg-gradient-to-b from-slate-900/95 via-slate-900/90 to-[#080e1e]/95 p-3 sm:p-4 shadow-xl shadow-black/40 backdrop-blur-md">
        {/* Glow neon superior sutil */}
        <div className="pointer-events-none absolute -top-12 left-1/2 -translate-x-1/2 h-24 w-72 rounded-full bg-cyan-500/15 blur-2xl" />
        <div className="pointer-events-none absolute inset-x-0 top-0 h-[1px] bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent" />

        {/* Bloco: Marca e Nome do Aplicativo (Ícone de Ponto Biométrico no lado esquerdo do cabeçalho) */}
        <div className="relative flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            {/* Ícone Original do Ponto Biométrico (Preservado 100% Intacto) */}
            <button
              type="button"
              onClick={onOpenBiometria}
              aria-label="Abrir Ponto Biométrico"
              title="Ponto Biométrico"
              className="relative h-11 w-11 sm:h-12 sm:w-12 shrink-0 cursor-pointer overflow-hidden rounded-2xl transition active:scale-95 shadow-md shadow-black/40 hover:opacity-95"
            >
              <img
                src={iconUrl}
                alt="Ponto Biométrico"
                className="h-full w-full object-cover"
              />
            </button>

            {/* Nome do Aplicativo */}
            <div className="text-left">
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-black tracking-tight text-white leading-tight">
                  Calendário de Horas Extras
                </h1>
                <span className="inline-flex items-center rounded-md bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-amber-950 shadow-sm shadow-amber-400/40 ring-1 ring-amber-200/70">
                  PRO
                </span>
              </div>
              <p className="text-[11px] font-semibold text-cyan-300/85 flex items-center gap-1.5 tracking-wide">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Sistema Inteligente · Gestão e Escala CLT</span>
              </p>
            </div>
          </div>
        </div>

        {/* Divisor Tecnológico Sutil */}
        <div className="my-2.5 h-[1px] w-full bg-gradient-to-r from-transparent via-slate-700/60 to-transparent" />

        {/* Botões de Comando Diagramados: 6 Ícones (Biometria + 5 Existentes) */}
        <div className="grid grid-cols-6 gap-1 sm:gap-1.5">
          {/* 1. Biometria (Ícone Principal de Acesso Rápido) */}
          <button
            type="button"
            onClick={onOpenBiometria}
            aria-label="Abrir Biometria e Ponto Digital"
            title="Biometria · Ponto Rápido e Segurança"
            className="group relative flex flex-col items-center justify-center gap-1 rounded-xl border border-cyan-500/40 bg-gradient-to-b from-cyan-500/20 via-cyan-500/10 to-transparent py-2 px-0.5 text-cyan-300 transition hover:border-cyan-400 hover:bg-cyan-500/25 active:scale-95 shadow-sm shadow-cyan-500/20"
          >
            <div className="relative">
              <Fingerprint className="h-4 w-4 text-cyan-400 transition group-hover:scale-110" strokeWidth={2.4} />
              <span className="absolute -top-0.5 -right-0.5 h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span className="absolute -top-0.5 -right-0.5 h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </div>
            <span className="text-[9px] sm:text-[10px] font-bold tracking-tight text-cyan-200">Biometria</span>
          </button>

          {/* 2. Menu */}
          {(onOpenMenu || onOpenInstall) ? (
            <button
              type="button"
              onClick={() => (onOpenMenu ? onOpenMenu() : onOpenInstall?.())}
              aria-label="Abrir Menu do Aplicativo"
              title="Menu do Aplicativo"
              className="group flex flex-col items-center justify-center gap-1 rounded-xl border border-emerald-500/30 bg-emerald-500/10 py-2 px-0.5 text-emerald-300 transition hover:border-emerald-400/60 hover:bg-emerald-500/20 active:scale-95 shadow-sm"
            >
              <Menu className="h-4 w-4 transition group-hover:scale-110 text-emerald-400" strokeWidth={2.4} />
              <span className="text-[9px] sm:text-[10px] font-bold tracking-tight text-emerald-200">Menu</span>
            </button>
          ) : (
            <div />
          )}

          {/* 3. Compartilhar Relatório */}
          <button
            type="button"
            onClick={onOpenShare || onToggleSmart}
            aria-pressed={smartMode}
            aria-label="Compartilhar relatório de horas extras via WhatsApp"
            title="Compartilhar · Relatório de Horas Extras e WhatsApp"
            className={`group flex flex-col items-center justify-center gap-1 rounded-xl border py-2 px-0.5 transition active:scale-95 shadow-sm ${
              smartMode
                ? "border-cyan-400/60 bg-cyan-500/20 text-cyan-200 shadow-[0_0_12px_rgba(34,211,238,0.25)]"
                : "border-slate-700/80 bg-slate-800/60 text-slate-300 hover:border-cyan-400/40 hover:bg-slate-800 hover:text-cyan-300"
            }`}
          >
            <div className="relative">
              <Share2 className="h-4 w-4 transition group-hover:scale-110 text-cyan-400" strokeWidth={2.4} />
            </div>
            <span className="text-[9px] sm:text-[10px] font-bold tracking-tight text-slate-200">Compartilhar</span>
          </button>

          {/* 4. Perfil / Nuvem */}
          <button
            type="button"
            onClick={onOpenAccount}
            aria-label="Perfil e Sincronização na Nuvem"
            title={userLoggedIn ? "Conta Google conectada (Sincronizado na Nuvem)" : "Conectar Nuvem / Perfil"}
            className="group flex flex-col items-center justify-center gap-1 rounded-xl border border-indigo-500/30 bg-indigo-500/10 py-2 px-0.5 text-indigo-200 transition hover:border-indigo-400/60 hover:bg-indigo-500/20 active:scale-95 shadow-sm"
          >
            <div className="relative h-5 w-5 shrink-0 overflow-hidden rounded-full ring-1 ring-indigo-300/50">
              {displayPhoto ? (
                <img
                  src={displayPhoto}
                  alt="Foto do perfil"
                  className="h-full w-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : avatar ? (
                <AvatarFace spec={avatar} className="h-full w-full" />
              ) : (
                <span className="flex h-full w-full items-center justify-center text-[10px] font-black text-white bg-indigo-600">
                  {initials}
                </span>
              )}
              {userLoggedIn && (
                <span className="absolute bottom-0 right-0 h-1.5 w-1.5 rounded-full bg-emerald-400 ring-1 ring-slate-950" />
              )}
            </div>
            <span className="text-[9px] sm:text-[10px] font-bold tracking-tight text-indigo-200">
              {userLoggedIn ? "Nuvem" : "Perfil"}
            </span>
          </button>

          {/* 5. Alternar Tema */}
          <button
            type="button"
            onClick={onToggleColor}
            aria-pressed={whiteMode}
            aria-label={whiteMode ? "Mudar para modo escuro" : "Mudar para modo claro"}
            title={whiteMode ? "Mudar para modo escuro" : "Mudar para modo claro"}
            className="group flex flex-col items-center justify-center gap-1 rounded-xl border border-slate-700/80 bg-slate-800/60 py-2 px-0.5 text-slate-300 transition hover:border-amber-400/50 hover:bg-slate-800 hover:text-amber-300 active:scale-95 shadow-sm"
          >
            {whiteMode ? (
              <Moon className="h-4 w-4 text-indigo-400 transition group-hover:scale-110" strokeWidth={2.4} />
            ) : (
              <Sun className="h-4 w-4 text-amber-400 transition group-hover:scale-110" strokeWidth={2.4} />
            )}
            <span className="text-[9px] sm:text-[10px] font-bold tracking-tight text-slate-200">Tema</span>
          </button>

          {/* 6. Sair / Início */}
          <button
            type="button"
            onClick={onLogout}
            aria-label="Sair para a tela inicial"
            title="Sair para a tela de boas-vindas"
            className="group flex flex-col items-center justify-center gap-1 rounded-xl border border-slate-700/80 bg-slate-800/60 py-2 px-0.5 text-slate-400 transition hover:border-rose-400/40 hover:bg-rose-500/10 hover:text-rose-300 active:scale-95 shadow-sm"
          >
            <LogOut className="h-4 w-4 transition group-hover:scale-110 text-slate-400 group-hover:text-rose-400" strokeWidth={2.4} />
            <span className="text-[9px] sm:text-[10px] font-bold tracking-tight text-slate-300 group-hover:text-rose-300">Sair</span>
          </button>
        </div>
      </div>
    </header>
  );
}
