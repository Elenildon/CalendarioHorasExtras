import { useState, useEffect, useMemo } from "react";
import QRCode from "qrcode";
import {
  X,
  QrCode,
  Share2,
  Copy,
  Check,
  Download,
  ShieldCheck,
  ArrowRight,
  PlusSquare,
  MoreVertical,
  Cloud,
  CheckCircle2,
  Info,
} from "lucide-react";
import iconUrl from "../assets/icon.png";

export const OFFICIAL_PROJECT_URL = "https://calendario-de-horas-extras.ai.studio/";

export interface InstallAppModalProps {
  onClose: () => void;
  onShowToast: (msg: string) => void;
  onOpenAccount?: () => void;
  whiteMode?: boolean;
  initialTab?: "auto" | "ios" | "android" | "qr";
}

export type PlatformType = "ios" | "android" | "desktop";

export function detectPlatform(): PlatformType {
  if (typeof window === "undefined" || typeof navigator === "undefined") {
    return "desktop";
  }
  const ua = navigator.userAgent || navigator.vendor || "";
  const isIOS =
    /iPad|iPhone|iPod/.test(ua) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  if (isIOS) return "ios";
  const isAndroid = /android/i.test(ua);
  if (isAndroid) return "android";
  return "desktop";
}

export function isAppStandalone(): boolean {
  if (typeof window === "undefined") return false;
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (window.navigator as any).standalone === true ||
    document.referrer.includes("android-app://")
  );
}

export default function InstallAppModal({
  onClose,
  onShowToast,
  onOpenAccount,
  whiteMode = false,
  initialTab = "auto",
}: InstallAppModalProps) {
  const detected = useMemo(() => detectPlatform(), []);
  const defaultTab =
    initialTab && initialTab !== "auto"
      ? initialTab
      : detected === "ios"
      ? "ios"
      : "android";
  const [activeTab, setActiveTab] = useState<"ios" | "android" | "qr">(defaultTab);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>("");
  const [copiedLink, setCopiedLink] = useState(false);
  const [alreadyInstalled, setAlreadyInstalled] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  useEffect(() => {
    if (initialTab) {
      if (initialTab === "auto") {
        setActiveTab(detected === "ios" ? "ios" : "android");
      } else {
        setActiveTab(initialTab);
      }
    }
  }, [initialTab, detected]);

  useEffect(() => {
    setAlreadyInstalled(isAppStandalone());

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
    };
  }, []);

  // URL ativa para acesso do QR Code garantindo acesso móvel sem erro 403
  const qrTargetUrl = useMemo(() => {
    const origin =
      typeof window !== "undefined" && window.location.origin
        ? window.location.origin
        : OFFICIAL_PROJECT_URL;
    const sep = origin.includes("?") ? "&" : "?";
    return `${origin}${sep}qr=1`;
  }, []);

  // Gera o QR Code oficial de alta fidelidade
  useEffect(() => {
    QRCode.toDataURL(qrTargetUrl, {
      width: 360,
      margin: 2,
      errorCorrectionLevel: "H",
      color: {
        dark: "#050714",
        light: "#ffffff",
      },
    })
      .then((url) => setQrCodeDataUrl(url))
      .catch((err) => console.error("Erro ao gerar QR Code:", err));
  }, [qrTargetUrl]);

  const handleCopyLink = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(qrTargetUrl);
      } else {
        const input = document.createElement("input");
        input.value = qrTargetUrl;
        document.body.appendChild(input);
        input.select();
        document.execCommand("copy");
        document.body.removeChild(input);
      }
      setCopiedLink(true);
      onShowToast("Link copiado com sucesso!");
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      onShowToast("Copie manualmente: " + qrTargetUrl);
    }
  };

  const handleShare = async () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({
          title: "Calendário de Horas Extras PRO",
          text: "Acesse e instale o Calendário de Horas Extras PRO no seu celular (Android & iPhone):",
          url: qrTargetUrl,
        });
        onShowToast("Compartilhado com sucesso!");
        return;
      } catch {
        // Usuário cancelou ou navegador não permitiu
      }
    }
    handleCopyLink();
  };

  const handleDownloadQr = () => {
    if (!qrCodeDataUrl) return;
    const a = document.createElement("a");
    a.href = qrCodeDataUrl;
    a.download = "qr-code-calendario-horas-extras.png";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    onShowToast("Imagem do QR Code baixada!");
  };

  const handleTriggerAndroidInstall = async () => {
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === "accepted") {
          onShowToast("Instalando o aplicativo no Android...");
          setDeferredPrompt(null);
        }
      } catch {
        onShowToast("Use os 3 pontinhos do Chrome para instalar");
      }
    } else {
      onShowToast("Toque no menu (⋮) do Chrome e selecione 'Instalar aplicativo'");
    }
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div
        className={`relative w-full max-w-lg max-h-[92vh] flex flex-col rounded-3xl border shadow-2xl overflow-hidden transition-all ${
          whiteMode
            ? "bg-slate-50 border-slate-300 text-slate-800"
            : "bg-gradient-to-b from-slate-900 via-[#0a1024] to-[#050714] border-slate-700/80 text-white"
        }`}
      >
        {/* Cabeçalho */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-700/60 shrink-0">
          <div className="flex items-center gap-3">
            <img
              src={iconUrl}
              alt="Ícone do App"
              className="h-10 w-10 rounded-2xl shadow-md border border-cyan-400/30 object-cover"
            />
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-base sm:text-lg font-black tracking-tight leading-tight">
                  Instalar & QR Code
                </h2>
                <span className="rounded bg-gradient-to-r from-amber-400 to-amber-500 px-1.5 py-0.5 text-[9px] font-black uppercase text-amber-950">
                  OFICIAL
                </span>
              </div>
              <p className="text-xs text-cyan-300/80 font-medium">
                Compatível 100% com iPhone (iOS) e Android
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar"
            className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700 transition active:scale-95"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Abas de Navegação */}
        <div className="px-4 pt-3 pb-1 shrink-0">
          <div className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-[11px] font-bold">
            <button
              type="button"
              onClick={() => setActiveTab("ios")}
              className={`py-2 px-1 rounded-xl transition flex flex-col sm:flex-row items-center justify-center gap-1 ${
                activeTab === "ios"
                  ? "bg-cyan-600 text-white shadow-md shadow-cyan-900/40"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <span>🍏</span>
              <span>iPhone</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("android")}
              className={`py-2 px-1 rounded-xl transition flex flex-col sm:flex-row items-center justify-center gap-1 ${
                activeTab === "android"
                  ? "bg-emerald-600 text-white shadow-md shadow-emerald-900/40"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              <span>🤖</span>
              <span>Android</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("qr")}
              className={`py-2 px-1 rounded-xl transition flex flex-col sm:flex-row items-center justify-center gap-1 ${
                activeTab === "qr"
                  ? "bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-black shadow-md shadow-amber-950/40"
                  : "text-amber-400 hover:text-white"
              }`}
            >
              <QrCode className="h-3.5 w-3.5" />
              <span>QR Code Oficial</span>
            </button>
          </div>
        </div>

        {/* Corpo com Scroll */}
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 no-scrollbar">
          {alreadyInstalled && (
            <div className="flex items-center gap-2.5 rounded-2xl border border-emerald-400/40 bg-emerald-950/30 p-3 text-xs text-emerald-200">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" />
              <div>
                <span className="font-bold block">Aplicativo já instalado no seu celular!</span>
                Você está utilizando a versão independente (PWA) em tela cheia com dados salvos no aparelho.
              </div>
            </div>
          )}

          {/* CONTEÚDO ESPECÍFICO CONFORME A ABA SELECIONADA */}

          {/* 1. SEÇÃO IPHONE (iOS / Safari) */}
          {activeTab === "ios" && (
            <div className="space-y-3">
              <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-br from-cyan-950/30 to-slate-900/70 p-4">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-cyan-500/20">
                  <div className="flex items-center gap-2 text-cyan-300 font-black text-sm">
                    <span>🍏</span>
                    <span>Instalar no iPhone (Safari)</span>
                  </div>
                  <span className="text-[10px] font-bold text-cyan-200 bg-cyan-900/60 px-2 py-0.5 rounded-full border border-cyan-400/30">
                    Sem Apple Store · Grátis
                  </span>
                </div>

                <div className="space-y-3 text-xs text-slate-300">
                  <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 font-black text-cyan-300 text-xs">
                      1
                    </span>
                    <div>
                      <p className="font-semibold text-slate-100">
                        Abra este link no navegador oficial <strong className="text-cyan-300">Safari</strong> do iPhone.
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        O Safari é o único navegador que permite criar o ícone nativo na tela inicial do iOS.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 font-black text-cyan-300 text-xs">
                      2
                    </span>
                    <div>
                      <p className="font-semibold text-slate-100 flex items-center gap-1.5 flex-wrap">
                        Toque no botão <strong className="text-cyan-300">Compartilhar</strong>
                        <span className="inline-flex items-center justify-center h-5 w-5 rounded bg-slate-800 text-cyan-300 border border-slate-600 text-[10px]">
                          ⎋
                        </span>
                        (quadrado com seta para cima no rodapé do Safari).
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 font-black text-cyan-300 text-xs">
                      3
                    </span>
                    <div>
                      <p className="font-semibold text-slate-100 flex items-center gap-1.5 flex-wrap">
                        Role para baixo e toque em
                        <strong className="text-cyan-300 inline-flex items-center gap-1">
                          <PlusSquare className="h-3.5 w-3.5" />
                          &quot;Adicionar à Tela de Início&quot;
                        </strong>.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/20 font-black text-cyan-300 text-xs">
                      4
                    </span>
                    <div>
                      <p className="font-semibold text-slate-100">
                        Toque em <strong className="text-emerald-400">&quot;Adicionar&quot;</strong> no canto superior direito.
                      </p>
                      <p className="text-[11px] text-slate-400 mt-0.5">
                        Pronto! O aplicativo abrirá em tela cheia com ícone HD e carregamento instantâneo.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="rounded-xl border border-cyan-500/25 bg-cyan-950/30 p-2.5 text-[11px] text-cyan-200/90 space-y-1 mt-3">
                  <div className="font-bold flex items-center gap-1.5 text-cyan-300">
                    <Info className="h-3.5 w-3.5" />
                    <span>Dica para Safari / iPhone:</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">
                    Se o navegador exibir aviso de cookies ou &quot;Action required&quot;, basta tocar em <strong>Compartilhar (⎋)</strong> e <strong>&quot;Adicionar à Tela de Início&quot;</strong>. Como aplicativo instalado, ele roda com armazenamento 100% autônomo e sem bloqueios.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 2. SEÇÃO ANDROID (Chrome / Edge / Samsung) */}
          {activeTab === "android" && (
            <div className="space-y-3">
              <div className="rounded-2xl border border-emerald-500/30 bg-gradient-to-br from-emerald-950/30 to-slate-900/70 p-4">
                <div className="flex items-center justify-between pb-2 mb-3 border-b border-emerald-500/20">
                  <div className="flex items-center gap-2 text-emerald-300 font-black text-sm">
                    <span>🤖</span>
                    <span>Instalar no Android (Google Chrome)</span>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-200 bg-emerald-900/60 px-2 py-0.5 rounded-full border border-emerald-400/30">
                    PWA Nativo
                  </span>
                </div>

                {deferredPrompt ? (
                  <button
                    type="button"
                    onClick={handleTriggerAndroidInstall}
                    className="w-full mb-3 flex items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 py-3 px-4 font-black text-white shadow-lg shadow-emerald-950/60 transition active:scale-95"
                  >
                    <Download className="h-5 w-5" />
                    <span>Instalar Aplicativo Agora</span>
                  </button>
                ) : (
                  <div className="space-y-3 text-xs text-slate-300">
                    <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 font-black text-emerald-300 text-xs">
                        1
                      </span>
                      <div>
                        <p className="font-semibold text-slate-100 flex items-center gap-1">
                          No Chrome, toque no menu <MoreVertical className="h-4 w-4 text-emerald-400 inline" /> (três pontinhos no topo direito).
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 font-black text-emerald-300 text-xs">
                        2
                      </span>
                      <div>
                        <p className="font-semibold text-slate-100">
                          Selecione <strong className="text-emerald-300">&quot;Instalar aplicativo&quot;</strong> ou <strong className="text-emerald-300">&quot;Adicionar à tela inicial&quot;</strong>.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-700/60">
                      <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/20 font-black text-emerald-300 text-xs">
                        3
                      </span>
                      <div>
                        <p className="font-semibold text-slate-100">
                          Confirme em <strong className="text-emerald-400">&quot;Instalar&quot;</strong>.
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          O aplicativo será instalado na gaveta de aplicativos e na tela inicial do seu Android com badge PRO.
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 3. SEÇÃO DESKTOP (Caso acesse por PC/Mac) */}
          {detected === "desktop" && activeTab !== "qr" && (
            <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-indigo-950/30 to-slate-900/70 p-4 text-xs text-slate-300 space-y-2">
              <span className="text-sm font-bold text-indigo-300 block">
                💻 Computador / Notebook detectado
              </span>
              <p>
                Você pode instalar este app no seu navegador (Chrome/Edge) clicando no ícone de computador/instalação na barra de endereços (à direita da URL) ou escanear o QR Code abaixo com seu celular.
              </p>
            </div>
          )}

          {/* 4. BLOCO DO QR CODE OFICIAL (SEMPRE ACESSÍVEL / DESTAQUE NA ABA QR) */}
          <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-br from-amber-950/20 via-slate-900/70 to-slate-950 p-4">
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-amber-500/20">
              <div className="flex items-center gap-2 text-amber-300 font-black text-sm">
                <QrCode className="h-4 w-4" />
                <span>QR Code Oficial para Câmera do Celular</span>
              </div>
              <span className="text-[10px] font-bold text-amber-300 bg-amber-950/80 px-2 py-0.5 rounded-full border border-amber-500/40">
                iPhone & Android
              </span>
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="relative shrink-0 rounded-2xl bg-white p-2.5 shadow-xl shadow-black/60">
                {qrCodeDataUrl ? (
                  <img
                    src={qrCodeDataUrl}
                    alt="QR Code Oficial"
                    className="h-44 w-44 object-contain rounded-lg"
                  />
                ) : (
                  <div className="h-44 w-44 flex items-center justify-center text-xs text-slate-600">
                    Gerando QR Code...
                  </div>
                )}
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="h-9 w-9 rounded-xl bg-white/95 p-1 shadow-md border border-slate-200">
                    <img src={iconUrl} alt="Ícone Central" className="h-full w-full object-cover rounded-md" />
                  </div>
                </div>
              </div>

              <div className="flex-1 space-y-2.5 w-full text-center sm:text-left">
                <div className="text-xs">
                  <span className="font-bold text-slate-200 block">
                    URL do Aplicativo:
                  </span>
                  <a
                    href={qrTargetUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-cyan-300 font-mono text-[11px] underline break-all hover:text-cyan-200"
                  >
                    {qrTargetUrl}
                  </a>
                </div>

                <p className="text-[11px] text-slate-400 leading-tight">
                  Aponte a câmera nativa do seu <strong>iPhone</strong> ou <strong>Android</strong> para o código. Ele abrirá instantaneamente sem erro 403 ou 404.
                </p>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/80 py-2 px-3 text-xs font-bold text-slate-200 hover:bg-slate-700 hover:text-white transition active:scale-95"
                  >
                    {copiedLink ? (
                      <>
                        <Check className="h-3.5 w-3.5 text-emerald-400" />
                        <span className="text-emerald-300">Copiado!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5 text-cyan-400" />
                        <span>Copiar Link</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadQr}
                    className="flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-800/80 py-2 px-3 text-xs font-bold text-slate-200 hover:bg-slate-700 hover:text-white transition active:scale-95"
                  >
                    <Download className="h-3.5 w-3.5 text-amber-400" />
                    <span>Baixar QR</span>
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleShare}
                  className="w-full flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 py-2 px-3 text-xs font-bold text-white shadow-md hover:from-indigo-500 hover:to-violet-500 transition active:scale-95"
                >
                  <Share2 className="h-3.5 w-3.5" />
                  <span>Compartilhar Link / WhatsApp</span>
                </button>
              </div>
            </div>
          </div>

          {/* 5. BACKUP NA NUVEM GOOGLE & SALVAMENTO NO APARELHO */}
          <div className="rounded-2xl border border-slate-700/60 bg-slate-900/60 p-3.5 text-xs text-slate-300 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 flex items-center gap-1.5">
                <Cloud className="h-4 w-4 text-cyan-400" />
                Backup na Nuvem & Segurança dos Dados
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold flex items-center gap-1">
                <ShieldCheck className="h-3.5 w-3.5" />
                Salvo no Aparelho
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Todos os seus cálculos, horas extras, empresa e cargo são salvos localmente no seu aparelho. Conecte sua conta do Google para sincronização automática em tempo real entre seus celulares.
            </p>
            {onOpenAccount && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenAccount();
                }}
                className="w-full flex items-center justify-center gap-2 rounded-xl border border-indigo-500/40 bg-indigo-950/40 py-2 text-xs font-bold text-indigo-300 hover:bg-indigo-900/50 hover:text-white transition active:scale-95"
              >
                <span>Conectar com Google / Gerenciar Nuvem</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Rodapé com Botão "Gerar meu QR Code" */}
        <div className="p-3 sm:p-4 border-t border-slate-700/60 bg-slate-950/80 flex items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab("qr")}
            className="flex items-center gap-1.5 text-xs font-bold text-amber-300 bg-amber-950/40 border border-amber-500/40 py-2 px-3 rounded-xl hover:bg-amber-900/50 transition active:scale-95"
          >
            <QrCode className="h-4 w-4" />
            <span>Gerar meu QR Code</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-800 hover:bg-slate-700 py-2 px-4 text-xs font-bold text-slate-200 transition active:scale-95"
          >
            Concluir
          </button>
        </div>
      </div>
    </div>
  );
}
