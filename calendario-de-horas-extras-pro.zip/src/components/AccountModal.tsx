import { useState } from "react";
import { Cloud, CloudCheck, LogOut, ShieldCheck, X, Loader2, Briefcase, Building2, User as UserIcon } from "lucide-react";
import type { User } from "../lib/firebase";
import { loginWithGoogle, logoutUser } from "../lib/firebase";
import AvatarFace from "./AvatarFace";
import { getAvatar } from "../lib/avatars";
import { APP_VERSION, type Settings } from "../lib/calc";

interface AccountModalProps {
  user: User | null;
  settings: Settings;
  lastCloudSync: number | null;
  isSyncing: boolean;
  onSyncNow: () => void;
  onClose: () => void;
  onUserChange?: () => void;
  onUpdateSettings?: (patch: Partial<Settings>, immediate?: boolean) => void;
  onOpenWelcome?: () => void;
}

export default function AccountModal({
  user,
  settings,
  lastCloudSync,
  isSyncing,
  onSyncNow,
  onClose,
  onUpdateSettings,
  onOpenWelcome,
}: AccountModalProps) {
  const [loadingLogin, setLoadingLogin] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    try {
      setLoadingLogin(true);
      setErrorMsg(null);
      await loginWithGoogle();
    } catch (err: unknown) {
      console.error(err);
      const e = err as { code?: string; message?: string };
      if (e.code === "auth/popup-closed-by-user") {
        setErrorMsg("Janela de login fechada antes de concluir.");
      } else if (e.code === "auth/popup-blocked") {
        setErrorMsg("O navegador bloqueou a janela pop-up do Google. Permita pop-ups.");
      } else {
        setErrorMsg("Não foi possível conectar com o Google. Tente novamente.");
      }
    } finally {
      setLoadingLogin(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
    } catch (err) {
      console.error(err);
    }
  };

  const avatar = getAvatar(settings.avatarId);

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-4">
      {/* backdrop */}
      <div
        onClick={onClose}
        className="backdrop-fade fixed inset-0 bg-black/70 backdrop-blur-sm"
      />

      <div className="relative w-full max-w-sm rounded-[2rem] border border-indigo-400/25 bg-[#0e1630] p-6 shadow-2xl text-slate-200">
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/50">
          <div className="flex items-center gap-2">
            <Cloud className="h-5 w-5 text-indigo-400" />
            <h2 className="text-xl font-black text-white">Conta & Nuvem</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-11 w-11 items-center justify-center rounded-xl bg-slate-800 text-slate-300 hover:text-white transition active:scale-95"
            aria-label="Fechar conta e nuvem"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Informações do usuário */}
        <div className="mt-5 flex items-center gap-4">
          <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-2xl ring-2 ring-indigo-500/50">
            {settings.photoURL ? (
              <img
                src={settings.photoURL}
                alt="Foto pessoal"
                className="h-full w-full object-cover"
              />
            ) : user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || "Avatar Google"}
                className="h-full w-full object-cover"
                referrerPolicy="no-referrer"
              />
            ) : avatar ? (
              <AvatarFace spec={avatar} className="h-full w-full" />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-indigo-600 text-2xl font-black text-white">
                {(settings.name || "U")[0]?.toUpperCase()}
              </div>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-lg font-bold text-white">
              {user?.displayName || settings.name || "Usuário"}
            </h3>
            <p className="truncate text-sm text-slate-400">
              {user?.email || "Modo offline (armazenamento local)"}
            </p>
            <div className="mt-1 flex items-center gap-1.5">
              <span
                className={`h-2 w-2 rounded-full ${
                  user ? "bg-emerald-400 animate-pulse" : "bg-amber-400"
                }`}
              />
              <span className="text-xs font-semibold text-slate-300">
                {user ? "Sincronização ativa" : "Apenas local"}
              </span>
            </div>
          </div>
        </div>

        {errorMsg && (
          <div className="mt-4 rounded-xl bg-rose-500/20 border border-rose-500/40 p-3 text-xs text-rose-200">
            {errorMsg}
          </div>
        )}

        {/* Bloco de status do Firestore */}
        <div className="mt-5 rounded-2xl border border-slate-700/60 bg-slate-800/50 p-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-400">Última sincronização:</span>
            <span className="font-semibold text-white">
              {lastCloudSync
                ? new Date(lastCloudSync).toLocaleTimeString("pt-BR")
                : user
                ? "Conectado"
                : "Não sincronizado"}
            </span>
          </div>

          <div className="mt-3 flex items-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
            <span>Banco de dados Firestore criptografado e seguro.</span>
          </div>
        </div>

        {/* Campos de Nome, Cargo e Empresa com salvamento automático */}
        <div className="mt-4 space-y-3 rounded-2xl border border-slate-700/60 bg-slate-800/40 p-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Dados Cadastrais
            </span>
            <span className="text-[10px] font-semibold text-emerald-400 flex items-center gap-1">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Salva automático
            </span>
          </div>

          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              Nome do usuário
            </label>
            <div className="flex items-center gap-2 rounded-xl border border-slate-700/80 bg-slate-950/60 px-3 py-2">
              <UserIcon className="h-4 w-4 text-indigo-400 shrink-0" />
              <input
                type="text"
                value={settings.name}
                onChange={(e) => onUpdateSettings?.({ name: e.target.value })}
                onBlur={() => onUpdateSettings?.({ name: settings.name }, true)}
                placeholder="Informe seu nome"
                className="w-full bg-transparent text-sm text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              Cargo
            </label>
            <div className="flex items-center gap-2 rounded-xl border border-slate-700/80 bg-slate-950/60 px-3 py-2">
              <Briefcase className="h-4 w-4 text-indigo-400 shrink-0" />
              <input
                type="text"
                value={settings.cargo}
                onChange={(e) => onUpdateSettings?.({ cargo: e.target.value })}
                onBlur={() => onUpdateSettings?.({ cargo: settings.cargo }, true)}
                placeholder="Informe seu cargo (ex.: Montador B)"
                className="w-full bg-transparent text-sm text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-[11px] font-medium text-slate-400 block mb-1">
              Empresa
            </label>
            <div className="flex items-center gap-2 rounded-xl border border-slate-700/80 bg-slate-950/60 px-3 py-2">
              <Building2 className="h-4 w-4 text-indigo-400 shrink-0" />
              <input
                type="text"
                value={settings.empresa}
                onChange={(e) => onUpdateSettings?.({ empresa: e.target.value })}
                onBlur={() => onUpdateSettings?.({ empresa: settings.empresa }, true)}
                placeholder="Informe sua empresa"
                className="w-full bg-transparent text-sm text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Ações */}
        <div className="mt-6 flex flex-col gap-3">
          {onOpenWelcome && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenWelcome();
              }}
              className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-violet-400/40 bg-gradient-to-r from-violet-600/30 to-purple-600/30 font-bold text-violet-200 transition active:scale-95 hover:bg-violet-600/40 shadow-sm"
            >
              <span>✨</span>
              <span>Abrir Tela de Boas-Vindas & Foto</span>
            </button>
          )}

          {user ? (
            <>
              <button
                type="button"
                onClick={onSyncNow}
                disabled={isSyncing}
                className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-indigo-600 font-bold text-white shadow-lg shadow-indigo-900/40 transition active:scale-95 disabled:opacity-50"
              >
                {isSyncing ? (
                  <>
                    <Loader2 className="h-5 w-5 animate-spin" />
                    Sincronizando...
                  </>
                ) : (
                  <>
                    <CloudCheck className="h-5 w-5" />
                    Sincronizar agora com a nuvem
                  </>
                )}
              </button>

              <div className="space-y-1.5 w-full">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 font-bold text-slate-300 transition active:scale-95 hover:bg-slate-700"
                >
                  <LogOut className="h-5 w-5 text-rose-400" />
                  Desconectar conta Google
                </button>
                <p className="text-[11px] text-amber-300/90 text-center leading-tight bg-amber-500/10 border border-amber-500/20 rounded-lg p-2">
                  ⚠️ <strong>Atenção:</strong> desconectar fará parar a sincronização. Seus dados salvos na nuvem não serão apagados.
                </p>
              </div>
            </>
          ) : (
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={loadingLogin}
              className="flex h-14 w-full items-center justify-center gap-3 rounded-2xl bg-white font-black text-slate-900 shadow-xl transition active:scale-95 hover:bg-slate-100 disabled:opacity-50"
            >
              {loadingLogin ? (
                <Loader2 className="h-6 w-6 animate-spin text-slate-900" />
              ) : (
                <svg className="h-6 w-6" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.04 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
              )}
              Entrar com Google
            </button>
          )}
        </div>

        <p className="mt-4 text-center text-[11px] text-slate-500 font-mono">
          Calendário de Horas Extras · Versão {APP_VERSION}
        </p>
      </div>
    </div>
  );
}
