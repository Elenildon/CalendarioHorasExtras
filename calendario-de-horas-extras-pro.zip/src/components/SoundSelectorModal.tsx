import React, { useState, useEffect } from "react";
import { X, Play, Square, Check, Volume2, Vibrate, RotateCw, BellRing } from "lucide-react";
import { cn } from "../utils/cn";
import {
  AlarmSoundPreset,
  ALARM_SOUND_PRESETS,
  AlarmRepeatOption,
  playSoundPreview,
  stopSoundPreview,
  testAlarmRepetition,
  stopAlarmAudiovisual,
} from "../lib/intervalAlarm";

interface SoundSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPresetId: string;
  onSelectPreset: (presetId: string) => void;
  repeatCount?: AlarmRepeatOption;
  onSelectRepeat?: (count: AlarmRepeatOption) => void;
  vibrationEnabled?: boolean;
  onToggleVibration?: (enabled: boolean) => void;
  onShowToast?: (message: string) => void;
}

export default function SoundSelectorModal({
  isOpen,
  onClose,
  selectedPresetId,
  onSelectPreset,
  repeatCount = 3,
  onSelectRepeat,
  vibrationEnabled = true,
  onToggleVibration,
  onShowToast,
}: SoundSelectorModalProps) {
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [isTestingFullAlarm, setIsTestingFullAlarm] = useState(false);

  // Interrompe qualquer áudio ao fechar ou desmontar
  useEffect(() => {
    if (!isOpen) {
      stopSoundPreview();
      stopAlarmAudiovisual();
      setPlayingId(null);
      setIsTestingFullAlarm(false);
    }
    return () => {
      stopSoundPreview();
      stopAlarmAudiovisual();
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const currentPreset =
    ALARM_SOUND_PRESETS.find((p) => p.id === selectedPresetId) || ALARM_SOUND_PRESETS[0];

  // Reproduz prévia isolada (sem vibração, sem notificação, sem alarme completo)
  const handleTogglePlay = (e: React.MouseEvent, preset: AlarmSoundPreset) => {
    e.stopPropagation();

    if (isTestingFullAlarm) {
      stopAlarmAudiovisual();
      setIsTestingFullAlarm(false);
    }

    if (playingId === preset.id) {
      stopSoundPreview();
      setPlayingId(null);
    } else {
      stopSoundPreview();
      setPlayingId(preset.id);
      playSoundPreview(preset.id, () => {
        setPlayingId((curr) => (curr === preset.id ? null : curr));
      });
    }
  };

  const handleSelect = (preset: AlarmSoundPreset) => {
    onSelectPreset(preset.id);
    if (onShowToast) {
      onShowToast(`🔊 Som selecionado: ${preset.name}`);
    }
  };

  const handleTestFull = () => {
    stopSoundPreview();
    setPlayingId(null);
    setIsTestingFullAlarm(true);
    testAlarmRepetition(repeatCount, selectedPresetId);
    if (onShowToast) {
      onShowToast(`🔔 Testando ${currentPreset.name} com ${repeatCount}× repetições...`);
    }
  };

  const handleStopTestFull = () => {
    stopAlarmAudiovisual();
    setIsTestingFullAlarm(false);
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-150">
      <div
        className="w-full max-w-xl rounded-3xl border border-cyan-500/40 bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 shadow-2xl shadow-cyan-950/60 flex flex-col max-h-[92vh] overflow-hidden text-white"
        role="dialog"
        aria-modal="true"
        aria-labelledby="sound-selector-title"
      >
        {/* Cabeçalho */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-900/90">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 to-teal-600 text-slate-950 font-black shadow-lg shadow-cyan-500/30">
              <Volume2 className="h-6 w-6" />
            </div>
            <div>
              <h3 id="sound-selector-title" className="text-base sm:text-lg font-black text-white tracking-tight flex items-center gap-2">
                <span>🔊 SOM DO ALARME</span>
                <span className="rounded-full bg-cyan-500/20 px-2 py-0.5 text-[10px] font-black text-cyan-300 border border-cyan-500/30 uppercase">
                  10 Presets
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Retornar Intervalo / Volta às atividades · 100% Offline
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="rounded-xl p-2 text-slate-400 hover:bg-slate-800 hover:text-white transition active:scale-95 cursor-pointer"
            aria-label="Fechar seletor de som"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Barra de Status e Controles Superiores (Repetições & Vibração) */}
        <div className="px-4 sm:px-5 py-3 bg-slate-950/80 border-b border-slate-800/80 space-y-2.5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <span className="text-slate-400 flex items-center gap-1.5">
              <span>Preset Ativo:</span>
              <strong className="text-cyan-300 font-mono font-bold">
                {currentPreset.emoji} {currentPreset.name}
              </strong>
            </span>

            {/* Controle de Vibração */}
            {onToggleVibration && (
              <div className="flex items-center gap-2">
                <span className="text-slate-400 flex items-center gap-1">
                  <Vibrate className="h-3.5 w-3.5 text-teal-400" />
                  <span>Vibração:</span>
                </span>
                <div className="inline-flex rounded-lg bg-slate-900 border border-slate-800 p-0.5">
                  <button
                    type="button"
                    onClick={() => onToggleVibration(true)}
                    className={cn(
                      "px-2.5 py-0.5 rounded-md text-[10px] font-bold transition cursor-pointer",
                      vibrationEnabled
                        ? "bg-teal-500 text-slate-950 font-black shadow-sm"
                        : "text-slate-400 hover:text-white"
                    )}
                  >
                    Ligada
                  </button>
                  <button
                    type="button"
                    onClick={() => onToggleVibration(false)}
                    className={cn(
                      "px-2.5 py-0.5 rounded-md text-[10px] font-bold transition cursor-pointer",
                      !vibrationEnabled
                        ? "bg-slate-700 text-white font-black shadow-sm"
                        : "text-slate-400 hover:text-white"
                    )}
                  >
                    Desligada
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Controle de Repetições (1x, 2x, 3x, 5x) */}
          {onSelectRepeat && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800/60 text-xs">
              <span className="text-slate-300 font-bold flex items-center gap-1.5">
                <RotateCw className="h-3.5 w-3.5 text-amber-400" />
                <span>🔁 REPETIÇÕES DO ALARME:</span>
              </span>
              <div className="flex items-center gap-1.5">
                {([1, 2, 3, 5] as AlarmRepeatOption[]).map((count) => (
                  <button
                    key={count}
                    type="button"
                    onClick={() => onSelectRepeat(count)}
                    className={cn(
                      "px-3 py-1 rounded-xl font-mono text-xs font-black transition active:scale-95 cursor-pointer border",
                      repeatCount === count
                        ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-950/50"
                        : "bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800 hover:text-white"
                    )}
                  >
                    {count}×
                  </button>
                ))}
                <span className="text-[10px] text-slate-400 ml-1">
                  {repeatCount === 1 && "(toca 1 vez)"}
                  {repeatCount === 2 && "(2 repetições)"}
                  {repeatCount === 3 && "(3× padrão)"}
                  {repeatCount === 5 && "(5 repetições com pausa)"}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Lista dos 10 Presets Oficiais */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 space-y-2.5">
          {ALARM_SOUND_PRESETS.map((preset, idx) => {
            const isSelected = preset.id === selectedPresetId;
            const isPlaying = playingId === preset.id;
            const itemNumber = String(idx + 1).padStart(2, "0");

            return (
              <div
                key={preset.id}
                onClick={() => handleSelect(preset)}
                className={cn(
                  "group relative flex items-center justify-between gap-3 p-3.5 rounded-2xl border transition-all cursor-pointer select-none",
                  isSelected
                    ? "bg-cyan-950/60 border-cyan-400 shadow-lg shadow-cyan-950/50 ring-1 ring-cyan-400/40"
                    : "bg-slate-900/80 border-slate-800 hover:bg-slate-800/80 hover:border-slate-700"
                )}
              >
                {/* Indicador de Seleção + Número + Nome + Descrição */}
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  {/* Botão de Seleção (Radio / Check) */}
                  <div
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full border transition",
                      isSelected
                        ? "bg-cyan-400 border-cyan-300 text-slate-950 shadow-md shadow-cyan-400/50"
                        : "border-slate-600 bg-slate-950 text-slate-500 group-hover:border-slate-400"
                    )}
                  >
                    {isSelected ? (
                      <Check className="h-4 w-4 stroke-[3]" />
                    ) : (
                      <span className="text-xs font-bold">○</span>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-xs font-mono font-bold text-slate-400">
                        {itemNumber}
                      </span>
                      <h4 className="text-sm sm:text-base font-black text-white tracking-tight flex items-center gap-1.5">
                        <span>🔊</span>
                        <span>{preset.name}</span>
                      </h4>
                      <span className="rounded-md bg-slate-800 border border-slate-700 px-1.5 py-0.5 text-[9px] font-bold text-slate-300 uppercase">
                        {preset.style}
                      </span>
                      {isSelected && (
                        <span className="rounded-md bg-cyan-400 text-slate-950 px-2 py-0.5 text-[9px] font-black uppercase tracking-wider shadow-sm">
                          ◉ Selecionado
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-1 group-hover:text-slate-300">
                      {preset.description}
                    </p>
                  </div>
                </div>

                {/* Botão de Prévia: ▶ Ouvir / ⏹ Parar */}
                <div className="shrink-0 flex items-center gap-2">
                  <button
                    type="button"
                    onClick={(e) => handleTogglePlay(e, preset)}
                    className={cn(
                      "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 shadow cursor-pointer",
                      isPlaying
                        ? "bg-rose-500 text-white shadow-rose-950/50 animate-pulse ring-1 ring-rose-400"
                        : "bg-slate-800 hover:bg-cyan-600 hover:text-white text-slate-200 border border-slate-700"
                    )}
                    title={isPlaying ? "Parar prévia" : `Ouvir prévia de ${preset.name}`}
                  >
                    {isPlaying ? (
                      <>
                        <Square className="h-3.5 w-3.5 fill-current" />
                        <span>Parar</span>
                      </>
                    ) : (
                      <>
                        <Play className="h-3.5 w-3.5 fill-current text-cyan-400 group-hover:text-white" />
                        <span>Ouvir</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Rodapé com Teste Completo e Conclusão */}
        <div className="p-4 bg-slate-900 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            {isTestingFullAlarm ? (
              <button
                type="button"
                onClick={handleStopTestFull}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl bg-rose-600 hover:bg-rose-500 px-4 py-2 text-xs font-black text-white shadow-md transition active:scale-95 cursor-pointer animate-pulse"
              >
                <Square className="h-3.5 w-3.5 fill-current" />
                <span>Parar Teste do Alarme</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleTestFull}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl border border-cyan-500/40 bg-cyan-950/50 hover:bg-cyan-900/60 px-4 py-2 text-xs font-bold text-cyan-300 shadow-sm transition active:scale-95 cursor-pointer"
                title="Testar sequência completa com o som e repetições selecionados"
              >
                <BellRing className="h-3.5 w-3.5 text-cyan-400" />
                <span>Testar Som ({repeatCount}×)</span>
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-full sm:w-auto rounded-xl bg-cyan-500 hover:bg-cyan-400 px-6 py-2.5 text-xs font-black text-slate-950 transition active:scale-95 shadow-md shadow-cyan-950/50 cursor-pointer text-center"
          >
            Concluir Seleção
          </button>
        </div>
      </div>
    </div>
  );
}
