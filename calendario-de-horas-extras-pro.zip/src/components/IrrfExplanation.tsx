import { useState } from "react";
import { ChevronDown, ChevronUp, ShieldCheck, Percent, Info, CheckCircle2 } from "lucide-react";
import { fmtBRL } from "../lib/calc";

export interface IrrfExplanationProps {
  grossSalary: number;
  inssValue: number;
  irrfValue: number;
  defaultOpen?: boolean;
  className?: string;
}

export const IRRF_BRACKETS_INFO = [
  { faixa: "1ª Faixa", range: "Até R$ 2.259,20", rate: "0%", deducao: "R$ 0,00", desc: "Isento oficial" },
  { faixa: "2ª Faixa", range: "R$ 2.259,21 a R$ 2.826,65", rate: "7,5%", deducao: "R$ 169,44", desc: "Parcela deduzida" },
  { faixa: "3ª Faixa", range: "R$ 2.826,66 a R$ 3.751,05", rate: "15,0%", deducao: "R$ 381,44", desc: "Parcela deduzida" },
  { faixa: "4ª Faixa", range: "R$ 3.751,06 a R$ 4.664,68", rate: "22,5%", deducao: "R$ 662,77", desc: "Parcela deduzida" },
  { faixa: "5ª Faixa", range: "Acima de R$ 4.664,68", rate: "27,5%", deducao: "R$ 896,00", desc: "Alíquota máxima" },
];

export default function IrrfExplanation({
  grossSalary,
  inssValue,
  irrfValue,
  defaultOpen = false,
  className = "",
}: IrrfExplanationProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const baseCalculo = Math.max(0, grossSalary - inssValue);
  const isExempt = baseCalculo <= 5000 || irrfValue <= 0;
  const effectiveRate = grossSalary > 0 ? (irrfValue / grossSalary) * 100 : 0;
  const effectiveRateStr = effectiveRate.toFixed(2).replace(".", ",");

  return (
    <div className={`mt-1.5 transition-all ${className}`}>
      {/* Gatilho Clicável Integrado ao Resumo: fica minimizado por padrão */}
      <div className="flex items-center justify-between gap-2 rounded-xl bg-amber-500/10 border border-amber-400/25 px-3 py-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-amber-300">
            <Percent className="h-3.5 w-3.5" />
          </span>
          <div className="text-xs text-amber-200 min-w-0 truncate">
            <span className="font-bold">Regra IRRF 2026:</span>{" "}
            {isExempt ? (
              <span className="text-emerald-300 font-semibold">Isenção até R$ 5.000 (R$ 0,00)</span>
            ) : (
              <span className="text-amber-100">Alíquota efetiva {effectiveRateStr}%</span>
            )}
            <span className="hidden sm:inline text-amber-300/80"> · Base pós-INSS</span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen((prev) => !prev)}
          aria-expanded={isOpen}
          className="flex items-center gap-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 px-2.5 py-1 text-xs font-bold text-amber-100 transition active:scale-95 shrink-0 border border-amber-400/30"
          title={isOpen ? "Minimizar explicação do IRRF" : "Visualizar regra e alíquotas do IRRF 2026"}
        >
          <span>{isOpen ? "Minimizar" : "Ver regra"}</span>
          {isOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Aba Pequena que se abre com a regra explicativa e simples */}
      {isOpen && (
        <div className="mt-2.5 rounded-2xl border border-amber-400/30 bg-gradient-to-b from-[#1c150a]/95 via-[#161007]/95 to-[#0e0a04]/95 p-3.5 sm:p-4 text-xs shadow-xl shadow-black/40 backdrop-blur-md">
          {/* Cabeçalho da Aba */}
          <div className="flex items-start justify-between gap-2 border-b border-amber-500/20 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-amber-400 border border-amber-400/30">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                  Tabela IRRF 2026 (Atualizada)
                  <span className="rounded bg-amber-500/25 px-1.5 py-0.2 text-[10px] font-black text-amber-300 border border-amber-400/30">
                    Receita Federal
                  </span>
                </h4>
                <p className="text-[11px] text-amber-300/80">
                  Cálculo sobre a remuneração após desconto do INSS
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="rounded-lg p-1 text-slate-400 hover:text-white hover:bg-white/10 transition"
              title="Fechar aba explicativa"
            >
              <ChevronUp className="h-4 w-4" />
            </button>
          </div>

          {/* Explicação Curta e Simples */}
          <div className="mt-2.5 rounded-xl bg-slate-900/60 p-2.5 border border-slate-800 text-slate-300 leading-relaxed">
            <div className="flex items-start gap-1.5">
              <Info className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">Como funciona na prática:</strong> O IRRF incide somente sobre a base líquida (Bruto − INSS). Em 2026, quem tem rendimentos de até <strong className="text-emerald-400">R$ 5.000,00</strong> possui <strong className="text-emerald-400">isenção completa</strong> de imposto retido.
              </div>
            </div>
          </div>

          {/* Status Atual do Usuário */}
          <div className="mt-3 rounded-xl bg-slate-900/80 p-2.5 border border-slate-800">
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <span className="block text-[10px] text-slate-400 uppercase font-bold">Base IRRF</span>
                <span className="text-xs font-black text-white">{fmtBRL(baseCalculo)}</span>
                <span className="block text-[9px] text-slate-500">Bruto − INSS</span>
              </div>
              <div>
                <span className="block text-[10px] text-slate-400 uppercase font-bold">Desconto IRRF</span>
                <span className={`text-xs font-black ${isExempt ? "text-emerald-400" : "text-rose-400"}`}>
                  {isExempt ? "R$ 0,00" : `-${fmtBRL(irrfValue)}`}
                </span>
                <span className="block text-[9px] text-slate-500">{isExempt ? "ISENTO" : "Retenção mensal"}</span>
              </div>
              <div>
                <span className="block text-[10px] text-slate-400 uppercase font-bold">Alíquota Efetiva</span>
                <span className="text-xs font-black text-amber-200">
                  {isExempt ? "0,00%" : `${effectiveRateStr}%`}
                </span>
                <span className="block text-[9px] text-slate-500">Desconto real</span>
              </div>
            </div>

            {isExempt && (
              <div className="mt-2 flex items-center justify-center gap-1.5 rounded-lg bg-emerald-500/15 py-1 px-2 text-[11px] font-bold text-emerald-300 border border-emerald-500/25">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>Seu rendimento está dentro da faixa de isenção de 2026</span>
              </div>
            )}
          </div>

          {/* Tabela Progressiva Oficial */}
          <div className="mt-3 space-y-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Faixas Oficiais da Receita Federal:
            </span>
            {IRRF_BRACKETS_INFO.map((item, idx) => {
              const activeBracket =
                !isExempt &&
                ((idx === 1 && baseCalculo <= 2826.65) ||
                  (idx === 2 && baseCalculo > 2826.65 && baseCalculo <= 3751.05) ||
                  (idx === 3 && baseCalculo > 3751.05 && baseCalculo <= 4664.68) ||
                  (idx === 4 && baseCalculo > 4664.68));

              return (
                <div
                  key={item.faixa}
                  className={`flex items-center justify-between rounded-xl px-2.5 py-1.5 text-[11px] border transition ${
                    activeBracket
                      ? "bg-amber-500/15 border-amber-400/40 text-amber-100"
                      : "bg-slate-900/40 border-slate-800/80 text-slate-400"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`font-black rounded px-1.5 py-0.5 text-[10px] ${
                        activeBracket
                          ? "bg-amber-500/30 text-amber-200 border border-amber-400/30"
                          : "bg-slate-800 text-slate-500"
                      }`}
                    >
                      {item.rate}
                    </span>
                    <span className="font-semibold">{item.range}</span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-slate-400">Deduz: {item.deducao}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Resumo Final */}
          <div className="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-[11px] px-1 text-slate-300">
            <span>Regra de Isenção 2026: <strong className="text-emerald-400">Até R$ 5.000,00</strong></span>
            <span>Retenção no Mês: <strong className={isExempt ? "text-emerald-400" : "text-rose-400"}>{fmtBRL(irrfValue)}</strong></span>
          </div>
        </div>
      )}
    </div>
  );
}
