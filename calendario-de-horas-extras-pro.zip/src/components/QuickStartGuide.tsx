import { useState } from "react";
import {
  BookOpen,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { cn } from "../utils/cn";

export interface QuickStartGuideProps {
  onOpenAccount?: () => void;
  onOpenConfig?: () => void;
  onOpenBiometria?: () => void;
  onOpenMenu?: () => void;
  onOpenShare?: () => void;
  isSyncing?: boolean;
  className?: string;
}

export default function QuickStartGuide({
  onOpenAccount,
  onOpenConfig,
  onOpenBiometria,
  onOpenMenu,
  onOpenShare,
  isSyncing = false,
  className = "",
}: QuickStartGuideProps) {
  // Por padrão aberto para novos usuários, com chave no localStorage para persistir fechamento caso desejado
  const [isOpen, setIsOpen] = useState(() => {
    try {
      const saved = localStorage.getItem("che_guia_como_usar_aberto");
      return saved !== null ? saved === "true" : true;
    } catch {
      return true;
    }
  });

  const toggle = () => {
    setIsOpen((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("che_guia_como_usar_aberto", String(next));
      } catch {}
      return next;
    });
  };

  return (
    <div
      id="guia-como-usar"
      className={cn(
        "rounded-2xl border transition-all duration-300 shadow-lg",
        isOpen
          ? "border-indigo-500/40 bg-gradient-to-b from-slate-900/95 via-[#0e1630]/95 to-[#080d1c]/95 p-4 sm:p-5"
          : "border-slate-700/60 bg-slate-900/70 p-3",
        className
      )}
    >
      {/* CABEÇALHO DO GUIA */}
      <div
        onClick={toggle}
        className="flex items-center justify-between gap-3 cursor-pointer select-none group"
      >
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500/25 to-violet-600/25 text-indigo-300 ring-1 ring-indigo-400/40 group-hover:scale-105 transition-transform">
            <BookOpen className="h-5 w-5" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-black text-white tracking-tight flex items-center gap-1.5">
                <span>📖 COMO USAR — Passo a Passo</span>
              </h3>
              <span className="rounded-full bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300 border border-indigo-400/30">
                Guia Rápido
              </span>
            </div>
            {!isOpen && (
              <p className="text-[11px] text-slate-400 truncate mt-0.5">
                Clique para ver os 5 passos para registrar ponto, lançar horas extras e gerar cálculos
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <span className="text-[11px] font-bold text-slate-400 group-hover:text-slate-200 transition-colors hidden sm:inline">
            {isOpen ? "Minimizar" : "Abrir Guia"}
          </span>
          <div className="flex h-7 w-7 items-center justify-center rounded-lg border border-slate-700/70 bg-slate-800/80 text-slate-300 group-hover:text-white transition">
            {isOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </div>
        </div>
      </div>

      {/* CONTEÚDO EXPANDIDO: OS 5 PASSOS DEFINIDOS NO BRIEFING */}
      {isOpen && (
        <div className="mt-3.5 space-y-2.5 pt-3 border-t border-slate-800/80">
          {/* Passo 1: DADOS */}
          <div
            onClick={onOpenAccount}
            className="flex items-start gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] p-2.5 sm:p-3 transition hover:border-indigo-400/40 hover:bg-slate-800/50 cursor-pointer group"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-500/20 text-indigo-300 font-black text-xs ring-1 ring-indigo-400/30">
              1️⃣
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-black text-white group-hover:text-indigo-200 transition-colors">
                  DADOS
                </span>
                <span className="text-[10px] font-bold text-indigo-300/80 group-hover:text-indigo-300">
                  Toque para conferir →
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-snug">
                Confirme seu nome, cargo, empresa e salário base para cálculo automático.
              </p>
            </div>
          </div>

          {/* Passo 2: CONFIG */}
          <div
            onClick={onOpenConfig}
            className="flex items-start gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] p-2.5 sm:p-3 transition hover:border-violet-400/40 hover:bg-slate-800/50 cursor-pointer group"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-violet-500/20 text-violet-300 font-black text-xs ring-1 ring-violet-400/30">
              2️⃣
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-black text-white group-hover:text-violet-200 transition-colors">
                  CONFIG
                </span>
                <span className="text-[10px] font-bold text-violet-300/80 group-hover:text-violet-300">
                  Ajustar jornada →
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-snug">
                Defina sua jornada (220h, 180h ou personalizada), horário de entrada (06:00) e adicionais (insalubridade/noturno).
              </p>
            </div>
          </div>

          {/* Passo 3: PONTO */}
          <div
            onClick={onOpenBiometria}
            className="flex items-start gap-3 rounded-xl border border-cyan-500/25 bg-cyan-500/[0.04] p-2.5 sm:p-3 transition hover:border-cyan-400/50 hover:bg-cyan-500/10 cursor-pointer group"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-cyan-500/20 text-cyan-300 font-black text-xs ring-1 ring-cyan-400/30">
              3️⃣
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-black text-white group-hover:text-cyan-200 transition-colors">
                  PONTO BIOMÉTRICO
                </span>
                <span className="text-[10px] font-bold text-cyan-300">
                  Bater ponto agora →
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-snug">
                Registre entrada → intervalo → retorno → saída com biometria ou lançamento manual.
              </p>
            </div>
          </div>

          {/* Passo 4: LANÇAMENTOS */}
          <div
            onClick={onOpenMenu}
            className="flex items-start gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] p-2.5 sm:p-3 transition hover:border-emerald-400/40 hover:bg-slate-800/50 cursor-pointer group"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-300 font-black text-xs ring-1 ring-emerald-400/30">
              4️⃣
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-black text-white group-hover:text-emerald-200 transition-colors">
                  LANÇAMENTOS
                </span>
                <span className="text-[10px] font-bold text-emerald-300/80 group-hover:text-emerald-300">
                  Lançar horas →
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-snug">
                Inclua as horas extras realizadas: são calculadas automaticamente nas faixas de 60%, 75% e 100%.
              </p>
            </div>
          </div>

          {/* Passo 5: RELATÓRIO */}
          <div
            onClick={onOpenShare}
            className="flex items-start gap-3 rounded-xl border border-white/[0.07] bg-white/[0.03] p-2.5 sm:p-3 transition hover:border-amber-400/40 hover:bg-slate-800/50 cursor-pointer group"
          >
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-amber-500/20 text-amber-300 font-black text-xs ring-1 ring-amber-400/30">
              5️⃣
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs sm:text-sm font-black text-white group-hover:text-amber-200 transition-colors">
                  RELATÓRIO & PDF
                </span>
                <span className="text-[10px] font-bold text-amber-300/80 group-hover:text-amber-300">
                  Visualizar relatório →
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5 leading-snug">
                Confira o cálculo detalhado de proventos, DSR, INSS e exporte o espelho em PDF ou compartilhe.
              </p>
            </div>
          </div>

          {/* RODAPÉ DO GUIA: SINCRONIZAÇÃO NA NUVEM */}
          <div className="flex items-center justify-between gap-2 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-xs text-emerald-300">
            <div className="flex items-center gap-2">
              <span className="text-base">🔄</span>
              <span className="font-bold">
                Sincronização automática na nuvem a cada alteração
              </span>
            </div>
            {isSyncing && (
              <span className="text-[10px] font-bold bg-emerald-400/20 px-2 py-0.5 rounded-full animate-pulse">
                Sincronizando...
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
