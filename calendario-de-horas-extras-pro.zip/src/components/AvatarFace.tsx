import { useId } from "react";
import type { AvatarSpec, BeardStyle, HairStyle } from "../lib/avatars";

function shade(hex: string, amount: number) {
  const n = hex.replace("#", "");
  const num = parseInt(n.length === 3 ? n.split("").map((c) => c + c).join("") : n, 16);
  const r = Math.min(255, Math.max(0, ((num >> 16) & 255) + amount));
  const g = Math.min(255, Math.max(0, ((num >> 8) & 255) + amount));
  const b = Math.min(255, Math.max(0, (num & 255) + amount));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

function Hair({ style, color }: { style: HairStyle; color: string }) {
  const dark = shade(color, -28);
  if (style === "bald") return null;
  if (style === "buzz") {
    return <ellipse cx="40" cy="30" rx="18.5" ry="16.5" fill={color} opacity="0.55" />;
  }
  if (style === "short") {
    return (
      <path
        fill={color}
        d="M21 36c1-14 9-22 19-22s18 8 19 22c-3-8-9-12-19-12S24 28 21 36Z"
      />
    );
  }
  if (style === "wavy") {
    return (
      <path
        fill={color}
        d="M19 38c0-14 8-24 21-24 13 0 21 10 21 24-2-9-6-14-12-16 1 5-2 8-6 8s-7-3-6-8c-6 2-12 8-18 16Z"
      />
    );
  }
  if (style === "curly") {
    return (
      <g fill={color}>
        <circle cx="26" cy="22" r="6.2" />
        <circle cx="34" cy="16" r="6.4" />
        <circle cx="44" cy="15" r="6.6" />
        <circle cx="54" cy="21" r="6.2" />
        <circle cx="22" cy="30" r="5.4" />
        <circle cx="58" cy="30" r="5.4" />
        <circle cx="40" cy="20" r="5.8" />
      </g>
    );
  }
  if (style === "afro") {
    return (
      <g fill={color}>
        <circle cx="40" cy="28" r="24" />
        <circle cx="22" cy="22" r="10" />
        <circle cx="58" cy="22" r="10" />
        <circle cx="18" cy="34" r="8" />
        <circle cx="62" cy="34" r="8" />
        <circle cx="28" cy="14" r="8" />
        <circle cx="52" cy="14" r="8" />
      </g>
    );
  }
  if (style === "long") {
    return (
      <g>
        <path
          fill={color}
          d="M18 34c1-16 10-24 22-24s21 8 22 24v28c-4-8-10-12-22-12S22 54 18 62V34Z"
        />
        <path fill={dark} d="M21 34c1-13 9-20 19-20s18 7 19 20c-4-7-10-11-19-11S25 27 21 34Z" />
      </g>
    );
  }
  if (style === "bun") {
    return (
      <g fill={color}>
        <circle cx="40" cy="14" r="8.5" />
        <path d="M21 36c1-13 9-20 19-20s18 7 19 20c-3-8-9-12-19-12S24 28 21 36Z" />
      </g>
    );
  }
  return (
    <g fill={color}>
      <path d="M32 14c0-8 4-12 8-12s8 4 8 12v10H32V14Z" />
      <path d="M22 36c1-10 8-16 18-16s17 6 18 16c-4-6-10-9-18-9S26 30 22 36Z" />
    </g>
  );
}

function Beard({ style, color, skin }: { style: BeardStyle; color: string; skin: string }) {
  if (style === "none") return null;
  if (style === "mustache") {
    return (
      <path
        fill={color}
        d="M28 54c4-4 8-5 12-5s8 1 12 5c-4-1-8-2-12-2s-8 1-12 2Z"
      />
    );
  }
  if (style === "goatee") {
    return (
      <g fill={color}>
        <path d="M28 54c4-3 8-4 12-4s8 1 12 4c-4-1-8-2-12-2s-8 1-12 2Z" />
        <ellipse cx="40" cy="62" rx="4.2" ry="5.5" />
      </g>
    );
  }
  if (style === "beard") {
    return (
      <path
        fill={color}
        d="M24 50c2 12 8 18 16 18s14-6 16-18c-3 4-9 7-16 7s-13-3-16-7Z"
      />
    );
  }
  return (
    <g>
      <path
        fill={color}
        d="M22 46c1 16 9 24 18 24s17-8 18-24c-3 8-10 13-18 13s-15-5-18-13Z"
      />
      <ellipse cx="40" cy="52" rx="7" ry="3.2" fill={skin} opacity="0.35" />
    </g>
  );
}

export default function AvatarFace({
  spec,
  className,
}: {
  spec: AvatarSpec;
  className?: string;
}) {
  // id único por instância: o mesmo avatar pode aparecer no cabeçalho, no
  // cartão e na galeria ao mesmo tempo — ids repetidos quebravam o fundo
  // quando uma das cópias saía da tela.
  const gid = `avatar-bg-${useId().replace(/:/g, "")}`;
  const skinDark = shade(spec.skin, -22);
  const skinLight = shade(spec.skin, 18);
  const shirtDark = shade(spec.shirt, -30);
  const helmet = spec.work === "helmetY" ? "#FACC15" : spec.work === "helmetW" ? "#F8FAFC" : "";
  const cap = spec.work === "cap";
  const scarf = spec.work === "scarf";

  return (
    <svg viewBox="0 0 80 80" className={className} aria-hidden>
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={spec.bgFrom} />
          <stop offset="100%" stopColor={spec.bgTo} />
        </linearGradient>
      </defs>
      <rect width="80" height="80" rx="18" fill={`url(#${gid})`} />

      {/* camisa */}
      <path fill={spec.shirt} d="M10 80c6-16 16-24 30-24s24 8 30 24H10Z" />
      <path fill={shirtDark} d="M32 62h16v18H32Z" opacity="0.35" />

      {/* pescoço */}
      <rect x="33" y="52" width="14" height="12" rx="4" fill={skinDark} />

      {/* orelhas */}
      <ellipse cx="21.5" cy="40" rx="4.2" ry="5.4" fill={spec.skin} />
      <ellipse cx="58.5" cy="40" rx="4.2" ry="5.4" fill={spec.skin} />

      {/* cabelo atrás (afro/longo) */}
      {(spec.hair === "afro" || spec.hair === "long" || spec.hair === "curly") && (
        <Hair style={spec.hair} color={spec.hairColor} />
      )}

      {/* cabeça */}
      <ellipse cx="40" cy="38" rx="18" ry="20" fill={spec.skin} />
      <ellipse cx="33" cy="36" rx="6" ry="8" fill={skinLight} opacity="0.35" />

      {/* cabelo na frente */}
      {spec.hair !== "afro" && spec.hair !== "long" && spec.hair !== "curly" && (
        <Hair style={spec.hair} color={spec.hairColor} />
      )}
      {spec.hair === "long" && (
        <path
          fill={spec.hairColor}
          d="M22 34c1-12 8-18 18-18s17 6 18 18c-3-7-9-11-18-11S25 27 22 34Z"
        />
      )}

      {/* olhos */}
      <ellipse cx="33" cy="39" rx="2.4" ry="2.8" fill="#1E293B" />
      <ellipse cx="47" cy="39" rx="2.4" ry="2.8" fill="#1E293B" />
      <circle cx="33.7" cy="38.2" r="0.7" fill="#fff" />
      <circle cx="47.7" cy="38.2" r="0.7" fill="#fff" />

      {/* sobrancelhas */}
      <path d="M29 34.2c2.4-1.6 6-1.6 8.2 0" stroke={shade(spec.hairColor, -10)} strokeWidth="1.5" fill="none" strokeLinecap="round" />
      <path d="M42.8 34.2c2.4-1.6 6-1.6 8.2 0" stroke={shade(spec.hairColor, -10)} strokeWidth="1.5" fill="none" strokeLinecap="round" />

      {/* nariz */}
      <path d="M40 40.5c1.6 2.4 1.6 4.2 0 5.4" stroke={skinDark} strokeWidth="1.4" fill="none" strokeLinecap="round" />

      {/* boca */}
      <path d="M35 51.5c2.4 2.4 7.6 2.4 10 0" stroke="#B45309" strokeWidth="1.5" fill="none" strokeLinecap="round" />

      <Beard style={spec.beard} color={spec.hairColor} skin={spec.skin} />

      {/* óculos */}
      {spec.glasses === "degree" && (
        <g fill="none" stroke="#1E293B" strokeWidth="1.6">
          <circle cx="33" cy="39.2" r="6.2" />
          <circle cx="47" cy="39.2" r="6.2" />
          <path d="M39.2 39.2h1.6" />
          <path d="M26.8 39.2h-4.2M53.2 39.2h4.2" />
        </g>
      )}
      {spec.glasses === "sun" && (
        <g>
          <ellipse cx="33" cy="39.2" rx="6.4" ry="5.6" fill="#111827" />
          <ellipse cx="47" cy="39.2" rx="6.4" ry="5.6" fill="#111827" />
          <path d="M39.4 39.2h1.2" stroke="#111827" strokeWidth="1.8" />
          <path d="M26.6 39.2h-4M53.4 39.2h4" stroke="#111827" strokeWidth="1.8" />
          <ellipse cx="31.5" cy="37.6" rx="2" ry="1.2" fill="#fff" opacity="0.18" />
        </g>
      )}

      {/* lenço */}
      {scarf && (
        <g>
          <path fill="#BE123C" d="M20 30c4-12 12-16 20-16s16 4 20 16c-6-6-13-8-20-8s-14 2-20 8Z" />
          <path fill="#9F1239" d="M22 28c8 6 28 6 36 0-4 8-12 12-18 12s-14-4-18-12Z" opacity="0.5" />
        </g>
      )}

      {/* boné */}
      {cap && (
        <g>
          <path fill="#1E3A8A" d="M22 32c2-14 10-20 18-20s16 6 18 20H22Z" />
          <path fill="#1E40AF" d="M18 32h48c-2 4-8 6-24 6S20 36 18 32Z" />
          <ellipse cx="40" cy="18" rx="7" ry="3" fill="#312E81" />
        </g>
      )}

      {/* capacete */}
      {helmet && (
        <g>
          <path fill={helmet} d="M20 34c2-16 10-22 20-22s18 6 20 22H20Z" />
          <path fill={shade(helmet, -25)} d="M16 34h48c-2 3-10 5-24 5S18 37 16 34Z" />
          <rect x="38" y="14" width="4" height="8" rx="1" fill={shade(helmet, -40)} />
        </g>
      )}
    </svg>
  );
}
