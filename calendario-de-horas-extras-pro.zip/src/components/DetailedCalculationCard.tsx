import { useState, useEffect } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Moon,
  Percent,
  ShieldAlert,
} from "lucide-react";
import InssExplanation from "./InssExplanation";
import IrrfExplanation from "./IrrfExplanation";
import DsrExplanation from "./DsrExplanation";
import {
  MESES,
  fmtBRL,
  fmtH,
  horaBase,
  type MonthStats,
  type Settings,
  type SimState,
} from "../lib/calc";
import { cn } from "../utils/cn";

export interface DetailedCalculationCardProps {
  month: number;
  year: number;
  settings: Settings;
  stats: MonthStats;
  sim?: SimState;
  avancado?: boolean;
  onUpdateSettings: (patch: Partial<Settings>, immediate?: boolean) => void;
  defaultExpanded?: boolean;
  className?: string;
  sourceLabel?: string;
}

export default function DetailedCalculationCard({
  month,
  year,
  settings,
  stats,
  sim,
  avancado: _avancado = false,
  onUpdateSettings,
  defaultExpanded = false,
  className = "",
  sourceLabel,
}: DetailedCalculationCardProps) {
  // Entra no Modo Simplificado ativado por padrão quando settings.modo === "desativado"
  const [isExpanded, setIsExpanded] = useState(() => {
    if (settings.modo === "desativado") return false;
    if (settings.modo === "avancado") return true;
    return defaultExpanded;
  });

  // Sincroniza quando o usuário alternar o modo global no painel ou cabeçalho
  useEffect(() => {
    if (settings.modo === "desativado") {
      setIsExpanded(false);
    } else if (settings.modo === "avancado") {
      setIsExpanded(true);
    }
  }, [settings.modo]);

  // Estado local para o botão e campo de % digitável de Outros Descontos
  const [discountDraft, setDiscountDraft] = useState(() =>
    String(settings.otherDiscounts !== undefined ? settings.otherDiscounts : 0)
  );
  const [discountFocused, setDiscountFocused] = useState(false);
  // Aba Outros Descontos mantida minimizada por padrão no Modo Avançado
  const [isDiscountsOpen, setIsDiscountsOpen] = useState(false);

  useEffect(() => {
    if (!discountFocused) {
      setDiscountDraft(
        String(settings.otherDiscounts !== undefined ? settings.otherDiscounts : 0)
      );
    }
  }, [settings.otherDiscounts, discountFocused]);

  const handleDiscountChange = (valStr: string) => {
    const cleaned = valStr.replace(/[^0-9.,]/g, "");
    setDiscountDraft(cleaned);

    const parsed = parseFloat(cleaned.replace(",", "."));
    if (!isNaN(parsed) && parsed >= 0) {
      const clamped = Math.min(100, parsed);
      onUpdateSettings(
        {
          otherDiscounts: clamped,
          otherDiscountsMode: "%",
        },
        true
      );
    }
  };

  const handleDiscountBlur = () => {
    setDiscountFocused(false);
    const parsed = parseFloat(discountDraft.replace(",", "."));
    if (isNaN(parsed) || parsed <= 0) {
      setDiscountDraft("0");
      onUpdateSettings({ otherDiscounts: 0, otherDiscountsMode: "%" }, true);
    } else {
      const clamped = Math.min(100, Math.max(0, Math.round(parsed * 100) / 100));
      setDiscountDraft(String(clamped));
      onUpdateSettings({ otherDiscounts: clamped, otherDiscountsMode: "%" }, true);
    }
  };

  const handleDiscountBump = (delta: number) => {
    const current = typeof settings.otherDiscounts === "number" ? settings.otherDiscounts : 0;
    const next = Math.min(100, Math.max(0, Math.round((current + delta) * 10) / 10));
    setDiscountDraft(String(next));
    onUpdateSettings({ otherDiscounts: next, otherDiscountsMode: "%" }, true);
  };

  const handleDiscountPreset = (pct: number) => {
    setDiscountDraft(String(pct));
    onUpdateSettings({ otherDiscounts: pct, otherDiscountsMode: "%" }, true);
  };

  const monthName = MESES[month] || "Mês Atual";
  const vHora = horaBase(settings.salary, settings.jornada);

  // Faixas de horas extras
  const pctWeekday = sim?.weekday?.pct ?? 60;
  const pctSaturday = sim?.saturday?.pct ?? 75;
  const pctSunday = sim?.sunday?.pct ?? 100;

  const vHoraWeekday = vHora * (1 + pctWeekday / 100);
  const vHoraSaturday = vHora * (1 + pctSaturday / 100);
  const vHoraSunday = vHora * (1 + pctSunday / 100);

  const simWeekdayHours = sim?.weekday
    ? (Number(sim.weekday.hours) || 0) + (Number(sim.weekday.minutes) || 0) / 60
    : 0;
  const simSaturdayHours = sim?.saturday
    ? (Number(sim.saturday.hours) || 0) + (Number(sim.saturday.minutes) || 0) / 60
    : 0;
  const simSundayHours = sim?.sunday
    ? (Number(sim.sunday.hours) || 0) + (Number(sim.sunday.minutes) || 0) / 60
    : 0;

  const hoursWeekday = (stats.hoursByBand?.weekday ?? 0) > 0 ? stats.hoursByBand.weekday : simWeekdayHours;
  const hoursSaturday = (stats.hoursByBand?.saturday ?? 0) > 0 ? stats.hoursByBand.saturday : simSaturdayHours;
  const hoursSunday =
    ((stats.hoursByBand?.sunday ?? 0) + (stats.hoursByBand?.holiday ?? 0)) > 0
      ? (stats.hoursByBand.sunday + (stats.hoursByBand.holiday ?? 0))
      : simSundayHours;

  const valWeekday =
    (stats.valueByBand?.weekday ?? 0) > 0 ? stats.valueByBand.weekday : hoursWeekday * vHoraWeekday;
  const valSaturday =
    (stats.valueByBand?.saturday ?? 0) > 0 ? stats.valueByBand.saturday : hoursSaturday * vHoraSaturday;
  const valSunday =
    ((stats.valueByBand?.sunday ?? 0) + (stats.valueByBand?.holiday ?? 0)) > 0
      ? (stats.valueByBand.sunday + (stats.valueByBand.holiday ?? 0))
      : hoursSunday * vHoraSunday;

  // Noturno
  const noturnoPct = settings.noturnoPct ?? 20;
  const noturnoRate = vHora * (noturnoPct / 100);
  const noturnoHours = (sim?.weekday?.noturno ? hoursWeekday : 0) +
                       (sim?.saturday?.noturno ? hoursSaturday : 0) +
                       (sim?.sunday?.noturno ? hoursSunday : 0);
  const noturnoVal = settings.noturnoEnabled ? noturnoHours * noturnoRate : 0;

  // Insalubridade: CLT Art. 192 (Mínimo 10%, Médio 20%, Máximo 40%)
  const insalubridadeGraus = [
    { grau: "Mínimo", pct: 10 },
    { grau: "Médio", pct: 20 },
    { grau: "Máximo", pct: 40 },
  ] as const;

  const currentInsalubGrau =
    settings.insalubridadePct === 10
      ? "Mínimo (10%)"
      : settings.insalubridadePct === 20
      ? "Médio (20%)"
      : settings.insalubridadePct === 40
      ? "Máximo (40%)"
      : `${settings.insalubridadePct ?? 20}%`;

  // Card do Total de Horas Extras Somadas com DSR e Adicional Noturno interativos
  const renderTotalHECard = () => {
    const isDsrActive = settings.dsrEnabled;
    const isNoturnoActive = settings.noturnoEnabled;
    const totalHEComDsr = stats.totalHE + (isDsrActive ? stats.dsr : 0);
    return (
      <div className="rounded-2xl border-2 border-yellow-400/80 bg-gradient-to-r from-yellow-500/20 via-amber-500/15 to-yellow-500/20 p-4 shadow-xl shadow-yellow-950/40 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="h-2.5 w-2.5 rounded-full bg-yellow-400 shrink-0 animate-pulse" />
              <span className="text-sm sm:text-base font-black uppercase tracking-wider text-yellow-300">
                Total de Horas Extras Somadas {isDsrActive ? "+ DSR" : ""}
              </span>
              <span
                className={cn(
                  "rounded-md border px-2 py-0.5 text-[11px] font-black",
                  isDsrActive
                    ? "bg-yellow-400/20 border-yellow-400/50 text-yellow-200"
                    : "bg-slate-800/80 border-slate-600 text-slate-300"
                )}
              >
                {isDsrActive ? "HE + DSR" : "Apenas HE"}
              </span>
              <span
                className={cn(
                  "rounded-md border px-2 py-0.5 text-[11px] font-black flex items-center gap-1",
                  isNoturnoActive
                    ? "bg-indigo-500/25 border-indigo-400/50 text-indigo-200"
                    : "bg-slate-800/80 border-slate-600 text-slate-400"
                )}
              >
                <Moon className="h-3 w-3" />
                {isNoturnoActive ? `Noturno +${noturnoPct}%` : "Noturno Desligado"}
              </span>
            </div>
            <p className="text-xs text-yellow-200/80 font-medium mt-1">
              Soma das faixas (<strong className="text-white font-bold">{fmtH(stats.totalHours)}</strong>){" "}
              {isDsrActive ? "+ reflexo do DSR no mês" : "(sem reflexo do DSR)"}
              {isNoturnoActive ? ` • Adicional noturno ativo (+${noturnoPct}%)` : ""}
            </p>
          </div>

          <div className="flex items-center gap-2.5 ml-auto flex-wrap justify-end">
            {/* Botão de Ativar ou Desativar DSR */}
            <button
              type="button"
              onClick={() => onUpdateSettings({ dsrEnabled: !isDsrActive }, true)}
              className={cn(
                "flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-black transition shadow-sm active:scale-95 cursor-pointer border",
                isDsrActive
                  ? "bg-sky-500 text-slate-950 border-sky-300 shadow-sky-950/50 hover:bg-sky-400"
                  : "bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700 hover:text-white"
              )}
              title={isDsrActive ? "Clique para desativar o cálculo do DSR" : "Clique para ativar o cálculo do DSR"}
            >
              <span
                className={cn(
                  "h-2 w-2 rounded-full",
                  isDsrActive ? "bg-slate-950 animate-pulse" : "bg-slate-500"
                )}
              />
              <span>DSR {isDsrActive ? "Ativo" : "Inativo"}</span>
            </button>

            {/* Botão de Ligar e Desligar Adicional Noturno */}
            <button
              type="button"
              onClick={() => onUpdateSettings({ noturnoEnabled: !isNoturnoActive }, true)}
              className={cn(
                "flex items-center gap-2 rounded-xl px-3 py-2 text-xs font-black transition shadow-sm active:scale-95 cursor-pointer border",
                isNoturnoActive
                  ? "bg-indigo-600 text-white border-indigo-300 shadow-indigo-950/50 hover:bg-indigo-500"
                  : "bg-slate-800 text-slate-300 border-slate-600 hover:bg-slate-700 hover:text-white"
              )}
              title={isNoturnoActive ? "Clique para desligar o Adicional Noturno" : "Clique para ligar o Adicional Noturno"}
            >
              <Moon
                className={cn(
                  "h-3.5 w-3.5",
                  isNoturnoActive ? "text-yellow-300 fill-yellow-300/40" : "text-slate-400"
                )}
              />
              <span>Noturno {isNoturnoActive ? "Ligado" : "Desligado"}</span>
            </button>

            <div className="text-right">
              <span className="num font-black text-2xl sm:text-3xl text-yellow-300 tracking-tight">
                {fmtBRL(totalHEComDsr)}
              </span>
              <div className="text-[11px] text-yellow-200/80 font-semibold">
                {isDsrActive ? "Total somado com DSR" : "Total sem DSR"}
              </div>
            </div>
          </div>
        </div>

        {/* Discriminação detalhada: Horas Extras + DSR + Adicional Noturno */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2.5 border-t border-yellow-400/20 text-xs sm:text-sm">
          <div className="flex items-center justify-between rounded-xl bg-slate-950/70 px-3.5 py-2.5 border border-yellow-400/25">
            <span className="text-slate-300 font-medium">
              Horas extras apuradas ({fmtH(stats.totalHours)}):
            </span>
            <strong className="num text-white font-black text-sm sm:text-base">
              {fmtBRL(stats.totalHE)}
            </strong>
          </div>
          <div
            className={cn(
              "flex items-center justify-between rounded-xl px-3.5 py-2.5 border transition",
              isDsrActive
                ? "bg-sky-950/60 border-sky-400/35"
                : "bg-slate-950/60 border-slate-700/60"
            )}
          >
            <div className="flex items-center gap-1.5">
              <span
                className={cn(
                  "font-medium",
                  isDsrActive ? "text-sky-200" : "text-slate-400"
                )}
              >
                {isDsrActive ? "(+) Reflexo DSR:" : "Reflexo DSR:"}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <strong
                className={cn(
                  "num font-black text-sm sm:text-base",
                  isDsrActive ? "text-sky-300" : "text-slate-500 line-through"
                )}
              >
                {isDsrActive ? `+${fmtBRL(stats.dsr)}` : "Desativado"}
              </strong>
              <button
                type="button"
                onClick={() => onUpdateSettings({ dsrEnabled: !isDsrActive }, true)}
                className={cn(
                  "text-[10px] font-black px-2 py-0.5 rounded-md transition active:scale-95 border cursor-pointer",
                  isDsrActive
                    ? "bg-sky-400/20 text-sky-200 border-sky-400/40 hover:bg-sky-400/30"
                    : "bg-emerald-500/20 text-emerald-300 border-emerald-400/40 hover:bg-emerald-500/30"
                )}
              >
                {isDsrActive ? "Desativar" : "Ativar"}
              </button>
            </div>
          </div>
          <div
            className={cn(
              "flex items-center justify-between rounded-xl px-3.5 py-2.5 border transition",
              isNoturnoActive
                ? "bg-indigo-950/60 border-indigo-400/35"
                : "bg-slate-950/60 border-slate-700/60"
            )}
          >
            <div className="flex items-center gap-1.5">
              <Moon className={cn("h-3.5 w-3.5", isNoturnoActive ? "text-yellow-300" : "text-slate-500")} />
              <span
                className={cn(
                  "font-medium",
                  isNoturnoActive ? "text-indigo-200" : "text-slate-400"
                )}
              >
                Noturno ({noturnoPct}%):
              </span>
            </div>
            <div className="flex items-center gap-2">
              <strong
                className={cn(
                  "num font-black text-sm sm:text-base",
                  isNoturnoActive ? "text-indigo-300" : "text-slate-500 line-through"
                )}
              >
                {isNoturnoActive ? (noturnoVal > 0 ? `+${fmtBRL(noturnoVal)}` : "Ligado") : "Desligado"}
              </strong>
              <button
                type="button"
                onClick={() => onUpdateSettings({ noturnoEnabled: !isNoturnoActive }, true)}
                className={cn(
                  "text-[10px] font-black px-2 py-0.5 rounded-md transition active:scale-95 border cursor-pointer",
                  isNoturnoActive
                    ? "bg-indigo-400/20 text-indigo-200 border-indigo-400/40 hover:bg-indigo-400/30"
                    : "bg-indigo-500/30 text-indigo-200 border-indigo-400/50 hover:bg-indigo-500/40"
                )}
              >
                {isNoturnoActive ? "Desligar" : "Ligar"}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div
      id="card-calculo-detalhado"
      className={cn("scroll-mt-4 rounded-2xl border transition-all duration-300 shadow-xl", className, {
        "border-indigo-500/40 bg-gradient-to-b from-slate-900 via-slate-900/95 to-[#080d1c] p-4 sm:p-6": isExpanded,
        "border-slate-700/60 bg-slate-900/80 p-4": !isExpanded,
      })}
    >
      {/* CABEÇALHO / SUMÁRIO MINIMIZADO */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div
          onClick={() => {
            const next = !isExpanded;
            setIsExpanded(next);
            onUpdateSettings({ modo: next ? "avancado" : "desativado" }, true);
          }}
          className="flex items-center gap-3 min-w-0 cursor-pointer flex-1 select-none"
        >
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 text-emerald-300 ring-1 ring-emerald-400/40 shadow-sm shadow-emerald-500/20">
            <span className="text-xl">💰</span>
          </div>

          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white uppercase">
                RESUMO DO MÊS & CÁLCULO DETALHADO — {monthName.toUpperCase()}/{year}
              </h3>
              <span className="inline-flex items-center gap-1 rounded-full border border-emerald-400/30 bg-emerald-500/15 px-2.5 py-0.5 text-[11px] font-black text-emerald-300 shadow-sm">
                <CheckCircle2 className="h-3 w-3" />
                Líquido: {fmtBRL(stats.liquido)}
              </span>
              <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/30 bg-amber-500/15 px-2.5 py-0.5 text-[11px] font-black text-amber-300 shadow-sm">
                HE: {fmtBRL(stats.totalHE)}
              </span>
              {settings.otherDiscounts > 0 && (
                <span className="inline-flex items-center gap-1 rounded-full border border-rose-400/30 bg-rose-500/15 px-2.5 py-0.5 text-[11px] font-black text-rose-300 shadow-sm">
                  <Percent className="h-3 w-3" />
                  Desc: {settings.otherDiscounts}% (-{fmtBRL(stats.otherDiscountsVal)})
                </span>
              )}
              <span
                className={cn(
                  "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-black shadow-sm",
                  !isExpanded
                    ? "border-emerald-400/40 bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-400/30"
                    : "border-indigo-400/30 bg-indigo-500/15 text-indigo-200"
                )}
              >
                <span className={cn("h-1.5 w-1.5 rounded-full animate-pulse", !isExpanded ? "bg-emerald-400" : "bg-indigo-400")} />
                {!isExpanded ? "Modo Simplificado • Minimizado" : "Modo Detalhado"}
              </span>
            </div>

            <p className="text-xs text-slate-400 mt-0.5 truncate">
              {!isExpanded
                ? "Clique aqui para expandir o cálculo detalhado completo (faixas, adicionais, INSS e IRRF)"
                : (sourceLabel || "Demonstrativo completo de Proventos, Horas Extras, DSR e Descontos")}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => {
              const next = !isExpanded;
              setIsExpanded(next);
              onUpdateSettings({ modo: next ? "avancado" : "desativado" }, true);
            }}
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-black transition active:scale-95 shadow-md cursor-pointer",
              isExpanded
                ? "border border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
                : "border border-emerald-500/40 bg-gradient-to-r from-emerald-600/30 to-teal-600/30 text-emerald-200 hover:from-emerald-600/40 hover:to-teal-600/40 hover:border-emerald-400/60 ring-1 ring-emerald-400/30"
            )}
            title={isExpanded ? "Minimizar (Modo Simplificado)" : "Expandir Detalhes"}
          >
            <span>{isExpanded ? "Minimizar" : "Expandir Detalhes"}</span>
            {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* DETALHAMENTO EXPANDIDO (TELA DETALHADA COMPLETA QUANDO EXPANDIDO) */}
      {isExpanded && (
        <div className="mt-5 space-y-4 pt-4 border-t border-slate-800/80">
          {/* BLOCO 1: HORAS EXTRAS DISCRIMINADAS — 60%, 75% E 100% */}
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4 space-y-3.5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                1. TABELA DE HORAS EXTRAS DO MÊS (DISCRIMINAÇÃO CLT)
              </span>
              <span className="text-[11px] text-slate-400 font-semibold">
                Faixas de +{pctWeekday}% • +{pctSaturday}% • +{pctSunday}%
              </span>
            </div>

            {/* CARDS DAS FAIXAS COM ALTA VISIBILIDADE (60%, 75% E 100%) */}
            <div className="space-y-3">
              {/* Faixa 1: Dias Úteis (Seg–Sex) +60% */}
              <div className="rounded-2xl border-2 border-indigo-500/50 bg-gradient-to-r from-indigo-950/70 via-slate-900/80 to-indigo-950/50 p-3.5 sm:p-4 shadow-md transition hover:border-indigo-400/80">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2.5">
                    <span className="h-3 w-3 rounded-full bg-indigo-400 shrink-0 shadow-sm shadow-indigo-400/50 animate-pulse" />
                    <div className="flex items-center gap-2">
                      <span className="text-sm sm:text-base font-black text-white">
                        Dias Úteis (Seg–Sex)
                      </span>
                      <span className="rounded-lg bg-indigo-500/30 px-2.5 py-0.5 text-xs sm:text-sm font-black text-indigo-300 border border-indigo-400/60 shadow-sm">
                        +{pctWeekday}%
                      </span>
                    </div>
                  </div>

                  <div className="text-right ml-auto">
                    <div className="num text-xl sm:text-2xl font-black text-indigo-300 tracking-tight">
                      {fmtBRL(valWeekday)}
                    </div>
                  </div>
                </div>

                {/* Detalhes da Faixa (Horas e Valor da Hora) */}
                <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-950/70 border border-indigo-500/25 px-3 py-2 text-xs sm:text-sm">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span>Horas apuradas:</span>
                    <strong className="num text-white font-black text-sm">{fmtH(hoursWeekday)}</strong>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span>Valor da hora (+{pctWeekday}%):</span>
                    <strong className="num text-indigo-200 font-bold">{fmtBRL(vHoraWeekday)}/h</strong>
                  </div>
                  <div className="text-[11px] text-indigo-300/70 font-mono hidden xs:block">
                    {fmtH(hoursWeekday)} × {fmtBRL(vHoraWeekday)}
                  </div>
                </div>
              </div>

              {/* Faixa 2: Sábado (Fim de Semana) +75% */}
              <div className="rounded-2xl border-2 border-amber-500/60 bg-gradient-to-r from-amber-950/70 via-slate-900/80 to-amber-950/50 p-3.5 sm:p-4 shadow-lg shadow-amber-950/40 transition hover:border-amber-400/80">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2.5">
                    <span className="h-3 w-3 rounded-full bg-amber-400 shrink-0 shadow-sm shadow-amber-400/50 animate-pulse" />
                    <div className="flex items-center gap-2">
                      <span className="text-sm sm:text-base font-black text-amber-200">
                        Sábado (Fim de Semana)
                      </span>
                      <span className="rounded-lg bg-amber-500/30 px-2.5 py-0.5 text-xs sm:text-sm font-black text-amber-300 border border-amber-400/60 shadow-sm">
                        +{pctSaturday}%
                      </span>
                    </div>
                  </div>

                  <div className="text-right ml-auto">
                    <div className="num text-xl sm:text-2xl font-black text-amber-300 tracking-tight">
                      {fmtBRL(valSaturday)}
                    </div>
                  </div>
                </div>

                {/* Detalhes da Faixa (Horas e Valor da Hora) */}
                <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-950/70 border border-amber-500/25 px-3 py-2 text-xs sm:text-sm">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span>Horas apuradas:</span>
                    <strong className="num text-white font-black text-sm">{fmtH(hoursSaturday)}</strong>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span>Valor da hora (+{pctSaturday}%):</span>
                    <strong className="num text-amber-200 font-bold">{fmtBRL(vHoraSaturday)}/h</strong>
                  </div>
                  <div className="text-[11px] text-amber-300/70 font-mono hidden xs:block">
                    {fmtH(hoursSaturday)} × {fmtBRL(vHoraSaturday)}
                  </div>
                </div>
              </div>

              {/* Faixa 3: Domingos e Feriados +100% */}
              <div className="rounded-2xl border-2 border-rose-500/60 bg-gradient-to-r from-rose-950/70 via-slate-900/80 to-rose-950/50 p-3.5 sm:p-4 shadow-lg shadow-rose-950/40 transition hover:border-rose-400/80">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-2.5">
                    <span className="h-3 w-3 rounded-full bg-rose-400 shrink-0 shadow-sm shadow-rose-400/50 animate-pulse" />
                    <div className="flex items-center gap-2">
                      <span className="text-sm sm:text-base font-black text-rose-200">
                        Domingos e Feriados
                      </span>
                      <span className="rounded-lg bg-rose-500/30 px-2.5 py-0.5 text-xs sm:text-sm font-black text-rose-300 border border-rose-400/60 shadow-sm">
                        +{pctSunday}%
                      </span>
                    </div>
                  </div>

                  <div className="text-right ml-auto">
                    <div className="num text-xl sm:text-2xl font-black text-rose-300 tracking-tight">
                      {fmtBRL(valSunday)}
                    </div>
                  </div>
                </div>

                {/* Detalhes da Faixa (Horas e Valor da Hora) */}
                <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-slate-950/70 border border-rose-500/25 px-3 py-2 text-xs sm:text-sm">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span>Horas apuradas:</span>
                    <strong className="num text-white font-black text-sm">{fmtH(hoursSunday)}</strong>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <span>Valor da hora (+{pctSunday}%):</span>
                    <strong className="num text-rose-200 font-bold">{fmtBRL(vHoraSunday)}/h</strong>
                  </div>
                  <div className="text-[11px] text-rose-300/70 font-mono hidden xs:block">
                    {fmtH(hoursSunday)} × {fmtBRL(vHoraSunday)}
                  </div>
                </div>
              </div>

              {/* Total das Horas Extras Somadas com DSR e botão de ativação/desativação */}
              {renderTotalHECard()}
            </div>

            {/* ADICIONAIS LEGAIS CLT: NOTURNO, INSALUBRIDADE E PERICULOSIDADE EM DESTAQUE MAIOR */}
            <div className="space-y-3 pt-3 border-t border-white/[0.08]">
              {/* 1. Adicional Noturno */}
              <div className="rounded-2xl border-2 border-indigo-500/40 bg-gradient-to-r from-indigo-950/50 via-slate-900/60 to-indigo-950/40 p-4 space-y-2 shadow-md">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-500/20 border border-indigo-400/40 text-indigo-300 shrink-0">
                      <Moon className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base sm:text-lg font-black text-white">
                          Adicional Noturno
                        </span>
                        <span className="rounded-lg bg-indigo-400/20 px-2 py-0.5 text-xs font-black text-indigo-300 border border-indigo-400/40">
                          +{noturnoPct}%
                        </span>
                      </div>
                      <p className="text-xs text-indigo-200/80 font-medium">
                        Acréscimo legal de {noturnoPct}% sobre as horas trabalhadas em horário noturno.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 ml-auto">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ noturnoEnabled: !settings.noturnoEnabled }, true)
                      }
                      className={cn(
                        "rounded-xl px-3.5 py-1.5 text-xs font-black transition shadow-sm border",
                        settings.noturnoEnabled
                          ? "bg-indigo-600 text-white border-indigo-400 hover:bg-indigo-500"
                          : "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700 hover:text-white"
                      )}
                    >
                      {settings.noturnoEnabled ? "Ligado" : "Desligado"}
                    </button>
                    <div className="text-right">
                      <div
                        className={cn(
                          "num text-xl sm:text-2xl font-black tracking-tight",
                          settings.noturnoEnabled ? "text-indigo-300" : "text-slate-500 line-through"
                        )}
                      >
                        {fmtBRL(noturnoVal)}
                      </div>
                      {noturnoHours > 0 ? (
                        <div className="num text-xs text-indigo-200/80 font-mono">
                          {fmtH(noturnoHours)} × {fmtBRL(vHora * (1 + noturnoPct / 100))}
                        </div>
                      ) : (
                        <div className="text-[11px] text-slate-400 font-medium">
                          0,00 h registradas
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Adicional de Insalubridade */}
              <div className="rounded-2xl border-2 border-emerald-500/40 bg-gradient-to-r from-emerald-950/50 via-slate-900/60 to-emerald-950/40 p-4 space-y-3 shadow-md">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 shrink-0">
                      <AlertTriangle className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base sm:text-lg font-black text-white">
                          Adicional de Insalubridade
                        </span>
                        <span className="rounded-lg bg-emerald-400/20 px-2 py-0.5 text-xs font-black text-emerald-300 border border-emerald-400/40">
                          {currentInsalubGrau}
                        </span>
                      </div>
                      <p className="text-xs text-emerald-200/80 font-medium">
                        Calculado sobre o valor do salário mínimo vigente (CLT, Art. 192).
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 ml-auto">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ insalubridadeEnabled: !settings.insalubridadeEnabled }, true)
                      }
                      className={cn(
                        "rounded-xl px-3.5 py-1.5 text-xs font-black transition shadow-sm",
                        settings.insalubridadeEnabled
                          ? "bg-emerald-500 text-slate-950 shadow-emerald-900/50 hover:bg-emerald-400"
                          : "bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white"
                      )}
                    >
                      {settings.insalubridadeEnabled ? "Ativo" : "Inativo"}
                    </button>

                    <span
                      className={cn(
                        "num text-xl sm:text-2xl font-black tracking-tight",
                        settings.insalubridadeEnabled ? "text-emerald-300" : "text-slate-500 line-through"
                      )}
                    >
                      {fmtBRL(stats.insalubridade)}
                    </span>
                  </div>
                </div>

                {/* Seletor de Graus: Mínimo (10%), Médio (20%), Máximo (40%) */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-emerald-500/20">
                  <span className="text-xs text-emerald-200/90 font-semibold">
                    Grau de insalubridade:
                  </span>
                  {insalubridadeGraus.map((g) => (
                    <button
                      key={g.grau}
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ insalubridadePct: g.pct, insalubridadeEnabled: true }, true)
                      }
                      className={cn(
                        "rounded-xl px-3 py-1.5 text-xs font-black transition",
                        settings.insalubridadeEnabled && settings.insalubridadePct === g.pct
                          ? "bg-emerald-500 text-slate-950 shadow-md ring-2 ring-emerald-300"
                          : "bg-slate-800/90 text-slate-300 hover:bg-slate-700 hover:text-white border border-white/[0.06]"
                      )}
                      title={`Definir Grau ${g.grau} (${g.pct}%)`}
                    >
                      {g.grau} ({g.pct}%)
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Adicional de Periculosidade */}
              <div className="rounded-2xl border-2 border-amber-500/40 bg-gradient-to-r from-amber-950/50 via-slate-900/60 to-amber-950/40 p-4 space-y-3 shadow-md">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-300 shrink-0">
                      <ShieldAlert className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-base sm:text-lg font-black text-white">
                          Adicional de Periculosidade
                        </span>
                        <span className="rounded-lg bg-amber-400/20 px-2 py-0.5 text-xs font-black text-amber-300 border border-amber-400/40">
                          {settings.periculosidadePct ?? 30}%
                        </span>
                      </div>
                      <p className="text-xs text-amber-200/80 font-medium">
                        Calculado sobre o salário-base contratual (CLT, Art. 193).
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 ml-auto">
                    <button
                      type="button"
                      onClick={() =>
                        onUpdateSettings({ periculosidadeEnabled: !settings.periculosidadeEnabled }, true)
                      }
                      className={cn(
                        "rounded-xl px-3.5 py-1.5 text-xs font-black transition shadow-sm",
                        settings.periculosidadeEnabled
                          ? "bg-amber-500 text-slate-950 shadow-amber-900/50 hover:bg-amber-400"
                          : "bg-slate-800 text-slate-400 hover:bg-slate-700 hover:text-white"
                      )}
                    >
                      {settings.periculosidadeEnabled ? "Ativo" : "Inativo"}
                    </button>

                    <span
                      className={cn(
                        "num text-xl sm:text-2xl font-black tracking-tight",
                        settings.periculosidadeEnabled ? "text-amber-300" : "text-slate-500 line-through"
                      )}
                    >
                      {fmtBRL(stats.periculosidade)}
                    </span>
                  </div>
                </div>

                {/* Explicação com gramática correta */}
                <div className="flex items-center gap-2 text-xs text-amber-200/90 bg-amber-500/10 rounded-xl px-3.5 py-2 border border-amber-400/25">
                  <ShieldAlert className="h-4 w-4 shrink-0 text-amber-400" />
                  <span>
                    <strong>Explicação legal:</strong> 30% calculados sobre o salário-base contratual (não incide sobre as horas extras).
                  </span>
                </div>
              </div>
            </div>

            {/* DSR sobre Horas Extras */}
            <div className="space-y-2 py-2 border-t border-white/[0.08]">
              <div className="flex flex-wrap items-center justify-between gap-2 text-sm sm:text-base">
                <span className="text-slate-200 font-bold">
                  Descanso Semanal Remunerado (DSR sobre Horas Extras):
                </span>
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateSettings({ dsrEnabled: !settings.dsrEnabled }, true)
                    }
                    className={cn(
                      "rounded-xl px-3.5 py-1.5 text-xs font-black transition shadow-sm border",
                      settings.dsrEnabled
                        ? "bg-sky-500 text-slate-950 border-sky-400 hover:bg-sky-400"
                        : "bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700 hover:text-white"
                    )}
                  >
                    {settings.dsrEnabled ? "Ativo" : "Inativo"}
                  </button>
                  <span
                    className={cn(
                      "num font-black text-lg sm:text-xl",
                      settings.dsrEnabled ? "text-sky-300" : "text-slate-500 line-through"
                    )}
                  >
                    {fmtBRL(stats.dsr)}
                  </span>
                </div>
              </div>

              {/* Explicação DSR rápida */}
              <DsrExplanation
                totalHE={stats.totalHE}
                dsrValue={stats.dsr}
                uteis={stats.uteis}
                domingos={stats.domingos}
                feriados={stats.feriados}
                dsrEnabled={settings.dsrEnabled}
              />
            </div>
          </div>

          {/* BLOCO 2: TOTAIS E DEDUÇÕES */}
          <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-2.5">
              <span className="text-xs font-bold uppercase tracking-wider text-rose-400">
                2. PROVENTOS & DEDUÇÕES CLT
              </span>
              <span className="text-[11px] text-slate-400 font-medium">
                Tabelas Oficiais 2026
              </span>
            </div>

            {/* (+) Total Proventos */}
            <div className="flex items-center justify-between gap-3 text-base sm:text-lg font-bold text-white">
              <span>(+) Total Proventos:</span>
              <span className="num font-black text-xl text-white">
                {fmtBRL(stats.bruta)}
              </span>
            </div>

            {/* (-) INSS */}
            <div className="space-y-1 pt-1 border-t border-white/[0.04]">
              <div className="flex items-center justify-between gap-3 text-sm sm:text-base">
                <span className="text-slate-300">(-) INSS:</span>
                <span className="num font-bold text-rose-400">
                  -{fmtBRL(stats.inss)}
                </span>
              </div>
              <InssExplanation grossSalary={stats.bruta} inssValue={stats.inss} />
            </div>

            {/* (-) IRRF */}
            <div className="space-y-1 pt-1 border-t border-white/[0.04]">
              <div className="flex items-center justify-between gap-3 text-sm sm:text-base">
                <span className="text-slate-300">(-) IRRF:</span>
                <span className="num font-bold text-rose-400">
                  -{fmtBRL(stats.irrf)}
                </span>
              </div>
              <IrrfExplanation grossSalary={stats.bruta} inssValue={stats.inss} irrfValue={stats.irrf} />
            </div>

            {/* (-) Outros descontos (Aba minimizada por padrão no Modo Avançado) */}
            <div className="rounded-2xl border border-rose-500/30 bg-gradient-to-r from-rose-950/40 via-slate-900/60 to-rose-950/30 p-3.5 sm:p-4 space-y-3 shadow-md transition-all">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div
                  onClick={() => setIsDiscountsOpen((prev) => !prev)}
                  className="flex items-center gap-2.5 cursor-pointer select-none group min-w-0 flex-1"
                  title={isDiscountsOpen ? "Clique para minimizar outros descontos" : "Clique para expandir controles de outros descontos"}
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-rose-500/20 border border-rose-400/40 text-rose-300 shrink-0 group-hover:bg-rose-500/30 transition">
                    <Percent className="h-4.5 w-4.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm sm:text-base font-bold text-white group-hover:text-rose-200 transition">
                        (-) Outros descontos:
                      </span>
                      {settings.otherDiscounts > 0 ? (
                        <span className="rounded-lg bg-rose-400/20 px-2 py-0.5 text-xs font-black text-rose-300 border border-rose-400/40">
                          {settings.otherDiscounts}%
                        </span>
                      ) : (
                        <span className="rounded-lg bg-slate-800/80 px-2 py-0.5 text-[11px] font-bold text-slate-400 border border-slate-700">
                          0% (sem descontos)
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-rose-200/70 font-medium truncate">
                      {isDiscountsOpen
                        ? "Descontos em folha (ex.: Vale-Transporte até 6% CLT, alimentação, coparticipação)"
                        : "Vale-Transporte (até 6%), alimentação ou coparticipações"}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 ml-auto text-right">
                  <div>
                    <span className="num font-bold text-lg sm:text-xl text-rose-400">
                      -{fmtBRL(stats.otherDiscountsVal)}
                    </span>
                    {settings.otherDiscounts > 0 && (
                      <div className="text-[11px] text-rose-300/80 font-mono">
                        {settings.otherDiscounts}% sobre proventos ({fmtBRL(stats.bruta)})
                      </div>
                    )}
                  </div>

                  {/* Botão de Minimizar / Expandir Aba */}
                  <button
                    type="button"
                    onClick={() => setIsDiscountsOpen((prev) => !prev)}
                    className={cn(
                      "flex items-center gap-1 rounded-xl px-2.5 py-1.5 text-xs font-bold transition active:scale-95 border cursor-pointer shrink-0 shadow-sm",
                      isDiscountsOpen
                        ? "bg-rose-500/20 text-rose-200 border-rose-400/40 hover:bg-rose-500/30"
                        : "bg-slate-800 text-rose-300 border-rose-500/40 hover:bg-rose-500/20 hover:text-white"
                    )}
                    title={isDiscountsOpen ? "Minimizar aba Outros descontos" : "Expandir aba e ajustar percentual de desconto"}
                    aria-expanded={isDiscountsOpen}
                  >
                    <span>{isDiscountsOpen ? "Minimizar" : "Ajustar %"}</span>
                    {isDiscountsOpen ? (
                      <ChevronUp className="h-3.5 w-3.5" />
                    ) : (
                      <ChevronDown className="h-3.5 w-3.5" />
                    )}
                  </button>
                </div>
              </div>

              {/* Conteúdo Expansível: Botão de % Digitável + Controles Interativos (aberto apenas quando expandido) */}
              {isDiscountsOpen && (
                <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2.5 border-t border-rose-500/20">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs text-slate-300 font-semibold">
                      Percentual (%):
                    </span>

                    {/* Componente: Botão de % Digitável com Steppers */}
                    <div className="flex items-center gap-1.5">
                      {/* Botão diminuir -1% */}
                      <button
                        type="button"
                        aria-label="Diminuir desconto em 1%"
                        onClick={() => handleDiscountBump(-1)}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-rose-500/40 bg-slate-800 text-rose-300 transition hover:bg-rose-500/20 active:scale-95 text-base font-bold cursor-pointer"
                        title="Diminuir 1%"
                      >
                        −
                      </button>

                      {/* Caixa com Botão de % e Input Digitável */}
                      <div
                        className={cn(
                          "flex h-8.5 items-center rounded-xl border bg-slate-950/80 px-2 transition shadow-inner",
                          discountFocused
                            ? "border-rose-400 ring-2 ring-rose-400/30 bg-slate-900"
                            : "border-rose-500/40 hover:border-rose-400/70"
                        )}
                      >
                        {/* Botão de % clicável para focar e digitar */}
                        <button
                          type="button"
                          onClick={() => {
                            const inputEl = document.getElementById("input-outros-descontos-pct");
                            inputEl?.focus();
                          }}
                          className="flex items-center gap-1 rounded-md bg-rose-500/25 px-1.5 py-0.5 text-[11px] font-black text-rose-300 border border-rose-400/40 mr-1.5 hover:bg-rose-500/40 transition cursor-pointer"
                          title="Botão de % digitável — clique para digitar o percentual desejado"
                        >
                          <Percent className="h-3 w-3" />
                          <span>%</span>
                        </button>

                        <input
                          id="input-outros-descontos-pct"
                          type="text"
                          inputMode="decimal"
                          value={discountDraft}
                          onFocus={() => setDiscountFocused(true)}
                          onBlur={handleDiscountBlur}
                          onChange={(e) => handleDiscountChange(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              (e.target as HTMLInputElement).blur();
                            }
                          }}
                          placeholder="0"
                          aria-label="Percentual de outros descontos"
                          className="w-12 bg-transparent text-right text-sm font-black tabular-nums text-white outline-none placeholder:text-slate-500 font-mono"
                        />
                        <span className="pl-1 pr-0.5 text-xs font-bold text-rose-300 select-none">
                          %
                        </span>
                      </div>

                      {/* Botão aumentar +1% */}
                      <button
                        type="button"
                        aria-label="Aumentar desconto em 1%"
                        onClick={() => handleDiscountBump(1)}
                        className="flex h-8 w-8 items-center justify-center rounded-lg border border-rose-500/40 bg-slate-800 text-rose-300 transition hover:bg-rose-500/20 active:scale-95 text-base font-bold cursor-pointer"
                        title="Aumentar 1%"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  {/* Botões de Atalhos Rápidos */}
                  <div className="flex items-center gap-1.5 flex-wrap ml-auto">
                    <span className="text-[11px] text-slate-400 font-medium">
                      Atalhos:
                    </span>
                    {[
                      { label: "0%", pct: 0, title: "Sem desconto (0%)" },
                      { label: "6% VT", pct: 6, title: "Vale-Transporte CLT (até 6%)" },
                      { label: "5%", pct: 5, title: "Desconto de 5%" },
                      { label: "10%", pct: 10, title: "Desconto de 10%" },
                    ].map((p) => {
                      const isActive = settings.otherDiscounts === p.pct;
                      return (
                        <button
                          key={p.label}
                          type="button"
                          onClick={() => handleDiscountPreset(p.pct)}
                          className={cn(
                            "rounded-lg px-2.5 py-1 text-xs font-bold transition active:scale-95 border cursor-pointer",
                            isActive
                              ? "bg-rose-500 text-white border-rose-300 shadow-sm shadow-rose-950/50"
                              : "bg-slate-800/90 text-slate-300 border-white/[0.08] hover:bg-slate-700 hover:text-white"
                          )}
                          title={p.title}
                        >
                          {p.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* BLOCO 4: DESTAQUE EM VERDE — LÍQUIDO A RECEBER */}
          <div className="rounded-2xl border-2 border-emerald-400/80 bg-gradient-to-br from-emerald-950/70 via-emerald-900/60 to-slate-950 p-5 shadow-2xl shadow-emerald-950/60 ring-2 ring-emerald-500/30">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="text-2xl">✅</span>
                <span className="text-base sm:text-lg font-black uppercase tracking-wider text-emerald-300">
                  LÍQUIDO A RECEBER
                </span>
              </div>
              <span className="rounded-full bg-emerald-400/20 px-3 py-1 text-xs font-black text-emerald-200 border border-emerald-400/40">
                Resultado Oficial
              </span>
            </div>

            <div className="num mt-2 text-4xl sm:text-5xl font-black text-emerald-300 tracking-tight">
              {fmtBRL(stats.liquido)}
            </div>

            <p className="mt-2 text-xs sm:text-sm text-emerald-200/80 font-medium leading-relaxed">
              Total Proventos ({fmtBRL(stats.bruta)}) − INSS ({fmtBRL(stats.inss)}) − IRRF ({fmtBRL(stats.irrf)}) − Descontos ({fmtBRL(stats.otherDiscountsVal)}) = Saldo líquido a creditar em conta.
            </p>
          </div>

          {/* BOTÃO PARA RETORNAR AO MODO SIMPLIFICADO */}
          <div className="pt-2 flex justify-center">
            <button
              type="button"
              onClick={() => {
                setIsExpanded(false);
                onUpdateSettings({ modo: "desativado" }, true);
              }}
              className="rounded-xl border border-slate-700 bg-slate-800/80 hover:bg-slate-700 px-5 py-2.5 text-xs sm:text-sm font-bold text-slate-200 hover:text-white transition active:scale-95 flex items-center gap-2 shadow-sm cursor-pointer"
            >
              <ChevronUp className="h-4 w-4 text-emerald-400" />
              <span>Voltar ao Modo Simplificado</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
