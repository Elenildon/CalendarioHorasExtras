import { useState } from "react";
import { ChevronDown, ChevronUp, ShieldCheck, Percent, Info } from "lucide-react";
import { fmtBRL } from "../lib/calc";

export interface InssExplanationProps {
  grossSalary: number;
  inssValue: number;
  defaultOpen?: boolean;
  className?: string;
}

export function getINSSBreakdown(gross: number) {
  let prev = 0;
  let totalTax = 0;

  const BRACKETS_DEF = [
    { limit: 1621.0, rate: 0.075, label: "1ª Faixa", range: "Até R$ 1.621,00" },
    { limit: 2902.84, rate: 0.09, label: "2ª Faixa", range: "R$ 1.621,01 a R$ 2.902,84" },
    { limit: 4354.27, rate: 0.12, label: "3ª Faixa", range: "R$ 2.902,85 a R$ 4.354,27" },
    { limit: 8475.55, rate: 0.14, label: "4ª Faixa", range: "R$ 4.354,28 a R$ 8.475,55" },
  ];

  const brackets = BRACKETS_DEF.map((item, idx) => {
    let baseInBracket = 0;
    let tax = 0;

    if (gross > prev) {
      baseInBracket = Math.min(gross, item.limit) - prev;
      tax = baseInBracket * item.rate;
      totalTax += tax;
    }

    const res = {
      bracket: idx + 1,
      label: item.label,
      range: item.range,
      rate: item.rate,
      ratePct: `${(item.rate * 100).toFixed(1).replace(".", ",")}%`,
      baseInBracket,
      tax,
      reached: gross > prev,
    };

    prev = item.limit;
    return res;
  });

  const effectiveRate = gross > 0 ? (totalTax / gross) * 100 : 0;
  const isCeiling = gross >= 8475.55;

  return {
    brackets,
    totalTax,
    effectiveRate,
    isCeiling,
    ceilingValue: 8475.55,
    maxTax: 988.09, // limite teto progressivo 2026 pelas faixas oficiais
  };
}

export default function InssExplanation({
  grossSalary,
  inssValue,
  defaultOpen = false,
  className = "",
}: InssExplanationProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const breakdown = getINSSBreakdown(grossSalary);

  const effectiveRateStr = breakdown.effectiveRate.toFixed(2).replace(".", ",");

  return (
    <div className={`mt-1.5 transition-all ${className}`}>
      {/* Gatilho Clicável Integrado ao Resumo: fica minimizado por padrão */}
      <div className="flex items-center justify-between gap-2 rounded-xl bg-rose-500/10 border border-rose-400/25 px-3 py-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-rose-500/20 text-rose-300">
            <Percent className="h-3.5 w-3.5" />
          </span>
          <div className="text-xs text-rose-200 min-w-0 truncate">
            <span className="font-bold">Regra INSS 2026:</span>{" "}
            <span className="text-rose-100">Alíquota efetiva {effectiveRateStr}%</span>
            <span className="hidden sm:inline text-rose-300/80"> · Tabela progressiva</span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen((prev) => !prev)}
          aria-expanded={isOpen}
          className="flex items-center gap-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 px-2.5 py-1 text-xs font-bold text-rose-100 transition active:scale-95 shrink-0 border border-rose-400/30"
          title={isOpen ? "Minimizar explicação do INSS" : "Visualizar regra e alíquotas do INSS 2026"}
        >
          <span>{isOpen ? "Minimizar" : "Ver regra"}</span>
          {isOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Aba Pequena que se abre com a regra explicativa e simples */}
      {isOpen && (
        <div className="mt-2.5 rounded-2xl border border-rose-400/30 bg-gradient-to-b from-[#160d1f]/95 via-[#120a1b]/95 to-[#0b0813]/95 p-3.5 sm:p-4 text-xs shadow-xl shadow-black/40 backdrop-blur-md">
          {/* Cabeçalho da Aba */}
          <div className="flex items-start justify-between gap-2 border-b border-rose-500/20 pb-2.5">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-rose-500/20 text-rose-400 border border-rose-400/30">
                <ShieldCheck className="h-4 w-4" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                  Tabela INSS 2026 (Atualizada)
                  <span className="rounded bg-rose-500/25 px-1.5 py-0.2 text-[10px] font-black text-rose-300 border border-rose-400/30">
                    CLT
                  </span>
                </h4>
                <p className="text-[11px] text-rose-300/80">
                  Desconto progressivo por faixas salariais
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="rounded-lg p-1 text-slate-400 hover:text-white hover:bg-white/10 transition"
              title="Fechar aba explicativa"
            >
              <ChevronUp className="h-4 w-4" />
            </button>
          </div>

          {/* Explicação Curta e Simples */}
          <div className="mt-2.5 rounded-xl bg-slate-900/60 p-2.5 border border-slate-800 text-slate-300 leading-relaxed">
            <div className="flex items-start gap-1.5">
              <Info className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-white">Como funciona na prática:</strong> O INSS não cobra a alíquota cheia sobre todo o salário. Cada percentual incide apenas sobre a respectiva fatia.
              </div>
            </div>
          </div>

          {/* As 4 Faixas em formato compacto */}
          <div className="mt-3 space-y-1.5">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-1">
              Faixas de Contribuição 2026:
            </span>
            {breakdown.brackets.map((b) => (
              <div
                key={b.bracket}
                className={`flex items-center justify-between rounded-xl px-2.5 py-1.5 text-[11px] border transition ${
                  b.reached
                    ? "bg-rose-500/10 border-rose-400/30 text-rose-100"
                    : "bg-slate-900/40 border-slate-800/80 text-slate-500"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span
                    className={`font-black rounded px-1.5 py-0.5 text-[10px] ${
                      b.reached
                        ? "bg-rose-500/30 text-rose-200 border border-rose-400/30"
                        : "bg-slate-800 text-slate-500"
                    }`}
                  >
                    {b.ratePct}
                  </span>
                  <span className="font-semibold">{b.range}</span>
                </div>

                <div className="text-right">
                  {b.baseInBracket > 0 ? (
                    <span className="font-bold text-rose-200">
                      R$ {b.tax.toFixed(2).replace(".", ",")}
                    </span>
                  ) : (
                    <span className="text-[10px] text-slate-500">—</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Teto e Alíquota Efetiva do Usuário */}
          <div className="mt-3 pt-2.5 border-t border-slate-800 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-xl bg-slate-900/80 p-2 border border-slate-800">
              <span className="block text-[10px] text-slate-400 uppercase font-bold">
                Teto Máximo 2026
              </span>
              <span className="text-xs font-black text-amber-300">
                {fmtBRL(breakdown.ceilingValue)}
              </span>
              <span className="block text-[9px] text-slate-500">
                {breakdown.isCeiling ? "Teto atingido" : "Limite de desconto"}
              </span>
            </div>

            <div className="rounded-xl bg-rose-500/15 p-2 border border-rose-400/30">
              <span className="block text-[10px] text-rose-300 uppercase font-bold">
                Alíquota Efetiva
              </span>
              <span className="text-xs font-black text-rose-200">
                {effectiveRateStr}%
              </span>
              <span className="block text-[9px] text-rose-300/80">
                Desconto real do bruto
              </span>
            </div>
          </div>

          {/* Resumo de Fechamento */}
          <div className="mt-2.5 flex items-center justify-between text-[11px] px-1 text-slate-300">
            <span>Remuneração Bruta: <strong className="text-white">{fmtBRL(grossSalary)}</strong></span>
            <span>Desconto INSS: <strong className="text-rose-400">-{fmtBRL(inssValue)}</strong></span>
          </div>
        </div>
      )}
    </div>
  );
}
