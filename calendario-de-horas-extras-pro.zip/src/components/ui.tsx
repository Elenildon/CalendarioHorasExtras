import type { ReactNode } from "react";
import { Minus, Plus } from "lucide-react";
import { cn } from "../utils/cn";

export function Card({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return <div className={cn("card p-5", className)}>{children}</div>;
}

export function IconTile({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl",
        className
      )}
    >
      {children}
    </div>
  );
}

export function Stepper({
  value,
  onDec,
  onInc,
  prefix,
  suffix,
  editable = true,
  onValue,
  className,
}: {
  value: string;
  onDec: () => void;
  onInc: () => void;
  prefix?: string;
  suffix?: string;
  editable?: boolean;
  onValue?: (v: string) => void;
  className?: string;
}) {
  const btn =
    "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-slate-500/30 bg-slate-800/70 text-slate-300 active:scale-95 transition text-3xl font-light";
  return (
    <div className={cn("flex items-stretch gap-3", className)}>
      <button type="button" className={btn} onClick={onDec} aria-label="diminuir">
        <Minus className="h-6 w-6" strokeWidth={2.5} />
      </button>
      <div className="field flex flex-1 items-center justify-center gap-1 px-3">
        {prefix && <span className="text-2xl text-slate-400">{prefix}</span>}
        <input
          inputMode="decimal"
          value={value}
          disabled={!editable}
          onChange={(e) => onValue?.(e.target.value)}
          className="num w-full min-w-0 bg-transparent text-center text-3xl font-bold text-white outline-none disabled:text-white"
        />
        {suffix && <span className="text-2xl text-slate-400">{suffix}</span>}
      </div>
      <button type="button" className={btn} onClick={onInc} aria-label="aumentar">
        <Plus className="h-6 w-6" strokeWidth={2.5} />
      </button>
    </div>
  );
}

export function Chip({
  children,
  active,
  onClick,
  activeClass = "bg-indigo-600 border-indigo-400 text-white",
  className,
}: {
  children: ReactNode;
  active?: boolean;
  onClick?: () => void;
  activeClass?: string;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "rounded-2xl border border-slate-500/30 bg-slate-800/60 px-5 py-3 text-lg font-semibold text-slate-300 transition active:scale-95",
        active && activeClass,
        className
      )}
    >
      {children}
    </button>
  );
}

export function Toggle({
  on,
  onChange,
  color = "emerald",
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  color?: "emerald" | "sky" | "amber";
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={on}
      onClick={() => onChange(!on)}
      className={cn(
        "relative h-10 w-[72px] shrink-0 rounded-full transition-colors",
        on
          ? color === "amber"
            ? "bg-amber-500"
            : color === "emerald"
            ? "bg-emerald-500"
            : "bg-sky-500"
          : "bg-slate-700"
      )}
    >
      <span
        className={cn(
          "absolute top-1 h-8 w-8 rounded-full bg-white shadow transition-all",
          on ? "left-[37px]" : "left-1"
        )}
      />
    </button>
  );
}

type ButtonVariant = "primary" | "ghost" | "outline";

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
}

export function Button({ variant = "outline", className, ...rest }: ButtonProps) {
  const variants: Record<ButtonVariant, string> = {
    primary:
      "bg-indigo-600 text-white shadow-sm shadow-indigo-500/30 hover:bg-indigo-500",
    outline:
      "border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700",
    ghost:
      "text-slate-500 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800",
  };
  return (
    <button
      type="button"
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition-all active:scale-[0.98]",
        variants[variant],
        className
      )}
      {...rest}
    />
  );
}
