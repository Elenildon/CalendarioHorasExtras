import { useState, useMemo } from "react";
import {
  X,
  Share2,
  Copy,
  Check,
  ExternalLink,
  QrCode,
  Calendar,
  Clock,
  Coins,
  Brain,
} from "lucide-react";
import {
  MESES,
  fmtBRL,
  fmtH,
  type MonthStats,
  type Settings,
  type DayEntry,
} from "../lib/calc";
import InssExplanation from "./InssExplanation";
import IrrfExplanation from "./IrrfExplanation";
import DsrExplanation from "./DsrExplanation";

interface ShareModalProps {
  settings: Settings;
  stats: MonthStats;
  cursor: { y: number; m: number };
  entries?: Record<string, DayEntry>;
  smartMode: boolean;
  onToggleSmart: () => void;
  onClose: () => void;
  onShowToast: (msg: string) => void;
  onOpenInstall?: (tab?: "auto" | "ios" | "android" | "qr") => void;
}

export default function ShareModal({
  settings,
  stats,
  cursor,
  entries,
  smartMode,
  onToggleSmart,
  onClose,
  onShowToast,
  onOpenInstall,
}: ShareModalProps) {
  const [copiedText, setCopiedText] = useState(false);

  const monthName = MESES[cursor.m] || "Mês atual";

  // Extrai anotações do mês como blocos com quebras preservadas
  const notesOfMonth = useMemo(() => {
    if (!entries) return [];
    const list: Array<{ date: string; note: string; day: number }> = [];
    Object.entries(entries).forEach(([k, entry]) => {
      if (!entry.note || !entry.note.trim()) return;
      const [y, m, d] = k.split("-").map(Number);
      if (y === cursor.y && m === cursor.m + 1) {
        list.push({
          date: `${String(d).padStart(2, "0")}/${String(m).padStart(2, "0")}`,
          note: entry.note.trim(),
          day: d,
        });
      }
    });
    return list.sort((a, b) => a.day - b.day);
  }, [entries, cursor.y, cursor.m]);

  // Mensagem formatada para o WhatsApp (relatório sem o link do app)
  const whatsappMessage = useMemo(() => {
    const effectiveInssPct =
      stats.bruta > 0
        ? ((stats.inss / stats.bruta) * 100).toFixed(1).replace(".", ",")
        : "0,0";

    const baseIrrf = Math.max(0, stats.bruta - stats.inss);
    const isIrrfExempt = baseIrrf <= 5000 || stats.irrf <= 0;
    const effectiveIrrfPct =
      stats.bruta > 0
        ? ((stats.irrf / stats.bruta) * 100).toFixed(1).replace(".", ",")
        : "0,0";

    const notesBlock =
      notesOfMonth.length > 0
        ? `\n📋 *Observações Registradas no Mês:*\n` +
          notesOfMonth
            .map(
              (n) =>
                `• *Dia ${n.date}:*\n${n.note
                  .split("\n")
                  .map((l) => `  ${l}`)
                  .join("\n")}`
            )
            .join("\n\n") +
          `\n`
        : "";

    return (
      `📊 *Relatório de Horas Extras — Calendário PRO*\n` +
      `👤 *Colaborador:* ${settings.name || "Não informado"}\n` +
      (settings.cargo ? `💼 *Cargo:* ${settings.cargo}\n` : "") +
      (settings.empresa ? `🏢 *Empresa:* ${settings.empresa}\n` : "") +
      `📅 *Mês de Referência:* ${monthName} de ${cursor.y}\n\n` +
      `⏱ *Total de Horas Extras:* ${fmtH(stats.totalHours)}\n` +
      ((stats.hoursByBand?.weekday ?? 0) > 0 ? `  • Dias Úteis (60%): ${fmtH(stats.hoursByBand.weekday)} (${fmtBRL(stats.valueByBand.weekday)})\n` : "") +
      ((stats.hoursByBand?.saturday ?? 0) > 0 ? `  • Sábado (75%): ${fmtH(stats.hoursByBand.saturday)} (${fmtBRL(stats.valueByBand.saturday)})\n` : "") +
      (((stats.hoursByBand?.sunday ?? 0) + (stats.hoursByBand?.holiday ?? 0)) > 0 ? `  • Dom/Feriados (100%): ${fmtH(stats.hoursByBand.sunday + (stats.hoursByBand.holiday ?? 0))} (${fmtBRL(stats.valueByBand.sunday + (stats.valueByBand.holiday ?? 0))})\n` : "") +
      `📝 *Lançamentos no Mês:* ${stats.lancamentos} dias registrados\n` +
      (stats.dsr > 0 ? `📈 *DSR 2026 (Repouso Semanal):* ${fmtBRL(stats.dsr)}\n` : "") +
      `💰 *Total Bruto Estimado:* ${fmtBRL(stats.bruta)}\n` +
      `🛡 *INSS 2026 (progressivo):* -${fmtBRL(stats.inss)} (efetivo: ${effectiveInssPct}%)\n` +
      (isIrrfExempt
        ? `🧾 *IRRF 2026:* R$ 0,00 (ISENTO até R$ 5 mil)\n`
        : `🧾 *IRRF 2026:* -${fmtBRL(stats.irrf)} (efetivo: ${effectiveIrrfPct}%)\n`) +
      (stats.otherDiscountsVal > 0
        ? `📉 *Outros descontos${settings.otherDiscountsMode !== "currency" ? ` (${settings.otherDiscounts}%)` : ""}:* -${fmtBRL(stats.otherDiscountsVal)}\n`
        : "") +
      `💵 *Líquido Estimado:* ${fmtBRL(stats.liquido)}\n` +
      notesBlock +
      `\nℹ️ *Regras 2026:* DSR (Lei 605/49 · Súmula 172 TST) · INSS progressivo (7,5% a 14%) · IRRF com isenção até R$ 5.000,00.`
    );
  }, [settings.name, settings.cargo, settings.empresa, settings.otherDiscounts, settings.otherDiscountsMode, monthName, cursor.y, stats, notesOfMonth]);

  // Abre WhatsApp
  const handleOpenWhatsApp = () => {
    const encoded = encodeURIComponent(whatsappMessage);
    const url = `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(url, "_blank", "noopener,noreferrer");
    onShowToast("Abrindo WhatsApp...");
  };

  // Copia o texto formatado
  const handleCopyText = async () => {
    try {
      await navigator.clipboard.writeText(whatsappMessage);
      setCopiedText(true);
      onShowToast("Texto copiado para a área de transferência!");
      setTimeout(() => setCopiedText(false), 2500);
    } catch {
      onShowToast("Não foi possível copiar o texto.");
    }
  };

  // Compartilhamento nativo via sistema (se disponível)
  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Calendário de Horas Extras PRO",
          text: whatsappMessage,
        });
      } catch (err) {
        console.debug("Compartilhamento nativo cancelado:", err);
      }
    } else {
      handleCopyText();
    }
  };

  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="backdrop-fade fixed inset-0 bg-black/75 backdrop-blur-sm"
      />

      {/* Caixa do Modal */}
      <div className="relative w-full max-w-lg rounded-[2rem] border border-cyan-400/30 bg-[#0a1024] p-5 sm:p-6 shadow-2xl text-slate-200 my-auto">
        {/* Topo / Cabeçalho */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/60">
          <div className="flex items-center gap-2.5">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-400/30">
              <Share2 className="h-5 w-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-white flex items-center gap-2">
                Compartilhar Relatório
                <span className="rounded-md bg-gradient-to-r from-cyan-400 to-indigo-400 px-2 py-0.5 text-[10px] font-black uppercase text-slate-950">
                  {monthName.slice(0, 3)}/{cursor.y}
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Relatório de horas extras, cálculos e exportação para WhatsApp
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar modal"
            className="flex h-9 w-9 items-center justify-center rounded-xl bg-slate-800 text-slate-400 hover:text-white transition active:scale-95"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Status Modo Inteligente e Mês */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-slate-800/40 p-2.5 border border-slate-700/50">
          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={onToggleSmart}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border font-bold transition active:scale-95 ${
                smartMode
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-400/50 shadow-[0_0_12px_rgba(34,211,238,0.25)]"
                  : "bg-slate-700/50 text-slate-400 border-slate-600/50"
              }`}
            >
              <Brain className="h-3.5 w-3.5" />
              <span>{smartMode ? "Modo Inteligente Ativo" : "Modo Normal"}</span>
            </button>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-indigo-300 font-semibold bg-indigo-950/50 border border-indigo-500/30 px-3 py-1.5 rounded-xl">
            <Calendar className="h-3.5 w-3.5 text-indigo-400" />
            <span>{monthName} de {cursor.y}</span>
          </div>
        </div>

        {/* Card Resumo dos Dados de Compartilhamento */}
        <div className="mt-3.5 rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-indigo-950/40 to-slate-900/60 p-3.5 shadow-inner">
          <div className="flex flex-wrap items-center justify-between gap-1 text-xs text-indigo-300 pb-2 border-b border-indigo-500/20">
            <span className="flex items-center gap-1 font-semibold">
              <Calendar className="h-3.5 w-3.5 text-indigo-400" />
              {monthName} de {cursor.y}
            </span>
            <div className="text-right">
              <span className="font-bold text-slate-200">
                {settings.name || "Colaborador"}
              </span>
              {settings.empresa && (
                <span className="block text-[11px] text-cyan-300 font-semibold">
                  {settings.empresa}
                </span>
              )}
            </div>
          </div>

          {/* Destaque das Horas Extras */}
          <div className="my-3 grid grid-cols-2 gap-2 text-center">
            <div className="rounded-xl bg-slate-900/80 p-2.5 border border-indigo-500/20">
              <span className="block text-[11px] text-slate-400 flex items-center justify-center gap-1">
                <Clock className="h-3 w-3 text-cyan-400" /> Horas Extras
              </span>
              <span className="text-lg font-black text-cyan-300">
                {fmtH(stats.totalHours)}
              </span>
              <span className="block text-[10px] text-slate-400">
                {stats.lancamentos} lançamentos
              </span>
            </div>

            <div className="rounded-xl bg-slate-900/80 p-2.5 border border-indigo-500/20">
              <span className="block text-[11px] text-slate-400 flex items-center justify-center gap-1">
                <Coins className="h-3 w-3 text-emerald-400" /> Bruto Total
              </span>
              <span className="text-lg font-black text-emerald-400">
                {fmtBRL(stats.bruta)}
              </span>
              <span className="block text-[10px] text-emerald-300/80">
                (inc. DSR {fmtBRL(stats.dsr)})
              </span>
            </div>
          </div>

          {/* Faixas e Descontos */}
          <div className="space-y-1.5 text-xs text-slate-300 border-t border-slate-700/60 pt-2.5">
            <div className="flex justify-between items-center text-slate-400 text-[11px]">
              <span>Dias Úteis (60%):</span>
              <span className="font-semibold text-slate-200">
                {fmtH(stats.hoursByBand?.weekday ?? 0)} · {fmtBRL(stats.valueByBand?.weekday ?? 0)}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-400 text-[11px]">
              <span>Sábados (75%):</span>
              <span className="font-semibold text-slate-200">
                {fmtH(stats.hoursByBand?.saturday ?? 0)} · {fmtBRL(stats.valueByBand?.saturday ?? 0)}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-400 text-[11px]">
              <span>Domingos e Feriados (100%):</span>
              <span className="font-semibold text-slate-200">
                {fmtH((stats.hoursByBand?.sunday ?? 0) + (stats.hoursByBand?.holiday ?? 0))} ·{" "}
                {fmtBRL((stats.valueByBand?.sunday ?? 0) + (stats.valueByBand?.holiday ?? 0))}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-400 text-[11px]">
              <span>DSR (Descanso Semanal Remunerado):</span>
              <span className="font-semibold text-amber-300">
                +{fmtBRL(stats.dsr)}
              </span>
            </div>

            <div className="flex justify-between items-center text-rose-300/90 text-[11px]">
              <span>Desconto INSS (progressivo 2026):</span>
              <span className="font-semibold">-{fmtBRL(stats.inss)}</span>
            </div>

            <div className="flex justify-between items-center text-rose-300/90 text-[11px]">
              <span>Desconto IRRF (isenção até R$ 5 mil):</span>
              <span className="font-semibold">-{fmtBRL(stats.irrf)}</span>
            </div>

            {stats.otherDiscountsVal > 0 && (
              <div className="flex justify-between items-center text-rose-300/90 text-[11px]">
                <span>Outros Descontos:</span>
                <span className="font-semibold">-{fmtBRL(stats.otherDiscountsVal)}</span>
              </div>
            )}

            <div className="flex justify-between items-center border-t border-indigo-500/30 pt-1.5 text-sm font-bold text-white">
              <span className="text-cyan-300">Líquido Estimado:</span>
              <span className="text-emerald-400 text-base font-black">
                {fmtBRL(stats.liquido)}
              </span>
            </div>
          </div>

          <DsrExplanation
            totalHE={stats.totalHE}
            dsrValue={stats.dsr}
            uteis={stats.uteis}
            domingos={stats.domingos}
            feriados={stats.feriados}
            dsrEnabled={settings.dsrEnabled}
          />
          <InssExplanation grossSalary={stats.bruta} inssValue={stats.inss} />
          <IrrfExplanation grossSalary={stats.bruta} inssValue={stats.inss} irrfValue={stats.irrf} />

          {/* No relatório, aparecer como bloco contínuo, com quebras preservadas */}
          {notesOfMonth.length > 0 && (
            <div className="mt-3 rounded-2xl border border-indigo-500/30 bg-slate-900/90 p-3.5 text-left">
              <span className="block text-[11px] font-bold uppercase tracking-wider text-slate-300 mb-2 flex items-center gap-1.5">
                <span>📝</span> Observações Registradas no Mês ({notesOfMonth.length})
              </span>
              <div className="space-y-2.5 max-h-48 overflow-y-auto pr-1">
                {notesOfMonth.map((n, idx) => (
                  <div
                    key={idx}
                    className="rounded-xl bg-slate-950/80 border border-slate-800 p-2.5 text-xs text-slate-200 border-l-4 border-l-emerald-500"
                  >
                    <span className="font-extrabold text-emerald-400 block mb-1">
                      Dia {n.date}
                    </span>
                    <div className="whitespace-pre-wrap break-words leading-relaxed text-slate-200 text-left font-sans">
                      {n.note}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Bloco: Enviar via WhatsApp ou Copiar */}
        <div className="mt-4">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5 mb-2">
            <span className="h-2 w-2 rounded-full bg-[#25D366] animate-pulse" />
            Enviar Relatório no WhatsApp
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleOpenWhatsApp}
              className="flex h-13 w-full items-center justify-center gap-2.5 rounded-xl bg-[#25D366] font-extrabold text-slate-950 shadow-lg shadow-emerald-950/40 transition active:scale-[0.98] hover:bg-[#22c55e]"
            >
              <svg className="h-5 w-5 fill-current" viewBox="0 0 24 24">
                <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm.01 1.67c4.54 0 8.24 3.7 8.24 8.24 0 2.2-.86 4.27-2.42 5.82a8.188 8.188 0 01-5.82 2.42c-1.48 0-2.93-.39-4.2-1.15l-.3-.18-3.12.82.83-3.04-.2-.31a8.196 8.196 0 01-1.25-4.38c0-4.54 3.7-8.24 8.24-8.24zm4.52 11.66c-.25-.13-1.47-.72-1.7-.81-.23-.08-.39-.13-.56.13-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.13-1.06-.39-2.02-1.25-.75-.67-1.26-1.5-1.41-1.75-.15-.25-.02-.39.11-.51.11-.11.25-.29.38-.44.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.44-.06-.13-.56-1.34-.76-1.84-.2-.49-.4-.42-.56-.43l-.47-.01c-.16 0-.42.06-.64.3-.22.25-.85.83-.85 2.02s.87 2.34 1 2.5c.12.17 1.71 2.61 4.14 3.66.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.47-.6 1.68-1.18.21-.58.21-1.08.15-1.18-.06-.1-.23-.17-.48-.3z" />
              </svg>
              <span>Enviar no WhatsApp</span>
            </button>

            <button
              type="button"
              onClick={handleCopyText}
              className="flex h-13 w-full items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800/80 font-bold text-slate-200 transition active:scale-[0.98] hover:bg-slate-700 hover:text-white"
            >
              {copiedText ? (
                <>
                  <Check className="h-4 w-4 text-emerald-400" />
                  <span>Relatório Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 text-cyan-400" />
                  <span>Copiar Relatório</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Passar QR Code Oficial para Câmera para a aba Instalar & QR Code */}
        {onOpenInstall && (
          <div className="mt-4 pt-3.5 border-t border-slate-700/60">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenInstall("qr");
              }}
              className="group flex w-full items-center justify-between gap-3 rounded-2xl border border-amber-500/40 bg-gradient-to-r from-amber-950/30 via-slate-900/90 to-slate-900 p-3.5 text-left transition hover:border-amber-400 hover:bg-slate-800/80 active:scale-[0.99] shadow-md shadow-amber-950/20"
            >
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 border border-amber-400/40 group-hover:scale-105 transition-transform">
                  <QrCode className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs sm:text-sm font-black text-amber-300">
                      QR Code Oficial para Câmera
                    </span>
                    <span className="rounded bg-gradient-to-r from-amber-400 to-amber-500 px-1.5 py-0.5 text-[9px] font-black uppercase text-amber-950">
                      OFICIAL
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Acessar na aba <strong>Instalar & QR Code</strong> para escanear com a câmera do celular
                  </p>
                </div>
              </div>
              <div className="shrink-0 flex items-center gap-1 text-xs font-bold text-amber-400 group-hover:translate-x-0.5 transition-transform">
                <span>Abrir</span>
                <span>→</span>
              </div>
            </button>
          </div>
        )}

        {typeof navigator !== "undefined" && "share" in navigator && (
          <button
            type="button"
            onClick={handleNativeShare}
            className="mt-2.5 w-full flex items-center justify-center gap-1.5 rounded-xl bg-slate-800/80 border border-slate-700 py-2.5 px-3 text-xs font-bold text-slate-300 transition hover:bg-slate-700 hover:text-white active:scale-95"
          >
            <ExternalLink className="h-3.5 w-3.5 text-cyan-400" />
            <span>Mais Opções de Envio (Sistema)</span>
          </button>
        )}
      </div>
    </div>
  );
}
