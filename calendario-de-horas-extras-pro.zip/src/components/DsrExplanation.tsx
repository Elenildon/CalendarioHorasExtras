import { useState } from "react";
import { ChevronDown, ChevronUp, CalendarDays, Percent } from "lucide-react";
import { fmtBRL } from "../lib/calc";

export interface DsrExplanationProps {
  totalHE: number;
  dsrValue: number;
  uteis: number;
  domingos: number;
  feriados?: number;
  dsrEnabled?: boolean;
  defaultOpen?: boolean;
  className?: string;
}

export default function DsrExplanation({
  totalHE,
  dsrValue,
  uteis,
  domingos,
  feriados = 0,
  dsrEnabled = true,
  defaultOpen = false,
  className = "",
}: DsrExplanationProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  const totalDescansos = domingos + feriados;
  // Percentual efetivo que o DSR acrescenta sobre o total de horas extras
  const pctEfetivo = totalHE > 0 && dsrValue > 0 ? (dsrValue / totalHE) * 100 : (uteis > 0 ? (totalDescansos / uteis) * 100 : 0);
  const pctEfetivoStr = pctEfetivo.toFixed(1).replace(".", ",");

  return (
    <div className={`mt-1.5 transition-all ${className}`}>
      {/* Gatilho Clicável Integrado ao Resumo: fica minimizado por padrão */}
      <div className="flex items-center justify-between gap-2 rounded-xl bg-sky-500/10 border border-sky-400/25 px-3 py-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-sky-500/20 text-sky-300">
            <CalendarDays className="h-3.5 w-3.5" />
          </span>
          <div className="text-xs text-sky-200 min-w-0 truncate">
            <span className="font-bold">Regra DSR 2026:</span>{" "}
            {dsrEnabled ? (
              <>
                <span className="text-sky-100">+{pctEfetivoStr}% sobre HE</span>
                <span className="hidden sm:inline text-sky-300/80">
                  {" "}· ({totalDescansos} descansos ÷ {uteis} úteis)
                </span>
              </>
            ) : (
              <span className="text-slate-400">Desativado na configuração</span>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsOpen((prev) => !prev)}
          aria-expanded={isOpen}
          className="flex items-center gap-1 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 px-2.5 py-1 text-xs font-bold text-sky-100 transition active:scale-95 shrink-0 border border-sky-400/30"
          title={isOpen ? "Minimizar explicação do DSR" : "Visualizar regra, % e cálculo do DSR 2026"}
        >
          <span>{isOpen ? "Minimizar" : "Ver regra"}</span>
          {isOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
        </button>
      </div>

      {/* Aba Pequena que se abre com a regra explicativa, curta e simples */}
      {isOpen && (
        <div className="mt-2 rounded-xl border border-sky-400/30 bg-slate-900/95 p-3 sm:p-4 text-xs shadow-xl shadow-sky-950/20">
          {/* Cabeçalho Curto */}
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-2">
            <div className="flex items-center gap-1.5 font-black text-sky-300">
              <Percent className="h-4 w-4 text-sky-400" />
              <span>Cálculo do DSR 2026 (Lei 605/49 · Súmula 172 TST)</span>
            </div>
            <span className="rounded-md bg-sky-400/15 px-2 py-0.5 text-[10px] font-extrabold text-sky-300 border border-sky-400/30">
              CLT Atualizada
            </span>
          </div>

          {/* O que é em 1 frase simples */}
          <p className="mt-2 text-slate-300 leading-relaxed">
            Quem faz hora extra tem direito ao repouso remunerado proporcional nos domingos e feriados do mês.
          </p>

          {/* Fórmula Oficial Curta e Visual */}
          <div className="my-2.5 rounded-lg border border-sky-500/30 bg-sky-950/40 p-2.5">
            <div className="text-[11px] font-bold text-sky-300 mb-1">Fórmula Oficial:</div>
            <div className="text-center font-mono font-black text-sky-100 text-xs sm:text-sm tracking-wide">
              DSR = (Total HE ÷ Dias Úteis) × (Domingos + Feriados)
            </div>
          </div>

          {/* Dados do seu mês aplicados na prática */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center my-2">
            <div className="rounded-lg bg-slate-800/70 p-2 border border-slate-700/60">
              <div className="text-[10px] text-slate-400 font-semibold">Total de HE</div>
              <div className="num font-bold text-white text-xs mt-0.5">{fmtBRL(totalHE)}</div>
            </div>
            <div className="rounded-lg bg-slate-800/70 p-2 border border-slate-700/60">
              <div className="text-[10px] text-slate-400 font-semibold">Dias Úteis</div>
              <div className="num font-bold text-white text-xs mt-0.5">{uteis} dias</div>
            </div>
            <div className="rounded-lg bg-slate-800/70 p-2 border border-slate-700/60">
              <div className="text-[10px] text-slate-400 font-semibold">Dom + Feriados</div>
              <div className="num font-bold text-sky-300 text-xs mt-0.5">{totalDescansos} dias</div>
            </div>
            <div className="rounded-lg bg-sky-500/20 p-2 border border-sky-400/40">
              <div className="text-[10px] text-sky-200 font-semibold">Valor do DSR</div>
              <div className="num font-black text-sky-300 text-xs mt-0.5">+{fmtBRL(dsrValue)}</div>
            </div>
          </div>

          {/* Percentual e Regra 2026 Resumida */}
          <div className="mt-2.5 rounded-lg bg-white/[0.03] p-2.5 border border-white/[0.06] space-y-1.5 text-[11px] text-slate-300">
            <div className="flex items-start gap-1.5">
              <span className="text-sky-400 font-bold">•</span>
              <span>
                <strong>Percentual no seu mês:</strong> {totalDescansos} descansos em relação a {uteis} dias úteis representam um acréscimo de <strong className="text-sky-300">+{pctEfetivoStr}%</strong> sobre o total ganho em horas extras.
              </span>
            </div>
            <div className="flex items-start gap-1.5">
              <span className="text-sky-400 font-bold">•</span>
              <span>
                <strong>Atualização 2026 (Tema 1046 STF e TST):</strong> O DSR sobre horas extras não gera reflexo duplo ("efeito cascata"), sendo somado diretamente à remuneração bruta para cálculo de férias, 13º e FGTS.
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
