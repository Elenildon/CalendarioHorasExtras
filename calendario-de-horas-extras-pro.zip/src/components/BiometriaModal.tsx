import { useState, useEffect, useRef } from "react";
import {
  Fingerprint,
  X,
  Clock,
  Calendar,
  CheckCircle2,
  Check,
  CalendarPlus,
  History,
  Timer,
  Coffee,
  Play,
  Eye,
  EyeOff,
  Receipt,
  Trash2,
  Lock,
  Edit3,
  AlarmClock,
  Bell,
  Volume2,
  Vibrate,
  RotateCw,
  Square,
} from "lucide-react";
import {
  IntervalAlarmSettings,
  ActiveIntervalAlarm,
  AlarmRepeatOption,
  ALARM_SOUND_PRESETS,
  getAlarmSettings,
  saveAlarmSettings,
  getActiveAlarm,
  calculateIntervalTimes,
  scheduleIntervalAlarm,
  cancelIntervalAlarm,
  testIntervalAlarmNotification,
  playSoundPreview,
  stopSoundPreview,
  checkDueAlarm,
  minutesToHHdotMM,
  parseDurationInput,
  stopAlarmAudiovisual,
  wakeScreenIfPossible,
} from "../lib/intervalAlarm";
import SoundSelectorModal from "./SoundSelectorModal";
import IntervalAlarmAlertModal from "./IntervalAlarmAlertModal";
import { CircularTimePickerModal } from "./CircularTimePickerModal";
import { NativeAnalogClock } from "./NativeAnalogClock";
import { useLiveDay } from "../lib/dayRollover";
import { cn } from "../utils/cn";
import {
  PontoEventType,
  PontoRecord,
  PontoDaySummary,
  PontoBiometrico,
  calculateDaySummary,
  addPontoRecord,
  getPontoRecordsForDate,
  getAllPontoRecords,
  deletePontoRecord,
  clearPontoRecordsForDate,
  getPontoTypeLabel,
  getPontoTypeEmoji,
  getPontoBiometrico,
  saveManualCorrection,
  calculateWorkedAndOvertime,
} from "../lib/pontoStorage";
import BiometricPromptSheet from "./BiometricPromptSheet";
import iconUrl from "../assets/icon.png";

interface BiometriaModalProps {
  onClose: () => void;
  onOpenAppointment?: () => void;
  privacyMode: boolean;
  onTogglePrivacy: () => void;
  onShowToast: (msg: string) => void;
  userName?: string;
  initialDate?: string; // YYYY-MM-DD
  autoTriggerRetorno?: boolean;
  onClearAutoTriggerRetorno?: () => void;
}

export default function BiometriaModal({
  onClose,
  onOpenAppointment,
  privacyMode,
  onTogglePrivacy,
  onShowToast,
  userName = "Colaborador",
  initialDate,
  autoTriggerRetorno,
  onClearAutoTriggerRetorno,
}: BiometriaModalProps) {
  // Sincronização automática dia após dia com o motor de virada de dia
  const liveDay = useLiveDay();
  const getTodayISO = () => liveDay.todayISO;

  const [selectedDate, setSelectedDate] = useState<string>(() => initialDate || liveDay.todayISO);

  // Monitora virada de dia: se a data do ponto era a de hoje anterior, avança automaticamente
  const prevTodayRef = useRef(liveDay.todayISO);
  useEffect(() => {
    if (prevTodayRef.current !== liveDay.todayISO) {
      const oldToday = prevTodayRef.current;
      prevTodayRef.current = liveDay.todayISO;
      setSelectedDate((curr) => {
        if (curr === oldToday || !curr) {
          return liveDay.todayISO;
        }
        return curr;
      });
    }
  }, [liveDay.todayISO]);

  const [activeTab, setActiveTab] = useState<"registro" | "historico" | "comprovante">("registro");

  // Relógio oficial em tempo real
  const [currentTimeStr, setCurrentTimeStr] = useState(() => {
    return new Date().toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTimeStr(
        new Date().toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })
      );
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Resumo do dia e registros
  const [daySummary, setDaySummary] = useState<PontoDaySummary>(() =>
    calculateDaySummary(selectedDate)
  );

  const [pontoBio, setPontoBio] = useState<PontoBiometrico | null>(() =>
    getPontoBiometrico(selectedDate)
  );

  // Modal de Correção Manual (Requisito 15)
  const [showManualCorrection, setShowManualCorrection] = useState(false);
  const [manualEntrada, setManualEntrada] = useState("");
  const [manualInicioIntervalo, setManualInicioIntervalo] = useState("");
  const [manualRetornoIntervalo, setManualRetornoIntervalo] = useState("");
  const [manualSaida, setManualSaida] = useState("");

  // Recarrega sempre que a data mudar
  const refreshDaySummary = (dateStr: string = selectedDate) => {
    const summary = calculateDaySummary(dateStr);
    setDaySummary(summary);
    setPontoBio(getPontoBiometrico(dateStr));
  };

  useEffect(() => {
    refreshDaySummary(selectedDate);
  }, [selectedDate]);

  const [selectedCorrectionField, setSelectedCorrectionField] = useState<
    "entrada" | "inicioIntervalo" | "retornoIntervalo" | "saida"
  >("entrada");

  const openManualCorrection = () => {
    const currentBio = getPontoBiometrico(selectedDate);
    setManualEntrada(currentBio?.entrada || daySummary.entry?.timeShort || "");
    setManualInicioIntervalo(currentBio?.inicioIntervalo || daySummary.breakStart?.timeShort || "");
    setManualRetornoIntervalo(currentBio?.retornoIntervalo || daySummary.breakEnd?.timeShort || "");
    setManualSaida(currentBio?.saida || daySummary.exit?.timeShort || "");
    setSelectedCorrectionField("entrada");
    setShowManualCorrection(true);
  };

  const workedAndOvertime = calculateWorkedAndOvertime({
    entrada: pontoBio?.entrada || daySummary.entry?.timeShort,
    inicioIntervalo: pontoBio?.inicioIntervalo || daySummary.breakStart?.timeShort,
    retornoIntervalo: pontoBio?.retornoIntervalo || daySummary.breakEnd?.timeShort,
    saida: pontoBio?.saida || daySummary.exit?.timeShort,
  });

  // Estados do Despertador de Retorno de Intervalo (100% isolado do motor financeiro)
  const [alarmSettings, setAlarmSettings] = useState<IntervalAlarmSettings>(() => getAlarmSettings());
  const [activeAlarm, setActiveAlarm] = useState<ActiveIntervalAlarm | null>(() => getActiveAlarm());
  const [alarmAlertOpen, setAlarmAlertOpen] = useState(false);
  const [countdownStr, setCountdownStr] = useState<string>("");
  const [isTestingAlarm, setIsTestingAlarm] = useState(false);
  const [showSoundSelectorModal, setShowSoundSelectorModal] = useState(false);
  const [inlinePreviewPlaying, setInlinePreviewPlaying] = useState(false);

  const activeSoundPreset =
    ALARM_SOUND_PRESETS.find((p) => p.id === alarmSettings.soundPresetId) || ALARM_SOUND_PRESETS[0];

  const handleToggleInlineSoundPreview = () => {
    if (inlinePreviewPlaying) {
      stopSoundPreview();
      setInlinePreviewPlaying(false);
    } else {
      stopSoundPreview();
      setInlinePreviewPlaying(true);
      playSoundPreview(activeSoundPreset.id, () => {
        setInlinePreviewPlaying(false);
      });
    }
  };
  // Estado do Seletor de Hora estilo Relógio Analógico Circular 24h
  const [isCircularClockOpen, setIsCircularClockOpen] = useState(false);
  const [circularClockConfig, setCircularClockConfig] = useState<{
    target: "duracaoPadrao" | "manualEntrada" | "manualInicioIntervalo" | "manualRetornoIntervalo" | "manualSaida";
    title: string;
    initialTime?: string;
    initialMinutes?: number;
  }>({
    target: "duracaoPadrao",
    title: "Duração Padrão do Intervalo",
  });

  // Campo digital moderno e editável para digitação flexível (HH.MM ou HH:MM, ex: 01.30, 00.50, 02.00)
  const [digitalDurationInput, setDigitalDurationInput] = useState<string>(() =>
    minutesToHHdotMM(alarmSettings.durationMinutes)
  );
  const [isEditingDigitalDuration, setIsEditingDigitalDuration] = useState(false);

  useEffect(() => {
    if (!isEditingDigitalDuration) {
      setDigitalDurationInput(minutesToHHdotMM(alarmSettings.durationMinutes));
    }
  }, [alarmSettings.durationMinutes, isEditingDigitalDuration]);

  const handleApplyDigitalDuration = (val: string) => {
    const mins = parseDurationInput(val);
    if (mins && mins > 0) {
      handleUpdateAlarmSettings({ durationMinutes: mins });
      setDigitalDurationInput(minutesToHHdotMM(mins));
      setIsEditingDigitalDuration(false);
      onShowToast(`⏱️ Duração do intervalo definida para ${minutesToHHdotMM(mins)} (${mins} min)`);
    } else {
      setDigitalDurationInput(minutesToHHdotMM(alarmSettings.durationMinutes));
      setIsEditingDigitalDuration(false);
      onShowToast("⚠️ Formato inválido. Use HH.MM ou HH:MM (ex: 01.30, 00.50, 02.00)");
    }
  };

  // Contagem regressiva ao vivo quando o intervalo estiver em andamento
  useEffect(() => {
    const updateCountdown = () => {
      if (!daySummary.breakStart || daySummary.breakEnd) {
        setCountdownStr("");
        return;
      }

      const { alarmTimestamp } = calculateIntervalTimes(
        daySummary.breakStart.timeShort,
        alarmSettings.durationMinutes,
        alarmSettings.leadTimeMinutes,
        selectedDate
      );

      const now = Date.now();
      const diffMs = alarmTimestamp - now;

      if (diffMs <= 0) {
        setCountdownStr("00:00:00");
      } else {
        const totalSecs = Math.max(0, Math.floor(diffMs / 1000));
        const h = Math.floor(totalSecs / 3600);
        const m = Math.floor((totalSecs % 3600) / 60);
        const s = totalSecs % 60;
        setCountdownStr(
          `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
        );
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);
    return () => clearInterval(interval);
  }, [daySummary.breakStart, daySummary.breakEnd, alarmSettings, selectedDate]);

  // Escuta eventos globais do despertador e checa alarme pendente ao abrir
  useEffect(() => {
    const handleAlarmFired = () => {
      setAlarmAlertOpen(true);
    };
    const handleAlarmStateChanged = () => {
      setActiveAlarm(getActiveAlarm());
      setAlarmSettings(getAlarmSettings());
    };

    window.addEventListener("che:alarm-fired", handleAlarmFired);
    window.addEventListener("che:alarm-state-changed", handleAlarmStateChanged);
    window.addEventListener("che:alarm-settings-changed", handleAlarmStateChanged);

    const handleOpenPontoRetorno = () => {
      wakeScreenIfPossible().catch(() => {});
      stopAlarmAudiovisual();
      setAlarmAlertOpen(false);
      setSelectedDate(getTodayISO());
      setActiveTab("registro");
      setTimeout(() => {
        const summary = calculateDaySummary(getTodayISO());
        if (summary.breakStart && !summary.breakEnd) {
          handleStartBiometricAuth("BREAK_END");
        } else {
          const el = document.getElementById("step-retorno-intervalo");
          if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }, 150);
    };
    window.addEventListener("che:open-ponto-retorno", handleOpenPontoRetorno);

    // Se o modal foi aberto pelo gatilho da notificação de retorno
    if (autoTriggerRetorno) {
      handleOpenPontoRetorno();
      onClearAutoTriggerRetorno?.();
    }

    // Checa se há alarme vencido pendente de encerramento
    const due = checkDueAlarm();
    if (due && !daySummary.breakEnd) {
      setAlarmAlertOpen(true);
    }

    return () => {
      window.removeEventListener("che:alarm-fired", handleAlarmFired);
      window.removeEventListener("che:alarm-state-changed", handleAlarmStateChanged);
      window.removeEventListener("che:alarm-settings-changed", handleAlarmStateChanged);
      window.removeEventListener("che:open-ponto-retorno", handleOpenPontoRetorno);
    };
  }, [daySummary.breakEnd, autoTriggerRetorno]);

  // Alterna liga / desliga do despertador com destaque máximo e mínimo espaço
  const handleToggleAlarm = async () => {
    const nextEnabled = !alarmSettings.enabled;
    const newSettings: IntervalAlarmSettings = { ...alarmSettings, enabled: nextEnabled };
    setAlarmSettings(newSettings);
    saveAlarmSettings(newSettings);

    if (!nextEnabled) {
      await cancelIntervalAlarm();
      setActiveAlarm(null);
      onShowToast("🔕 Despertador do intervalo DESLIGADO");
    } else {
      onShowToast("🔔 Despertador do intervalo LIGADO");
      if (daySummary.breakStart && !daySummary.breakEnd) {
        const res = await scheduleIntervalAlarm(daySummary.breakStart.timeShort, selectedDate);
        if (res.success) {
          setActiveAlarm(getActiveAlarm());
          onShowToast(`⏰ Alarme programado para o retorno às ${res.returnTime}`);
        }
      }
    }
  };

  const handleUpdateAlarmSettings = async (patch: Partial<IntervalAlarmSettings>) => {
    const updated = { ...alarmSettings, ...patch };
    setAlarmSettings(updated);
    saveAlarmSettings(updated);

    if (updated.enabled && daySummary.breakStart && !daySummary.breakEnd) {
      const res = await scheduleIntervalAlarm(daySummary.breakStart.timeShort, selectedDate);
      if (res.success) {
        setActiveAlarm(getActiveAlarm());
      }
    }
  };

  const handleTestAlarm = async () => {
    setIsTestingAlarm(true);
    onShowToast("🔔 Testando notificação, som e vibração...");
    await testIntervalAlarmNotification();
    setTimeout(() => {
      setIsTestingAlarm(false);
      onShowToast("✅ Teste do despertador executado!");
    }, 1200);
  };

  const handleSaveManualCorrection = (e: React.FormEvent) => {
    e.preventDefault();
    saveManualCorrection(selectedDate, {
      entrada: manualEntrada.trim() || undefined,
      inicioIntervalo: manualInicioIntervalo.trim() || undefined,
      retornoIntervalo: manualRetornoIntervalo.trim() || undefined,
      saida: manualSaida.trim() || undefined,
    });
    refreshDaySummary(selectedDate);
    setShowManualCorrection(false);
    onShowToast("✅ Registro de ponto corrigido manualmente com sucesso.");
  };

  // Estado e ação para Zerar o Registro de hoje / da data selecionada
  const [showConfirmZerar, setShowConfirmZerar] = useState(false);
  const [recordToDelete, setRecordToDelete] = useState<PontoRecord | null>(null);

  const handleZerarHoje = () => {
    setShowConfirmZerar(true);
  };

  const handleConfirmZerar = () => {
    clearPontoRecordsForDate(selectedDate);
    refreshDaySummary(selectedDate);
    cancelIntervalAlarm().then(() => setActiveAlarm(null));
    setShowConfirmZerar(false);
    onShowToast(`🗑️ Registro de ${formatDisplayDate(selectedDate)} apagado com sucesso!`);
  };

  const handleDeleteRecord = (rec: PontoRecord) => {
    setRecordToDelete(rec);
  };

  const handleConfirmDeleteRecord = () => {
    if (!recordToDelete) return;
    const label = getPontoTypeLabel(recordToDelete.type);
    const time = recordToDelete.timeShort;
    if (recordToDelete.type === "BREAK_START") {
      cancelIntervalAlarm().then(() => setActiveAlarm(null));
    }
    deletePontoRecord(recordToDelete.id);
    refreshDaySummary(selectedDate);
    setRecordToDelete(null);
    onShowToast(`🗑️ Registro de ${label} (${time}) apagado com sucesso!`);
  };

  // Controle do Prompt Biométrico do Android
  const [promptEventType, setPromptEventType] = useState<PontoEventType | null>(null);

  // ========================================================
  // CONTROLE DE ETAPAS DO REGISTRO DIÁRIO:
  // Regras de funcionamento:
  // 1. Estado inicial: apenas Entrada como .ativa, demais sem destaque
  // 2. Ao clicar em Registrar Entrada → Entrada recebe .registrada, Iniciar Intervalo recebe .ativa
  // 3. Ao clicar em Iniciar → recebe .registrada, Retornar recebe .ativa
  // 4. Ao clicar em Retornar → recebe .registrada, Saída recebe .ativa
  // 5. Ao clicar em Saída → recebe .registrada, todas ficam iluminadas
  // 6. Regra de ouro: NUNCA remover .registrada de nenhuma etapa — uma vez feita, fica iluminada para sempre
  // ========================================================
  const getNextActiveStep = (summary: PontoDaySummary): PontoEventType | null => {
    if (!summary.entry) return "ENTRY";
    if (!summary.breakStart) return "BREAK_START";
    if (!summary.breakEnd) return "BREAK_END";
    if (!summary.exit) return "EXIT";
    return null; // Todas as etapas registradas!
  };

  const [activeStep, setActiveStep] = useState<PontoEventType | null>(() => {
    return getNextActiveStep(daySummary);
  });

  // Sincroniza a etapa ativa padrão ao trocar de data ou quando registros são adicionados/removidos
  useEffect(() => {
    const nextExpected = getNextActiveStep(daySummary);
    setActiveStep(nextExpected);
  }, [daySummary.entry, daySummary.breakStart, daySummary.breakEnd, daySummary.exit, selectedDate]);

  // Lógica JS: ao selecionar/clicar em uma etapa
  const handleSelectStep = (type: PontoEventType) => {
    setActiveStep(type);

    const isDone =
      (type === "ENTRY" && !!daySummary.entry) ||
      (type === "BREAK_START" && !!daySummary.breakStart) ||
      (type === "BREAK_END" && !!daySummary.breakEnd) ||
      (type === "EXIT" && !!daySummary.exit);

    if (!isDone) {
      handleStartBiometricAuth(type);
    }
  };

  // Fecha sub-diálogos internos ao receber comando de voltar do celular ou teclado
  useEffect(() => {
    const handleBackNav = (e: Event) => {
      if (promptEventType) {
        e.preventDefault();
        setPromptEventType(null);
        return;
      }
      if (showSoundSelectorModal) {
        e.preventDefault();
        setShowSoundSelectorModal(false);
        return;
      }
      if (showConfirmZerar) {
        e.preventDefault();
        setShowConfirmZerar(false);
        return;
      }
      if (showManualCorrection) {
        e.preventDefault();
        setShowManualCorrection(false);
        return;
      }
      if (recordToDelete) {
        e.preventDefault();
        setRecordToDelete(null);
        return;
      }
    };
    window.addEventListener("che:back-navigation", handleBackNav);
    return () => {
      window.removeEventListener("che:back-navigation", handleBackNav);
    };
  }, [promptEventType, showSoundSelectorModal, showConfirmZerar, showManualCorrection, recordToDelete]);

  const handleStartBiometricAuth = (type: PontoEventType) => {
    // Validação preliminar da máquina de estados
    const existing = getPontoRecordsForDate(selectedDate);
    const hasType = existing.some((r) => r.type === type);
    if (hasType) {
      const label = getPontoTypeLabel(type);
      onShowToast(`⚠️ O registro de ${label} já foi realizado.`);
      return;
    }

    setPromptEventType(type);
  };

  // Callback de sucesso da autenticação biométrica
  const handleBiometricSuccess = (result: { time: string; timeShort: string }) => {
    if (!promptEventType) return;

    const newRecord: PontoRecord = {
      id: "ponto_" + Date.now() + "_" + Math.random().toString(36).substring(2, 7),
      user: userName,
      date: selectedDate,
      time: result.time,
      timeShort: result.timeShort,
      type: promptEventType,
      authStatus: "AUTHENTICATED_BIOMETRIC",
      createdAt: Date.now(),
      geo: null, // Pronto para futura expansão GPS
    };

    const addResult = addPontoRecord(newRecord);
    setPromptEventType(null);

    if (addResult.success) {
      refreshDaySummary(selectedDate);

      // Formatação da data para o toast no padrão do exemplo: 21/09/2026 — 07:58
      const [y, m, d] = selectedDate.split("-");
      const dataFormatada = `${d}/${m}/${y}`;

      if (promptEventType === "ENTRY") {
        onShowToast(`✅ Entrada registrada com sucesso (${dataFormatada} — ${result.timeShort})`);
      } else if (promptEventType === "BREAK_START") {
        onShowToast(`✅ Início do intervalo registrado com sucesso (${dataFormatada} — ${result.timeShort})`);
        // Agenda o horário de retorno com som repetitivo, tela ligada e notificação em tela cheia
        scheduleIntervalAlarm(result.timeShort, selectedDate).then((alarmRes) => {
          if (alarmRes.success) {
            setActiveAlarm(getActiveAlarm());
            const leadMsg = alarmRes.leadMinutes > 0 ? ` (aviso ${alarmRes.leadMinutes} min antes)` : "";
            onShowToast(`⏰ Retorno programado para ${alarmRes.returnTime}${leadMsg} · Alerta em tela cheia agendado.`);
          }
        });
      } else if (promptEventType === "BREAK_END") {
        onShowToast(`✅ Retorno do intervalo registrado com sucesso (${dataFormatada} — ${result.timeShort})`);
        cancelIntervalAlarm().then(() => {
          setActiveAlarm(null);
          setAlarmAlertOpen(false);
        });
      } else if (promptEventType === "EXIT") {
        onShowToast(`✅ Saída registrada com sucesso (${dataFormatada} — ${result.timeShort})`);
      }
    } else {
      onShowToast(`❌ ${addResult.error || "Erro ao registrar o ponto."}`);
    }
  };

  // Callback de cancelamento ou falha biométrica
  const handleBiometricCancel = (_reason?: string) => {
    if (!promptEventType) return;
    setPromptEventType(null);

    // Mensagem de falha no formato exato solicitado:
    // ❌ Entrada não registrada
    if (promptEventType === "ENTRY") {
      onShowToast("❌ Entrada não registrada");
    } else if (promptEventType === "BREAK_START") {
      onShowToast("❌ Início do intervalo não registrado");
    } else if (promptEventType === "BREAK_END") {
      onShowToast("❌ Retorno do intervalo não registrado");
    } else if (promptEventType === "EXIT") {
      onShowToast("❌ Saída não registrada");
    }
  };

  // Formatação amigável da data selecionada
  const formatDisplayDate = (dateStr: string) => {
    try {
      const [y, m, d] = dateStr.split("-").map(Number);
      const dt = new Date(y, m - 1, d, 12, 0, 0);
      return dt.toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric",
      });
    } catch {
      return dateStr;
    }
  };

  const isToday = selectedDate === getTodayISO();

  // Histórico de todos os registros
  const allRecords = getAllPontoRecords().sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative flex flex-col w-full max-w-xl max-h-[94vh] rounded-3xl border border-cyan-500/40 bg-gradient-to-b from-[#0a1730] via-[#071022] to-[#040914] text-white shadow-2xl shadow-cyan-950/70 overflow-hidden">
        
        {/* Glow Tecnológico Superior */}
        <div className="pointer-events-none absolute -top-12 left-1/2 -translate-x-1/2 h-24 w-80 rounded-full bg-cyan-500/20 blur-3xl" />

        {/* Topo do Modal: Identidade e Fechar */}
        <div className="relative flex items-center justify-between border-b border-slate-800/80 px-5 pt-4 pb-3">
          <div className="flex items-center gap-3">
            <div className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl overflow-hidden shadow-md shadow-black/40 ring-1 ring-cyan-400/50">
              <img src={iconUrl} alt="Ícone Oficial do Ponto Biométrico" className="h-full w-full object-cover" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                  <span>🕐 Registro de Ponto</span>
                </h2>
                <span className="rounded-md bg-cyan-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-cyan-300 border border-cyan-500/40">
                  Biometria
                </span>
              </div>
              <p className="text-xs text-cyan-200/70">
                Ponto Eletrônico Oficial · Segurança Android BiometricPrompt
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            {onTogglePrivacy && (
              <button
                type="button"
                onClick={onTogglePrivacy}
                className={cn(
                  "rounded-xl p-2 transition active:scale-95",
                  privacyMode
                    ? "text-amber-400 bg-amber-500/15 border border-amber-500/30"
                    : "text-slate-400 hover:bg-white/10 hover:text-white"
                )}
                title={privacyMode ? "Modo Privacidade Ativado (valores em R$ ocultos)" : "Modo Privacidade Desativado"}
                aria-label="Alternar Modo Privacidade"
              >
                {privacyMode ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl p-2 text-slate-400 hover:bg-white/10 hover:text-white transition active:scale-95"
              aria-label="Fechar"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Abas Superiores de Navegação Interna */}
        <div className="flex items-center border-b border-slate-800 bg-slate-900/50 px-4 py-1.5 gap-1.5 overflow-x-auto text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab("registro")}
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-3 py-1.5 transition whitespace-nowrap",
              activeTab === "registro"
                ? "bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 shadow-sm"
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            )}
          >
            <Fingerprint className="h-3.5 w-3.5" />
            <span>Bater Ponto</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("historico")}
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-3 py-1.5 transition whitespace-nowrap",
              activeTab === "historico"
                ? "bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 shadow-sm"
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            )}
          >
            <History className="h-3.5 w-3.5" />
            <span>Histórico ({allRecords.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab("comprovante")}
            className={cn(
              "flex items-center gap-1.5 rounded-xl px-3 py-1.5 transition whitespace-nowrap",
              activeTab === "comprovante"
                ? "bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 shadow-sm"
                : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
            )}
          >
            <Receipt className="h-3.5 w-3.5" />
            <span>Comprovante REP</span>
          </button>
        </div>

        {/* Corpo do Modal (com Rolagem Otimizada) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          
          {/* ABA 1: BATER PONTO */}
          {activeTab === "registro" && (
            <>
              {/* Barra de Data e Horário em Tempo Real */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 rounded-2xl border border-slate-800 bg-slate-900/80 p-3.5">
                {/* Seletor da Data Integrada com o Calendário */}
                <div className="flex items-center gap-2.5 w-full sm:w-auto">
                  <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
                    <Calendar className="h-4 w-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        Data de Registro
                      </span>
                      {isToday ? (
                        <span className="rounded bg-emerald-500/20 px-1.5 py-0.2 text-[9px] font-bold text-emerald-300 flex items-center gap-1">
                          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span>Hoje</span>
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setSelectedDate(liveDay.todayISO)}
                          className="text-[10px] font-bold text-cyan-400 hover:underline cursor-pointer"
                          title="Voltar para o dia atual"
                        >
                          Ir para Hoje
                        </button>
                      )}
                    </div>
                    <input
                      type="date"
                      value={selectedDate}
                      onChange={(e) => {
                        if (e.target.value) setSelectedDate(e.target.value);
                      }}
                      className="mt-0.5 block w-full rounded-lg border border-slate-700 bg-slate-950 px-2 py-1 text-xs font-semibold text-white focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Relógio Oficial com Segundos */}
                <div className="flex items-center gap-2 rounded-xl border border-cyan-500/30 bg-cyan-950/30 px-3.5 py-1.5 text-right w-full sm:w-auto justify-between sm:justify-end">
                  <Clock className="h-4 w-4 text-cyan-400" />
                  <div>
                    <div className="text-[10px] font-bold uppercase tracking-wider text-cyan-300">
                      Horário Oficial
                    </div>
                    <div className="font-mono text-base font-black tracking-tight text-white">
                      {currentTimeStr}
                    </div>
                  </div>
                </div>
              </div>

              {/* 🔐 CARD PRINCIPAL EM DESTAQUE: PONTO BIOMÉTRICO (Requisitos 13 e 15) */}
              <div className="rounded-2xl border-2 border-cyan-400/50 bg-gradient-to-br from-cyan-950/60 via-slate-900/90 to-slate-950 p-4 shadow-xl shadow-cyan-950/40 relative overflow-hidden">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-cyan-500/20">
                  <div>
                    <div className="text-base font-black tracking-tight text-white flex items-center gap-2">
                      <Fingerprint className="h-5 w-5 text-cyan-400" />
                      <span>Ponto Biométrico</span>
                      {pontoBio?.corrigidoManualmente && (
                        <span className="rounded bg-amber-500/20 border border-amber-500/40 px-2 py-0.5 text-[10px] font-bold text-amber-300">
                          Ajustado manualmente
                        </span>
                      )}
                    </div>
                    <div className="mt-1 flex items-center gap-1.5 text-xs">
                      <span className="text-slate-400 font-medium">Status atual:</span>
                      <span className="font-extrabold text-cyan-300">
                        {daySummary.isComplete
                          ? "Jornada do dia concluída ✓"
                          : daySummary.nextExpectedAction === "ENTRY"
                          ? "Próximo registro: Entrada (06:00) — ajustável 🟢"
                          : daySummary.nextExpectedAction === "BREAK_START"
                          ? "Próximo registro: Intervalo ☕"
                          : daySummary.nextExpectedAction === "BREAK_END"
                          ? "Próximo registro: Retorno ▶️"
                          : daySummary.nextExpectedAction === "EXIT"
                          ? "Próximo registro: Saída 🔴"
                          : "Aguardando registro"}
                      </span>
                    </div>
                  </div>

                  {/* Opção Corrigir Registro (Requisito 15) */}
                  <button
                    type="button"
                    onClick={openManualCorrection}
                    className="inline-flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 text-xs font-bold text-amber-300 hover:bg-amber-500/20 transition active:scale-95 self-start sm:self-auto shadow-sm"
                  >
                    <Edit3 className="h-3.5 w-3.5" />
                    <span>Corrigir registro</span>
                  </button>
                </div>

                {/* Botão Principal em Destaque: Registrar Ponto (Requisito 13) */}
                <div className="pt-3">
                  <button
                    type="button"
                    disabled={daySummary.isComplete}
                    onClick={() => {
                      const next =
                        activeStep ||
                        daySummary.nextExpectedAction ||
                        (!daySummary.entry
                          ? "ENTRY"
                          : !daySummary.breakStart
                          ? "BREAK_START"
                          : !daySummary.breakEnd
                          ? "BREAK_END"
                          : "EXIT");
                      handleSelectStep(next);
                    }}
                    className={cn(
                      "w-full flex items-center justify-center gap-3 rounded-2xl py-3.5 px-4 text-base font-black transition-all duration-200 shadow-lg active:scale-[0.98]",
                      daySummary.isComplete
                        ? "bg-slate-800/80 text-emerald-400 border border-emerald-500/30 cursor-default shadow-none"
                        : "bg-gradient-to-r from-cyan-500 via-teal-400 to-emerald-400 text-slate-950 hover:brightness-110 shadow-cyan-500/25 ring-2 ring-cyan-300/50 cursor-pointer"
                    )}
                  >
                    <Lock className="h-5 w-5" />
                    <div className="text-left">
                      <div className="leading-tight">
                        {daySummary.isComplete
                          ? "✓ Todos os Pontos do Dia Foram Registrados"
                          : `🔐 Registrar Ponto (${getPontoTypeLabel(activeStep || daySummary.nextExpectedAction || (!daySummary.entry ? "ENTRY" : !daySummary.breakStart ? "BREAK_START" : !daySummary.breakEnd ? "BREAK_END" : "EXIT"))})`}
                      </div>
                      {!daySummary.isComplete && (
                        <div className="text-[11px] font-medium text-slate-900/80 leading-tight">
                          Toque para abrir a autenticação biométrica nativa do sistema
                        </div>
                      )}
                    </div>
                  </button>
                </div>
              </div>

              {/* MÁQUINA DE ESTADOS: 4 BOTÕES PRINCIPAIS DE REGISTRO */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs px-1">
                  <span className="font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <Fingerprint className="h-3.5 w-3.5 text-cyan-400" />
                    Etapas do Registro Diário
                  </span>
                  <span className="text-[11px] text-cyan-300 font-medium">
                    {daySummary.isComplete
                      ? "✓ Jornada do Dia Concluída"
                      : `Aguardando: ${getPontoTypeLabel(activeStep || daySummary.nextExpectedAction || "ENTRY")}`}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  
                  {/* 1. 🟢 REGISTRAR ENTRADA */}
                  <div
                    id="step-entrada"
                    onClick={() => handleSelectStep("ENTRY")}
                    className={cn(
                      "etapa-registro-card etapa-entrada",
                      daySummary.entry ? "registrada" : activeStep === "ENTRY" ? "ativa" : ""
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "etapa-icone-box flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-base shadow-sm transition-all duration-200",
                          daySummary.entry && "font-bold"
                        )}
                      >
                        {daySummary.entry ? <CheckCircle2 className="h-6 w-6 stroke-[2.5]" /> : "🟢"}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>Registrar Entrada</span>
                          {!daySummary.entry && (
                            <span
                              className={cn(
                                "rounded px-1.5 py-0.2 text-[9px] font-black uppercase transition-colors",
                                activeStep === "ENTRY"
                                  ? "bg-[#28a745] text-white font-black"
                                  : "bg-slate-800 text-slate-400 border border-slate-700"
                              )}
                            >
                              {activeStep === "ENTRY" ? "Ativo" : daySummary.nextExpectedAction === "ENTRY" ? "Próximo" : "Liberado"}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-300">
                          {daySummary.entry ? (
                            <span className="font-mono font-bold text-emerald-300">
                              Registrado às {daySummary.entry.timeShort}
                            </span>
                          ) : (
                            "Início da jornada · Toque para registrar"
                          )}
                        </div>
                      </div>
                    </div>

                    {daySummary.entry ? (
                      <div className="flex items-center gap-1.5">
                        <div className="rounded-xl px-3 py-2 text-xs font-bold shadow-md flex items-center gap-1.5 bg-[#28a745]/20 text-emerald-300 border border-[#28a745]/40 cursor-default">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Registrado</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteRecord(daySummary.entry!);
                          }}
                          className="rounded-xl border border-rose-500/40 bg-rose-950/40 p-2 text-rose-300 hover:bg-rose-900/70 hover:text-white transition active:scale-95 shadow-sm cursor-pointer"
                          title="Apagar este registro de Entrada"
                          aria-label="Apagar registro de Entrada"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectStep("ENTRY");
                        }}
                        className={cn(
                          "rounded-xl px-3.5 py-2 text-xs font-bold transition active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer",
                          activeStep === "ENTRY"
                            ? "bg-[#28a745] text-white hover:bg-emerald-600 ring-2 ring-emerald-300/60 shadow-emerald-500/30"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700"
                        )}
                      >
                        <Fingerprint className="h-3.5 w-3.5" />
                        <span>Registrar</span>
                      </button>
                    )}
                  </div>

                  {/* 2. ☕ INICIAR INTERVALO (Liberação total) */}
                  <div
                    id="step-inicio-intervalo"
                    onClick={() => handleSelectStep("BREAK_START")}
                    className={cn(
                      "etapa-registro-card etapa-intervalo",
                      daySummary.breakStart ? "registrada" : activeStep === "BREAK_START" ? "ativa" : ""
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "etapa-icone-box flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-base shadow-sm transition-all duration-200",
                          daySummary.breakStart && "font-bold"
                        )}
                      >
                        {daySummary.breakStart ? <CheckCircle2 className="h-6 w-6 stroke-[2.5]" /> : <Coffee className="h-5 w-5" />}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>Iniciar Intervalo</span>
                          {!daySummary.breakStart && (
                            <span
                              className={cn(
                                "rounded px-1.5 py-0.2 text-[9px] font-black uppercase transition-colors",
                                activeStep === "BREAK_START"
                                  ? "bg-[#ffc107] text-slate-950 font-black"
                                  : "bg-slate-800 text-slate-400 border border-slate-700"
                              )}
                            >
                              {activeStep === "BREAK_START" ? "Ativo" : daySummary.nextExpectedAction === "BREAK_START" ? "Próximo" : "Liberado"}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-300">
                          {daySummary.breakStart ? (
                            <span className="font-mono font-bold text-amber-300">
                              Registrado às {daySummary.breakStart.timeShort}
                            </span>
                          ) : (
                            "Saída para refeição · Toque para iniciar"
                          )}
                        </div>
                      </div>
                    </div>

                    {daySummary.breakStart ? (
                      <div className="flex items-center gap-1.5">
                        <div className="rounded-xl px-3 py-2 text-xs font-bold shadow-md flex items-center gap-1.5 bg-[#ffc107]/20 text-amber-300 border border-[#ffc107]/40 cursor-default">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Registrado</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteRecord(daySummary.breakStart!);
                          }}
                          className="rounded-xl border border-rose-500/40 bg-rose-950/40 p-2 text-rose-300 hover:bg-rose-900/70 hover:text-white transition active:scale-95 shadow-sm cursor-pointer"
                          title="Apagar este registro de Início de Intervalo"
                          aria-label="Apagar registro de Início de Intervalo"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectStep("BREAK_START");
                        }}
                        className={cn(
                          "rounded-xl px-3.5 py-2 text-xs font-bold transition active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer",
                          activeStep === "BREAK_START"
                            ? "bg-[#ffc107] text-slate-950 hover:bg-amber-400 ring-2 ring-amber-300/60 shadow-amber-500/30"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700"
                        )}
                      >
                        <Fingerprint className="h-3.5 w-3.5" />
                        <span>Iniciar</span>
                      </button>
                    )}
                  </div>

                  {/* 3. ▶️ RETORNAR DO INTERVALO */}
                  <div
                    id="step-retorno-intervalo"
                    onClick={() => handleSelectStep("BREAK_END")}
                    className={cn(
                      "etapa-registro-card etapa-retorno",
                      daySummary.breakEnd ? "registrada" : activeStep === "BREAK_END" ? "ativa" : ""
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "etapa-icone-box flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-base shadow-sm transition-all duration-200",
                          daySummary.breakEnd && "font-bold"
                        )}
                      >
                        {daySummary.breakEnd ? <CheckCircle2 className="h-6 w-6 stroke-[2.5]" /> : <Play className="h-5 w-5" />}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>Retornar Intervalo</span>
                          {!daySummary.breakEnd && (
                            <span
                              className={cn(
                                "rounded px-1.5 py-0.2 text-[9px] font-black uppercase transition-colors",
                                activeStep === "BREAK_END"
                                  ? "bg-[#17a2b8] text-white font-black"
                                  : "bg-slate-800 text-slate-400 border border-slate-700"
                              )}
                            >
                              {activeStep === "BREAK_END" ? "Ativo" : daySummary.nextExpectedAction === "BREAK_END" ? "Próximo" : "Liberado"}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-300">
                          {daySummary.breakEnd ? (
                            <span className="font-mono font-bold text-cyan-300">
                              Registrado às {daySummary.breakEnd.timeShort}
                            </span>
                          ) : (
                            "Volta às atividades · Toque para registrar"
                          )}
                        </div>
                      </div>
                    </div>

                    {daySummary.breakEnd ? (
                      <div className="flex items-center gap-1.5">
                        <div className="rounded-xl px-3 py-2 text-xs font-bold shadow-md flex items-center gap-1.5 bg-[#17a2b8]/20 text-cyan-300 border border-[#17a2b8]/40 cursor-default">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Registrado</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteRecord(daySummary.breakEnd!);
                          }}
                          className="rounded-xl border border-rose-500/40 bg-rose-950/40 p-2 text-rose-300 hover:bg-rose-900/70 hover:text-white transition active:scale-95 shadow-sm cursor-pointer"
                          title="Apagar este registro de Retorno de Intervalo"
                          aria-label="Apagar registro de Retorno de Intervalo"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectStep("BREAK_END");
                        }}
                        className={cn(
                          "rounded-xl px-3.5 py-2 text-xs font-bold transition active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer",
                          activeStep === "BREAK_END"
                            ? "bg-[#17a2b8] text-white hover:bg-cyan-600 ring-2 ring-cyan-300/60 shadow-cyan-500/30"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700"
                        )}
                      >
                        <Fingerprint className="h-3.5 w-3.5" />
                        <span>Retornar</span>
                      </button>
                    )}
                  </div>

                  {/* 4. 🔴 REGISTRAR SAÍDA */}
                  <div
                    id="step-saida"
                    onClick={() => handleSelectStep("EXIT")}
                    className={cn(
                      "etapa-registro-card etapa-saida",
                      daySummary.exit ? "registrada" : activeStep === "EXIT" ? "ativa" : ""
                    )}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={cn(
                          "etapa-icone-box flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-base shadow-sm transition-all duration-200",
                          daySummary.exit && "font-bold"
                        )}
                      >
                        {daySummary.exit ? <CheckCircle2 className="h-6 w-6 stroke-[2.5]" /> : "🔴"}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <span>Registrar Saída</span>
                          {!daySummary.exit && (
                            <span
                              className={cn(
                                "rounded px-1.5 py-0.2 text-[9px] font-black uppercase transition-colors",
                                activeStep === "EXIT"
                                  ? "bg-[#dc3545] text-white font-black"
                                  : "bg-slate-800 text-slate-400 border border-slate-700"
                              )}
                            >
                              {activeStep === "EXIT" ? "Ativo" : daySummary.nextExpectedAction === "EXIT" ? "Próximo" : "Liberado"}
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-300">
                          {daySummary.exit ? (
                            <span className="font-mono font-bold text-rose-300">
                              Registrado às {daySummary.exit.timeShort}
                            </span>
                          ) : (
                            "Término da jornada · Toque para registrar"
                          )}
                        </div>
                      </div>
                    </div>

                    {daySummary.exit ? (
                      <div className="flex items-center gap-1.5">
                        <div className="rounded-xl px-3 py-2 text-xs font-bold shadow-md flex items-center gap-1.5 bg-[#dc3545]/20 text-rose-300 border border-[#dc3545]/40 cursor-default">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Registrado</span>
                        </div>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteRecord(daySummary.exit!);
                          }}
                          className="rounded-xl border border-rose-500/40 bg-rose-950/40 p-2 text-rose-300 hover:bg-rose-900/70 hover:text-white transition active:scale-95 shadow-sm cursor-pointer"
                          title="Apagar este registro de Saída"
                          aria-label="Apagar registro de Saída"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectStep("EXIT");
                        }}
                        className={cn(
                          "rounded-xl px-3.5 py-2 text-xs font-bold transition active:scale-95 shadow-md flex items-center gap-1.5 cursor-pointer",
                          activeStep === "EXIT"
                            ? "bg-[#dc3545] text-white hover:bg-rose-600 ring-2 ring-rose-300/60 shadow-rose-500/30"
                            : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700"
                        )}
                      >
                        <Fingerprint className="h-3.5 w-3.5" />
                        <span>Registrar</span>
                      </button>
                    )}
                  </div>

                </div>
              </div>

              {/* ⏰ RELÓGIO “RETORNAR INTERVALO” (Diagramação de ponta a ponta, visualmente abaixo do Registro de Saída) */}
              <div className="rounded-2xl border border-cyan-500/40 bg-gradient-to-r from-cyan-950/50 via-slate-900/90 to-slate-950 p-4 shadow-xl shadow-cyan-950/30 space-y-3.5">
                {/* Cabeçalho do Bloco: Título, Badges e Botão LIGADO / DESLIGADO */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-cyan-500/20">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className={cn(
                        "flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-base transition shadow-md",
                        alarmSettings.enabled
                          ? "bg-cyan-500 text-slate-950 font-black shadow-cyan-400/30"
                          : "bg-slate-800 text-slate-400 border border-slate-700"
                      )}
                    >
                      <AlarmClock className={cn("h-5 w-5", alarmSettings.enabled && "animate-pulse")} />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-black text-white tracking-tight uppercase">
                          ⏰ Retornar Intervalo
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            setCircularClockConfig({
                              target: "duracaoPadrao",
                              title: "Duração Padrão do Intervalo",
                              initialMinutes: alarmSettings.durationMinutes,
                            });
                            setIsCircularClockOpen(true);
                          }}
                          className="rounded-md bg-cyan-500/20 px-2 py-0.5 text-[11px] font-mono font-bold text-cyan-300 border border-cyan-500/30 hover:bg-cyan-500/35 transition cursor-pointer flex items-center gap-1 active:scale-95 shadow-sm"
                          title="Clique para ajustar duração no Relógio Analógico Circular 24h"
                        >
                          <Clock className="h-3 w-3 text-cyan-400" />
                          <span>{minutesToHHdotMM(alarmSettings.durationMinutes)}</span>
                        </button>
                        {alarmSettings.leadTimeMinutes > 0 && (
                          <span className="rounded-md bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-300 border border-amber-500/30">
                            -{alarmSettings.leadTimeMinutes}min
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Interruptor LIGADO / DESLIGADO Super Destacado */}
                  <div className="shrink-0 self-start sm:self-center">
                    <button
                      type="button"
                      onClick={handleToggleAlarm}
                      className={cn(
                        "flex items-center gap-2 rounded-xl px-4 py-1.5 text-xs font-black tracking-wider transition active:scale-95 shadow-md cursor-pointer",
                        alarmSettings.enabled
                          ? "bg-emerald-500 hover:bg-emerald-400 text-slate-950 ring-2 ring-emerald-300/80 shadow-emerald-950/60"
                          : "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600"
                      )}
                      title={alarmSettings.enabled ? "Clique para DESLIGAR o aviso" : "Clique para LIGAR o aviso"}
                    >
                      <span
                        className={cn(
                          "h-2 w-2 rounded-full",
                          alarmSettings.enabled ? "bg-slate-950 animate-ping" : "bg-slate-500"
                        )}
                      />
                      <span>{alarmSettings.enabled ? "LIGADO" : "DESLIGADO"}</span>
                    </button>
                  </div>
                </div>

                {/* 1. CRONÔMETRO CENTRALIZADO E EVIDENTE (Hierarquia Visual Principal do Bloco) */}
                <div className="py-4 px-3 sm:px-5 rounded-2xl bg-slate-950/80 border border-cyan-500/25 text-center space-y-2.5 shadow-inner">
                  {daySummary.breakStart && !daySummary.breakEnd ? (
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-1.5 rounded-full bg-amber-500/20 border border-amber-500/40 px-3 py-0.5 text-xs font-bold text-amber-300">
                        <span className="h-2 w-2 rounded-full bg-amber-400 animate-ping" />
                        <span>Intervalo em andamento</span>
                      </div>

                      {/* Display do Cronômetro em Tamanho Gigante e Destaque Visual */}
                      <div className="font-mono text-5xl sm:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-teal-200 to-emerald-300 tracking-tight text-center drop-shadow-md select-all">
                        {countdownStr || "00:00:00"}
                      </div>

                      <p className="text-xs sm:text-sm font-semibold text-slate-300">
                        Tempo restante para retornar
                      </p>

                      <div className="text-[11px] text-slate-400 flex items-center justify-center gap-2 flex-wrap pt-0.5">
                        <span>
                          Retorno previsto:{" "}
                          <strong className="text-cyan-300 font-mono font-bold">
                            {activeAlarm?.returnTime ||
                              calculateIntervalTimes(
                                daySummary.breakStart.timeShort,
                                alarmSettings.durationMinutes,
                                0,
                                selectedDate
                              ).returnTimeStr}
                          </strong>
                        </span>
                        <span>•</span>
                        <span>
                          Início: <strong className="text-amber-300 font-mono font-bold">{daySummary.breakStart.timeShort}</strong>
                        </span>
                      </div>

                      {/* 🔵 REGISTRAR RETORNO DO INTERVALO AGORA (Com o mesmo padrão visual, tamanho e ícone) */}
                      <div className="pt-2 flex justify-center">
                        <button
                          type="button"
                          onClick={() => handleStartBiometricAuth("BREAK_END")}
                          className="inline-flex items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-400 hover:brightness-110 text-slate-950 font-black px-6 py-3 text-xs sm:text-sm shadow-xl shadow-cyan-500/30 transition active:scale-95 cursor-pointer w-full sm:w-auto"
                        >
                          <Fingerprint className="h-4 w-4 sm:h-5 sm:w-5 stroke-[2.5]" />
                          <span>Registrar Retorno do Intervalo Agora</span>
                        </button>
                      </div>
                    </div>
                  ) : daySummary.breakEnd ? (
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 border border-emerald-500/40 px-3 py-1 text-xs font-bold text-emerald-300">
                        <CheckCircle2 className="h-3.5 w-3.5" />
                        <span>Intervalo encerrado / Retorno registrado</span>
                      </div>

                      <div className="font-mono text-4xl sm:text-5xl font-black text-emerald-400 tracking-tight">
                        {daySummary.breakEnd.timeShort}
                      </div>

                      <p className="text-xs sm:text-sm text-slate-300 font-medium">
                        Retorno registrado às {daySummary.breakEnd.timeShort} com autenticação biométrica.
                      </p>

                      <div className="pt-1 flex justify-center">
                        <div className="inline-flex items-center gap-2 rounded-xl bg-slate-900 border border-emerald-500/30 px-4 py-2 text-xs font-bold text-emerald-300 shadow-sm">
                          <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                          <span>Retorno concluído com sucesso ✓</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <div className="inline-flex items-center gap-1.5 rounded-full bg-cyan-500/15 border border-cyan-500/35 px-3 py-0.5 text-xs font-semibold text-cyan-300">
                        <Timer className="h-3.5 w-3.5" />
                        <span>Duração configurada para o retorno</span>
                      </div>

                      {/* Cronômetro Centralizado no formato HH:MM:00 (Ex: 01:30:00) */}
                      <div className="font-mono text-5xl sm:text-6xl font-black text-white tracking-tight drop-shadow-md select-all">
                        {`${String(Math.floor(alarmSettings.durationMinutes / 60)).padStart(2, "0")}:${String(alarmSettings.durationMinutes % 60).padStart(2, "0")}:00`}
                      </div>

                      <p className="text-xs sm:text-sm font-semibold text-slate-300">
                        Tempo restante para retornar
                      </p>

                      <p className="text-[11px] text-slate-400 max-w-md mx-auto">
                        Ao registrar o <strong>Início do Intervalo</strong> acima, o cronômetro iniciará a contagem regressiva automaticamente.
                      </p>

                      {/* 🔵 REGISTRAR RETORNO DO INTERVALO AGORA */}
                      <div className="pt-2 flex justify-center">
                        <button
                          type="button"
                          onClick={() => handleStartBiometricAuth("BREAK_END")}
                          className="inline-flex items-center justify-center gap-2.5 rounded-2xl bg-gradient-to-r from-cyan-500 to-emerald-400 hover:brightness-110 text-slate-950 font-black px-6 py-3 text-xs sm:text-sm shadow-xl shadow-cyan-500/30 transition active:scale-95 cursor-pointer w-full sm:w-auto"
                        >
                          <Fingerprint className="h-4 w-4 sm:h-5 sm:w-5 stroke-[2.5]" />
                          <span>Registrar Retorno do Intervalo Agora</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Controles de Configuração: Duração padrão com 01:00, 02:00 e Campo Digital Editável */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-1">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-200">Duração padrão:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setCircularClockConfig({
                          target: "duracaoPadrao",
                          title: "Duração Padrão do Intervalo",
                          initialMinutes: alarmSettings.durationMinutes,
                        });
                        setIsCircularClockOpen(true);
                      }}
                      className="inline-flex items-center justify-center p-1 rounded-lg bg-cyan-500/10 text-cyan-400 hover:bg-cyan-500/25 border border-cyan-500/30 transition cursor-pointer"
                      title="Abrir seletor de hora estilo relógio analógico circular (formato 24h)"
                    >
                      <Clock className="h-3 w-3" />
                    </button>
                  </div>

                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Botão Seletor de Hora estilo Relógio Analógico Circular 24h */}
                    <button
                      type="button"
                      onClick={() => {
                        setCircularClockConfig({
                          target: "duracaoPadrao",
                          title: "Duração Padrão do Intervalo",
                          initialMinutes: alarmSettings.durationMinutes,
                        });
                        setIsCircularClockOpen(true);
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-mono text-xs font-black transition cursor-pointer border bg-slate-800 text-cyan-300 border-cyan-500/50 hover:bg-cyan-500/20 active:scale-95 shadow-sm shadow-cyan-950/40"
                      title="Abrir seletor de hora estilo relógio analógico circular (formato 24h)"
                    >
                      <Clock className="h-3.5 w-3.5 text-cyan-400" />
                      <span>Relógio 24h</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        handleUpdateAlarmSettings({ durationMinutes: 60 });
                        setDigitalDurationInput("01.00");
                      }}
                      className={cn(
                        "px-3 py-1.5 rounded-xl font-mono text-xs font-black transition cursor-pointer border",
                        alarmSettings.durationMinutes === 60
                          ? "bg-cyan-500 text-slate-950 border-cyan-400 shadow-sm shadow-cyan-500/30"
                          : "bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700"
                      )}
                    >
                      01:00
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        handleUpdateAlarmSettings({ durationMinutes: 120 });
                        setDigitalDurationInput("02.00");
                      }}
                      className={cn(
                        "px-3 py-1.5 rounded-xl font-mono text-xs font-black transition cursor-pointer border",
                        alarmSettings.durationMinutes === 120
                          ? "bg-cyan-500 text-slate-950 border-cyan-400 shadow-sm shadow-cyan-500/30"
                          : "bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700"
                      )}
                    >
                      02:00
                    </button>

                    {/* Campo digital moderno e editável para tocar e digitar manualmente (aceita HH.MM e HH:MM) com Botão [Aplicar] */}
                    <div className="flex items-center gap-1.5">
                      <div className="flex items-center gap-1 bg-slate-950 border border-cyan-500/40 rounded-xl px-2.5 py-1 focus-within:border-cyan-400 focus-within:ring-1 focus-within:ring-cyan-400 transition shadow-inner">
                        <span className="text-[10px] text-slate-400 font-mono font-bold">HH.MM:</span>
                        <input
                          type="text"
                          inputMode="decimal"
                          value={digitalDurationInput}
                          placeholder="05.00"
                          maxLength={5}
                          onFocus={() => setIsEditingDigitalDuration(true)}
                          onChange={(e) => setDigitalDurationInput(e.target.value)}
                          onBlur={(e) => handleApplyDigitalDuration(e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              (e.target as HTMLInputElement).blur();
                            }
                          }}
                          className="w-14 bg-transparent font-mono text-xs font-black text-cyan-300 focus:outline-none text-center cursor-text"
                          title="Toque para digitar no formato HH.MM ou HH:MM (ex: 00.20, 00.50, 01.10, 01.30, 02.00, 05.00)"
                        />
                      </div>
                      <button
                        type="button"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => handleApplyDigitalDuration(digitalDurationInput)}
                        className="rounded-xl bg-cyan-600 hover:bg-cyan-500 px-3 py-1.5 text-xs font-bold text-white transition active:scale-95 shadow-sm cursor-pointer"
                        title="Aplicar duração digitada"
                      >
                        Aplicar
                      </button>
                    </div>
                  </div>
                </div>

                {/* Avisar com opções de antecedência */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-800/80">
                  <span className="text-xs font-bold text-slate-200">Avisar:</span>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      { label: "No horário", val: 0 },
                      { label: "5m antes", val: 5 },
                      { label: "10m antes", val: 10 },
                      { label: "15m antes", val: 15 },
                    ].map(({ label, val }) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => handleUpdateAlarmSettings({ leadTimeMinutes: val })}
                        className={cn(
                          "px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer border",
                          alarmSettings.leadTimeMinutes === val
                            ? "bg-amber-500 text-slate-950 font-black border-amber-400 shadow-sm"
                            : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700"
                        )}
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 🔊 SEÇÃO OFICIAL: SOM DO ALARME, REPETIÇÕES E VIBRAÇÃO */}
                <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-3 sm:p-3.5 space-y-3 shadow-inner">
                  {/* Topo: Som do Alarme com 10 Presets */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        <Volume2 className="h-4 w-4" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-black uppercase tracking-wider text-cyan-400">
                            🔊 SOM DO ALARME:
                          </span>
                          <span className="text-xs font-black text-white flex items-center gap-1">
                            <span>{activeSoundPreset.emoji}</span>
                            <span>{activeSoundPreset.name}</span>
                          </span>
                          <span className="rounded bg-slate-800 border border-slate-700 px-1.5 py-0.2 text-[9px] font-bold text-slate-300">
                            {activeSoundPreset.style}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">
                          {activeSoundPreset.description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 self-start sm:self-auto">
                      {/* Botão de Prévia Isolada: ▶ Ouvir / ⏹ Parar */}
                      <button
                        type="button"
                        onClick={handleToggleInlineSoundPreview}
                        className={cn(
                          "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 shadow cursor-pointer",
                          inlinePreviewPlaying
                            ? "bg-rose-500 text-white shadow-rose-950/50 animate-pulse ring-1 ring-rose-400"
                            : "bg-slate-800 hover:bg-cyan-600 hover:text-white text-slate-200 border border-slate-700"
                        )}
                        title={inlinePreviewPlaying ? "Parar prévia" : `Ouvir prévia de ${activeSoundPreset.name}`}
                      >
                        {inlinePreviewPlaying ? (
                          <>
                            <Square className="h-3 w-3 fill-current" />
                            <span>Parar</span>
                          </>
                        ) : (
                          <>
                            <Play className="h-3 w-3 fill-current text-cyan-400 group-hover:text-white" />
                            <span>Ouvir</span>
                          </>
                        )}
                      </button>

                      {/* Botão para abrir o seletor completo dos 10 presets */}
                      <button
                        type="button"
                        onClick={() => setShowSoundSelectorModal(true)}
                        className="inline-flex items-center gap-1.5 rounded-xl border border-cyan-500/40 bg-cyan-950/50 hover:bg-cyan-900/60 px-3 py-1.5 text-xs font-black text-cyan-300 transition active:scale-95 shadow-sm cursor-pointer"
                        title="Ver e escolher entre os 10 presets de som"
                      >
                        <span>10 Presets ▾</span>
                      </button>
                    </div>
                  </div>

                  {/* Linha de Repetições e Vibração */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 pt-2.5 border-t border-slate-800/80 text-xs">
                    {/* 🔁 REPETIÇÕES DO ALARME: 1×, 2×, 3×, 5× */}
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-slate-300 font-bold flex items-center gap-1">
                        <RotateCw className="h-3.5 w-3.5 text-amber-400" />
                        <span>🔁 Repetições:</span>
                      </span>
                      <div className="flex items-center gap-1">
                        {([1, 2, 3, 5] as AlarmRepeatOption[]).map((count) => (
                          <button
                            key={count}
                            type="button"
                            onClick={() => handleUpdateAlarmSettings({ repeatCount: count })}
                            className={cn(
                              "px-2.5 py-1 rounded-xl font-mono text-xs font-black transition active:scale-95 cursor-pointer border",
                              (alarmSettings.repeatCount || 3) === count
                                ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-950/50 font-black"
                                : "bg-slate-900 text-slate-300 border-slate-700 hover:bg-slate-800"
                            )}
                            title={`Repetir alarme ${count} vez${count > 1 ? "es" : ""}`}
                          >
                            {count}×
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* 📳 VIBRAÇÃO & TESTE */}
                    <div className="flex items-center gap-3 flex-wrap">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-300 font-bold flex items-center gap-1">
                          <Vibrate className="h-3.5 w-3.5 text-teal-400" />
                          <span>Vibração:</span>
                        </span>
                        <div className="inline-flex rounded-lg bg-slate-900 border border-slate-800 p-0.5">
                          <button
                            type="button"
                            onClick={() => handleUpdateAlarmSettings({ vibrationEnabled: true })}
                            className={cn(
                              "px-2 py-0.5 rounded-md text-[10px] font-bold transition cursor-pointer",
                              alarmSettings.vibrationEnabled
                                ? "bg-teal-500 text-slate-950 font-black shadow-sm"
                                : "text-slate-400 hover:text-white"
                            )}
                          >
                            Ligada
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUpdateAlarmSettings({ vibrationEnabled: false })}
                            className={cn(
                              "px-2 py-0.5 rounded-md text-[10px] font-bold transition cursor-pointer",
                              !alarmSettings.vibrationEnabled
                                ? "bg-slate-700 text-white font-black shadow-sm"
                                : "text-slate-400 hover:text-white"
                            )}
                          >
                            Desligada
                          </button>
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={isTestingAlarm}
                        onClick={handleTestAlarm}
                        className="rounded-xl bg-indigo-600 hover:bg-indigo-500 px-3 py-1.5 text-xs font-bold text-white transition active:scale-95 flex items-center gap-1.5 shadow-md cursor-pointer disabled:opacity-50"
                        title="Testar disparo audiovisual do alarme com repetições"
                      >
                        <Bell className="h-3.5 w-3.5 text-indigo-200" />
                        <span>{isTestingAlarm ? "Testando..." : "🔔 Testar Alarme"}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 🛡️ Confirmação Oficial da Autorização de Despertador Nativo */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 rounded-xl bg-slate-950/80 border border-cyan-500/30 p-2.5 text-xs text-cyan-200">
                  <div className="flex items-center gap-2">
                    <span className="text-base shrink-0">⏰</span>
                    <div>
                      <span className="font-bold text-white">Despertador com Tela Desligada:</span>{" "}
                      <span className="text-slate-300">
                        Autorizado a tocar como despertador nativo do celular mesmo fora do app e com a tela apagada.
                      </span>
                    </div>
                  </div>
                  <span className="shrink-0 self-start sm:self-auto rounded-lg bg-emerald-500/20 border border-emerald-500/40 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-emerald-300">
                    ✓ Autorizado
                  </span>
                </div>
              </div>

              {/* 📋 VISUALIZAÇÃO DO REGISTRO DO DIA (SOMENTE OS REALIZADOS) */}
              <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/80 pb-2.5 mb-3">
                  <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <History className="h-4 w-4 text-cyan-400" />
                    <span>Registro de hoje ({formatDisplayDate(selectedDate)})</span>
                  </h3>
                  <div className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">
                      {daySummary.records.length} de 4 eventos
                    </span>
                    <button
                      type="button"
                      id="btn-zerar-registro-hoje"
                      onClick={handleZerarHoje}
                      className="rounded-xl border border-rose-500/40 bg-rose-950/40 px-3 py-1 text-xs font-bold text-rose-300 transition hover:bg-rose-900/70 hover:text-white active:scale-95 flex items-center gap-1.5 shadow-sm cursor-pointer"
                      title="Apagar todos os registros deste dia (Lixeira)"
                    >
                      <Trash2 className="h-3.5 w-3.5 text-rose-400" />
                      <span>Apagar Ponto</span>
                    </button>
                  </div>
                </div>

                {daySummary.records.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-400">
                    <Fingerprint className="mx-auto h-8 w-8 text-slate-600 mb-2" />
                    Nenhum ponto registrado para esta data ainda. Toque em <strong>Registrar Entrada</strong> com sua biometria para iniciar.
                  </div>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {/* Mostra somente os registros que já foram realizados */}
                    {daySummary.entry && (
                      <div className="relative group rounded-xl border border-emerald-500/30 bg-emerald-950/30 p-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(daySummary.entry!)}
                          className="absolute top-1.5 right-1.5 rounded-lg p-1 text-slate-400 hover:bg-rose-500/30 hover:text-rose-200 transition active:scale-90 cursor-pointer"
                          title="Apagar este registro de Entrada"
                          aria-label="Apagar Entrada"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                        <div className="text-[10px] font-bold text-emerald-300 uppercase">🟢 Entrada</div>
                        <div className="mt-1 font-mono text-lg font-black text-white">
                          {daySummary.entry.timeShort}
                        </div>
                        <div className="text-[9px] text-emerald-400/80">Biometria ✓</div>
                      </div>
                    )}

                    {daySummary.breakStart && (
                      <div className="relative group rounded-xl border border-amber-500/30 bg-amber-950/30 p-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(daySummary.breakStart!)}
                          className="absolute top-1.5 right-1.5 rounded-lg p-1 text-slate-400 hover:bg-rose-500/30 hover:text-rose-200 transition active:scale-90 cursor-pointer"
                          title="Apagar este registro de Início de Intervalo"
                          aria-label="Apagar Intervalo"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                        <div className="text-[10px] font-bold text-amber-300 uppercase">☕ Início intervalo</div>
                        <div className="mt-1 font-mono text-lg font-black text-white">
                          {daySummary.breakStart.timeShort}
                        </div>
                        <div className="text-[9px] text-amber-400/80">Biometria ✓</div>
                      </div>
                    )}

                    {daySummary.breakEnd && (
                      <div className="relative group rounded-xl border border-cyan-500/30 bg-cyan-950/30 p-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(daySummary.breakEnd!)}
                          className="absolute top-1.5 right-1.5 rounded-lg p-1 text-slate-400 hover:bg-rose-500/30 hover:text-rose-200 transition active:scale-90 cursor-pointer"
                          title="Apagar este registro de Retorno de Intervalo"
                          aria-label="Apagar Retorno"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                        <div className="text-[10px] font-bold text-cyan-300 uppercase">▶️ Retorno</div>
                        <div className="mt-1 font-mono text-lg font-black text-white">
                          {daySummary.breakEnd.timeShort}
                        </div>
                        <div className="text-[9px] text-cyan-400/80">Biometria ✓</div>
                      </div>
                    )}

                    {daySummary.exit && (
                      <div className="relative group rounded-xl border border-rose-500/30 bg-rose-950/30 p-2.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(daySummary.exit!)}
                          className="absolute top-1.5 right-1.5 rounded-lg p-1 text-slate-400 hover:bg-rose-500/30 hover:text-rose-200 transition active:scale-90 cursor-pointer"
                          title="Apagar este registro de Saída"
                          aria-label="Apagar Saída"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                        <div className="text-[10px] font-bold text-rose-300 uppercase">🔴 Saída</div>
                        <div className="mt-1 font-mono text-lg font-black text-white">
                          {daySummary.exit.timeShort}
                        </div>
                        <div className="text-[9px] text-rose-400/80">Biometria ✓</div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* ⏱️ CÁLCULO AUTOMÁTICO DA JORNADA */}
              {daySummary.records.length > 0 && (
                <div className="rounded-2xl border border-cyan-500/30 bg-gradient-to-r from-cyan-950/40 via-indigo-950/40 to-slate-900/60 p-4">
                  <div className="flex items-center justify-between mb-3 border-b border-cyan-500/20 pb-2">
                    <span className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                      <Timer className="h-4 w-4" />
                      Cálculo da Jornada de Trabalho
                    </span>
                    <span className="text-[11px] text-slate-300">Padrão: 08h 00m</span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
                    <div className="rounded-xl bg-slate-900/80 p-2 border border-slate-800">
                      <div className="text-[10px] font-bold uppercase text-slate-400">Tempo Trabalhado</div>
                      <div className="mt-1 font-mono text-base font-black text-white">
                        {pontoBio?.corrigidoManualmente ? workedAndOvertime.workedFormatted : daySummary.workedFormatted}
                      </div>
                    </div>

                    <div className="rounded-xl bg-slate-900/80 p-2 border border-slate-800">
                      <div className="text-[10px] font-bold uppercase text-slate-400">Tempo de Intervalo</div>
                      <div className="mt-1 font-mono text-base font-black text-white">
                        {daySummary.breakFormatted}
                      </div>
                    </div>

                    <div className="rounded-xl bg-slate-900/80 p-2 border border-slate-800">
                      <div className="text-[10px] font-bold uppercase text-slate-400">Saldo da Jornada</div>
                      <div
                        className={cn(
                          "mt-1 font-mono text-base font-black",
                          (pontoBio?.corrigidoManualmente ? workedAndOvertime.balanceMinutes : daySummary.balanceMinutes) > 0
                            ? "text-emerald-400"
                            : (pontoBio?.corrigidoManualmente ? workedAndOvertime.balanceMinutes : daySummary.balanceMinutes) < 0
                            ? "text-rose-400"
                            : "text-slate-300"
                        )}
                      >
                        {pontoBio?.corrigidoManualmente ? workedAndOvertime.balanceFormatted : daySummary.balanceFormatted}
                      </div>
                    </div>

                    <div className="rounded-xl bg-slate-900/80 p-2 border border-slate-800">
                      <div className="text-[10px] font-bold uppercase text-slate-400">Horas Extras</div>
                      <div
                        className={cn(
                          "mt-1 font-mono text-base font-black",
                          (pontoBio?.corrigidoManualmente ? workedAndOvertime.overtimeMinutes : daySummary.overtimeMinutes) > 0
                            ? "text-emerald-300"
                            : "text-slate-400"
                        )}
                      >
                        {pontoBio?.corrigidoManualmente ? workedAndOvertime.overtimeFormatted : daySummary.overtimeFormatted}
                      </div>
                    </div>
                  </div>

                  {/* Ação de Conexão Opcional com o Formulário de Apontamento */}
                  {onOpenAppointment && daySummary.isComplete && (
                    <div className="mt-3 pt-3 border-t border-cyan-500/20 flex flex-col sm:flex-row items-center justify-between gap-2">
                      <p className="text-[11px] text-cyan-200/80">
                        Deseja lançar estas horas no calendário como apontamento manual?
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          onClose();
                          onOpenAppointment();
                        }}
                        className="inline-flex items-center gap-1.5 rounded-xl bg-cyan-600/80 hover:bg-cyan-500 px-3 py-1.5 text-xs font-bold text-white transition active:scale-95 shadow"
                      >
                        <CalendarPlus className="h-3.5 w-3.5" />
                        <span>Abrir Apontamento</span>
                      </button>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* ABA 2: HISTÓRICO GERAL DE REGISTROS */}
          {activeTab === "historico" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-300 px-1">
                <span className="font-bold uppercase tracking-wider">Histórico de Batidas Biométricas</span>
                <span>{allRecords.length} registros no aparelho</span>
              </div>

              {allRecords.length === 0 ? (
                <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-8 text-center text-xs text-slate-300">
                  <p className="font-semibold text-slate-200">
                    Nenhum registro de ponto ainda. Comece registrando sua entrada!
                  </p>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Toque no botão principal de registro de ponto para bater sua entrada (06:00).
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {allRecords.map((rec) => {
                    const [y, m, d] = rec.date.split("-");
                    const dateFmt = `${d}/${m}/${y}`;
                    const label = getPontoTypeLabel(rec.type);
                    const emoji = getPontoTypeEmoji(rec.type);

                    return (
                      <div
                        key={rec.id}
                        className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/60 p-3 text-xs"
                      >
                        <div className="flex items-center gap-2.5">
                          <span className="text-base">{emoji}</span>
                          <div>
                            <div className="font-bold text-white">{label}</div>
                            <div className="text-[10px] text-slate-400">
                              {dateFmt} · ID: {rec.id.substring(0, 14)}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <div className="font-mono text-sm font-bold text-cyan-300">
                              {rec.timeShort}
                            </div>
                            <div className="text-[9px] text-emerald-400 font-semibold">
                              Biometria Oficial ✓
                            </div>
                          </div>

                          <button
                            type="button"
                            onClick={() => handleDeleteRecord(rec)}
                            className="rounded-lg p-2 text-rose-400 hover:bg-rose-500/20 hover:text-rose-200 transition active:scale-95 cursor-pointer"
                            title="Remover este registro"
                            aria-label={`Remover registro de ${label}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* ABA 3: COMPROVANTE DIGITAL REP */}
          {activeTab === "comprovante" && (
            <div className="space-y-3">
              <div className="rounded-2xl border border-slate-700 bg-slate-900 p-4 text-xs font-mono text-slate-300 space-y-2">
                <div className="border-b border-dashed border-slate-700 pb-2 text-center">
                  <div className="font-bold text-white uppercase text-sm">Comprovante de Registro de Ponto</div>
                  <div className="text-[10px] text-slate-400">Padrão Portaria MTP 671 / REP-P</div>
                </div>

                <div className="space-y-1 text-[11px]">
                  <div><strong>Colaborador:</strong> {userName}</div>
                  <div><strong>Data do Ponto:</strong> {selectedDate}</div>
                  <div><strong>Dispositivo:</strong> Android Biometric Authenticator</div>
                </div>

                <div className="border-t border-b border-dashed border-slate-700 py-2 space-y-1">
                  <div className="font-bold text-white">Eventos Registrados:</div>
                  {daySummary.records.length === 0 ? (
                    <div className="text-slate-500 italic">Sem eventos para este dia.</div>
                  ) : (
                    daySummary.records.map((r) => (
                      <div key={r.id} className="flex justify-between">
                        <span>{getPontoTypeLabel(r.type)}:</span>
                        <span className="font-bold text-cyan-300">{r.time}</span>
                      </div>
                    ))
                  )}
                </div>

                <div className="text-[10px] text-slate-400 space-y-0.5 pt-1">
                  <div>Autenticação: Biometria Nativa do Dispositivo</div>
                  <div>Armazenamento Seguro: Local Offline & Criptografado</div>
                </div>
              </div>

              {daySummary.records.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    window.print();
                  }}
                  className="w-full flex items-center justify-center gap-2 rounded-xl border border-slate-700 bg-slate-800 py-2.5 text-xs font-bold text-slate-200 hover:bg-slate-700 transition"
                >
                  <Receipt className="h-4 w-4" />
                  <span>Imprimir / Salvar Comprovante PDF</span>
                </button>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Modal de Correção Manual com Relógio Analógico Nativo (Requisito 15) */}
      {showManualCorrection && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3 bg-slate-950/85 backdrop-blur-md animate-in fade-in overflow-y-auto">
          <div className="relative w-full max-w-lg rounded-3xl border border-amber-500/40 bg-gradient-to-b from-[#0b1424] via-[#091120] to-[#060c18] p-4 sm:p-5 text-white shadow-2xl shadow-amber-950/80 my-auto">
            {/* Cabeçalho */}
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/40 shadow-sm">
                  <Clock className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-white flex items-center gap-1.5">
                    <span>Corrigir Registro de Ponto</span>
                    <span className="rounded-md bg-amber-500/20 px-1.5 py-0.5 text-[10px] font-bold text-amber-300 border border-amber-500/30 uppercase">
                      Relógio Analógico
                    </span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {formatDisplayDate(selectedDate)} · Ajuste direto com o relógio analógico nativo
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowManualCorrection(false)}
                className="rounded-full p-1.5 text-slate-400 hover:bg-slate-800 hover:text-white transition"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 mb-3">
              Selecione a batida desejada abaixo e utilize o <strong>relógio analógico</strong> para definir ou corrigir o horário com precisão.
            </p>

            {/* As 4 Batidas como Cards Selecionáveis */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-3">
              {/* Entrada */}
              <button
                type="button"
                onClick={() => setSelectedCorrectionField("entrada")}
                className={cn(
                  "flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 text-center cursor-pointer",
                  selectedCorrectionField === "entrada"
                    ? "bg-emerald-500/20 border-emerald-400 ring-2 ring-emerald-400/40 shadow-md shadow-emerald-950/50"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700 opacity-80"
                )}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 flex items-center gap-1">
                  <span>🟢</span> Entrada
                </span>
                <span className="font-mono text-base font-black text-white mt-0.5">
                  {manualEntrada || "--:--"}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5">
                  {selectedCorrectionField === "entrada" ? "● Selecionado" : "Toque p/ ajustar"}
                </span>
              </button>

              {/* Início Intervalo */}
              <button
                type="button"
                onClick={() => setSelectedCorrectionField("inicioIntervalo")}
                className={cn(
                  "flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 text-center cursor-pointer",
                  selectedCorrectionField === "inicioIntervalo"
                    ? "bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/40 shadow-md shadow-amber-950/50"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700 opacity-80"
                )}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1">
                  <span>☕</span> Início Int.
                </span>
                <span className="font-mono text-base font-black text-white mt-0.5">
                  {manualInicioIntervalo || "--:--"}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5">
                  {selectedCorrectionField === "inicioIntervalo" ? "● Selecionado" : "Toque p/ ajustar"}
                </span>
              </button>

              {/* Retorno Intervalo */}
              <button
                type="button"
                onClick={() => setSelectedCorrectionField("retornoIntervalo")}
                className={cn(
                  "flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 text-center cursor-pointer",
                  selectedCorrectionField === "retornoIntervalo"
                    ? "bg-cyan-500/20 border-cyan-400 ring-2 ring-cyan-400/40 shadow-md shadow-cyan-950/50"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700 opacity-80"
                )}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1">
                  <span>▶️</span> Retorno Int.
                </span>
                <span className="font-mono text-base font-black text-white mt-0.5">
                  {manualRetornoIntervalo || "--:--"}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5">
                  {selectedCorrectionField === "retornoIntervalo" ? "● Selecionado" : "Toque p/ ajustar"}
                </span>
              </button>

              {/* Saída */}
              <button
                type="button"
                onClick={() => setSelectedCorrectionField("saida")}
                className={cn(
                  "flex flex-col items-center justify-center p-2 rounded-2xl border transition active:scale-95 text-center cursor-pointer",
                  selectedCorrectionField === "saida"
                    ? "bg-rose-500/20 border-rose-400 ring-2 ring-rose-400/40 shadow-md shadow-rose-950/50"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700 opacity-80"
                )}
              >
                <span className="text-[10px] font-bold uppercase tracking-wider text-rose-300 flex items-center gap-1">
                  <span>🔴</span> Saída
                </span>
                <span className="font-mono text-base font-black text-white mt-0.5">
                  {manualSaida || "--:--"}
                </span>
                <span className="text-[9px] text-slate-400 mt-0.5">
                  {selectedCorrectionField === "saida" ? "● Selecionado" : "Toque p/ ajustar"}
                </span>
              </button>
            </div>

            {/* SEÇÃO DO RELÓGIO ANALÓGICO NATIVO INTEGRADO */}
            <div className="rounded-2xl border border-slate-800 bg-slate-950/70 p-3 flex flex-col items-center shadow-inner">
              <div className="flex items-center justify-between w-full mb-1 px-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                  <span>Ajustando:</span>
                  <strong
                    className={cn(
                      selectedCorrectionField === "entrada" && "text-emerald-400",
                      selectedCorrectionField === "inicioIntervalo" && "text-amber-400",
                      selectedCorrectionField === "retornoIntervalo" && "text-cyan-400",
                      selectedCorrectionField === "saida" && "text-rose-400"
                    )}
                  >
                    {selectedCorrectionField === "entrada" && "🟢 Entrada"}
                    {selectedCorrectionField === "inicioIntervalo" && "☕ Início do Intervalo"}
                    {selectedCorrectionField === "retornoIntervalo" && "▶️ Retorno do Intervalo"}
                    {selectedCorrectionField === "saida" && "🔴 Saída"}
                  </strong>
                </span>

                <button
                  type="button"
                  onClick={() => {
                    if (selectedCorrectionField === "entrada") setManualEntrada("");
                    if (selectedCorrectionField === "inicioIntervalo") setManualInicioIntervalo("");
                    if (selectedCorrectionField === "retornoIntervalo") setManualRetornoIntervalo("");
                    if (selectedCorrectionField === "saida") setManualSaida("");
                  }}
                  className="text-[10px] font-bold text-slate-400 hover:text-rose-400 underline transition cursor-pointer"
                >
                  Limpar este campo
                </button>
              </div>

              {/* O Relógio Analógico Nativo */}
              <NativeAnalogClock
                value={
                  selectedCorrectionField === "entrada"
                    ? manualEntrada || "08:00"
                    : selectedCorrectionField === "inicioIntervalo"
                    ? manualInicioIntervalo || "12:00"
                    : selectedCorrectionField === "retornoIntervalo"
                    ? manualRetornoIntervalo || "13:00"
                    : manualSaida || "17:00"
                }
                onChange={(newTime) => {
                  if (selectedCorrectionField === "entrada") setManualEntrada(newTime);
                  else if (selectedCorrectionField === "inicioIntervalo") setManualInicioIntervalo(newTime);
                  else if (selectedCorrectionField === "retornoIntervalo") setManualRetornoIntervalo(newTime);
                  else if (selectedCorrectionField === "saida") setManualSaida(newTime);
                }}
                accentColor={
                  selectedCorrectionField === "entrada"
                    ? "emerald"
                    : selectedCorrectionField === "inicioIntervalo"
                    ? "amber"
                    : selectedCorrectionField === "retornoIntervalo"
                    ? "cyan"
                    : "rose"
                }
              />
            </div>

            {/* Ações Inferiores */}
            <div className="flex gap-2 pt-3">
              <button
                type="button"
                onClick={() => setShowManualCorrection(false)}
                className="flex-1 rounded-xl border border-slate-700 bg-slate-800 py-3 text-xs font-bold text-slate-300 hover:bg-slate-700 active:scale-95 transition cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleSaveManualCorrection}
                className="flex-1 flex items-center justify-center gap-1.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 py-3 text-xs font-black text-slate-950 hover:from-amber-400 hover:to-amber-500 shadow-lg shadow-amber-950/60 active:scale-95 transition cursor-pointer"
              >
                <Check className="h-4 w-4" />
                <span>Salvar Correção Manual</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação: Apagar Registro Individual */}
      {recordToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-2xl border border-rose-500/40 bg-[#0a1426] p-5 shadow-2xl text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-rose-500/20 text-rose-400 mb-3">
              <Trash2 className="h-6 w-6" />
            </div>
            <h4 className="text-base font-bold text-white">Apagar Registro de Ponto?</h4>
            <p className="mt-2 text-xs text-slate-300 leading-relaxed">
              Deseja remover o registro de{" "}
              <strong className="text-rose-300">{getPontoTypeLabel(recordToDelete.type)}</strong> das{" "}
              <strong className="text-cyan-300 font-mono">{recordToDelete.timeShort}</strong> ({formatDisplayDate(recordToDelete.date)})?
            </p>
            <div className="mt-5 flex gap-2 justify-center">
              <button
                type="button"
                onClick={() => setRecordToDelete(null)}
                className="rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-bold text-slate-300 hover:bg-slate-700 active:scale-95 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                id="btn-confirmar-apagar-ponto"
                onClick={handleConfirmDeleteRecord}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500 active:scale-95 shadow-md shadow-rose-900/50 flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Sim, Apagar</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação: Zerar / Apagar Registro do Dia */}
      {showConfirmZerar && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-sm rounded-2xl border border-rose-500/40 bg-[#0a1426] p-5 shadow-2xl text-center">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-rose-500/20 text-rose-400 mb-3">
              <Trash2 className="h-6 w-6" />
            </div>
            <h4 className="text-base font-bold text-white">Apagar Registro do Dia?</h4>
            <p className="mt-2 text-xs text-slate-300 leading-relaxed">
              Tem certeza que deseja apagar todos os registros de ponto de{" "}
              <span className="font-semibold text-rose-300">
                {formatDisplayDate(selectedDate)}
              </span>
              ? Todos os horários (entrada, intervalo, saída) deste dia serão limpos do aparelho.
            </p>
            <div className="mt-5 flex gap-2 justify-center">
              <button
                type="button"
                onClick={() => setShowConfirmZerar(false)}
                className="rounded-xl border border-slate-700 bg-slate-800 px-4 py-2 text-xs font-bold text-slate-300 hover:bg-slate-700 active:scale-95 cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                id="btn-confirmar-zerar"
                onClick={handleConfirmZerar}
                className="rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500 active:scale-95 shadow-md shadow-rose-900/50 flex items-center gap-1.5 cursor-pointer"
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Sim, Apagar Tudo</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL ALERTA EM TELA CHEIA: ⏰ VOLTE DO INTERVALO AGORA! */}
      <IntervalAlarmAlertModal
        isOpen={alarmAlertOpen}
        onClose={() => {
          stopAlarmAudiovisual();
          setAlarmAlertOpen(false);
        }}
        onRetomarIntervalo={() => {
          stopAlarmAudiovisual();
          setAlarmAlertOpen(false);
          cancelIntervalAlarm();
          setActiveAlarm(null);
          handleStartBiometricAuth("BREAK_END");
        }}
        alarm={activeAlarm}
      />

      {/* Sheet Modal do Android BiometricPrompt */}
      {promptEventType && (
        <BiometricPromptSheet
          eventType={promptEventType}
          userName={userName}
          onSuccess={handleBiometricSuccess}
          onCancel={handleBiometricCancel}
        />
      )}

      {/* Modal Seletor de Som com 10 Presets */}
      <SoundSelectorModal
        isOpen={showSoundSelectorModal}
        onClose={() => setShowSoundSelectorModal(false)}
        selectedPresetId={alarmSettings.soundPresetId || "pulse"}
        onSelectPreset={(presetId) => {
          handleUpdateAlarmSettings({ soundPresetId: presetId });
        }}
        onShowToast={onShowToast}
      />

      {/* SELETOR DE HORA ESTILO RELÓGIO ANALÓGICO CIRCULAR 24H (INTEGRADO EM DURAÇÃO PADRÃO E PONTO) */}
      <CircularTimePickerModal
        isOpen={isCircularClockOpen}
        initialMinutes={circularClockConfig.initialMinutes}
        initialTime={circularClockConfig.initialTime}
        title={circularClockConfig.title}
        onClose={() => setIsCircularClockOpen(false)}
        onConfirm={(durationMinutes, timeString) => {
          if (circularClockConfig.target === "duracaoPadrao") {
            handleUpdateAlarmSettings({ durationMinutes });
            setDigitalDurationInput(minutesToHHdotMM(durationMinutes));
            onShowToast(`⏱️ Duração padrão definida para ${minutesToHHdotMM(durationMinutes)} (${durationMinutes} min) via Relógio 24h`);
          } else if (circularClockConfig.target === "manualEntrada") {
            setManualEntrada(timeString);
            onShowToast(`🟢 Entrada definida para ${timeString}`);
          } else if (circularClockConfig.target === "manualInicioIntervalo") {
            setManualInicioIntervalo(timeString);
            onShowToast(`☕ Início do intervalo definido para ${timeString}`);
          } else if (circularClockConfig.target === "manualRetornoIntervalo") {
            setManualRetornoIntervalo(timeString);
            onShowToast(`▶️ Retorno do intervalo definido para ${timeString}`);
          } else if (circularClockConfig.target === "manualSaida") {
            setManualSaida(timeString);
            onShowToast(`🔴 Saída definida para ${timeString}`);
          }
        }}
        onClear={() => {
          if (circularClockConfig.target === "duracaoPadrao") {
            handleUpdateAlarmSettings({ durationMinutes: 60 });
            setDigitalDurationInput("01.00");
            onShowToast("⏱️ Duração redefinida para o padrão de 01:00");
          } else if (circularClockConfig.target === "manualEntrada") {
            setManualEntrada("");
          } else if (circularClockConfig.target === "manualInicioIntervalo") {
            setManualInicioIntervalo("");
          } else if (circularClockConfig.target === "manualRetornoIntervalo") {
            setManualRetornoIntervalo("");
          } else if (circularClockConfig.target === "manualSaida") {
            setManualSaida("");
          }
        }}
      />
    </div>
  );
}
