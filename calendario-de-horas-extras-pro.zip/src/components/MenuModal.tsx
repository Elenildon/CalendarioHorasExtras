import { useState, useMemo, useEffect, useRef } from "react";
import {
  Menu,
  X,
  CalendarPlus,
  Save,
  Trash2,
  Sparkles,
  CheckCircle2,
  Pencil,
  AlertCircle,
  Moon,
  ChevronDown,
  ChevronUp,
  ChevronRight,
  Clock,
} from "lucide-react";
import iconUrl from "../assets/icon.png";
import { CircularTimePickerModal } from "./CircularTimePickerModal";
import { NotepadObservationField } from "./NotepadObservationField";
import { useLiveDay } from "../lib/dayRollover";
import {
  dayPercent,
  SEMANA_LONGA,
  type DayEntry,
  type DotColor,
  type Settings,
} from "../lib/calc";
import { cn } from "../utils/cn";

export interface MenuModalProps {
  onClose: () => void;
  entries: Record<string, DayEntry>;
  settings: Settings;
  cursor: { y: number; m: number };
  onSaveAppointment: (dateStr: string, entry: DayEntry) => void;
  onDeleteAppointment: (dateStr: string) => void;
  onNavigateDate?: (y: number, m: number) => void;
  onNavigateTab?: (tab: "cal" | "painel") => void;
  onShowToast: (msg: string) => void;
  whiteMode?: boolean;
}

// Função auxiliar para calcular duração entre horários de entrada e saída
function calculateHours(entrada: string, saida: string, intervalo: string): {
  hours: number;
  minutes: number;
  label: string;
} {
  if (!entrada || !saida) {
    return { hours: 0, minutes: 0, label: "0:00 h" };
  }
  const [eH, eM] = entrada.split(":").map(Number);
  const [sH, sM] = saida.split(":").map(Number);
  if (isNaN(eH) || isNaN(eM) || isNaN(sH) || isNaN(sM)) {
    return { hours: 0, minutes: 0, label: "0:00 h" };
  }

  let startMinutes = eH * 60 + eM;
  let endMinutes = sH * 60 + sM;
  if (endMinutes < startMinutes) {
    // Virada de turno noturno
    endMinutes += 24 * 60;
  }
  let durationMinutes = endMinutes - startMinutes;

  if (intervalo) {
    const [iH, iM] = intervalo.split(":").map(Number);
    if (!isNaN(iH) && !isNaN(iM)) {
      const intTotal = iH * 60 + iM;
      durationMinutes = Math.max(0, durationMinutes - intTotal);
    }
  }

  const h = Math.floor(durationMinutes / 60);
  const m = durationMinutes % 60;
  return {
    hours: h,
    minutes: m,
    label: `${h}:${String(m).padStart(2, "0")} h`,
  };
}

export default function MenuModal({
  onClose,
  entries,
  settings,
  cursor,
  onSaveAppointment,
  onDeleteAppointment,
  onNavigateDate,
  onNavigateTab,
  onShowToast,
}: MenuModalProps) {
  // Sincronização automática dia após dia em tempo real
  const liveDay = useLiveDay();

  // Inicialização padrão dinâmica com data no mês ativo ou dia de hoje
  const defaultDateStr = useMemo(() => {
    const y = cursor?.y ?? liveDay.year;
    const m = cursor?.m !== undefined ? cursor.m : liveDay.month;
    // Se o mês do cursor for o mês atual em tempo real, usa a data exata de hoje
    if (y === liveDay.year && m === liveDay.month) {
      return liveDay.todayISO;
    }
    return `${y}-${String(m + 1).padStart(2, "0")}-01`;
  }, [cursor, liveDay.year, liveDay.month, liveDay.todayISO]);

  // Inicialização inteligente da % baseada na data padrão e calendário
  const initialAutoPct = useMemo(() => {
    const parts = defaultDateStr.split("-").map(Number);
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
      const dt = new Date(parts[0], parts[1] - 1, parts[2]);
      const dow = dt.getDay();
      const auto = dayPercent(defaultDateStr, dow, settings);
      return auto.pct;
    }
    return 60;
  }, [defaultDateStr, settings]);

  // Estados do formulário — NADA É SALVO AUTOMATICAMENTE (Isolamento total até clicar em Salvar)
  const [isMinimized, setIsMinimized] = useState(true);
  const [editingDateKey, setEditingDateKey] = useState<string | null>(null);

  const [dateVal, setDateVal] = useState(defaultDateStr);

  // Monitora virada do dia: atualiza dateVal automaticamente se o usuário estava na data de hoje anterior
  const prevTodayRef = useRef(liveDay.todayISO);
  useEffect(() => {
    if (prevTodayRef.current !== liveDay.todayISO) {
      const oldToday = prevTodayRef.current;
      prevTodayRef.current = liveDay.todayISO;
      setDateVal((curr) => {
        if (curr === oldToday || !curr) {
          return liveDay.todayISO;
        }
        return curr;
      });
    }
  }, [liveDay.todayISO]);

  // ⏰ CAMPOS QUE PODEM MANTER A ÚLTIMA CONFIGURAÇÃO: Entrada, Saída, Intervalo
  const [entrada, setEntrada] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("che.last-times");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed?.entrada === "string" && parsed.entrada) return parsed.entrada;
      }
    } catch {}
    return "18:00";
  });

  const [saida, setSaida] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("che.last-times");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed?.saida === "string" && parsed.saida) return parsed.saida;
      }
    } catch {}
    return "21:00";
  });

  const [intervalo, setIntervalo] = useState<string>(() => {
    try {
      const saved = localStorage.getItem("che.last-times");
      if (saved) {
        const parsed = JSON.parse(saved);
        if (typeof parsed?.intervalo === "string" && parsed.intervalo) return parsed.intervalo;
      }
    } catch {}
    return "00:00";
  });

  // 💰 CAMPO QUE NÃO DEVE SER MEMORIZADO: Tipo de hora → sempre seguir o Calendário
  const [tipoPct, setTipoPct] = useState<number>(initialAutoPct);
  const [noturno, setNoturno] = useState(false);
  const [observacao, setObservacao] = useState("Finalização da produção");
  const [formError, setFormError] = useState<string | null>(null);
  const [savedSuccessMsg, setSavedSuccessMsg] = useState<string | null>(null);

  // Estado para controle do Relógio Analógico Circular 24h
  const [activeClockTarget, setActiveClockTarget] = useState<"entrada" | "saida" | "intervalo" | null>(null);

  const openClockPicker = (target: "entrada" | "saida" | "intervalo") => {
    setActiveClockTarget(target);
  };

  const closeClockPicker = () => {
    setActiveClockTarget(null);
  };

  const handleClockConfirm = (_mins: number, timeStr: string) => {
    if (activeClockTarget === "entrada") {
      setEntrada(timeStr);
      onShowToast(`⏰ Entrada definida para ${timeStr}`);
    } else if (activeClockTarget === "saida") {
      setSaida(timeStr);
      onShowToast(`⏰ Saída definida para ${timeStr}`);
    } else if (activeClockTarget === "intervalo") {
      setIntervalo(timeStr);
      onShowToast(`☕ Intervalo definido para ${timeStr}`);
    }
    setActiveClockTarget(null);
  };

  const handleClockClear = () => {
    if (activeClockTarget === "entrada") {
      setEntrada("00:00");
    } else if (activeClockTarget === "saida") {
      setSaida("00:00");
    } else if (activeClockTarget === "intervalo") {
      setIntervalo("00:00");
    }
  };

  // 🔒 REGRA DE SINCRONIZAÇÃO: DATA SELECIONADA → CALENDÁRIO → TIPO DE HORA AUTOMÁTICO
  // Em caso de conflito: CALENDÁRIO TEM PRIORIDADE SOBRE A CONFIGURAÇÃO SALVA DO APONTAMENTO.
  // Tipo de hora nunca memoriza a última seleção ao mudar de dia.
  const lastSyncDateRef = useRef<string>("");

  useEffect(() => {
    if (lastSyncDateRef.current !== dateVal) {
      lastSyncDateRef.current = dateVal;
      const parts = dateVal.split("-").map(Number);
      if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
        const dt = new Date(parts[0], parts[1] - 1, parts[2]);
        const dow = dt.getDay();
        const auto = dayPercent(dateVal, dow, settings);
        setTipoPct(auto.pct);
      }
    }
  }, [dateVal, settings]);

  // Informações completas de automação da data integrada ao calendário
  const autoDayInfo = useMemo(() => {
    const parts = dateVal.split("-").map(Number);
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
      const dt = new Date(parts[0], parts[1] - 1, parts[2]);
      const dow = dt.getDay();
      const auto = dayPercent(dateVal, dow, settings);
      const dowNames = [
        "Domingo",
        "Segunda-feira",
        "Terça-feira",
        "Quarta-feira",
        "Quinta-feira",
        "Sexta-feira",
        "Sábado",
      ];
      const dowName = dowNames[dow] || SEMANA_LONGA[dow];

      let labelDesc = "";
      if (auto.holiday) {
        labelDesc = `Feriado ${auto.holiday.kind} · ${auto.holiday.name}`;
      } else if (dow === 0) {
        labelDesc = "Domingo (DSR)";
      } else if (dow === 6) {
        labelDesc = "Sábado";
      } else {
        labelDesc = `${dowName} (Dia Útil)`;
      }

      return {
        dow,
        dowName,
        autoPct: auto.pct,
        holiday: auto.holiday,
        labelDesc,
        isHoliday: !!auto.holiday,
        isSunday: dow === 0,
        isSaturday: dow === 6,
        isWeekday: dow >= 1 && dow <= 5 && !auto.holiday,
      };
    }
    return null;
  }, [dateVal, settings]);

  // Calcula total em tempo real no formulário
  const totalCalc = useMemo(() => {
    return calculateHours(entrada, saida, intervalo);
  }, [entrada, saida, intervalo]);

  // Atualiza data e tipo automático conforme dia da semana e feriados do calendário
  const handleDateChange = (newDateStr: string) => {
    setDateVal(newDateStr);
    setFormError(null);
    setSavedSuccessMsg(null);

    const parts = newDateStr.split("-").map(Number);
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
      const dt = new Date(parts[0], parts[1] - 1, parts[2]);
      const dow = dt.getDay();
      const auto = dayPercent(newDateStr, dow, settings);
      setTipoPct(auto.pct);
    }
  };

  // Carrega um apontamento para edição
  const handleStartEdit = (key: string, entry: DayEntry) => {
    setEditingDateKey(key);
    setDateVal(key);
    // Tenta deduzir horários se possível ou formata com as horas registradas
    const h = entry.hours || 0;
    const m = entry.minutes || 0;
    setEntrada("18:00");
    const endH = (18 + h) % 24;
    setSaida(`${String(endH).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
    setIntervalo("00:00");
    setNoturno(entry.noturno ?? false);
    setObservacao(entry.note ?? "");

    // 🔒 REGRA DE PRIORIDADE: CALENDÁRIO TEM PRIORIDADE SOBRE A CONFIGURAÇÃO SALVA DO APONTAMENTO
    const parts = key.split("-").map(Number);
    if (parts.length === 3) {
      const dt = new Date(parts[0], parts[1] - 1, parts[2]);
      const dow = dt.getDay();
      const auto = dayPercent(key, dow, settings);
      setTipoPct(auto.pct);
    }

    setIsMinimized(false);
    setFormError(null);
    setSavedSuccessMsg(null);
  };

  // Limpa formulário para novo lançamento: Entrada, Saída e Intervalo MANTÊM a última configuração
  const handleNewAppointment = () => {
    setEditingDateKey(null);
    setDateVal(defaultDateStr);

    // Tipo de hora sempre segue o Calendário da data selecionada
    const parts = defaultDateStr.split("-").map(Number);
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
      const dt = new Date(parts[0], parts[1] - 1, parts[2]);
      const dow = dt.getDay();
      const auto = dayPercent(defaultDateStr, dow, settings);
      setTipoPct(auto.pct);
    } else {
      setTipoPct(60);
    }

    setNoturno(false);
    setObservacao("Finalização da produção");
    setIsMinimized(false);
    setFormError(null);
    setSavedSuccessMsg(null);
  };

  // 💾 REGRA DE SALVAMENTO: Processamento SOMENTE ao clicar em "SALVAR APONTAMENTO"
  const handleSalvarApontamento = () => {
    setFormError(null);
    setSavedSuccessMsg(null);

    // 1. Validar os dados
    if (!dateVal || dateVal.trim().length === 0) {
      setFormError("Por favor, selecione uma data válida.");
      return;
    }

    const [yNum, mNum, dNum] = dateVal.split("-").map(Number);
    if (isNaN(yNum) || isNaN(mNum) || isNaN(dNum)) {
      setFormError("Data inválida. Use o formato AAAA-MM-DD.");
      return;
    }

    if (totalCalc.hours === 0 && totalCalc.minutes === 0) {
      setFormError("O total de horas extras deve ser superior a 0:00 h.");
      return;
    }

    // 2. Criar o apontamento
    const dotColor: DotColor =
      tipoPct >= 100 ? "rose" : tipoPct >= 75 ? "amber" : "indigo";

    const payload: DayEntry = {
      hours: totalCalc.hours,
      minutes: totalCalc.minutes,
      noturno,
      note: observacao.trim(),
      dot: dotColor,
      pct: tipoPct,
      savedAt: Date.now(),
    };

    // 3. Salvar no Calendário + 4. Salvar em Lançamentos de Setembro
    onSaveAppointment(dateVal, payload);

    // ⏰ Salvar após o clique de salvar apontamento: Entrada, Saída e Intervalo mantêm a última configuração preenchida
    try {
      localStorage.setItem(
        "che.last-times",
        JSON.stringify({ entrada, saida, intervalo })
      );
    } catch {}

    // Sincroniza visualização do calendário para o mês do apontamento
    if (onNavigateDate) {
      onNavigateDate(yNum, mNum - 1);
    }
    if (onNavigateTab) {
      onNavigateTab("cal");
    }

    // 5. Confirmar visualmente que o lançamento foi salvo
    const msg = `Apontamento salvo no Calendário e em Lançamentos de Setembro (${String(dNum).padStart(2, "0")}/${String(mNum).padStart(2, "0")}/${yNum})!`;
    setSavedSuccessMsg(msg);
    onShowToast(msg);

    setEditingDateKey(null);
  };

  // Exclusão sincronizada do apontamento
  const handleExcluirApontamento = (targetKey: string) => {
    onDeleteAppointment(targetKey);
    onShowToast("Apontamento removido do Calendário e de Lançamentos de Setembro.");
    if (editingDateKey === targetKey) {
      handleNewAppointment();
    }
  };

  // Lista de apontamentos registrados em Setembro (ou mês ativo)
  const septemberEntriesList = useMemo(() => {
    const list: Array<{
      key: string;
      dateLabel: string;
      entry: DayEntry;
      dayNum: number;
      pct?: number;
    }> = [];

    const targetYear = cursor?.y ?? 2026;
    const targetMonth = cursor?.m !== undefined ? cursor.m : 8; // 8 = Setembro

    Object.entries(entries).forEach(([k, entry]) => {
      const parts = k.split("-").map(Number);
      if (parts.length === 3) {
        const [y, m, d] = parts;
        if (y === targetYear && m === targetMonth + 1) {
          const dow = new Date(y, m - 1, d).getDay();
          const auto = dayPercent(k, dow, settings);
          list.push({
            key: k,
            dateLabel: `${String(d).padStart(2, "0")}/${String(m).padStart(2, "0")}/${y}`,
            entry,
            dayNum: d,
            // 🔒 REGRA DE PRIORIDADE: CALENDÁRIO TEM PRIORIDADE SOBRE A CONFIGURAÇÃO SALVA DO APONTAMENTO
            pct: auto.pct,
          });
        }
      }
    });

    list.sort((a, b) => a.dayNum - b.dayNum);
    return list;
  }, [entries, cursor, settings]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl border border-slate-700/80 bg-gradient-to-b from-[#0e162e] via-[#090e1f] to-[#060914] p-5 sm:p-6 text-white shadow-2xl shadow-black/90">
        {/* Botão Fechar */}
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-2 text-slate-400 hover:bg-white/10 hover:text-white transition active:scale-95"
          aria-label="Fechar menu"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Cabeçalho do Menu */}
        <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
          <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg shadow-indigo-500/30 ring-1 ring-white/20">
            <Menu className="h-6 w-6 text-white" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-black text-white sm:text-2xl">
                Menu
              </h2>
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-[11px] font-bold text-emerald-400 border border-emerald-500/30">
                ⚙️ Motor do Calendário
              </span>
              {/* 📅 Atalho rápido 3D ao lado de ⚙️ Motor do Calendário */}
              <button
                type="button"
                onClick={() => {
                  if (onNavigateTab) onNavigateTab("cal");
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 rounded-xl bg-gradient-to-b from-indigo-500 via-indigo-600 to-indigo-800 px-3 py-1 text-xs font-black text-white shadow-md shadow-indigo-950/80 border-t border-white/25 border-x border-indigo-400/30 border-b-[3px] border-indigo-950 active:border-b-0 active:translate-y-[2px] ring-1 ring-white/20 hover:brightness-110 transition cursor-pointer"
                title="Abrir Calendário existente"
              >
                <img
                  src={iconUrl}
                  alt="Calendário Inteligente"
                  className="h-4 w-4 rounded-full object-cover ring-1 ring-cyan-300 shadow-sm"
                />
                <span>📅 Calendário</span>
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Automação inteligente exclusiva: Calendário & Lançamentos de Setembro
            </p>
          </div>
        </div>

        {/* 🔒 ITENS DO MENU: 📅 Calendário e ➕ Adicionar Apontamento com preenchimento direto */}
        <div className="mt-4 space-y-4">
          {/* 📅 Atalho Rápido para o Calendário (Botão em 3D com a imagem do Calendário Inteligente) */}
          <button
            type="button"
            onClick={() => {
              if (onNavigateTab) onNavigateTab("cal");
              onClose();
            }}
            className="w-full flex items-center justify-between gap-3 rounded-2xl bg-gradient-to-b from-indigo-600 via-indigo-700 to-indigo-900 p-3.5 sm:p-4 text-left text-white transition active:scale-[0.99] border-t border-indigo-300/40 border-x border-indigo-500/40 border-b-[4px] border-indigo-950 active:border-b-0 active:translate-y-[3px] shadow-xl shadow-indigo-950/90 ring-1 ring-white/20 group cursor-pointer"
          >
            <div className="flex items-center gap-3.5">
              <div className="relative h-11 w-11 shrink-0">
                <div className="absolute -inset-1 rounded-full bg-cyan-400/40 blur-sm" />
                <img
                  src={iconUrl}
                  alt="Calendário Inteligente"
                  className="relative h-11 w-11 rounded-full object-cover ring-2 ring-cyan-400 shadow-md shadow-cyan-500/30 group-hover:scale-105 transition"
                />
              </div>
              <div>
                <span className="text-base font-black text-white block tracking-wide flex items-center gap-2">
                  📅 Calendário
                  <span className="rounded-full bg-cyan-500/25 px-2 py-0.5 text-[10px] font-extrabold text-cyan-200 border border-cyan-400/30 uppercase">
                    Navegação Rápida
                  </span>
                </span>
                <span className="text-xs text-indigo-100/80 font-medium">
                  Ir para a tela principal do Calendário existente
                </span>
              </div>
            </div>
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white border border-white/20 shadow-sm group-hover:bg-white/20 transition shrink-0">
              <ChevronRight className="h-5 w-5" />
            </span>
          </button>

          {/* ➕ ABA ADICIONAR APONTAMENTO EM TOTAL EVIDÊNCIA: NOME COMPLETO E SEM CORTES */}
          <div
            className={cn(
              "rounded-2xl border transition-all duration-200 overflow-hidden shadow-xl",
              isMinimized
                ? "border-emerald-500/40 bg-gradient-to-br from-slate-900 via-slate-900/95 to-emerald-950/20 hover:border-emerald-400/60 shadow-emerald-950/30"
                : "border-emerald-400/60 bg-gradient-to-b from-slate-900/95 via-slate-900/90 to-[#0b1324] shadow-2xl ring-2 ring-emerald-500/30"
            )}
          >
            {/* Cabeçalho da Aba com Adicionar Apontamento em Evidência Total */}
            <div
              className={cn(
                "flex items-center justify-between gap-3 p-3.5 sm:p-4 transition-colors",
                isMinimized
                  ? "bg-slate-900/90 hover:bg-slate-900"
                  : "bg-emerald-500/15 border-b border-emerald-500/30"
              )}
            >
              <div
                onClick={() => setIsMinimized((prev) => !prev)}
                className="flex items-center gap-3.5 cursor-pointer flex-1 min-w-0 select-none group"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 via-teal-500 to-emerald-600 text-white shadow-lg shadow-emerald-500/30 ring-2 ring-emerald-400/40 group-hover:scale-105 transition">
                  <CalendarPlus className="h-6 w-6" />
                </div>
                <div className="min-w-0 flex-1">
                  {/* NOME EM TOTAL EVIDÊNCIA — COMPLETO, DESTACADO E SEM CORTES */}
                  <div className="flex flex-col sm:flex-row sm:items-center sm:gap-2.5">
                    <h3 className="text-lg sm:text-xl font-black tracking-tight text-white drop-shadow-md flex items-center gap-1.5 leading-tight">
                      <span className="text-emerald-400">➕</span>
                      <span>Adicionar apontamento</span>
                    </h3>
                    <div className="flex items-center gap-1.5 mt-1 sm:mt-0">
                      <span className="rounded-full bg-emerald-500/25 px-2.5 py-0.5 text-[11px] font-extrabold text-emerald-300 border border-emerald-500/40 whitespace-nowrap">
                        {septemberEntriesList.length > 0
                          ? `Setembro (${septemberEntriesList.length})`
                          : "Novo Registro"}
                      </span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    {isMinimized
                      ? septemberEntriesList.length > 0
                        ? `Toque para abrir formulário e ver lançamentos (${septemberEntriesList.length})`
                        : "Toque para abrir o formulário e lançar horas extras"
                      : "Formulário aberto · Lançar horas extras no Calendário e Setembro"}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                {editingDateKey && !isMinimized && (
                  <button
                    type="button"
                    onClick={handleNewAppointment}
                    className="rounded-xl bg-slate-800 px-3 py-1.5 text-xs font-bold text-slate-300 border border-slate-700 hover:bg-slate-700 transition"
                  >
                    Novo
                  </button>
                )}

                {/* Botão de Toggle compacto: Chevron elegante sem rótulo 'Abrir' */}
                <button
                  type="button"
                  onClick={() => setIsMinimized((prev) => !prev)}
                  className={cn(
                    "flex h-11 w-11 items-center justify-center rounded-2xl border transition active:scale-95 shadow-md cursor-pointer shrink-0",
                    isMinimized
                      ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30 ring-1 ring-emerald-400/30 shadow-emerald-950/40"
                      : "bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700 hover:text-white"
                  )}
                  title={isMinimized ? "Expandir formulário de apontamento" : "Minimizar formulário"}
                  aria-label={isMinimized ? "Expandir apontamento" : "Minimizar apontamento"}
                >
                  {isMinimized ? (
                    <ChevronDown className="h-5 w-5 text-emerald-400" />
                  ) : (
                    <ChevronUp className="h-5 w-5 text-slate-300" />
                  )}
                </button>
              </div>
            </div>

            {/* Conteúdo direto da aba (exibido quando aberta) */}
            {!isMinimized && (
              <>
                {/* Notificação de Sucesso */}
                {savedSuccessMsg && (
                  <div className="m-4 flex items-center gap-2.5 rounded-xl border border-emerald-500/40 bg-emerald-500/15 p-3 text-xs sm:text-sm font-semibold text-emerald-300 animate-in fade-in duration-200">
                    <CheckCircle2 className="h-5 w-5 text-emerald-400 shrink-0" />
                    <span>{savedSuccessMsg}</span>
                  </div>
                )}

                {/* Notificação de Erro */}
                {formError && (
                  <div className="m-4 flex items-center gap-2.5 rounded-xl border border-rose-500/40 bg-rose-500/15 p-3 text-xs sm:text-sm font-semibold text-rose-300 animate-in fade-in duration-200">
                    <AlertCircle className="h-5 w-5 text-rose-400 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                {/* CAMPOS DIRETAMENTE DENTRO DA ABA */}
                <div className="p-4 sm:p-5 space-y-4">
                  {/* Topo do formulário diagramado em linha reta */}
                  <div className="flex items-center justify-between pb-3 border-b border-emerald-500/20">
                    <div className="flex items-center gap-2">
                      <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-xs sm:text-sm font-black uppercase tracking-wider text-emerald-300 whitespace-nowrap">
                        Adicionar apontamento
                      </span>
                    </div>
                    <span className="rounded-md bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-400 border border-emerald-500/20 whitespace-nowrap">
                      {editingDateKey ? "Modo de Edição" : "Novo Lançamento"}
                    </span>
                  </div>
                  {/* 📅 Data: Selecionar a data do apontamento */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                        <span>📅</span>
                        <span>Data</span>
                        <span className="text-[11px] font-normal text-slate-400 lowercase">(selecionar a data do apontamento)</span>
                      </label>
                      <div className="flex items-center gap-1.5">
                        {dateVal === liveDay.todayISO ? (
                          <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 text-[10px] font-bold text-emerald-300 flex items-center gap-1">
                            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                            <span>Hoje</span>
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleDateChange(liveDay.todayISO)}
                            className="text-[10px] font-bold text-emerald-400 hover:underline cursor-pointer"
                          >
                            Ir para Hoje
                          </button>
                        )}
                        {autoDayInfo && (
                          <span className="rounded-md bg-indigo-500/20 px-2 py-0.5 text-[10px] font-bold text-indigo-300 border border-indigo-500/30">
                            {autoDayInfo.dowName}
                          </span>
                        )}
                      </div>
                    </div>
                    <input
                      type="date"
                      value={dateVal}
                      onChange={(e) => handleDateChange(e.target.value)}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950/80 px-3.5 py-2.5 text-sm font-semibold text-white focus:border-emerald-400 focus:outline-none"
                    />
                    {/* Badge e status da integração automática com o calendário */}
                    {autoDayInfo && (
                      <div className="mt-2 flex items-center justify-between gap-2 flex-wrap text-xs">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold border",
                            autoDayInfo.isHoliday || autoDayInfo.isSunday
                              ? "bg-rose-500/15 border-rose-500/30 text-rose-300"
                              : autoDayInfo.isSaturday
                              ? "bg-amber-500/15 border-amber-500/30 text-amber-300"
                              : "bg-indigo-500/15 border-indigo-500/30 text-indigo-300"
                          )}
                        >
                          <span>
                            {autoDayInfo.isHoliday ? "🎉" : autoDayInfo.isSunday ? "☀️" : autoDayInfo.isSaturday ? "📅" : "💼"}
                          </span>
                          <span>{autoDayInfo.labelDesc}</span>
                        </span>
                        <span className="text-[11px] text-emerald-400 font-bold flex items-center gap-1">
                          <span>⚡ Regra do calendário:</span>
                          <span className="underline decoration-emerald-500/50">+{autoDayInfo.autoPct}%</span>
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Grid: ⏰ Horário de entrada, ⏰ Horário de saída, ☕ Intervalo com Relógio Analógico Circular 24h */}
                  <div className="grid grid-cols-3 gap-2.5">
                    {/* Entrada com Relógio Analógico Circular 24h */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wide text-slate-300 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1 text-emerald-300">
                          <Clock className="h-3 w-3 text-emerald-400" /> Entrada
                        </span>
                      </label>
                      <button
                        type="button"
                        onClick={() => openClockPicker("entrada")}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-950/80 hover:bg-slate-900 hover:border-emerald-400/60 px-2.5 py-2 text-center text-sm font-black font-mono text-white transition active:scale-95 shadow-sm group cursor-pointer"
                        title="Abrir seletor de hora estilo relógio analógico circular (formato 24h)"
                      >
                        <Clock className="h-3.5 w-3.5 text-emerald-400 group-hover:rotate-45 transition-transform" />
                        <span className="tracking-wider">{entrada || "08:00"}</span>
                      </button>
                    </div>

                    {/* Saída com Relógio Analógico Circular 24h */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wide text-slate-300 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1 text-rose-300">
                          <Clock className="h-3 w-3 text-rose-400" /> Saída
                        </span>
                      </label>
                      <button
                        type="button"
                        onClick={() => openClockPicker("saida")}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-950/80 hover:bg-slate-900 hover:border-rose-400/60 px-2.5 py-2 text-center text-sm font-black font-mono text-white transition active:scale-95 shadow-sm group cursor-pointer"
                        title="Abrir seletor de hora estilo relógio analógico circular (formato 24h)"
                      >
                        <Clock className="h-3.5 w-3.5 text-rose-400 group-hover:rotate-45 transition-transform" />
                        <span className="tracking-wider">{saida || "17:00"}</span>
                      </button>
                    </div>

                    {/* Intervalo com Relógio Analógico Circular 24h */}
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wide text-slate-300 mb-1 flex items-center justify-between">
                        <span className="flex items-center gap-1 text-cyan-300">
                          <Clock className="h-3 w-3 text-cyan-400" /> Intervalo
                        </span>
                      </label>
                      <button
                        type="button"
                        onClick={() => openClockPicker("intervalo")}
                        className="w-full flex items-center justify-center gap-1.5 rounded-xl border border-slate-700 bg-slate-950/80 hover:bg-slate-900 hover:border-cyan-400/60 px-2.5 py-2 text-center text-sm font-black font-mono text-white transition active:scale-95 shadow-sm group cursor-pointer"
                        title="Abrir seletor de hora estilo relógio analógico circular (formato 24h)"
                      >
                        <Clock className="h-3.5 w-3.5 text-cyan-400 group-hover:rotate-45 transition-transform" />
                        <span className="tracking-wider">{intervalo || "00:00"}</span>
                      </button>
                    </div>
                  </div>

                  {/* 🕐 Total de horas */}
                  <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-emerald-300 uppercase tracking-wide flex items-center gap-1">
                        <span>🕐</span> Total de horas
                      </span>
                      <span className="text-[10px] text-slate-400 block">Cálculo automático pelos horários</span>
                    </div>
                    <span className="text-lg font-black text-emerald-400">
                      {totalCalc.label}
                    </span>
                  </div>

                  {/* 💰 Tipo de hora extra: Automação Integrada com o Calendário + Editável */}
                  <div className="rounded-xl border border-slate-700/80 bg-slate-950/60 p-3.5 space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-bold uppercase tracking-wide text-slate-200 flex items-center gap-1.5">
                        <span>💰</span> Tipo de hora extra
                      </label>
                      <div className="flex items-center gap-1.5">
                        <span className="rounded-full bg-emerald-500/20 px-2.5 py-0.5 text-xs font-black text-emerald-300 border border-emerald-500/40 shadow-sm">
                          +{tipoPct}% selecionado
                        </span>
                      </div>
                    </div>

                    {/* Banner explicativo da Automação Integrada com o Calendário */}
                    {autoDayInfo && (
                      <div
                        className={cn(
                          "rounded-xl p-3 text-xs border transition-all duration-200",
                          autoDayInfo.isHoliday || autoDayInfo.isSunday
                            ? "border-rose-500/40 bg-rose-500/10 text-rose-200"
                            : autoDayInfo.isSaturday
                            ? "border-amber-500/40 bg-amber-500/10 text-amber-200"
                            : "border-indigo-500/40 bg-indigo-500/10 text-indigo-200"
                        )}
                      >
                        <div className="flex items-start justify-between gap-2.5">
                          <div className="flex items-start gap-2.5 min-w-0">
                            <span className="text-xl shrink-0 select-none">
                              {autoDayInfo.isHoliday
                                ? "🎉"
                                : autoDayInfo.isSunday
                                ? "☀️"
                                : autoDayInfo.isSaturday
                                ? "📅"
                                : "💼"}
                            </span>
                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-black text-white text-xs sm:text-sm">
                                  {autoDayInfo.labelDesc}
                                </span>
                                <span
                                  className={cn(
                                    "px-2 py-0.5 rounded-md text-[10px] font-black border",
                                    autoDayInfo.isHoliday || autoDayInfo.isSunday
                                      ? "bg-rose-500/20 text-rose-300 border-rose-500/40"
                                      : autoDayInfo.isSaturday
                                      ? "bg-amber-500/20 text-amber-300 border-amber-500/40"
                                      : "bg-indigo-500/20 text-indigo-300 border-indigo-500/40"
                                  )}
                                >
                                  +{autoDayInfo.autoPct}% no Calendário
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-300 mt-1 leading-relaxed">
                                {autoDayInfo.isHoliday
                                  ? `Feriado ${autoDayInfo.holiday?.kind}: ${autoDayInfo.holiday?.name}. Percentual de +${autoDayInfo.autoPct}% ajustado automaticamente.`
                                  : autoDayInfo.isSunday
                                  ? "Domingo (DSR): adicional de 100% ajustado automaticamente conforme o calendário."
                                  : autoDayInfo.isSaturday
                                  ? "Sábado: adicional de 75% ajustado automaticamente conforme o calendário."
                                  : "Dia útil de semana (Segunda a Sexta): adicional padrão de 60% ajustado automaticamente conforme o calendário."}
                              </p>
                            </div>
                          </div>

                          {tipoPct !== autoDayInfo.autoPct && (
                            <button
                              type="button"
                              onClick={() => setTipoPct(autoDayInfo.autoPct)}
                              className="shrink-0 text-[10px] font-black bg-white/10 hover:bg-white/20 text-white px-2.5 py-1 rounded-lg border border-white/20 transition cursor-pointer active:scale-95 flex items-center gap-1"
                              title="Restaurar % automático do calendário"
                            >
                              <Sparkles className="h-3 w-3 text-amber-300" />
                              Reaplicar +{autoDayInfo.autoPct}%
                            </button>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Campo editável direto + Seletor com mais valores */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 items-center">
                      {/* Campo editável direto (permite digitar qualquer valor) */}
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block mb-1">
                          Digitar porcentagem (%):
                        </span>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-black text-emerald-400">
                            +
                          </span>
                          <input
                            type="number"
                            min={0}
                            max={1000}
                            step={1}
                            value={tipoPct}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              setTipoPct(isNaN(val) ? 0 : val);
                            }}
                            className="w-full rounded-xl border border-slate-700 bg-slate-900 pl-7 pr-8 py-2 text-sm font-black text-white focus:border-emerald-400 focus:outline-none"
                            placeholder="60"
                            title="Digite qualquer porcentagem de hora extra"
                          />
                          <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                            %
                          </span>
                        </div>
                      </div>

                      {/* Dropdown com mais valores em % */}
                      <div>
                        <span className="text-[10px] text-slate-400 font-semibold block mb-1">
                          Selecionar valor predefinido:
                        </span>
                        <select
                          value={[50, 60, 70, 75, 80, 100].includes(tipoPct) ? tipoPct : "custom"}
                          onChange={(e) => {
                            if (e.target.value !== "custom") {
                              setTipoPct(Number(e.target.value));
                            }
                          }}
                          className="w-full rounded-xl border border-slate-700 bg-slate-900 px-3 py-2 text-xs font-bold text-white focus:border-emerald-400 focus:outline-none"
                        >
                          <option value={50}>+50% (Padrão CLT)</option>
                          <option value={60}>+60% (Acordo Coletivo / Dias Úteis)</option>
                          <option value={70}>+70% (Convenção)</option>
                          <option value={75}>+75% (Sábado / Turno)</option>
                          <option value={80}>+80% (Escala Especial)</option>
                          <option value={100}>+100% (Domingo / Feriado)</option>
                          <option value="custom">Outro % (Personalizado)</option>
                        </select>
                      </div>
                    </div>

                    {/* Botões rápidos em % */}
                    <div className="pt-2 border-t border-slate-800/80">
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">
                          Valores rápidos:
                        </span>
                        <span className="text-[10px] text-slate-400">
                          (máximo +100%)
                        </span>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {[50, 60, 70, 75, 80, 100].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => setTipoPct(val)}
                            className={cn(
                              "rounded-lg px-2.5 py-1 text-xs font-bold transition active:scale-95 cursor-pointer",
                              tipoPct === val
                                ? "bg-emerald-500 text-slate-950 font-black shadow-sm ring-1 ring-emerald-300"
                                : "bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700/60"
                            )}
                          >
                            +{val}%
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Adicional noturno, quando aplicável */}
                  <button
                    type="button"
                    onClick={() => setNoturno((v) => !v)}
                    className={cn(
                      "w-full flex items-center justify-between rounded-xl border p-2.5 text-xs font-bold transition",
                      noturno
                        ? "border-indigo-400/60 bg-indigo-500/20 text-indigo-200"
                        : "border-slate-700 bg-slate-950/60 text-slate-400 hover:text-slate-300"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <Moon className="h-4 w-4 text-indigo-400" />
                      <span>Adicional noturno, quando aplicável (22h–5h)</span>
                    </div>
                    <span>+{settings?.noturnoPct || 20}%</span>
                  </button>

                  {/* 📝 Observação: Campo tipo Bloco de Notas multilinha */}
                  <NotepadObservationField
                    value={observacao}
                    onChange={setObservacao}
                    placeholder="Digite anotações ou detalhes adicionais (ex: Finalização da produção, plantão emergencial...)"
                    label="Observação"
                    optionalText="(opcional)"
                    theme="emerald"
                  />

                  {/* BOTÃO SALVAR APONTAMENTO NA PARTE INFERIOR DO FORMULÁRIO */}
                  <div className="pt-2 flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={handleSalvarApontamento}
                      className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-500 px-4 py-3.5 text-sm sm:text-base font-black text-white shadow-lg shadow-emerald-900/50 hover:from-emerald-500 hover:to-teal-500 active:scale-95 transition cursor-pointer"
                    >
                      <Save className="h-5 w-5" />
                      <span>💾 Salvar Apontamento</span>
                    </button>

                    {editingDateKey && (
                      <button
                        type="button"
                        onClick={() => handleExcluirApontamento(editingDateKey)}
                        className="flex items-center justify-center gap-1.5 rounded-xl border border-rose-500/40 bg-rose-500/10 px-3.5 py-3 text-xs font-bold text-rose-300 hover:bg-rose-500/20 active:scale-95 transition cursor-pointer"
                      >
                        <Trash2 className="h-4 w-4" />
                        <span>Excluir</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* 📋 LANÇAMENTOS DE SETEMBRO REGISTRADOS: INCLUSO DENTRO DA ABA ADICIONAR APONTAMENTO */}
                <div className="border-t border-emerald-500/30 bg-slate-950/70 p-4 sm:p-5">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                      <Sparkles className="h-3.5 w-3.5 text-amber-400" />
                      Lançamentos de Setembro Registrados ({septemberEntriesList.length})
                    </h4>
                    {septemberEntriesList.length > 0 && (
                      <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-md">
                        {septemberEntriesList.length} {septemberEntriesList.length === 1 ? "registro ativo" : "registros ativos"}
                      </span>
                    )}
                  </div>

                  {septemberEntriesList.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-slate-800 p-4 text-center text-xs text-slate-500">
                      Nenhum apontamento registrado em Setembro ainda. Preencha os campos acima e clique em{" "}
                      <strong className="text-slate-300">💾 Salvar Apontamento</strong>.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                      {septemberEntriesList.map((item) => (
                        <div
                          key={item.key}
                          className="flex flex-col gap-2 rounded-xl border border-slate-800 bg-slate-900/90 p-2.5 sm:p-3 text-xs text-slate-300 hover:border-emerald-500/40 transition"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <div className="min-w-0 flex items-center gap-2 sm:gap-2.5 flex-wrap">
                              <span className="font-bold text-white bg-slate-800 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-lg border border-slate-700 text-xs">
                                {item.dateLabel}
                              </span>
                              <span className="font-black text-emerald-400 text-xs sm:text-sm">
                                {item.entry.hours}:{String(item.entry.minutes || 0).padStart(2, "0")} h
                              </span>
                              {item.pct && (
                                <span className="font-bold text-[10px] text-indigo-300 bg-indigo-500/20 border border-indigo-500/30 px-1.5 py-0.5 rounded">
                                  +{item.pct}%
                                </span>
                              )}
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleStartEdit(item.key, item.entry)}
                                className="p-1.5 rounded-lg text-indigo-400 hover:bg-indigo-500/20 active:scale-95 transition"
                                title="Editar apontamento"
                              >
                                <Pencil className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleExcluirApontamento(item.key)}
                                className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/20 active:scale-95 transition"
                                title="Excluir apontamento"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>

                          {/* No relatório/lista: bloco contínuo, com quebras preservadas */}
                          {item.entry.note && (
                            <div className="w-full rounded-lg bg-slate-950/70 border border-slate-800/80 p-2 text-xs text-slate-200 whitespace-pre-wrap break-words text-left leading-relaxed font-sans border-l-2 border-l-emerald-400">
                              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                                Observação:
                              </span>
                              {item.entry.note}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* SELETOR DE HORA ESTILO RELÓGIO ANALÓGICO CIRCULAR 24H (ENTRADA, SAÍDA E INTERVALO) */}
      <CircularTimePickerModal
        isOpen={activeClockTarget !== null}
        initialTime={
          activeClockTarget === "entrada"
            ? entrada
            : activeClockTarget === "saida"
            ? saida
            : intervalo
        }
        title={
          activeClockTarget === "entrada"
            ? "⏰ Horário de Entrada"
            : activeClockTarget === "saida"
            ? "⏰ Horário de Saída"
            : "☕ Tempo de Intervalo"
        }
        onClose={closeClockPicker}
        onConfirm={handleClockConfirm}
        onClear={handleClockClear}
      />
    </div>
  );
}
