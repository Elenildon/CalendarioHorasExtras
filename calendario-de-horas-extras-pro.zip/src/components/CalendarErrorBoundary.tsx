import { Component, ErrorInfo, ReactNode } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";

interface Props {
  children: ReactNode;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  errorMessage: string;
}

/**
 * ErrorBoundary protetor da área do Calendário e edição de dias.
 * Se ocorrer qualquer exceção inesperada ao clicar ou renderizar um dia,
 * evita tela preta / unmount geral e apresenta opção segura de retorno.
 */
export default class CalendarErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    errorMessage: "",
  };

  public static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      errorMessage: error?.message || "Erro inesperado ao carregar dados do calendário",
    };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error("CalendarErrorBoundary capturou erro:", error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, errorMessage: "" });
    if (this.props.onReset) {
      this.props.onReset();
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="mx-4 my-6 rounded-2xl border border-amber-500/40 bg-slate-900/95 p-6 text-center shadow-xl backdrop-blur-sm">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl border border-amber-400/40 bg-amber-500/20 text-amber-300">
            <AlertTriangle className="h-6 w-6" />
          </div>
          <h3 className="text-lg font-black text-white">
            Instabilidade temporária no Calendário
          </h3>
          <p className="mt-2 text-sm text-slate-300 leading-relaxed max-w-md mx-auto">
            Ocorreu uma oscilação pontual ao abrir as informações deste dia. Seus dados e anotações continuam 100% seguros e preservados.
          </p>
          <div className="mt-5 flex justify-center">
            <button
              type="button"
              onClick={this.handleReset}
              className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 px-5 py-2.5 text-sm font-bold text-white shadow-lg shadow-indigo-900/40 transition hover:brightness-110 active:scale-95"
            >
              <RefreshCw className="h-4 w-4" />
              <span>Voltar ao Calendário</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
