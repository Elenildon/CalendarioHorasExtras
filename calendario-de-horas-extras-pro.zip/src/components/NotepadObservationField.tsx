import React, { useRef, useEffect, useCallback } from "react";
import { NotebookPen, CornerDownLeft } from "lucide-react";
import { cn } from "../utils/cn";

export interface NotepadObservationFieldProps {
  value: string;
  onChange: (val: string) => void;
  placeholder?: string;
  label?: string;
  optionalText?: string;
  className?: string;
  theme?: "emerald" | "indigo" | "amber";
}

export const NotepadObservationField: React.FC<NotepadObservationFieldProps> = ({
  value,
  onChange,
  placeholder = "Digite anotações ou detalhes adicionais (ex: Finalização da produção, plantão emergencial...)",
  label = "Observação",
  optionalText = "(opcional)",
  className,
  theme = "emerald",
}) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Ajusta a altura automaticamente: mínimo 3 linhas (~78px), expansível até 10 linhas (~240px)
  const adjustHeight = useCallback(() => {
    const el = textareaRef.current;
    if (!el) return;

    el.style.height = "auto";
    const minHeight = 78; // aprox. 3 linhas (com line-height e padding)
    const maxHeight = 240; // aprox. 10 linhas
    const scrollHeight = el.scrollHeight;

    if (scrollHeight <= minHeight) {
      el.style.height = `${minHeight}px`;
      el.style.overflowY = "hidden";
    } else if (scrollHeight >= maxHeight) {
      el.style.height = `${maxHeight}px`;
      el.style.overflowY = "auto";
    } else {
      el.style.height = `${scrollHeight}px`;
      el.style.overflowY = "hidden";
    }
  }, []);

  // Recalcula sempre que o valor mudar externamente (ex: ao carregar anotação para editar)
  useEffect(() => {
    adjustHeight();
  }, [value, adjustHeight]);

  const themeColors = {
    emerald: {
      borderFocus: "focus-within:border-emerald-400 focus-within:ring-1 focus-within:ring-emerald-400/40",
      accentBorder: "border-l-4 border-l-emerald-500",
      badge: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
      icon: "text-emerald-400",
    },
    indigo: {
      borderFocus: "focus-within:border-indigo-400 focus-within:ring-1 focus-within:ring-indigo-400/40",
      accentBorder: "border-l-4 border-l-indigo-500",
      badge: "bg-indigo-500/15 text-indigo-300 border-indigo-500/30",
      icon: "text-indigo-400",
    },
    amber: {
      borderFocus: "focus-within:border-amber-400 focus-within:ring-1 focus-within:ring-amber-400/40",
      accentBorder: "border-l-4 border-l-amber-500",
      badge: "bg-amber-500/15 text-amber-300 border-amber-500/30",
      icon: "text-amber-400",
    },
  }[theme];

  return (
    <div className={cn("w-full space-y-1.5", className)}>
      {/* Topo do Campo: Label e Badges de Formato */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <label className="text-xs font-bold uppercase tracking-wider text-slate-200 flex items-center gap-1.5">
          <NotebookPen className={cn("h-4 w-4", themeColors.icon)} />
          <span>{label}</span>
          {optionalText && (
            <span className="text-[10px] font-normal text-slate-400 lowercase">
              {optionalText}
            </span>
          )}
        </label>

        <span
          className={cn(
            "inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-bold border",
            themeColors.badge
          )}
          title="Bloco de Notas: digite livremente, aperte Enter para saltar linhas e o texto quebrará automaticamente"
        >
          <CornerDownLeft className="h-3 w-3" />
          <span>Bloco de Notas · Multilinha</span>
        </span>
      </div>

      {/* Caixa do Bloco de Notas */}
      <div
        className={cn(
          "w-full rounded-2xl border border-slate-700/80 bg-slate-950/90 p-3 shadow-inner transition-colors",
          themeColors.accentBorder,
          themeColors.borderFocus
        )}
      >
        <textarea
          ref={textareaRef}
          rows={3}
          wrap="soft"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            adjustHeight();
          }}
          onKeyDown={(e) => {
            // Garante que o ENTER salte linha inteira e desça o texto sem submeter formulários
            if (e.key === "Enter") {
              e.stopPropagation();
            }
          }}
          placeholder={placeholder}
          className="w-full bg-transparent text-sm sm:text-base text-slate-100 placeholder-slate-500 focus:outline-none resize-none leading-relaxed text-left whitespace-pre-wrap break-words min-h-[78px] max-h-[240px]"
          style={{ minHeight: "78px", maxHeight: "240px" }}
        />

        {/* Rodapé do Bloco de Notas: Guia de Uso e Contagem */}
        <div className="mt-1 flex items-center justify-between border-t border-slate-800/80 pt-1.5 text-[11px] text-slate-400">
          <span className="flex items-center gap-1">
            <span>Enter = saltar linha</span>
            <span>·</span>
            <span>Quebra automática ativa</span>
          </span>
          <span className="font-mono text-[10px] text-slate-400">
            {value.length > 0 ? `${value.length} carac.` : "3 a 10 linhas"}
          </span>
        </div>
      </div>
    </div>
  );
};
