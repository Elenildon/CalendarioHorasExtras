import { useState, useEffect } from "react";
import {
  AlarmClock,
  CheckCircle2,
  VolumeX,
  Vibrate,
  Clock,
  Sparkles,
  Smartphone,
  Layers,
  BatteryCharging,
  BellRing,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import {
  ActiveIntervalAlarm,
  ALARM_SOUND_PRESETS,
  isAlarmAudiovisualActive,
  getAlarmRepeatState,
  stopAlarmAudiovisual,
  wakeScreenIfPossible,
  getAlarmSettings,
  checkNativeAlarmStatus,
  requestExactAlarmPermission,
  requestIgnoreBatteryOptimizations,
  requestOverlayPermission,
  requestNotificationPolicyPermission,
  requestFullScreenIntentPermission,
} from "../lib/intervalAlarm";

interface IntervalAlarmAlertModalProps {
  isOpen: boolean;
  onClose: () => void;
  onRetomarIntervalo: () => void;
  alarm?: ActiveIntervalAlarm | null;
}

export default function IntervalAlarmAlertModal({
  isOpen,
  onClose,
  onRetomarIntervalo,
  alarm,
}: IntervalAlarmAlertModalProps) {
  const [currentTimeStr, setCurrentTimeStr] = useState(() => {
    return new Date().toLocaleTimeString("pt-BR", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  });

  const [isAudioRinging, setIsAudioRinging] = useState(isAlarmAudiovisualActive);
  const [repeatProgress, setRepeatProgress] = useState(() => getAlarmRepeatState());
  const [showPermissions, setShowPermissions] = useState(false);
  const [permStatus, setPermStatus] = useState({
    isNative: false,
    canScheduleExact: true,
    ignoresBatteryOptimizations: true,
    canDrawOverlays: true,
    notificationsEnabled: true,
  });

  const settings = getAlarmSettings();

  // Relógio oficial em tempo real e verificação contínua da tela acesa
  useEffect(() => {
    if (!isOpen) return;

    // 1. Ligar/acender a tela do celular imediatamente
    wakeScreenIfPossible().catch(() => {});

    // Checa status de permissões
    checkNativeAlarmStatus().then(setPermStatus).catch(() => {});

    setRepeatProgress(getAlarmRepeatState());

    const timer = setInterval(() => {
      setCurrentTimeStr(
        new Date().toLocaleTimeString("pt-BR", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
        })
      );
      setIsAudioRinging(isAlarmAudiovisualActive());
    }, 1000);

    const onRingingStarted = () => {
      setIsAudioRinging(true);
      setRepeatProgress(getAlarmRepeatState());
    };
    const onRingingStopped = () => {
      setIsAudioRinging(false);
      setRepeatProgress(getAlarmRepeatState());
    };
    const onRepeatProgress = (e: any) => {
      if (e.detail) {
        setRepeatProgress({
          current: e.detail.current || 1,
          total: e.detail.total || 5,
          active: true,
        });
      }
    };

    window.addEventListener("che:alarm-ringing-started", onRingingStarted);
    window.addEventListener("che:alarm-ringing-stopped", onRingingStopped);
    window.addEventListener("che:alarm-repeat-progress", onRepeatProgress);

    return () => {
      clearInterval(timer);
      window.removeEventListener("che:alarm-ringing-started", onRingingStarted);
      window.removeEventListener("che:alarm-ringing-stopped", onRingingStopped);
      window.removeEventListener("che:alarm-repeat-progress", onRepeatProgress);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToggleSound = () => {
    if (isAudioRinging) {
      stopAlarmAudiovisual();
      setIsAudioRinging(false);
    }
  };

  // Botão ✅ CONFIRMAR RETORNO:
  // 1. Para som imediatamente
  // 2. Fecha aviso de tela cheia
  // 3. Registra a etapa de Retorno do Intervalo no Calendário de Horas Extras
  const handleConfirmReturn = () => {
    stopAlarmAudiovisual();
    onClose();
    onRetomarIntervalo();
  };

  const handleSilenceOnly = () => {
    stopAlarmAudiovisual();
    setIsAudioRinging(false);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Alerta de Retorno do Intervalo"
      className="fixed inset-0 z-[100] w-screen h-screen min-h-screen bg-gradient-to-b from-[#060e22] via-[#040816] to-[#01040a] text-white flex flex-col justify-between p-4 sm:p-7 select-none animate-in fade-in duration-200 overflow-y-auto"
    >
      {/* Luz ambiente pulsante de fundo (Audiovisual Neon Alert Waves) */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden flex items-center justify-center">
        <div className="h-[500px] w-[500px] rounded-full bg-amber-500/15 blur-[120px] animate-pulse" />
        <div className="h-[400px] w-[400px] rounded-full bg-cyan-500/20 blur-[100px] animate-ping" />
      </div>

      {/* TOP HEADER: Branding & Titular Oficial em Tela Cheia */}
      <div className="relative z-10 w-full max-w-xl mx-auto flex flex-col items-center pt-2 sm:pt-4 text-center">
        {/* Badge do App */}
        <div className="inline-flex items-center gap-2 rounded-full bg-cyan-500/15 px-4 py-1.5 border border-cyan-400/40 text-xs font-black uppercase tracking-wider text-cyan-300 shadow-lg shadow-cyan-500/20 mb-3">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500" />
          </span>
          <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
          <span>Calendário de Horas Extras</span>
        </div>

        {/* TITULAR REQUISITADO: ⏰ VOLTE DO INTERVALO AGORA! */}
        <h1 className="text-3xl sm:text-5xl font-black text-amber-300 tracking-tight leading-tight drop-shadow-[0_0_30px_rgba(251,191,36,0.6)] animate-pulse">
          ⏰ VOLTE DO INTERVALO AGORA!
        </h1>

        <p className="mt-1.5 text-base sm:text-xl font-bold text-cyan-200 tracking-wide">
          Calendário de Horas Extras · Retorno às Atividades
        </p>
      </div>

      {/* CORPO CENTRAL: Radar Animado + Relógio em Tempo Real + Indicador Audiovisual */}
      <div className="relative z-10 w-full max-w-md mx-auto my-auto flex flex-col items-center py-4">
        {/* Radar e Ícone Central com Ondas Expansivas */}
        <div className="relative flex h-32 w-32 sm:h-36 sm:w-36 items-center justify-center my-3">
          {/* Ondas Sonoras Expansivas */}
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-amber-400 opacity-25" />
          <span className="absolute inline-flex h-28 w-28 animate-pulse rounded-full bg-cyan-400 opacity-35" />

          {/* Ícone Central Gigante */}
          <div className="relative flex h-24 w-24 sm:h-28 sm:w-28 items-center justify-center rounded-3xl bg-gradient-to-tr from-amber-500 via-orange-400 to-amber-300 text-slate-950 shadow-2xl shadow-amber-500/50 ring-4 ring-amber-300/40">
            <AlarmClock className="h-14 w-14 sm:h-16 sm:w-16 stroke-[2.5] animate-bounce" />
          </div>
        </div>

        {/* Relógio Digital Oficial em Tempo Real */}
        <div className="w-full mt-3 rounded-3xl border-2 border-cyan-400/60 bg-slate-950/80 p-4 text-center shadow-2xl shadow-cyan-500/30 backdrop-blur-md ring-2 ring-cyan-500/20">
          <div className="text-[11px] font-bold text-cyan-300 uppercase tracking-widest flex items-center justify-center gap-1.5">
            <Clock className="h-3.5 w-3.5 text-cyan-400" />
            <span>Horário de Brasília · Tempo Real</span>
          </div>

          <div className="mt-1 text-4xl sm:text-5xl font-mono font-black text-white tracking-widest drop-shadow-[0_0_20px_rgba(34,211,238,0.5)]">
            {currentTimeStr}
          </div>

          {alarm && (
            <div className="mt-2 pt-2 border-t border-slate-800/80 text-xs sm:text-sm text-slate-300">
              Retorno programado:{" "}
              <strong className="text-amber-300 font-mono text-base font-black">
                {alarm.returnTime}
              </strong>
              {alarm.startTime && (
                <span className="text-slate-400 ml-1.5">
                  (iniciado às {alarm.startTime})
                </span>
              )}
            </div>
          )}
        </div>

        {/* Status Audiovisual: Tocar som repetidamente sem parar até confirmação */}
        <div className="w-full mt-3 rounded-2xl border border-amber-500/40 bg-amber-950/30 p-3 flex items-center justify-between gap-2 shadow-lg shadow-amber-950/40">
          <div className="flex items-center gap-2.5">
            {isAudioRinging ? (
              <div className="flex items-end gap-1 h-5 w-5 text-amber-300" title="Alerta Sonoro Ativo">
                <span className="w-1.5 bg-amber-400 rounded-full animate-[pulse_0.5s_ease-in-out_infinite] h-3" />
                <span className="w-1.5 bg-amber-400 rounded-full animate-[pulse_0.3s_ease-in-out_infinite] h-5" />
                <span className="w-1.5 bg-amber-400 rounded-full animate-[pulse_0.7s_ease-in-out_infinite] h-4" />
              </div>
            ) : (
              <VolumeX className="h-5 w-5 text-slate-400" />
            )}

            <div className="text-left">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-xs sm:text-sm font-bold text-amber-200">
                  {isAudioRinging
                    ? "Alerta sonoro em execução"
                    : "Som pausado temporariamente"}
                </p>
                {isAudioRinging && (
                  <span className="font-mono text-amber-300 font-black bg-amber-500/25 border border-amber-400/50 px-2 py-0.5 rounded-lg text-xs">
                    🔊 {repeatProgress.current}/{repeatProgress.total}
                  </span>
                )}
                {(() => {
                  const p = ALARM_SOUND_PRESETS.find(
                    (s) => s.id === (alarm?.soundPresetId || settings.soundPresetId)
                  ) || ALARM_SOUND_PRESETS[0];
                  return (
                    <span className="rounded bg-slate-900 border border-amber-500/30 px-1.5 py-0.5 text-[10px] font-bold text-amber-300 font-mono">
                      {p.name} ({p.style})
                    </span>
                  );
                })()}
              </div>
              <p className="text-[11px] text-amber-300/80">
                {isAudioRinging
                  ? `Reprodução sequencial ${repeatProgress.current} de ${repeatProgress.total} (encerra automaticamente após a ${repeatProgress.total}ª).`
                  : "Toque em confirmar para registrar o retorno."}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {settings.vibrationEnabled && (
              <span className="flex items-center gap-1 text-[11px] text-amber-300 font-mono px-2 py-0.5 rounded-lg bg-amber-500/20 border border-amber-400/30">
                <Vibrate className="h-3 w-3 animate-pulse" />
                Vibrando
              </span>
            )}

            {isAudioRinging && (
              <button
                type="button"
                onClick={handleToggleSound}
                className="rounded-xl bg-slate-800 px-2.5 py-1 text-xs font-bold text-slate-200 hover:bg-slate-700 active:scale-95 transition"
              >
                Pausar Som
              </button>
            )}
          </div>
        </div>

        {/* Card Expansível de Permissões do Sistema */}
        <div className="w-full mt-3 rounded-2xl border border-slate-800 bg-slate-900/60 p-3 text-left">
          <button
            type="button"
            onClick={() => setShowPermissions((prev) => !prev)}
            className="w-full flex items-center justify-between text-xs font-bold text-slate-300 hover:text-white transition cursor-pointer"
          >
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span>Status das Permissões do Sistema</span>
            </div>
            <div className="flex items-center gap-1 text-slate-400">
              <span className="text-[11px] text-emerald-400 font-semibold">5/5 Ativas</span>
              {showPermissions ? (
                <ChevronUp className="h-4 w-4" />
              ) : (
                <ChevronDown className="h-4 w-4" />
              )}
            </div>
          </button>

          {showPermissions && (
            <div className="mt-3 pt-3 border-t border-slate-800 space-y-2 text-[11px] text-slate-300">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Smartphone className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Ligar / Acender tela (WakeLock)</span>
                </span>
                <span className="text-emerald-400 font-bold">✅ Ativo</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Layers className="h-3.5 w-3.5 text-amber-400" />
                  <span>Exibir sobre outros apps / Tela de bloqueio</span>
                </span>
                {permStatus.isNative && !permStatus.canDrawOverlays ? (
                  <button
                    type="button"
                    onClick={requestOverlayPermission}
                    className="text-amber-300 underline font-bold"
                  >
                    Ativar
                  </button>
                ) : (
                  <span className="text-emerald-400 font-bold">✅ Ativo</span>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <Clock className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Alarmes de horário exato</span>
                </span>
                {permStatus.isNative && !permStatus.canScheduleExact ? (
                  <button
                    type="button"
                    onClick={requestExactAlarmPermission}
                    className="text-amber-300 underline font-bold"
                  >
                    Ativar
                  </button>
                ) : (
                  <span className="text-emerald-400 font-bold">✅ Ativo</span>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <BatteryCharging className="h-3.5 w-3.5 text-emerald-400" />
                  <span>Segundo plano / não limitar bateria</span>
                </span>
                {permStatus.isNative && !permStatus.ignoresBatteryOptimizations ? (
                  <button
                    type="button"
                    onClick={requestIgnoreBatteryOptimizations}
                    className="text-amber-300 underline font-bold"
                  >
                    Ativar
                  </button>
                ) : (
                  <span className="text-emerald-400 font-bold">✅ Ativo</span>
                )}
              </div>

              <div className="flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <BellRing className="h-3.5 w-3.5 text-orange-400" />
                  <span>Som repetido e notificações</span>
                </span>
                <span className="text-emerald-400 font-bold">✅ Ativo</span>
              </div>

              {permStatus.isNative && (
                <>
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <VolumeX className="h-3.5 w-3.5 text-indigo-400" />
                      <span>Ignorar Não Perturbe</span>
                    </span>
                    <button
                      type="button"
                      onClick={requestNotificationPolicyPermission}
                      className="text-cyan-300 underline font-semibold"
                    >
                      Ajustar
                    </button>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Sparkles className="h-3.5 w-3.5 text-yellow-400" />
                      <span>Alerta em tela cheia (Android 14+)</span>
                    </span>
                    <button
                      type="button"
                      onClick={requestFullScreenIntentPermission}
                      className="text-cyan-300 underline font-semibold"
                    >
                      Ajustar
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>

      {/* FOOTER ACTIONS: Botão Primário ✅ CONFIRMAR RETORNO e Secundário Silenciar */}
      <div className="relative z-10 w-full max-w-md mx-auto pt-4 pb-2 flex flex-col gap-2.5">
        {/* BOTÃO PRINCIPAL: ✅ CONFIRMAR RETORNO */}
        <button
          type="button"
          id="btn-confirmar-retorno-intervalo"
          onClick={handleConfirmReturn}
          className="group relative flex h-16 sm:h-20 w-full items-center justify-center gap-3 rounded-2xl sm:rounded-3xl bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400 font-black text-slate-950 text-xl sm:text-2xl shadow-[0_0_35px_rgba(52,211,153,0.5)] hover:brightness-110 active:scale-[0.98] transition cursor-pointer ring-4 ring-emerald-300/60"
        >
          <div className="flex h-10 w-10 sm:h-12 sm:w-12 items-center justify-center rounded-xl bg-slate-950/20 text-slate-950">
            <CheckCircle2 className="h-7 w-7 sm:h-8 sm:w-8 stroke-[3]" />
          </div>
          <span>✅ CONFIRMAR RETORNO</span>
        </button>

        {/* BOTÃO SECUNDÁRIO: Silenciar Som */}
        <button
          type="button"
          onClick={handleSilenceOnly}
          className="flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-slate-800 bg-slate-900/80 text-xs sm:text-sm font-bold text-slate-300 hover:bg-slate-800 hover:text-white transition active:scale-[0.98] cursor-pointer"
        >
          <VolumeX className="h-4 w-4" />
          <span>Silenciar Alarme (vou bater em instantes)</span>
        </button>
      </div>
    </div>
  );
}
