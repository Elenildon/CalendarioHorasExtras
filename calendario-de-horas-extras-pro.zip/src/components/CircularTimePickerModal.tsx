import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { X, Clock, Check, RotateCcw } from "lucide-react";
import { cn } from "../utils/cn";

export interface QuickPresetItem {
  label: string;
  time?: string;
  mins?: number;
}

export interface CircularTimePickerModalProps {
  isOpen: boolean;
  initialMinutes?: number; // ex: 60 para 01:00
  initialTime?: string;    // ex: "08:00", "17:30"
  title?: string;
  onClose: () => void;
  onConfirm: (durationMinutes: number, timeString: string) => void;
  onClear?: () => void;
  quickPresets?: QuickPresetItem[];
}

type PickerMode = "hours" | "minutes";

// Constantes estáticas fora do componente para economizar alocações
const OUTER_HOURS = [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
const INNER_HOURS = [0, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23];
const MINUTE_NUMBERS = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55];
const CLOCK_RADIUS = 130;
const OUTER_RADIUS = 96; // Anel externo: 12, 1..11 (ou 00 a 11)
const INNER_RADIUS = 62; // Anel interno: 00, 13..23

function parseInitialTimeValues(initialTime?: string, initialMinutes?: number): { h: number; m: number } {
  if (initialTime && typeof initialTime === "string" && initialTime.includes(":")) {
    const parts = initialTime.trim().split(":");
    const h = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    if (!isNaN(h) && !isNaN(m)) {
      return {
        h: Math.min(23, Math.max(0, h)),
        m: Math.min(59, Math.max(0, m)),
      };
    }
  }
  const safeMins = Math.max(0, initialMinutes !== undefined ? initialMinutes : 60);
  return {
    h: Math.floor(safeMins / 60) % 24,
    m: safeMins % 60,
  };
}

export const CircularTimePickerModal: React.FC<CircularTimePickerModalProps> = ({
  isOpen,
  initialMinutes,
  initialTime,
  title,
  onClose,
  onConfirm,
  onClear,
  quickPresets,
}) => {
  // 1. Hook: useState mode
  const [mode, setMode] = useState<PickerMode>("hours");

  // 2. Hook: useState selectedHour
  const [selectedHour, setSelectedHour] = useState<number>(() => {
    return parseInitialTimeValues(initialTime, initialMinutes).h;
  });

  // 3. Hook: useState selectedMinute
  const [selectedMinute, setSelectedMinute] = useState<number>(() => {
    return parseInitialTimeValues(initialTime, initialMinutes).m;
  });

  // 4. Hook: useRef clockRef
  const clockRef = useRef<HTMLDivElement>(null);

  // 5. Hook: useState isDragging
  const [isDragging, setIsDragging] = useState(false);

  // 6. Hook: useEffect sincronização de abertura
  useEffect(() => {
    if (isOpen) {
      const parsed = parseInitialTimeValues(initialTime, initialMinutes);
      setSelectedHour(parsed.h);
      setSelectedMinute(parsed.m);
      setMode("hours");
    }
  }, [isOpen, initialTime, initialMinutes]);

  // Formatação digital com dois dígitos
  const formattedHour = String(selectedHour).padStart(2, "0");
  const formattedMinute = String(selectedMinute).padStart(2, "0");
  const timeString = `${formattedHour}:${formattedMinute}`;
  const totalMinutes = selectedHour * 60 + selectedMinute;

  // Calcula se a hora selecionada está no anel interno ou externo
  const isInnerHour = selectedHour === 0 || (selectedHour >= 13 && selectedHour <= 23);

  // 7. Hook: useMemo pointerAngle
  const pointerAngle = useMemo(() => {
    if (mode === "hours") {
      const baseHour = selectedHour % 12;
      return baseHour * 30;
    } else {
      return selectedMinute * 6;
    }
  }, [mode, selectedHour, selectedMinute]);

  // 8. Hook: useMemo pointerRadius
  const pointerRadius = useMemo(() => {
    if (mode === "hours") {
      return isInnerHour ? INNER_RADIUS : OUTER_RADIUS;
    }
    return OUTER_RADIUS;
  }, [mode, isInnerHour]);

  // 9. Hook: useCallback handlePointerCalculation
  const handlePointerCalculation = useCallback(
    (clientX: number, clientY: number, autoAdvance = false) => {
      if (!clockRef.current) return;
      const rect = clockRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const dx = clientX - centerX;
      const dy = clientY - centerY;
      const dist = Math.sqrt(dx * dx + dy * dy);

      // Ângulo em graus onde 0° é no topo (12 horas)
      let angle = (Math.atan2(dy, dx) * 180) / Math.PI + 90;
      if (angle < 0) angle += 360;

      if (mode === "hours") {
        // 12 posições angulares (30° cada)
        const hourIndex = Math.round(angle / 30) % 12;
        // Limiar de distância entre anel externo e interno (cerca de 80px)
        const isInner = dist < 78;

        let hourVal: number;
        if (isInner) {
          // Anel interno: 00, 13, 14, 15, ..., 23
          hourVal = hourIndex === 0 ? 0 : hourIndex + 12;
        } else {
          // Anel externo: 12, 1, 2, ..., 11
          hourVal = hourIndex === 0 ? 12 : hourIndex;
        }

        setSelectedHour(hourVal);

        if (autoAdvance) {
          // Transição automática suave para minutos ao selecionar a hora
          setTimeout(() => {
            setMode("minutes");
          }, 200);
        }
      } else {
        // Modo minutos: 60 posições (6° cada)
        const minuteVal = Math.round(angle / 6) % 60;
        setSelectedMinute(minuteVal);
      }
    },
    [mode]
  );

  // 10. Hook: useMemo activePresets (SEMPRE CHAMADO NO TOPO, NUNCA ATRÁS DE UM RETURN CONDICIONAL)
  const activePresets: QuickPresetItem[] = useMemo(() => {
    if (quickPresets && quickPresets.length > 0) return quickPresets;
    const t = (title || "").toLowerCase();
    if (t.includes("entrada")) {
      return [
        { label: "06:00", time: "06:00" },
        { label: "07:00", time: "07:00" },
        { label: "07:30", time: "07:30" },
        { label: "08:00", time: "08:00" },
        { label: "08:30", time: "08:30" },
        { label: "13:00", time: "13:00" },
      ];
    }
    if (t.includes("saída") || t.includes("saida")) {
      return [
        { label: "16:00", time: "16:00" },
        { label: "17:00", time: "17:00" },
        { label: "17:30", time: "17:30" },
        { label: "18:00", time: "18:00" },
        { label: "19:00", time: "19:00" },
        { label: "21:00", time: "21:00" },
      ];
    }
    if (t.includes("intervalo") || t.includes("duração") || t.includes("duracao")) {
      return [
        { label: "00:15", mins: 15, time: "00:15" },
        { label: "00:30", mins: 30, time: "00:30" },
        { label: "00:45", mins: 45, time: "00:45" },
        { label: "01:00", mins: 60, time: "01:00" },
        { label: "01:30", mins: 90, time: "01:30" },
        { label: "02:00", mins: 120, time: "02:00" },
      ];
    }
    return [
      { label: "08:00", time: "08:00" },
      { label: "12:00", time: "12:00" },
      { label: "13:00", time: "13:00" },
      { label: "17:00", time: "17:00" },
      { label: "18:00", time: "18:00" },
      { label: "22:00", time: "22:00" },
    ];
  }, [quickPresets, title]);

  // Eventos de Mouse e Toque
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragging(true);
    handlePointerCalculation(e.clientX, e.clientY);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    handlePointerCalculation(e.clientX, e.clientY);
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLDivElement>) => {
    if (isDragging) {
      setIsDragging(false);
      handlePointerCalculation(e.clientX, e.clientY, mode === "hours");
    }
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    setIsDragging(true);
    const touch = e.touches[0];
    if (touch) {
      handlePointerCalculation(touch.clientX, touch.clientY);
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    if (touch) {
      handlePointerCalculation(touch.clientX, touch.clientY);
    }
  };

  const handleTouchEnd = () => {
    if (isDragging) {
      setIsDragging(false);
      if (mode === "hours") {
        setTimeout(() => {
          setMode("minutes");
        }, 220);
      }
    }
  };

  // Botão Limpar: redefine para 00:00 (ou limpa seleção)
  const handleClear = () => {
    setSelectedHour(0);
    setSelectedMinute(0);
    setMode("hours");
    if (onClear) {
      onClear();
    }
  };

  // Botão Definir: confirma e aplica
  const handleConfirm = () => {
    onConfirm(totalMinutes, timeString);
    onClose();
  };

  // RETORNO CONDICIONAL SOMENTE APÓS A EXECUÇÃO DE TODOS OS HOOKS
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="clock-picker-title"
      className="fixed inset-0 z-[100] flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-sm rounded-3xl border border-cyan-500/30 bg-gradient-to-b from-slate-900 via-slate-900/95 to-slate-950 p-4 sm:p-5 shadow-2xl shadow-cyan-950/50 flex flex-col items-center space-y-4 text-slate-100"
      >
        {/* Topo: Título e Botão Fechar */}
        <div className="w-full flex items-center justify-between pb-2 border-b border-slate-800">
          <div className="flex items-center gap-2 text-cyan-300 font-bold text-sm sm:text-base">
            <Clock className="h-5 w-5 text-cyan-400" />
            <span id="clock-picker-title">{title || "Seletor de Hora Circular 24h"}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-full p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 transition active:scale-95 cursor-pointer"
            aria-label="Fechar seletor de hora"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Mostrador Digital no Topo (HH : MM) */}
        <div className="flex flex-col items-center justify-center space-y-1">
          <div className="flex items-center justify-center gap-2 px-4 py-2 rounded-2xl bg-slate-950/90 border border-slate-800 shadow-inner">
            {/* Bloco de Horas */}
            <button
              type="button"
              onClick={() => setMode("hours")}
              className={cn(
                "px-3.5 py-1.5 rounded-xl font-mono text-3xl sm:text-4xl font-black transition cursor-pointer border",
                mode === "hours"
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-400 shadow-sm shadow-cyan-500/30 ring-1 ring-cyan-400/50"
                  : "bg-transparent text-slate-400 border-transparent hover:text-slate-200"
              )}
              title="Clique para selecionar as horas"
            >
              {formattedHour}
            </button>

            <span className="text-2xl sm:text-3xl font-mono font-bold text-cyan-400 animate-pulse select-none">
              :
            </span>

            {/* Bloco de Minutos */}
            <button
              type="button"
              onClick={() => setMode("minutes")}
              className={cn(
                "px-3.5 py-1.5 rounded-xl font-mono text-3xl sm:text-4xl font-black transition cursor-pointer border",
                mode === "minutes"
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-400 shadow-sm shadow-cyan-500/30 ring-1 ring-cyan-400/50"
                  : "bg-transparent text-slate-400 border-transparent hover:text-slate-200"
              )}
              title="Clique para selecionar os minutos"
            >
              {formattedMinute}
            </button>
          </div>

          {/* Subtítulo indicativo */}
          <div className="text-[11px] font-semibold text-slate-400 flex items-center gap-1.5 pt-1">
            <span
              className={cn(
                "px-2 py-0.5 rounded-md text-[10px] font-bold uppercase transition",
                mode === "hours" ? "bg-cyan-900/60 text-cyan-300 border border-cyan-500/30" : "text-slate-500"
              )}
            >
              Formato 24h
            </span>
            <span>·</span>
            <span className="text-slate-300 font-medium">
              {mode === "hours" ? "Selecione a Hora (00 a 23)" : "Selecione os Minutos (00 a 59)"}
            </span>
            <span>·</span>
            <span className="text-cyan-400 font-bold font-mono">{timeString}</span>
          </div>
        </div>

        {/* Mostrador Analógico Circular (The Clock Face) */}
        <div
          ref={clockRef}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          className="relative h-64 w-64 select-none touch-none rounded-full border-2 border-cyan-500/40 bg-slate-950 p-2 shadow-2xl shadow-cyan-950/60 transition-colors"
          style={{ width: `${CLOCK_RADIUS * 2}px`, height: `${CLOCK_RADIUS * 2}px` }}
        >
          {/* Anel Guia / Marcação Estilizada */}
          <div className="absolute inset-2 rounded-full border border-slate-800/80 pointer-events-none" />
          {mode === "hours" && (
            <div className="absolute inset-16 rounded-full border border-slate-800/40 pointer-events-none" />
          )}

          {/* Pino Central */}
          <div className="absolute left-1/2 top-1/2 -ml-2 -mt-2 h-4 w-4 rounded-full bg-cyan-400 shadow-md shadow-cyan-400/80 z-20 pointer-events-none border border-slate-950" />

          {/* Ponteiro Analógico (Hand) */}
          <div
            className="absolute left-1/2 top-1/2 z-10 origin-bottom pointer-events-none transition-transform duration-75"
            style={{
              width: "2px",
              height: `${pointerRadius}px`,
              transform: `translate(-50%, -100%) rotate(${pointerAngle}deg)`,
            }}
          >
            {/* Haste do ponteiro */}
            <div className="h-full w-full bg-gradient-to-t from-cyan-400/50 to-cyan-300" />
            {/* Esfera indicadora na ponta do ponteiro */}
            <div
              className={cn(
                "absolute -top-3.5 left-1/2 -translate-x-1/2 rounded-full border-2 border-cyan-300 bg-cyan-500/30 backdrop-blur-sm shadow-lg shadow-cyan-400/50",
                mode === "hours" && isInnerHour ? "h-6 w-6 -top-3" : "h-7 w-7 -top-3.5"
              )}
            />
          </div>

          {/* MODO HORAS (24h com dois anéis concêntricos) */}
          {mode === "hours" && (
            <>
              {/* Anel Externo: 12, 1, 2, ..., 11 */}
              {OUTER_HOURS.map((h, i) => {
                const angleRad = ((i * 30 - 90) * Math.PI) / 180;
                const x = CLOCK_RADIUS + OUTER_RADIUS * Math.cos(angleRad);
                const y = CLOCK_RADIUS + OUTER_RADIUS * Math.sin(angleRad);
                const isSelected = selectedHour === h;

                return (
                  <button
                    key={`outer-${h}`}
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedHour(h);
                      setTimeout(() => setMode("minutes"), 200);
                    }}
                    className={cn(
                      "absolute flex h-7 w-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-mono text-xs font-bold transition-all z-20 cursor-pointer",
                      isSelected
                        ? "bg-cyan-400 text-slate-950 font-black shadow-lg shadow-cyan-400/50 scale-110"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    )}
                    style={{ left: `${x}px`, top: `${y}px` }}
                  >
                    {h}
                  </button>
                );
              })}

              {/* Anel Interno: 00, 13, 14, ..., 23 */}
              {INNER_HOURS.map((h, i) => {
                const angleRad = ((i * 30 - 90) * Math.PI) / 180;
                const x = CLOCK_RADIUS + INNER_RADIUS * Math.cos(angleRad);
                const y = CLOCK_RADIUS + INNER_RADIUS * Math.sin(angleRad);
                const isSelected = selectedHour === h;

                return (
                  <button
                    key={`inner-${h}`}
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedHour(h);
                      setTimeout(() => setMode("minutes"), 200);
                    }}
                    className={cn(
                      "absolute flex h-6 w-6 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-mono text-[10px] font-bold transition-all z-20 cursor-pointer",
                      isSelected
                        ? "bg-cyan-400 text-slate-950 font-black shadow-lg shadow-cyan-400/50 scale-110"
                        : "text-slate-400 hover:bg-slate-800 hover:text-slate-200"
                    )}
                    style={{ left: `${x}px`, top: `${y}px` }}
                  >
                    {String(h).padStart(2, "0")}
                  </button>
                );
              })}
            </>
          )}

          {/* MODO MINUTOS (00 a 55 em passos de 5 com marcadores intermediários) */}
          {mode === "minutes" && (
            <>
              {MINUTE_NUMBERS.map((m, i) => {
                const angleRad = ((i * 30 - 90) * Math.PI) / 180;
                const x = CLOCK_RADIUS + OUTER_RADIUS * Math.cos(angleRad);
                const y = CLOCK_RADIUS + OUTER_RADIUS * Math.sin(angleRad);
                const isSelected = selectedMinute === m;

                return (
                  <button
                    key={`min-${m}`}
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedMinute(m);
                    }}
                    className={cn(
                      "absolute flex h-7 w-7 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full font-mono text-xs font-bold transition-all z-20 cursor-pointer",
                      isSelected
                        ? "bg-cyan-400 text-slate-950 font-black shadow-lg shadow-cyan-400/50 scale-110"
                        : "text-slate-300 hover:bg-slate-800 hover:text-white"
                    )}
                    style={{ left: `${x}px`, top: `${y}px` }}
                  >
                    {String(m).padStart(2, "0")}
                  </button>
                );
              })}
            </>
          )}
        </div>

        {/* Atalhos Rápidos */}
        <div className="w-full flex items-center justify-center gap-1.5 flex-wrap pt-1">
          {activePresets.map((preset) => {
            let isMatch = false;
            if (preset.time) {
              isMatch = timeString === preset.time;
            } else if (preset.mins !== undefined) {
              isMatch = totalMinutes === preset.mins;
            }

            return (
              <button
                key={preset.label}
                type="button"
                onClick={() => {
                  if (preset.time && preset.time.includes(":")) {
                    const [hStr, mStr] = preset.time.split(":");
                    setSelectedHour(parseInt(hStr, 10) || 0);
                    setSelectedMinute(parseInt(mStr, 10) || 0);
                  } else if (preset.mins !== undefined) {
                    setSelectedHour(Math.floor(preset.mins / 60));
                    setSelectedMinute(preset.mins % 60);
                  }
                }}
                className={cn(
                  "px-2.5 py-1 rounded-lg font-mono text-[11px] font-bold transition border cursor-pointer",
                  isMatch
                    ? "bg-cyan-500/30 text-cyan-300 border-cyan-400 shadow-sm"
                    : "bg-slate-800/80 text-slate-400 border-slate-700/80 hover:bg-slate-700 hover:text-slate-200"
                )}
              >
                {preset.label}
              </button>
            );
          })}
        </div>

        {/* Botões de Ação no Rodapé: Limpar, Cancelar e Definir */}
        <div className="w-full grid grid-cols-3 gap-2 pt-2 border-t border-slate-800">
          {/* Botão Limpar */}
          <button
            type="button"
            onClick={handleClear}
            className="flex items-center justify-center gap-1 rounded-xl border border-slate-700 bg-slate-800/90 py-2.5 px-2 text-xs font-bold text-slate-300 hover:bg-slate-700 hover:text-white transition active:scale-95 shadow-sm cursor-pointer"
            title="Redefinir horário para 00:00"
          >
            <RotateCcw className="h-3.5 w-3.5 text-rose-400" />
            <span>Limpar</span>
          </button>

          {/* Botão Cancelar */}
          <button
            type="button"
            onClick={onClose}
            className="flex items-center justify-center gap-1 rounded-xl border border-slate-700 bg-slate-800/90 py-2.5 px-2 text-xs font-bold text-slate-300 hover:bg-slate-700 hover:text-white transition active:scale-95 shadow-sm cursor-pointer"
            title="Cancelar e fechar sem alterar"
          >
            <X className="h-3.5 w-3.5 text-slate-400" />
            <span>Cancelar</span>
          </button>

          {/* Botão Definir */}
          <button
            type="button"
            onClick={handleConfirm}
            className="flex items-center justify-center gap-1 rounded-xl border border-cyan-400 bg-gradient-to-r from-cyan-500 to-teal-500 py-2.5 px-2 text-xs font-black text-slate-950 hover:brightness-110 transition active:scale-95 shadow-md shadow-cyan-950/60 cursor-pointer"
            title="Definir e aplicar o horário selecionado"
          >
            <Check className="h-3.5 w-3.5 stroke-[3]" />
            <span>Definir</span>
          </button>
        </div>
      </div>
    </div>
  );
};
