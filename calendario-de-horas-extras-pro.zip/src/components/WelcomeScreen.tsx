import { useState } from "react";
import {
  Fingerprint,
  Calendar as CalendarIcon,
  Clock,
  BarChart3,
  ShieldCheck,
  Star,
  ArrowRight,
  Loader2,
  CheckCircle2,
} from "lucide-react";
import { type Settings } from "../lib/calc";
import type { User as FirebaseUser } from "../lib/firebase";
import iconUrl from "../assets/icon.png";

interface WelcomeScreenProps {
  settings: Settings;
  user?: FirebaseUser | null;
  onUpdate: (patch: Partial<Settings>, immediate?: boolean) => void;
  onEnter: () => void;
  onGoogleLogin?: () => Promise<FirebaseUser | null | void>;
  onOpenBiometria?: () => void;
  onOpenCalendar?: () => void;
  onOpenHorasExtras?: () => void;
  onOpenResumo?: () => void;
  onOpenControle?: () => void;
  onOpenPerfil?: () => void;
}

export default function WelcomeScreen({
  settings,
  user,
  onUpdate,
  onEnter,
  onGoogleLogin,
  onOpenBiometria,
  onOpenCalendar,
  onOpenHorasExtras,
  onOpenResumo,
  onOpenControle,
  onOpenPerfil,
}: WelcomeScreenProps) {
  const [loadingGoogle, setLoadingGoogle] = useState(false);

  // Extrai o primeiro nome de forma dinâmica (Google User ou configurações salvas)
  const currentFullName = user?.displayName || settings.name || "Elenildon Estevão";
  const firstName = currentFullName.trim().split(/\s+/)[0] || "Elenildon";

  // Login com Google atualizando o nome no Olá automaticamente
  const handleGoogleClick = async () => {
    if (!onGoogleLogin) return;
    try {
      setLoadingGoogle(true);
      const res = await onGoogleLogin();
      if (res && res.displayName) {
        onUpdate({ name: res.displayName }, true);
      }
    } catch (err) {
      console.error("Erro no login Google:", err);
    } finally {
      setLoadingGoogle(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[80] overflow-y-auto bg-[#05070f] text-slate-100 flex flex-col items-center justify-start sm:justify-center p-0 sm:p-4">
      {/* Moldura de Smartphone estilizada com a mesma cor padrão do painel */}
      <div
        className="relative w-full max-w-[440px] bg-[#070b18] sm:rounded-[2.8rem] shadow-2xl overflow-hidden flex flex-col min-h-screen sm:min-h-[860px] border border-slate-800/80"
        style={{
          background:
            "radial-gradient(120% 600px at 50% -120px, rgba(99, 72, 230, 0.28), transparent 60%), radial-gradient(90% 500px at 100% 300px, rgba(49, 39, 130, 0.25), transparent 60%), radial-gradient(120% 700px at 0% 900px, rgba(76, 29, 149, 0.18), transparent 55%), #070b18",
        }}
      >
        
        {/* ============================================================== */}
        {/* 1. CABEÇALHO SUPERIOR (Conforme solicitado e diagramado)       */}
        {/* ============================================================== */}
        <header className="px-5 pt-4 pb-3 flex items-center justify-between bg-[#070b18]/90 backdrop-blur-md z-20 shrink-0 border-b border-slate-800/80">
          <div className="flex items-center gap-3">
            {/* Ícone circular azul com relógio */}
            <div className="h-11 w-11 shrink-0 rounded-2xl overflow-hidden bg-gradient-to-tr from-[#0055EE] to-[#0088FF] p-0.5 shadow-md shadow-blue-500/25 flex items-center justify-center">
              <img
                src={iconUrl}
                alt="Calendário de Horas Extras PRO"
                className="h-full w-full object-cover rounded-[14px]"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = "none";
                }}
              />
            </div>

            {/* Diagramação do nome: Calendário de Horas Extras PRO */}
            <div className="flex flex-col">
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[15px] sm:text-base font-black text-white tracking-tight leading-tight">
                  Calendário de Horas Extras
                </span>
                <span className="text-[13px] sm:text-sm font-black text-[#38bdf8] tracking-wider leading-none">
                  PRO
                </span>
              </div>
              <p className="text-[11px] font-semibold text-slate-400 tracking-tight">
                Seu tempo. Seu direito.
              </p>
            </div>
          </div>

          {/* Status ou Conexão com Google no topo */}
          {user ? (
            <button
              type="button"
              onClick={onOpenPerfil || onEnter}
              title="Conta Google conectada"
              className="flex items-center gap-1.5 rounded-full bg-emerald-950/80 border border-emerald-500/40 py-1 px-2.5 text-[11px] font-bold text-emerald-300 shadow-xs cursor-pointer hover:bg-emerald-900/60 transition"
            >
              <span className="h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="max-w-[70px] truncate">{firstName}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleGoogleClick}
              disabled={loadingGoogle}
              title="Entrar com Google para sincronizar automaticamente"
              className="flex items-center gap-1.5 rounded-full border border-blue-500/40 bg-blue-950/60 hover:bg-blue-900/60 py-1.5 px-3 text-[11px] font-bold text-blue-300 transition cursor-pointer active:scale-95 shadow-xs disabled:opacity-50"
            >
              {loadingGoogle ? (
                <Loader2 className="h-3 w-3 animate-spin text-blue-400" />
              ) : (
                <svg className="h-3 w-3 shrink-0" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
                  <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z" />
                  <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.04 0 12s.45 3.82 1.25 5.42l4.03-3.15z" />
                  <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
                </svg>
              )}
              <span>Entrar</span>
            </button>
          )}
        </header>

        {/* ============================================================== */}
        {/* 2. HERO BANNER: Foto da trabalhadora sorridente com smartphone */}
        {/* ============================================================== */}
        <div className="relative h-[290px] sm:h-[310px] w-full overflow-hidden shrink-0 bg-slate-900">
          {/* Imagem de Fundo (Foto da Profissional Segurando Celular) */}
          <img
            src="/worker-hero.jpg"
            alt="Profissional com celular"
            className="absolute inset-0 h-full w-full object-cover object-[center_20%] select-none pointer-events-none"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=800&q=80";
            }}
          />

          {/* Degradê escuro à esquerda para leitura 100% perfeita do texto branco */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#04122e]/95 via-[#071c42]/75 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#070b18] via-transparent to-black/30" />

          {/* Textos do Hero (Conforme layout da imagem) */}
          <div className="relative z-10 p-5 sm:p-6 flex flex-col justify-center h-full max-w-[290px] sm:max-w-[310px]">
            {/* Olá dinâmico (com nome da conta Google quando conectado) */}
            <div className="font-serif italic font-extrabold text-[#7dd3fc] text-3xl sm:text-4xl drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] tracking-wide">
              {user ? `Olá, ${firstName}!` : "Olá!"}
            </div>

            {/* Título de Boas-Vindas */}
            <div className="mt-1">
              <h2 className="text-sm sm:text-base font-bold text-white drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)] leading-tight">
                Bem-vindo(a) ao
              </h2>
              <div className="mt-0.5 flex flex-col drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)]">
                <span className="text-lg sm:text-xl font-black text-white tracking-tight leading-tight">
                  Calendário de Horas Extras
                </span>
                <span className="text-2xl sm:text-[26px] font-black text-[#38bdf8] tracking-wider leading-none mt-0.5">
                  PRO
                </span>
              </div>
            </div>

            {/* Descrição acolhedora */}
            <p className="mt-2 text-xs sm:text-[13px] text-slate-100 font-medium leading-snug drop-shadow-[0_1px_4px_rgba(0,0,0,0.9)]">
              Aqui você registra seus pontos, acompanha suas horas e tem mais controle sobre o seu tempo.
            </p>
          </div>

          {/* Transição em onda suave curvada com a cor do painel */}
          <div className="absolute inset-x-0 -bottom-1 z-10">
            <svg
              viewBox="0 0 500 45"
              className="w-full h-8 sm:h-10 block fill-[#070b18]"
              preserveAspectRatio="none"
            >
              <path d="M0,25 Q180,48 500,5 L500,45 L0,45 Z" />
            </svg>
          </div>
        </div>

        {/* ============================================================== */}
        {/* 3. 6 CARTÕES INTERATIVOS E DIRECIONAIS (100% FUNCIONAIS)       */}
        {/* ============================================================== */}
        <div className="px-4 sm:px-5 pt-1 pb-3 flex-1 flex flex-col justify-between bg-transparent z-10">
          <div>
            <div className="grid grid-cols-3 gap-2 sm:gap-2.5">
              
              {/* 1. Ponto Biométrico (Direcional: Abre Biometria / Ponto Digital) */}
              <button
                type="button"
                onClick={onOpenBiometria || onEnter}
                className="group relative flex flex-col items-center justify-between rounded-2xl border border-slate-700/60 bg-slate-900/85 hover:bg-slate-800/90 hover:border-blue-400/50 p-2.5 sm:p-3 text-center transition-all active:scale-95 cursor-pointer shadow-md min-h-[116px] backdrop-blur-xs"
                title="Abrir Ponto Biométrico"
              >
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#0055EE] to-[#0088FF] text-white shadow-md shadow-blue-500/30 transition group-hover:scale-105">
                  <Fingerprint className="h-5 w-5 sm:h-6 sm:w-6" strokeWidth={2.3} />
                </div>
                <div className="mt-1.5 w-full">
                  <span className="block text-[11px] sm:text-xs font-black text-white leading-tight">
                    Ponto Biométrico
                  </span>
                  <span className="block text-[9px] sm:text-[10px] font-semibold text-slate-400 leading-tight mt-0.5">
                    Rápido, seguro e confiável.
                  </span>
                </div>
              </button>

              {/* 2. Calendário (Direcional: Abre visualização do Calendário de Horas) */}
              <button
                type="button"
                onClick={onOpenCalendar || onEnter}
                className="group relative flex flex-col items-center justify-between rounded-2xl border border-slate-700/60 bg-slate-900/85 hover:bg-slate-800/90 hover:border-emerald-400/50 p-2.5 sm:p-3 text-center transition-all active:scale-95 cursor-pointer shadow-md min-h-[116px] backdrop-blur-xs"
                title="Acessar o Calendário"
              >
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#009988] to-[#00CCAA] text-white shadow-md shadow-emerald-500/30 transition group-hover:scale-105">
                  <CalendarIcon className="h-5 w-5 sm:h-6 sm:w-6" strokeWidth={2.3} />
                </div>
                <div className="mt-1.5 w-full">
                  <span className="block text-[11px] sm:text-xs font-black text-white leading-tight">
                    Calendário
                  </span>
                  <span className="block text-[9px] sm:text-[10px] font-semibold text-slate-400 leading-tight mt-0.5">
                    Organização do seu tempo.
                  </span>
                </div>
              </button>

              {/* 3. Horas Extras (Direcional: Abre lançamento / cálculo de Horas Extras) */}
              <button
                type="button"
                onClick={onOpenHorasExtras || onEnter}
                className="group relative flex flex-col items-center justify-between rounded-2xl border border-slate-700/60 bg-slate-900/85 hover:bg-slate-800/90 hover:border-purple-400/50 p-2.5 sm:p-3 text-center transition-all active:scale-95 cursor-pointer shadow-md min-h-[116px] backdrop-blur-xs"
                title="Calcular e Lançar Horas Extras"
              >
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#6633EE] to-[#8855FF] text-white shadow-md shadow-purple-500/30 transition group-hover:scale-105">
                  <Clock className="h-5 w-5 sm:h-6 sm:w-6" strokeWidth={2.3} />
                </div>
                <div className="mt-1.5 w-full">
                  <span className="block text-[11px] sm:text-xs font-black text-white leading-tight">
                    Horas Extras
                  </span>
                  <span className="block text-[9px] sm:text-[10px] font-semibold text-slate-400 leading-tight mt-0.5">
                    Seu esforço valorizado.
                  </span>
                </div>
              </button>

              {/* 4. Resumo do Mês (Direcional: Abre Relatório Mensal e Estatísticas) */}
              <button
                type="button"
                onClick={onOpenResumo || onEnter}
                className="group relative flex flex-col items-center justify-between rounded-2xl border border-slate-700/60 bg-slate-900/85 hover:bg-slate-800/90 hover:border-amber-400/50 p-2.5 sm:p-3 text-center transition-all active:scale-95 cursor-pointer shadow-md min-h-[116px] backdrop-blur-xs"
                title="Ver Resumo do Mês"
              >
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#EE8800] to-[#FFAA22] text-white shadow-md shadow-amber-500/30 transition group-hover:scale-105">
                  <BarChart3 className="h-5 w-5 sm:h-6 sm:w-6" strokeWidth={2.3} />
                </div>
                <div className="mt-1.5 w-full">
                  <span className="block text-[11px] sm:text-xs font-black text-white leading-tight">
                    Resumo do Mês
                  </span>
                  <span className="block text-[9px] sm:text-[10px] font-semibold text-slate-400 leading-tight mt-0.5">
                    Veja tudo em um só lugar.
                  </span>
                </div>
              </button>

              {/* 5. Mais Controle (Direcional: Abre configurações CLT, adicionais e proteções) */}
              <button
                type="button"
                onClick={onOpenControle || onEnter}
                className="group relative flex flex-col items-center justify-between rounded-2xl border border-slate-700/60 bg-slate-900/85 hover:bg-slate-800/90 hover:border-rose-400/50 p-2.5 sm:p-3 text-center transition-all active:scale-95 cursor-pointer shadow-md min-h-[116px] backdrop-blur-xs"
                title="Configurações e Segurança CLT"
              >
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#EE2244] to-[#FF4466] text-white shadow-md shadow-rose-500/30 transition group-hover:scale-105">
                  <ShieldCheck className="h-5 w-5 sm:h-6 sm:w-6" strokeWidth={2.3} />
                </div>
                <div className="mt-1.5 w-full">
                  <span className="block text-[11px] sm:text-xs font-black text-white leading-tight">
                    Mais Controle
                  </span>
                  <span className="block text-[9px] sm:text-[10px] font-semibold text-slate-400 leading-tight mt-0.5">
                    Transparência e segurança.
                  </span>
                </div>
              </button>

              {/* 6. Você em Primeiro Lugar (Direcional: Abre Perfil do Usuário e Nuvem) */}
              <button
                type="button"
                onClick={onOpenPerfil || onEnter}
                className="group relative flex flex-col items-center justify-between rounded-2xl border border-slate-700/60 bg-slate-900/85 hover:bg-slate-800/90 hover:border-sky-400/50 p-2.5 sm:p-3 text-center transition-all active:scale-95 cursor-pointer shadow-md min-h-[116px] backdrop-blur-xs"
                title="Seu Perfil e Dados"
              >
                <div className="flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-[#0088EE] to-[#00BBFF] text-white shadow-md shadow-sky-500/30 transition group-hover:scale-105">
                  <Star className="h-5 w-5 sm:h-6 sm:w-6" strokeWidth={2.3} />
                </div>
                <div className="mt-1.5 w-full">
                  <span className="block text-[11px] sm:text-xs font-black text-white leading-tight">
                    Você em Primeiro Lugar
                  </span>
                  <span className="block text-[9px] sm:text-[10px] font-semibold text-slate-400 leading-tight mt-0.5">
                    Porque o seu tempo importa.
                  </span>
                </div>
              </button>

            </div>

            {/* Texto Manuscrito "Vamos juntos?" com sublinhado ondulado */}
            <div className="text-center mt-3 sm:mt-4 mb-2">
              <span className="font-serif italic font-extrabold text-[#38bdf8] text-2xl sm:text-[28px] tracking-wide inline-block drop-shadow-[0_2px_8px_rgba(0,0,0,0.6)]">
                Vamos juntos?
              </span>
              <svg
                className="w-32 sm:w-36 h-2.5 mx-auto text-[#38bdf8] -mt-1"
                viewBox="0 0 120 10"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                strokeLinecap="round"
              >
                <path d="M 4 6 Q 30 1, 60 7 T 116 5" />
              </svg>
            </div>
          </div>

          {/* ============================================================== */}
          {/* 4. BOTÃO PRINCIPAL "Começar ➔" E LOGIN COM GOOGLE              */}
          {/* ============================================================== */}
          <div className="space-y-2.5 pb-2">
            {/* Botão Começar */}
            <button
              type="button"
              onClick={onEnter}
              className="flex h-13 sm:h-14 w-full items-center justify-center gap-2.5 rounded-full bg-[#0066FF] hover:bg-[#0055EE] text-base sm:text-lg font-black text-white shadow-xl shadow-blue-500/35 transition-all active:scale-[0.98] cursor-pointer"
            >
              <span>Começar</span>
              <ArrowRight className="h-5 w-5" strokeWidth={2.6} />
            </button>

            {/* Botão de Conectar com Google caso ainda não esteja conectado */}
            {!user ? (
              <button
                type="button"
                onClick={handleGoogleClick}
                disabled={loadingGoogle}
                className="flex h-10 w-full items-center justify-center gap-2 rounded-full border border-slate-700/80 bg-slate-900/90 hover:bg-slate-800 text-xs font-bold text-slate-200 transition active:scale-[0.98] disabled:opacity-50 shadow-xs cursor-pointer"
              >
                {loadingGoogle ? (
                  <Loader2 className="h-4 w-4 animate-spin text-blue-400" />
                ) : (
                  <svg className="h-4 w-4" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z" />
                    <path fill="#34A853" d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z" />
                    <path fill="#FBBC05" d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.04 0 12s.45 3.82 1.25 5.42l4.03-3.15z" />
                    <path fill="#EA4335" d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z" />
                  </svg>
                )}
                <span>Conectar com Google (Identificação Automática)</span>
              </button>
            ) : (
              <div className="flex items-center justify-center gap-1.5 text-[11px] font-semibold text-emerald-400 bg-emerald-950/60 border border-emerald-500/40 rounded-full py-1 px-3">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                <span>Identificado como {currentFullName}</span>
              </div>
            )}

            {/* Barra inferior estética de smartphone */}
            <div className="pt-1 flex justify-center">
              <div className="h-1 w-28 bg-slate-700/60 rounded-full" />
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
