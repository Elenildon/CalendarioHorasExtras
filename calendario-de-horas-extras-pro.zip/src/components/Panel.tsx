import { useEffect, useRef, useState } from "react";
import {
  Banknote,
  Biohazard,
  Briefcase,
  Building2,
  CalendarDays,
  Calculator,
  Check,
  ChevronDown,
  ChevronUp,
  Clock,
  Filter,
  Minus,
  Moon,
  MoonStar,
  Plus,
  RotateCcw,
  ShieldAlert,
  User,
  X,
} from "lucide-react";
import { Card, Chip, IconTile, Stepper, Toggle } from "./ui";
import AvatarPicker from "./AvatarPicker";
import AvatarFace from "./AvatarFace";
import DetailedCalculationCard from "./DetailedCalculationCard";
import { getAvatar } from "../lib/avatars";
import {
  SALARIO_MINIMO_2026,
  calcSimBandValue,
  fmtBRL,
  type MonthStats,
  type Settings,
  type SimKey,
  type SimState,
} from "../lib/calc";
import { cn } from "../utils/cn";

const moneyStr = (v: number) =>
  v.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const parseMoney = (s: string) => Number(s.replace(/\D/g, "") || 0) / 100;

function SectionTitle({ children }: { children: React.ReactNode }) {
  return <h3 className="text-2xl font-extrabold text-white">{children}</h3>;
}

const BANDS: Array<{
  key: SimKey;
  title: string;
  text: string;
  dot: string;
  ring: string;
  bg: string;
}> = [
  {
    key: "weekday",
    title: "SEG–SEX · DIAS ÚTEIS",
    text: "text-indigo-300",
    dot: "bg-indigo-500",
    ring: "border-indigo-500/40",
    bg: "bg-indigo-500/[0.08]",
  },
  {
    key: "saturday",
    title: "SÁBADO · FIM DE SEMANA",
    text: "text-amber-300",
    dot: "bg-amber-500",
    ring: "border-amber-500/40",
    bg: "bg-amber-500/[0.07]",
  },
  {
    key: "sunday",
    title: "DOMINGO · REPOUSO SEMANAL",
    text: "text-rose-300",
    dot: "bg-rose-500",
    ring: "border-rose-500/40",
    bg: "bg-rose-500/[0.07]",
  },
];

const PCT_PRESETS = [50, 60, 75, 80, 100, 125, 150, 200];

export default function Panel({
  settings,
  update,
  sim,
  setSim,
  stats,
  month,
  year = 2026,
  onCalc,
}: {
  settings: Settings;
  update: (patch: Partial<Settings>, immediate?: boolean) => void;
  sim: SimState;
  setSim: React.Dispatch<React.SetStateAction<SimState>>;
  stats: MonthStats;
  month: number;
  year?: number;
  onCalc: () => void;
}) {
  const summaryRef = useRef<HTMLDivElement>(null);
  const [avatarOpen, setAvatarOpen] = useState(false);

  // Fecha o seletor de avatar ao receber comando de voltar do celular ou teclado
  useEffect(() => {
    const handleBackNav = (e: Event) => {
      if (avatarOpen) {
        e.preventDefault();
        setAvatarOpen(false);
      }
    };
    window.addEventListener("che:back-navigation", handleBackNav);
    return () => {
      window.removeEventListener("che:back-navigation", handleBackNav);
    };
  }, [avatarOpen]);
  const [salaryExpanded, setSalaryExpanded] = useState(false);
  const [jornadaExpanded, setJornadaExpanded] = useState(false);
  const [calcExpanded, setCalcExpanded] = useState(false);
  const [pericInsalubExpanded, setPericInsalubExpanded] = useState(false);
  const [resumoExpanded, setResumoExpanded] = useState(false);
  const [justReset, setJustReset] = useState(false);
  const avatar = getAvatar(settings.avatarId);
  const firstName = settings.name.trim() ? settings.name.trim().split(/\s+/)[0] : "Usuário";
  const avancado = settings.modo === "avancado";
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "BOM DIA" : hour < 18 ? "BOA TARDE" : "BOA NOITE";

  const hasSimValues = Boolean(
    (sim.weekday?.hours && sim.weekday.hours.trim() !== "" && sim.weekday.hours !== "0") ||
    (sim.weekday?.minutes && sim.weekday.minutes.trim() !== "" && sim.weekday.minutes !== "0") ||
    sim.weekday?.noturno ||
    (sim.saturday?.hours && sim.saturday.hours.trim() !== "" && sim.saturday.hours !== "0") ||
    (sim.saturday?.minutes && sim.saturday.minutes.trim() !== "" && sim.saturday.minutes !== "0") ||
    sim.saturday?.noturno ||
    (sim.sunday?.hours && sim.sunday.hours.trim() !== "" && sim.sunday.hours !== "0") ||
    (sim.sunday?.minutes && sim.sunday.minutes.trim() !== "" && sim.sunday.minutes !== "0") ||
    sim.sunday?.noturno
  );

  const handleResetSim = () => {
    setSim((s) => ({
      weekday: { hours: "", minutes: "", noturno: false, pct: s.weekday?.pct || 60 },
      saturday: { hours: "", minutes: "", noturno: false, pct: s.saturday?.pct || 75 },
      sunday: { hours: "", minutes: "", noturno: false, pct: s.sunday?.pct || 100 },
    }));
    setJustReset(true);
    setTimeout(() => setJustReset(false), 2000);
  };

  const patchBand = (b: SimKey, p: Partial<SimState[SimKey]>) =>
    setSim((s) => ({ ...s, [b]: { ...s[b], ...p } }));

  const cyclePct = (b: SimKey) => {
    const cur = sim[b].pct;
    const i = PCT_PRESETS.indexOf(cur);
    const nextPct = PCT_PRESETS[(i + 1) % PCT_PRESETS.length] ?? 60;
    patchBand(b, { pct: nextPct });
  };

  return (
    <div className="space-y-5 px-4 pb-12 pt-2">
      {/* boas-vindas */}
      <div className="relative overflow-hidden rounded-[1.8rem] bg-gradient-to-br from-indigo-600 via-violet-600 to-purple-700 p-6 shadow-2xl shadow-violet-900/40">
        <div className="dots-pattern absolute inset-0 opacity-40" />
        <div className="relative flex gap-4">
          <button
            type="button"
            onClick={() => setAvatarOpen(true)}
            aria-label="Escolher avatar ou foto pessoal"
            className="relative h-24 w-24 shrink-0 overflow-hidden rounded-[1.4rem] bg-white/15 text-3xl font-extrabold text-white ring-1 ring-white/30 transition active:scale-95"
          >
            {settings.photoURL ? (
              <img
                src={settings.photoURL}
                alt="Foto pessoal"
                className="h-full w-full object-cover"
              />
            ) : avatar ? (
              <AvatarFace spec={avatar} className="h-full w-full" />
            ) : settings.name.trim() ? (
              settings.name.trim().slice(0, 2).toUpperCase()
            ) : (
              <User className="h-10 w-10 text-white/80" />
            )}
          </button>
          <div className="min-w-0">
            <p className="text-sm font-bold tracking-[0.18em] text-white/75">
              {greeting} · Bem-vindo ao painel
            </p>
            <h2 className="mt-1 text-4xl font-extrabold leading-tight text-white">
              Olá, <span className="underline decoration-white/50 underline-offset-4">{firstName}</span>!
            </h2>
            <p className="mt-2 text-lg leading-snug text-white/85">
              Seu painel de horas extras está personalizado e pronto para usar.
            </p>
          </div>
        </div>

        <div className="relative mt-6 space-y-4">
          <div>
            <label className="mb-2 block text-base font-bold uppercase tracking-[0.16em] text-white/75">
              Nome do usuário
            </label>
            <div className="flex h-16 items-center gap-3 rounded-2xl border border-white/25 bg-slate-950/35 px-4">
              <User className="h-6 w-6 text-indigo-200" />
              <input
                value={settings.name}
                onChange={(e) => update({ name: e.target.value })}
                onBlur={() => update({ name: settings.name }, true)}
                className="w-full bg-transparent text-xl font-semibold text-white outline-none placeholder:text-white/50"
                placeholder="Seu nome"
              />
              {settings.name && (
                <button type="button" onClick={() => update({ name: "" }, true)} aria-label="limpar">
                  <X className="h-6 w-6 text-white/70" />
                </button>
              )}
            </div>
          </div>

          <div>
            <label className="mb-2 block text-base font-bold uppercase tracking-[0.16em] text-white/75">
              Cargo
            </label>
            <div className="flex h-16 items-center gap-3 rounded-2xl border border-white/25 bg-slate-950/35 px-4">
              <Briefcase className="h-6 w-6 text-indigo-200" />
              <input
                value={settings.cargo}
                onChange={(e) => update({ cargo: e.target.value })}
                onBlur={() => update({ cargo: settings.cargo }, true)}
                className="w-full bg-transparent text-xl font-semibold text-white outline-none placeholder:text-white/50"
                placeholder="Informe seu cargo (ex.: Montador B)"
              />
              {settings.cargo && (
                <button
                  type="button"
                  onClick={() => update({ cargo: "" }, true)}
                  aria-label="limpar cargo"
                >
                  <X className="h-6 w-6 text-white/70" />
                </button>
              )}
            </div>
          </div>

          <div>
            <label className="mb-2 block text-base font-bold uppercase tracking-[0.16em] text-white/75">
              Empresa
            </label>
            <div className="flex h-16 items-center gap-3 rounded-2xl border border-white/25 bg-slate-950/35 px-4">
              <Building2 className="h-6 w-6 text-indigo-200" />
              <input
                value={settings.empresa}
                onChange={(e) => update({ empresa: e.target.value })}
                onBlur={() => update({ empresa: settings.empresa }, true)}
                className="w-full bg-transparent text-xl font-semibold text-white outline-none placeholder:text-white/50"
                placeholder="Informe sua empresa"
              />
              {settings.empresa && (
                <button
                  type="button"
                  onClick={() => update({ empresa: "" }, true)}
                  aria-label="limpar empresa"
                >
                  <X className="h-6 w-6 text-white/70" />
                </button>
              )}
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between gap-2">
            <p className="flex items-center gap-2 text-base text-emerald-300 font-medium">
              <Check className="h-5 w-5 shrink-0 text-emerald-400" />
              <span>Salvo automaticamente no perfil e na nuvem.</span>
            </p>
          </div>
        </div>
      </div>

      {/* visão geral — só no Modo Avançado */}
      {avancado && (
      <div className="px-1">
        <h2 className="text-[2rem] font-extrabold leading-tight tracking-tight text-white">
          Visão geral das horas extras
        </h2>
        <p className="mt-2 text-xl leading-snug text-slate-400">
          Acompanhe volume, custo e aprovações do calendário automatizado de{" "}
          <span className="font-semibold text-indigo-400">
            {settings.name.split(" ")[0] || "você"}
          </span>
          . Custos calculados a partir do{" "}
          <span className="font-semibold text-emerald-400">salário bruto</span>.
        </p>
      </div>
      )}

      {/* aviso do modo simplificado */}
      {!avancado && (
        <div className="rounded-2xl border border-indigo-400/25 bg-indigo-500/10 px-4 py-3 text-center text-base font-medium text-indigo-200">
          Modo simplificado · salário bruto, jornada mensal, cálculo e resumo ficam
          minimizados. Ative o <strong>Modo Avançado</strong> para ver tudo expandido.
        </div>
      )}

      {/* filtros — só no Modo Avançado */}
      {avancado && (() => {
        const isMeses = settings.periodMode === "meses";
        const currentMonths =
          settings.periodMonths ??
          (settings.periodDays >= 28 ? Math.max(1, Math.round(settings.periodDays / 30)) : 1);

        return (
          <Card>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <Filter className="h-7 w-7 text-indigo-400" />
                <div>
                  <SectionTitle>Filtros do painel</SectionTitle>
                  <p className="text-xs sm:text-sm text-slate-400 font-medium">
                    Ajuste o período em {isMeses ? "meses" : "dias"}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-base font-bold uppercase tracking-wider text-slate-500">
                  Período
                </span>
                <div className="flex rounded-2xl bg-slate-800/70 p-1">
                  {(["dias", "meses"] as const).map((p) => {
                    const active = settings.periodMode === p;
                    return (
                      <button
                        key={p}
                        type="button"
                        onClick={() => {
                          if (p === "meses") {
                            const m =
                              settings.periodMonths ??
                              (settings.periodDays >= 28
                                ? Math.max(1, Math.round(settings.periodDays / 30))
                                : 1);
                            update({ periodMode: "meses", periodMonths: m, periodDays: m * 30 });
                          } else {
                            const d =
                              settings.periodDays && settings.periodDays > 0
                                ? settings.periodDays
                                : currentMonths * 30;
                            update({ periodMode: "dias", periodDays: d });
                          }
                        }}
                        className={cn(
                          "rounded-xl px-6 py-2.5 text-lg font-semibold capitalize transition",
                          active
                            ? "bg-slate-700 text-white shadow"
                            : "text-slate-400 hover:text-slate-200"
                        )}
                      >
                        {p === "dias" ? "Dias" : "Mês"}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <Stepper
              className="mt-5"
              value={String(isMeses ? currentMonths : settings.periodDays)}
              suffix={isMeses ? (currentMonths === 1 ? "mês" : "meses") : "d"}
              onDec={() => {
                if (isMeses) {
                  const next = Math.max(1, currentMonths - 1);
                  update({ periodMonths: next, periodDays: next * 30 });
                } else {
                  update({ periodDays: Math.max(1, settings.periodDays - 1) });
                }
              }}
              onInc={() => {
                if (isMeses) {
                  const next = Math.min(120, currentMonths + 1);
                  update({ periodMonths: next, periodDays: next * 30 });
                } else {
                  update({ periodDays: settings.periodDays + 1 });
                }
              }}
              onValue={(v) => {
                const num = Math.max(1, Number(v.replace(/\D/g, "")) || 1);
                if (isMeses) {
                  const next = Math.min(120, num);
                  update({ periodMonths: next, periodDays: next * 30 });
                } else {
                  update({ periodDays: num });
                }
              }}
            />

            <div className="mt-4 flex flex-wrap gap-3">
              {isMeses
                ? [1, 2, 3, 6, 12].map((m) => (
                    <Chip
                      key={m}
                      active={currentMonths === m}
                      onClick={() => update({ periodMonths: m, periodDays: m * 30 })}
                    >
                      {m} {m === 1 ? "mês" : "meses"}
                    </Chip>
                  ))
                : [7, 15, 30, 60, 90].map((d) => (
                    <Chip
                      key={d}
                      active={settings.periodDays === d}
                      onClick={() =>
                        update({
                          periodDays: d,
                          periodMonths: Math.max(1, Math.round(d / 30)),
                        })
                      }
                    >
                      {d} dias
                    </Chip>
                  ))}
            </div>
          </Card>
        );
      })()}

      {/* salário bruto */}
      {!avancado && !salaryExpanded ? (
        /* Modo Desativado: salário bruto minimizado */
        <div className="rounded-2xl border border-slate-700/50 bg-slate-800/40 p-4 transition-all">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-400/20">
                <Banknote className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-base font-bold text-white">Salário Bruto</span>
                  <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 text-xs font-black text-emerald-300 border border-emerald-400/30">
                    {fmtBRL(settings.salary)}
                  </span>
                  <span className="rounded-md bg-indigo-500/20 px-2 py-0.5 text-xs font-bold text-indigo-300 border border-indigo-400/30">
                    Hora: {fmtBRL(stats.valorHora)}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">(minimizada · toque em Expandir)</span>
                </div>
                <p className="text-xs text-slate-400 truncate">
                  Base de cálculo pela jornada de {settings.jornada}h · modo simplificado
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setSalaryExpanded(true)}
              className="flex items-center gap-1 rounded-xl bg-slate-700/60 px-3 py-1.5 text-xs font-bold text-slate-200 transition hover:bg-slate-700 active:scale-95 shrink-0"
              title="Editar e expandir Salário Bruto"
            >
              <span>Editar</span>
              <ChevronDown className="h-4 w-4" />
            </button>
          </div>
        </div>
      ) : (
        <Card>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <IconTile className="bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-400/30">
                <Banknote className="h-6 w-6" />
              </IconTile>
              <div>
                <SectionTitle>Salário Bruto</SectionTitle>
                <p className="text-lg text-slate-400">
                  Base de cálculo pela jornada informada
                </p>
              </div>
            </div>
            {!avancado && (
              <button
                type="button"
                onClick={() => setSalaryExpanded(false)}
                className="flex items-center gap-1 rounded-xl bg-slate-700/60 px-3 py-1.5 text-xs font-bold text-slate-200 transition hover:bg-slate-700 active:scale-95"
              >
                <span>Minimizar</span>
                <ChevronUp className="h-4 w-4" />
              </button>
            )}
          </div>

          <Stepper
            className="mt-5"
            prefix="R$"
            value={moneyStr(settings.salary)}
            onDec={() => update({ salary: Math.max(0, settings.salary - 100) })}
            onInc={() => update({ salary: settings.salary + 100 })}
            onValue={(v) => update({ salary: parseMoney(v) })}
          />

          <div className="mt-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 rounded-2xl border border-indigo-400/40 bg-indigo-500/10 p-4">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.16em] text-indigo-300">
                Valor da hora normal
              </span>
              <div className="num text-3xl font-extrabold text-indigo-200">
                {fmtBRL(stats.valorHora)}/hora
              </div>
            </div>
            <div className="rounded-xl bg-slate-900/80 border border-indigo-500/30 p-2.5 text-xs text-indigo-200">
              <div className="font-semibold text-indigo-300">Fórmula de cálculo:</div>
              <div className="font-mono font-bold text-white">Salário Bruto ÷ Jornada Mensal = Valor/Hora</div>
              <div className="text-[11px] text-slate-400 mt-0.5">Exemplo: {fmtBRL(settings.salary)} ÷ {settings.jornada}h = {fmtBRL(stats.valorHora)}/hora</div>
            </div>
          </div>

          <div className="mt-4">
            <span className="mb-3 block text-lg font-semibold uppercase tracking-wide text-slate-500">
              Atalhos
            </span>
            <div className="flex flex-wrap gap-3">
              {[2500, 3000, 3500, 4000, 4500, 5000, 6000].map((v) => (
                <Chip
                  key={v}
                  active={settings.salary === v}
                  onClick={() => update({ salary: v })}
                  activeClass="bg-emerald-600 border-emerald-400 text-white"
                >
                  R$ {v / 1000}k
                </Chip>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* jornada mensal */}
      {avancado ? (
        <Card>
          <div className="flex items-center gap-4">
            <IconTile className="bg-violet-500/15 text-violet-400 ring-1 ring-violet-400/30">
              <Clock className="h-6 w-6" />
            </IconTile>
            <div>
              <SectionTitle>Jornada mensal</SectionTitle>
              <p className="text-lg text-slate-400">
                Horas contratuais trabalhadas no mês
              </p>
            </div>
          </div>
          <Stepper
            className="mt-5"
            suffix="h"
            value={String(settings.jornada)}
            onDec={() => update({ jornada: Math.max(20, settings.jornada - 10) })}
            onInc={() => update({ jornada: settings.jornada + 10 })}
            onValue={(v) => update({ jornada: Math.max(20, Number(v.replace(/\D/g, "")) || 20) })}
          />
          <div className="mt-4 flex flex-wrap items-center gap-3">
            <span className="text-lg font-semibold uppercase tracking-wide text-violet-400">
              Jornadas
            </span>
            {[180, 200, 220].map((j) => (
              <Chip
                key={j}
                active={settings.jornada === j}
                onClick={() => update({ jornada: j })}
              >
                {j}h
              </Chip>
            ))}
          </div>
        </Card>
      ) : (
        /* Modo Desativado: jornada minimizada */
        <div className="rounded-2xl border border-slate-700/50 bg-slate-800/40 p-4 transition-all">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-violet-500/15 text-violet-400 border border-violet-400/20">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold text-white">Jornada mensal</span>
                  <span className="rounded-md bg-violet-500/20 px-2 py-0.5 text-xs font-black text-violet-300 border border-violet-400/30">
                    {settings.jornada}h
                  </span>
                  <span className="text-xs text-slate-400 font-medium">(minimizada)</span>
                </div>
                <p className="text-xs text-slate-400">
                  {settings.jornada === 220 ? "Padrão CLT (220h)" : `${settings.jornada}h contratuais`} · modo simplificado
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setJornadaExpanded((v) => !v)}
              className="flex items-center gap-1 rounded-xl bg-slate-700/60 px-3 py-1.5 text-xs font-bold text-slate-200 transition hover:bg-slate-700 active:scale-95"
            >
              {jornadaExpanded ? (
                <>
                  <span>Minimizar</span>
                  <ChevronUp className="h-4 w-4" />
                </>
              ) : (
                <>
                  <span>Configurar</span>
                  <ChevronDown className="h-4 w-4" />
                </>
              )}
            </button>
          </div>

          {jornadaExpanded && (
            <div className="mt-4 pt-3 border-t border-slate-700/50">
              <Stepper
                suffix="h"
                value={String(settings.jornada)}
                onDec={() => update({ jornada: Math.max(20, settings.jornada - 10) })}
                onInc={() => update({ jornada: settings.jornada + 10 })}
                onValue={(v) => update({ jornada: Math.max(20, Number(v.replace(/\D/g, "")) || 20) })}
              />
              <div className="mt-3 flex flex-wrap items-center gap-2">
                {[180, 200, 220].map((j) => (
                  <Chip
                    key={j}
                    active={settings.jornada === j}
                    onClick={() => update({ jornada: j })}
                  >
                    {j}h
                  </Chip>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* adicional noturno — só no Modo Avançado (fica desligado por padrão) */}
      {avancado && (
      <Card>
        <div className="flex items-center gap-4">
          <IconTile className="bg-sky-500/15 text-sky-400 ring-1 ring-sky-400/30">
            <MoonStar className="h-6 w-6" />
          </IconTile>
          <div className="flex-1">
            <SectionTitle>Adicional noturno</SectionTitle>
            <p className="text-lg text-slate-400">
              Aplicado às horas trabalhadas entre 22h e 5h
            </p>
          </div>
        </div>
        <Stepper
          className="mt-5"
          suffix="%"
          value={String(settings.noturnoPct)}
          onDec={() => update({ noturnoPct: Math.max(0, settings.noturnoPct - 5) })}
          onInc={() => update({ noturnoPct: Math.min(100, settings.noturnoPct + 5) })}
          onValue={(v) => update({ noturnoPct: Math.min(100, Number(v.replace(/\D/g, "")) || 0) })}
        />
        <div className="mt-4 flex flex-wrap items-center gap-3">
          {[20, 25, 30, 40].map((p) => (
            <Chip
              key={p}
              active={settings.noturnoPct === p}
              onClick={() => update({ noturnoPct: p })}
              activeClass="bg-sky-600 border-sky-400 text-white"
            >
              {p}%
            </Chip>
          ))}
          <Toggle
            on={settings.noturnoEnabled}
            color="sky"
            onChange={(v) => update({ noturnoEnabled: v })}
          />
        </div>
        <p className="mt-4 text-lg leading-snug text-slate-500">
          Hora noturna = (Salário ÷ jornada) × (1 + {settings.noturnoPct}%) — o
          percentual de hora extra incide sobre esse valor.
        </p>
      </Card>
      )}

      {/* DSR — só no Modo Avançado */}
      {avancado && (
      <Card>
        <div className="flex items-center gap-4">
          <IconTile className="bg-sky-500/15 text-sky-400 ring-1 ring-sky-400/30">
            <CalendarDays className="h-6 w-6" />
          </IconTile>
          <div className="flex-1">
            <SectionTitle>DSR · Descanso Semanal Remunerado</SectionTitle>
            <p className="text-lg text-slate-400">
              Soma o repouso semanal proporcional às horas extras
            </p>
          </div>
          <Toggle on={settings.dsrEnabled} onChange={(v) => update({ dsrEnabled: v })} />
        </div>
      </Card>
      )}

      {/* Bloco Único: [Periculosidade] & Insalubridade */}
      {(!avancado && !pericInsalubExpanded) ? (
        /* Modo Desativado / Minimizado (Modo Simplificado) */
        <div className="rounded-2xl border border-slate-700/50 bg-slate-800/40 p-4 transition-all">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400 border border-amber-400/20">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-base font-bold text-white">[Periculosidade]</span>
                  <span className="text-sm font-semibold text-slate-300">· Insalubridade</span>
                  {!settings.periculosidadeEnabled && !settings.insalubridadeEnabled ? (
                    <span className="rounded-md bg-slate-700/60 px-2 py-0.5 text-xs font-semibold text-slate-300 border border-slate-600/40">
                      Modo Simplificado Ativo
                    </span>
                  ) : (
                    <div className="flex flex-wrap items-center gap-1.5">
                      {settings.periculosidadeEnabled && (
                        <span className="rounded-md bg-amber-500/20 px-2 py-0.5 text-xs font-bold text-amber-300 border border-amber-400/30">
                          Peric. {settings.periculosidadePct ?? 30}%
                        </span>
                      )}
                      {settings.insalubridadeEnabled && (
                        <span className="rounded-md bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-300 border border-emerald-400/30">
                          Insalub. {settings.insalubridadePct ?? 30}%
                        </span>
                      )}
                    </div>
                  )}
                  <span className="text-xs text-slate-400 font-medium">(minimizada · toque em Expandir)</span>
                </div>
                <p className="text-xs text-slate-400 truncate mt-0.5">
                  {settings.periculosidadeEnabled
                    ? `Periculosidade ativa (${fmtBRL(stats.periculosidade)}/mês)`
                    : "Periculosidade desativada"}{" "}
                  ·{" "}
                  {settings.insalubridadeEnabled
                    ? `Insalubridade ativa (${fmtBRL(stats.insalubridade)}/mês)`
                    : "Insalubridade desativada"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                id="btn-ajustar-peric-insalub"
                onClick={() => setPericInsalubExpanded(true)}
                className="flex items-center gap-1 rounded-xl bg-slate-700/60 px-3 py-1.5 text-xs font-bold text-slate-200 transition hover:bg-slate-700 active:scale-95 shrink-0"
                title="Alterar e expandir Periculosidade e Insalubridade"
              >
                <span>Alterar</span>
                <ChevronDown className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Modo Avançado / Maximizado: Bloco único com Periculosidade e Insalubridade totalmente abertos */
        <Card className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400 border border-amber-400/20">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <div>
                <SectionTitle>Adicionais · Periculosidade & Insalubridade</SectionTitle>
                <p className="text-sm text-slate-400">
                  {avancado ? "Modo Avançado · motores de ajuste maximizados" : "Motores de ajuste e porcentagens de adicionais trabalhistas"}
                </p>
              </div>
            </div>
            {!avancado && (
              <button
                type="button"
                onClick={() => setPericInsalubExpanded(false)}
                className="flex items-center gap-1 rounded-xl bg-slate-800 hover:bg-slate-700 px-3 py-1.5 text-xs font-bold text-slate-300 transition"
                title="Minimizar bloco"
              >
                <span>Minimizar</span>
                <ChevronUp className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Item 1: Periculosidade */}
          <div className="rounded-2xl border border-slate-800/80 bg-slate-950/40 p-4 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-500/15 text-amber-400 ring-1 ring-amber-400/30">
                  <ShieldAlert className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-200">Periculosidade</span>
                    <span className="rounded bg-amber-500/20 px-2 py-0.5 text-xs font-bold text-amber-300 border border-amber-400/30">
                      +{settings.periculosidadePct ?? 30}% s/ base
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    30% sobre salário base (não incide sobre HE) · Calculado sobre {fmtBRL(settings.salary)}
                  </p>
                </div>
              </div>
              <Toggle
                on={settings.periculosidadeEnabled}
                color="amber"
                onChange={(v) => update({ periculosidadeEnabled: v })}
              />
            </div>

            {/* Stepper (− / +) e digitação direta de Periculosidade */}
            <div className="pt-2 border-t border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Percentual de Periculosidade
                </label>
                <button
                  type="button"
                  onClick={() => update({ periculosidadePct: 30 })}
                  className={cn(
                    "rounded-lg px-2.5 py-1 text-xs font-bold transition",
                    (settings.periculosidadePct ?? 30) === 30
                      ? "bg-amber-500/30 text-amber-200 border border-amber-400/40"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  )}
                  title="Restaurar padrão legal CLT (30%)"
                >
                  Padrão legal CLT (30%)
                </button>
              </div>

              <Stepper
                value={String(settings.periculosidadePct ?? 30)}
                suffix="%"
                onDec={() =>
                  update({
                    periculosidadePct: Math.max(0, (settings.periculosidadePct ?? 30) - 5),
                  })
                }
                onInc={() =>
                  update({
                    periculosidadePct: Math.min(200, (settings.periculosidadePct ?? 30) + 5),
                  })
                }
                onValue={(v) => {
                  const cleaned = Number(v.replace(/\D/g, "")) || 0;
                  update({ periculosidadePct: Math.min(200, Math.max(0, cleaned)) });
                }}
              />

              <div className="flex items-center justify-between text-xs text-slate-400 bg-slate-900/60 rounded-xl px-3 py-2">
                <span>Cálculo ao vivo (salário base × percentual):</span>
                <span
                  className={cn(
                    "font-bold text-sm",
                    settings.periculosidadeEnabled ? "text-amber-300" : "text-slate-500"
                  )}
                >
                  {fmtBRL(settings.salary * ((settings.periculosidadePct ?? 30) / 100))}
                  {!settings.periculosidadeEnabled && " (desativado)"}
                </span>
              </div>
            </div>
          </div>

          {/* Item 2: Insalubridade */}
          <div className="rounded-2xl border border-slate-800/80 bg-slate-950/40 p-4 space-y-3">
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-500/15 text-emerald-400 ring-1 ring-emerald-400/30">
                  <Biohazard className="h-5 w-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-slate-200">Insalubridade</span>
                    <span className="rounded bg-emerald-500/20 px-2 py-0.5 text-xs font-bold text-emerald-300 border border-emerald-400/30">
                      +{settings.insalubridadePct ?? 30}% s/ mínimo
                    </span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Calculado sobre o salário mínimo ({fmtBRL(SALARIO_MINIMO_2026)})
                  </p>
                </div>
              </div>
              <Toggle
                on={settings.insalubridadeEnabled}
                color="emerald"
                onChange={(v) => update({ insalubridadeEnabled: v })}
              />
            </div>

            {/* Stepper (− / +) e digitação direta de Insalubridade */}
            <div className="pt-2 border-t border-slate-800/60 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Percentual de Insalubridade
                </label>
                <button
                  type="button"
                  onClick={() => update({ insalubridadePct: 30 })}
                  className={cn(
                    "rounded-lg px-2.5 py-1 text-xs font-bold transition",
                    (settings.insalubridadePct ?? 30) === 30
                      ? "bg-emerald-500/30 text-emerald-200 border border-emerald-400/40"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  )}
                  title="Padrão do app (30%)"
                >
                  Padrão (30%)
                </button>
              </div>

              <Stepper
                value={String(settings.insalubridadePct ?? 30)}
                suffix="%"
                onDec={() =>
                  update({
                    insalubridadePct: Math.max(0, (settings.insalubridadePct ?? 30) - 5),
                  })
                }
                onInc={() =>
                  update({
                    insalubridadePct: Math.min(200, (settings.insalubridadePct ?? 30) + 5),
                  })
                }
                onValue={(v) => {
                  const cleaned = Number(v.replace(/\D/g, "")) || 0;
                  update({ insalubridadePct: Math.min(200, Math.max(0, cleaned)) });
                }}
              />

              {/* Botões rápidos dos graus CLT */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                {[
                  { pct: 10, label: "10% Mínimo" },
                  { pct: 20, label: "20% Médio" },
                  { pct: 40, label: "40% Máximo" },
                ].map((item) => (
                  <button
                    key={item.pct}
                    type="button"
                    onClick={() => update({ insalubridadePct: item.pct })}
                    className={cn(
                      "rounded-lg px-2.5 py-1 text-xs font-bold transition",
                      (settings.insalubridadePct ?? 30) === item.pct
                        ? "bg-emerald-500/30 text-emerald-200 border border-emerald-400/40"
                        : "bg-slate-800 text-slate-400 hover:text-white"
                    )}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              {/* Nota Legal conforme a CLT */}
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-950/20 p-2.5 text-xs text-emerald-300/90 leading-relaxed">
                <span className="font-bold text-emerald-300">Nota legal (Art. 192 da CLT):</span> A insalubridade é classificada nos graus mínimo (10%), médio (20%) e máximo (40%), calculada sobre o salário mínimo vigente ({fmtBRL(SALARIO_MINIMO_2026)}).
              </div>

              <div className="flex items-center justify-between text-xs text-slate-400 bg-slate-900/60 rounded-xl px-3 py-2">
                <span>Cálculo ao vivo (salário mínimo × percentual):</span>
                <span
                  className={cn(
                    "font-bold text-sm",
                    settings.insalubridadeEnabled ? "text-emerald-300" : "text-slate-500"
                  )}
                >
                  {fmtBRL(SALARIO_MINIMO_2026 * ((settings.insalubridadePct ?? 30) / 100))}
                  {!settings.insalubridadeEnabled && " (desativado)"}
                </span>
              </div>
            </div>
          </div>

          {/* Rodapé do Bloco com Ação de Minimizar */}
          <div className="flex items-center justify-between pt-2 border-t border-slate-800">
            <span className="text-xs text-slate-400">
              {!settings.periculosidadeEnabled && !settings.insalubridadeEnabled
                ? "Ambos adicionais estão em Modo Simplificado Ativo"
                : "Alterações salvas automaticamente no perfil"}
            </span>
            {!avancado && (
              <button
                type="button"
                onClick={() => setPericInsalubExpanded(false)}
                className="flex items-center gap-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 px-3 py-1.5 text-xs font-bold text-slate-300 transition"
              >
                <span>Minimizar bloco</span>
                <ChevronUp className="h-4 w-4" />
              </button>
            )}
          </div>
        </Card>
      )}

      {/* calcular horas extras */}
      {!avancado && !calcExpanded ? (
        /* Modo Simplificado: calcular horas extras minimizado */
        <div className="rounded-2xl border border-slate-700/50 bg-slate-800/40 p-4 transition-all">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-indigo-500/15 text-indigo-400 border border-indigo-400/20">
                <Calculator className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-base font-bold text-white">Calcular horas extras</span>
                  <span className="rounded-md bg-indigo-500/20 px-2 py-0.5 text-xs font-black text-indigo-300 border border-indigo-400/30">
                    Base {fmtBRL(stats.valorHora)}
                  </span>
                  <span className="text-xs text-slate-400 font-medium">(minimizada · toque em Expandir)</span>
                </div>
                <p className="text-xs text-slate-400 truncate">
                  Simulação de cálculo: dias úteis, sábados, domingos e feriados · modo simplificado
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  onCalc();
                  setResumoExpanded(true);
                  summaryRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
                }}
                className="hidden sm:flex items-center gap-1 rounded-xl bg-indigo-600 px-3 py-1.5 text-xs font-bold text-white transition hover:bg-indigo-500 active:scale-95"
                title="Calcular agora"
              >
                <Calculator className="h-3.5 w-3.5" />
                <span>Calcular</span>
              </button>
              <button
                type="button"
                onClick={() => setCalcExpanded(true)}
                className="flex items-center gap-1 rounded-xl bg-slate-700/60 px-3 py-1.5 text-xs font-bold text-slate-200 transition hover:bg-slate-700 active:scale-95"
                title="Editar e expandir cálculo de horas extras"
              >
                <span>Editar</span>
                <ChevronDown className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      ) : (
        <Card className="space-y-4">
          <div className="flex items-start justify-between gap-4">
            <div>
              <SectionTitle>Calcular horas extras</SectionTitle>
              <div className="mt-2.5 inline-flex items-center rounded-2xl bg-slate-800/70 px-4 py-2 text-base font-semibold">
                <span className="text-slate-400">Hora base:</span>
                <span className="num ml-2 font-bold text-white">
                  {fmtBRL(stats.valorHora)}
                </span>
              </div>
            </div>

            <div className="flex flex-col items-end gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setCalcExpanded(false)}
                className="flex items-center gap-1 rounded-xl bg-slate-700/60 px-3 py-1.5 text-xs font-bold text-slate-200 transition hover:bg-slate-700 active:scale-95"
                title="Minimizar aba de cálculo de horas extras"
              >
                <span>Minimizar</span>
                <ChevronUp className="h-4 w-4" />
              </button>

              {/* Botão [ZERAR] abaixo do nome Minimizar */}
              <button
                type="button"
                id="btn-zerar-horas-extras"
                onClick={handleResetSim}
                title="Limpar e zerar todos os 3 campos: 60%, 75% e 100%"
                className={cn(
                  "group relative flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-black tracking-wider uppercase transition-all duration-200 active:scale-95",
                  justReset
                    ? "border border-emerald-500/50 bg-emerald-500/20 text-emerald-300 ring-1 ring-emerald-500/40 shadow-md shadow-emerald-950/30"
                    : hasSimValues
                    ? "border border-rose-500/50 bg-gradient-to-r from-rose-500/20 via-red-500/15 to-amber-500/20 text-rose-300 hover:border-rose-400 hover:from-rose-500/30 hover:to-amber-500/30 hover:text-white shadow-md shadow-rose-950/40 ring-1 ring-rose-500/30"
                    : "border border-slate-700/60 bg-slate-800/50 text-slate-400 hover:border-slate-600 hover:bg-slate-700/50 hover:text-slate-200"
                )}
              >
                {justReset ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span className="text-emerald-300">ZERADO</span>
                  </>
                ) : (
                  <>
                    <RotateCcw
                      className={cn(
                        "h-3.5 w-3.5 transition-transform duration-300",
                        hasSimValues && "group-hover:-rotate-90 text-rose-400"
                      )}
                    />
                    <span>ZERAR</span>
                    {hasSimValues && (
                      <span className="h-1.5 w-1.5 rounded-full bg-rose-400 animate-pulse" />
                    )}
                  </>
                )}
              </button>
            </div>
          </div>

          {BANDS.map((b) => {
            const band = sim[b.key];
            const bandVal = calcSimBandValue(band, stats.valorHora, settings.noturnoPct, settings.noturnoEnabled);
            const hasValue = bandVal > 0;
            const pctBtn =
              "flex h-12 w-12 items-center justify-center rounded-xl border border-slate-500/30 bg-slate-800/70 text-slate-300 active:scale-95";
            return (
              <div
                key={b.key}
                className={cn("rounded-2xl border p-5", b.ring, b.bg)}
              >
                <div className="flex items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className={cn("h-2.5 w-2.5 rounded-full shrink-0", b.dot)} />
                    <span className={cn("text-xs sm:text-sm md:text-base font-extrabold uppercase tracking-wider truncate", b.text)}>
                      {b.title}
                    </span>
                  </div>

                  {/* Valor em R$ na frente do nome SEG–SEX · DIAS ÚTEIS [ R$ 0,00 ] */}
                  <div
                    id={`badge-valor-${b.key}`}
                    className={cn(
                      "inline-flex items-center justify-center rounded-xl px-3 py-1.5 font-bold transition-all duration-200 shrink-0",
                      hasValue
                        ? "border border-emerald-400/50 bg-emerald-500/20 text-emerald-300 shadow-sm shadow-emerald-950/25 ring-1 ring-emerald-500/30"
                        : "border border-slate-700/60 bg-slate-900/60 text-slate-400"
                    )}
                    title={`Valor correspondente às horas extras desta faixa (${band.pct}%): ${fmtBRL(bandVal)}`}
                  >
                    <span className="num text-xs sm:text-sm md:text-base font-black tracking-tight">
                      {fmtBRL(bandVal)}
                    </span>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-3">
                  <span className={cn("text-2xl font-extrabold", b.text)}>Horas +</span>
                  <button
                    type="button"
                    className={pctBtn}
                    onClick={() =>
                      patchBand(b.key, {
                        pct: Math.max(50, band.pct - 5),
                      })
                    }
                    aria-label="diminuir percentual"
                  >
                    <Minus className="h-5 w-5" strokeWidth={2.5} />
                  </button>
                  <button
                    type="button"
                    onClick={() => cyclePct(b.key)}
                    title="Toque para alterar o percentual"
                    className="field num flex h-14 flex-1 items-center justify-center rounded-xl px-3 text-3xl font-extrabold text-white"
                  >
                    {band.pct}
                    <span className="ml-2 text-xl font-bold text-slate-400">%</span>
                  </button>
                  <button
                    type="button"
                    className={pctBtn}
                    onClick={() =>
                      patchBand(b.key, {
                        pct: Math.min(200, band.pct + 5),
                      })
                    }
                    aria-label="aumentar percentual"
                  >
                    <Plus className="h-5 w-5" strokeWidth={2.5} />
                  </button>
                </div>

                <div className="mt-4 grid grid-cols-[1fr_auto_1fr] items-end gap-3">
                  <div>
                    <span className="mb-2 block text-base font-bold uppercase tracking-wide text-slate-500">
                      Horas
                    </span>
                    <div className="field flex h-14 items-center px-4">
                      <input
                        inputMode="numeric"
                        value={band.hours}
                        onChange={(e) =>
                          patchBand(b.key, {
                            hours: e.target.value.replace(/\D/g, ""),
                          })
                        }
                        placeholder="Horas"
                        className="w-full bg-transparent text-xl font-semibold text-white placeholder-slate-500 outline-none"
                      />
                    </div>
                  </div>
                  <span className="pb-3.5 text-2xl font-light text-slate-500">:</span>
                  <div>
                    <span className="mb-2 flex items-center justify-between text-base font-bold uppercase tracking-wide text-slate-500">
                      Minutos
                      <span className="text-sm font-semibold normal-case tracking-normal text-slate-500">
                        0-100
                      </span>
                    </span>
                    <div className="field flex h-14 items-center px-4">
                      <input
                        inputMode="numeric"
                        value={band.minutes}
                        onChange={(e) => {
                          const digits = e.target.value.replace(/\D/g, "").slice(0, 3);
                          const capped = digits
                            ? String(Math.min(100, Number(digits)))
                            : "";
                          patchBand(b.key, { minutes: capped });
                        }}
                        placeholder="0-100"
                        maxLength={3}
                        className="num w-full bg-transparent text-right text-xl font-semibold text-white placeholder-slate-500 outline-none"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => patchBand(b.key, { noturno: !band.noturno })}
                  className={cn(
                    "mt-3 flex w-full items-center gap-3 rounded-xl border px-5 py-3.5 text-left text-lg font-semibold transition",
                    band.noturno
                      ? "border-sky-400/50 bg-sky-500/15 text-sky-200"
                      : "border-slate-500/30 bg-[#18243c] text-slate-400"
                  )}
                >
                  <Moon className="h-5 w-5" />
                  <span className="flex-1">Noturno (22h–5h)</span>
                  <span className="font-bold">+{settings.noturnoPct}%</span>
                </button>
              </div>
            );
          })}

          <p className="px-1 pt-1 text-center text-lg leading-snug text-slate-500">
            O resultado inclui DSR de {stats.domingos + stats.feriados} repousos ({stats.domingos} domingos + {stats.feriados} feriado{stats.feriados === 1 ? "" : "s"}) /{" "}
            {stats.uteis} dias úteis, considerando {stats.facultativos} ponto{stats.facultativos === 1 ? "" : "s"} facultativo{stats.facultativos === 1 ? "" : "s"} do mês.
          </p>

          <button
            type="button"
            onClick={() => {
              onCalc();
              if (!avancado) setResumoExpanded(true);
              summaryRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
            }}
            className="btn-glow flex h-[4.5rem] w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 text-2xl font-extrabold text-white transition active:scale-[0.98]"
          >
            <Calculator className="h-7 w-7" />
            Calcular horas extras
          </button>
        </Card>
      )}

      {/* Resumo e Cálculo Detalhado do Mês */}
      <div ref={summaryRef} className="scroll-mt-4">
        <DetailedCalculationCard
          month={month}
          year={year}
          settings={settings}
          stats={stats}
          sim={sim}
          avancado={avancado}
          defaultExpanded={avancado || resumoExpanded}
          onUpdateSettings={(patch, immediate) => update(patch, immediate)}
          sourceLabel="Calculadora de horas extras e adicionais CLT"
        />
      </div>

      {avatarOpen && (
        <AvatarPicker
          selectedId={settings.avatarId}
          photoURL={settings.photoURL}
          onSelect={(id) => update({ avatarId: id, photoURL: "" })}
          onSelectPhoto={(url) => update({ photoURL: url })}
          onRemovePhoto={() => update({ photoURL: "" })}
          onClose={() => setAvatarOpen(false)}
        />
      )}
    </div>
  );
}
