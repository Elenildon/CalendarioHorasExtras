export type HairStyle =
  | "bald"
  | "buzz"
  | "short"
  | "wavy"
  | "curly"
  | "afro"
  | "long"
  | "bun"
  | "mohawk";

export type BeardStyle = "none" | "mustache" | "goatee" | "beard" | "full";
export type GlassesStyle = "none" | "degree" | "sun";
export type WorkGear = "none" | "helmetY" | "helmetW" | "cap" | "scarf";
export type AvatarFilter = "todos" | "curto" | "longo" | "barba" | "oculos" | "trabalho";

export interface AvatarSpec {
  id: string;
  skin: string;
  hair: HairStyle;
  hairColor: string;
  beard: BeardStyle;
  glasses: GlassesStyle;
  work: WorkGear;
  shirt: string;
  bgFrom: string;
  bgTo: string;
}

const SKIN = {
  light: "#F3C7A3",
  fair: "#E8B88A",
  medium: "#C68642",
  tan: "#8D5524",
  dark: "#5C3317",
  deep: "#3B2214",
} as const;

const HAIR = {
  black: "#1A1410",
  brown: "#4A2C0A",
  blonde: "#E6C35C",
  red: "#B5522A",
  gray: "#9CA3AF",
  platinum: "#E8E4D9",
} as const;

/** 32 avatares SVG — variedade real de pele, cabelo, barba, óculos e EPI. */
export const AVATARS: AvatarSpec[] = [
  { id: "1", skin: SKIN.light, hair: "short", hairColor: HAIR.black, beard: "none", glasses: "none", work: "none", shirt: "#1D4ED8", bgFrom: "#818CF8", bgTo: "#4F46E5" },
  { id: "2", skin: SKIN.light, hair: "long", hairColor: HAIR.blonde, beard: "none", glasses: "none", work: "none", shirt: "#DB2777", bgFrom: "#F9A8D4", bgTo: "#BE185D" },
  { id: "3", skin: SKIN.fair, hair: "wavy", hairColor: HAIR.brown, beard: "mustache", glasses: "degree", work: "none", shirt: "#0F766E", bgFrom: "#5EEAD4", bgTo: "#0F766E" },
  { id: "4", skin: SKIN.light, hair: "bald", hairColor: HAIR.black, beard: "full", glasses: "none", work: "helmetY", shirt: "#EA580C", bgFrom: "#FDBA74", bgTo: "#C2410C" },
  { id: "5", skin: SKIN.fair, hair: "curly", hairColor: HAIR.red, beard: "none", glasses: "sun", work: "none", shirt: "#7C3AED", bgFrom: "#C4B5FD", bgTo: "#6D28D9" },
  { id: "6", skin: SKIN.fair, hair: "bun", hairColor: HAIR.black, beard: "none", glasses: "none", work: "scarf", shirt: "#BE123C", bgFrom: "#FDA4AF", bgTo: "#9F1239" },
  { id: "7", skin: SKIN.fair, hair: "mohawk", hairColor: HAIR.platinum, beard: "none", glasses: "none", work: "none", shirt: "#65A30D", bgFrom: "#BEF264", bgTo: "#4D7C0F" },
  { id: "8", skin: SKIN.light, hair: "short", hairColor: HAIR.gray, beard: "beard", glasses: "degree", work: "none", shirt: "#1E40AF", bgFrom: "#93C5FD", bgTo: "#1D4ED8" },
  { id: "9", skin: SKIN.medium, hair: "afro", hairColor: HAIR.black, beard: "none", glasses: "none", work: "none", shirt: "#CA8A04", bgFrom: "#FDE047", bgTo: "#A16207" },
  { id: "10", skin: SKIN.medium, hair: "short", hairColor: HAIR.brown, beard: "goatee", glasses: "none", work: "cap", shirt: "#15803D", bgFrom: "#86EFAC", bgTo: "#166534" },
  { id: "11", skin: SKIN.medium, hair: "long", hairColor: HAIR.black, beard: "none", glasses: "none", work: "none", shirt: "#A21CAF", bgFrom: "#F0ABFC", bgTo: "#86198F" },
  { id: "12", skin: SKIN.medium, hair: "buzz", hairColor: HAIR.black, beard: "none", glasses: "none", work: "helmetW", shirt: "#334155", bgFrom: "#CBD5E1", bgTo: "#475569" },
  { id: "13", skin: SKIN.tan, hair: "wavy", hairColor: HAIR.black, beard: "beard", glasses: "sun", work: "none", shirt: "#0891B2", bgFrom: "#67E8F9", bgTo: "#0E7490" },
  { id: "14", skin: SKIN.tan, hair: "short", hairColor: HAIR.black, beard: "mustache", glasses: "none", work: "helmetY", shirt: "#B91C1C", bgFrom: "#FCA5A5", bgTo: "#991B1B" },
  { id: "15", skin: SKIN.tan, hair: "curly", hairColor: HAIR.brown, beard: "none", glasses: "degree", work: "none", shirt: "#4F46E5", bgFrom: "#A5B4FC", bgTo: "#3730A3" },
  { id: "16", skin: SKIN.tan, hair: "bun", hairColor: HAIR.brown, beard: "none", glasses: "none", work: "scarf", shirt: "#C2410C", bgFrom: "#FDBA74", bgTo: "#9A3412" },
  { id: "17", skin: SKIN.dark, hair: "afro", hairColor: HAIR.black, beard: "full", glasses: "none", work: "none", shirt: "#A16207", bgFrom: "#FACC15", bgTo: "#854D0E" },
  { id: "18", skin: SKIN.dark, hair: "short", hairColor: HAIR.black, beard: "beard", glasses: "degree", work: "none", shirt: "#1E3A8A", bgFrom: "#818CF8", bgTo: "#312E81" },
  { id: "19", skin: SKIN.dark, hair: "bald", hairColor: HAIR.black, beard: "none", glasses: "none", work: "helmetW", shirt: "#EA580C", bgFrom: "#FED7AA", bgTo: "#C2410C" },
  { id: "20", skin: SKIN.dark, hair: "long", hairColor: HAIR.black, beard: "none", glasses: "none", work: "none", shirt: "#047857", bgFrom: "#6EE7B7", bgTo: "#065F46" },
  { id: "21", skin: SKIN.deep, hair: "buzz", hairColor: HAIR.black, beard: "goatee", glasses: "sun", work: "none", shirt: "#6D28D9", bgFrom: "#DDD6FE", bgTo: "#5B21B6" },
  { id: "22", skin: SKIN.deep, hair: "afro", hairColor: HAIR.black, beard: "none", glasses: "none", work: "none", shirt: "#0F766E", bgFrom: "#99F6E4", bgTo: "#115E59" },
  { id: "23", skin: SKIN.deep, hair: "short", hairColor: HAIR.gray, beard: "full", glasses: "degree", work: "none", shirt: "#475569", bgFrom: "#CBD5E1", bgTo: "#334155" },
  { id: "24", skin: SKIN.deep, hair: "mohawk", hairColor: HAIR.black, beard: "none", glasses: "none", work: "none", shirt: "#9F1239", bgFrom: "#FB7185", bgTo: "#881337" },
  { id: "25", skin: SKIN.light, hair: "long", hairColor: HAIR.platinum, beard: "none", glasses: "degree", work: "none", shirt: "#7C3AED", bgFrom: "#E9D5FF", bgTo: "#6D28D9" },
  { id: "26", skin: SKIN.medium, hair: "short", hairColor: HAIR.blonde, beard: "mustache", glasses: "none", work: "cap", shirt: "#0369A1", bgFrom: "#7DD3FC", bgTo: "#075985" },
  { id: "27", skin: SKIN.fair, hair: "wavy", hairColor: HAIR.red, beard: "none", glasses: "none", work: "none", shirt: "#059669", bgFrom: "#A7F3D0", bgTo: "#047857" },
  { id: "28", skin: SKIN.medium, hair: "curly", hairColor: HAIR.gray, beard: "beard", glasses: "none", work: "none", shirt: "#9A3412", bgFrom: "#FDBA74", bgTo: "#7C2D12" },
  { id: "29", skin: SKIN.light, hair: "bun", hairColor: HAIR.brown, beard: "none", glasses: "sun", work: "none", shirt: "#FB7185", bgFrom: "#FECDD3", bgTo: "#E11D48" },
  { id: "30", skin: SKIN.dark, hair: "short", hairColor: HAIR.black, beard: "none", glasses: "none", work: "helmetY", shirt: "#F97316", bgFrom: "#FDE68A", bgTo: "#B45309" },
  { id: "31", skin: SKIN.tan, hair: "long", hairColor: HAIR.black, beard: "none", glasses: "none", work: "scarf", shirt: "#881337", bgFrom: "#FDA4AF", bgTo: "#9F1239" },
  { id: "32", skin: SKIN.light, hair: "short", hairColor: HAIR.black, beard: "goatee", glasses: "none", work: "cap", shirt: "#1D4ED8", bgFrom: "#93C5FD", bgTo: "#1E3A8A" },
];

const SHORT: HairStyle[] = ["bald", "buzz", "short", "wavy", "curly", "mohawk"];
const LONG: HairStyle[] = ["long", "bun", "afro"];

export const AVATAR_FILTERS: Array<{ id: AvatarFilter; label: string }> = [
  { id: "todos", label: "Todos" },
  { id: "curto", label: "Cabelo curto" },
  { id: "longo", label: "Cabelo longo" },
  { id: "barba", label: "Com barba" },
  { id: "oculos", label: "Óculos" },
  { id: "trabalho", label: "Trabalho" },
];

export function filterAvatars(list: AvatarSpec[], filter: AvatarFilter) {
  if (filter === "todos") return list;
  if (filter === "curto") return list.filter((a) => SHORT.includes(a.hair));
  if (filter === "longo") return list.filter((a) => LONG.includes(a.hair));
  if (filter === "barba") return list.filter((a) => a.beard !== "none");
  if (filter === "oculos") return list.filter((a) => a.glasses !== "none");
  return list.filter((a) => a.work !== "none");
}

export function getAvatar(id?: string) {
  if (!id) return undefined;
  return AVATARS.find((a) => a.id === id);
}

export function randomAvatarId(except?: string) {
  const pool = except ? AVATARS.filter((a) => a.id !== except) : AVATARS;
  return pool[Math.floor(Math.random() * pool.length)]?.id ?? "1";
}
