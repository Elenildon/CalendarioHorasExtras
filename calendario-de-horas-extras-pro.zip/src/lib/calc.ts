export const APP_VERSION = "1.0.0";

// ---------- Tipos ----------
export type DotColor =
  | "sky"
  | "emerald"
  | "violet"
  | "indigo"
  | "amber"
  | "rose"
  | "blue";

export interface DayEntry {
  hours: number;
  minutes: number; // 0-100 (conforme o app)
  noturno: boolean;
  note: string;
  dot: DotColor;
  pct?: number;
  savedAt?: number;
}

export interface Settings {
  name: string;
  cargo: string;
  empresa: string;
  salary: number;
  jornada: number;
  noturnoPct: number;
  noturnoEnabled: boolean;
  periculosidadePct: number;
  periculosidadeEnabled: boolean;
  insalubridadePct: number;
  insalubridadeEnabled: boolean;
  dsrEnabled: boolean;
  feriadoEnabled: boolean;
  feriadoPct: number;
  periodDays: number;
  periodMonths?: number;
  periodMode: "dias" | "meses";
  otherDiscounts: number;
  /** Modo de cálculo de outros descontos: "%" (percentual s/ remuneração bruta) ou "currency" (R$) */
  otherDiscountsMode?: "%" | "currency";
  city: string;
  state: string;
  /** id do avatar escolhido (1–32) ou vazio para as iniciais */
  avatarId: string;
  /** foto pessoal do usuário carregada da galeria (base64 dataURL) */
  photoURL?: string;
  /** "avancado" mostra todas as abas; "desativado" só as essenciais */
  modo: "avancado" | "desativado";
  /** a tela inicial só aparece na primeira abertura */
  onboardFeito: boolean;
  /** botão do cabeçalho à esquerda do avatar */
  modoInteligente: boolean;
}

export type BandKey = "weekday" | "saturday" | "sunday" | "holiday";

export interface SimBand {
  hours: string;
  minutes: string;
  noturno: boolean;
  pct: number;
}

export type SimKey = "weekday" | "saturday" | "sunday";
export type SimState = Record<SimKey, SimBand>;

// ---------- Feriados ----------
export type HolidayKind = "nacional" | "estadual" | "municipal" | "facultativo";

export interface Holiday {
  kind: HolidayKind;
  name: string;
}

export const KIND_META: Record<
  HolidayKind,
  { label: string; short: string; text: string; dot: string; chip: string; cell: string; border: string; soft: string }
> = {
  nacional: {
    label: "FERIADO NACIONAL",
    short: "Nacional",
    text: "text-rose-400",
    dot: "bg-rose-400",
    chip: "border-rose-400/40 bg-rose-500/10 text-rose-300",
    cell: "border-rose-400/35 bg-rose-500/[0.10]",
    border: "border-rose-400",
    soft: "text-rose-300",
  },
  estadual: {
    label: "FERIADO ESTADUAL · MG",
    short: "Minas Gerais",
    text: "text-sky-400",
    dot: "bg-sky-400",
    chip: "border-sky-400/40 bg-sky-500/10 text-sky-300",
    cell: "border-sky-400/35 bg-sky-500/[0.10]",
    border: "border-sky-400",
    soft: "text-sky-300",
  },
  municipal: {
    label: "FERIADO MUNICIPAL · EXTREMA",
    short: "Extrema",
    text: "text-amber-400",
    dot: "bg-amber-400",
    chip: "border-amber-400/40 bg-amber-500/10 text-amber-300",
    cell: "border-amber-400/35 bg-amber-500/[0.10]",
    border: "border-amber-400",
    soft: "text-amber-300",
  },
  facultativo: {
    label: "PONTO FACULTATIVO",
    short: "Facultativo",
    text: "text-violet-400",
    dot: "bg-violet-400",
    chip: "border-violet-400/40 bg-violet-500/10 text-violet-300",
    cell: "border-violet-400/30 bg-violet-500/[0.08]",
    border: "border-violet-400",
    soft: "text-violet-300",
  },
};

export const HOLIDAYS_ENABLED: HolidayKind[] = ["nacional", "estadual", "municipal"];

/** Algoritmo de Meeus/Jones/Butcher — Páscoa de qualquer ano. */
function easter(y: number) {
  const a = y % 19;
  const b = Math.floor(y / 100);
  const c = y % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return { m: month - 1, d: day };
}

/** Local de utilização do aplicativo (UF + município). */
export interface AppLoc {
  state: string;
  city: string;
}

const DEFAULT_LOC: AppLoc = { state: "MG", city: "Extrema" };

const normLoc = (s: string) =>
  (s ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();

/**
 * Feriados estaduais por UF (m = mês 0-11). Fontes: calendários oficiais dos
 * estados. O 20/11 não é repetido aqui porque já é feriado nacional.
 */
export const STATE_HOLIDAYS: Record<string, Array<{ m: number; d: number; name: string }>> = {
  AC: [
    { m: 0, d: 23, name: "Dia do Evangélico (AC)" },
    { m: 5, d: 15, name: "Aniversário do Estado do Acre" },
    { m: 8, d: 5, name: "Dia da Amazônia (AC)" },
    { m: 10, d: 17, name: "Tratado de Petrópolis (AC)" },
  ],
  AL: [
    { m: 5, d: 24, name: "São João (AL)" },
    { m: 5, d: 29, name: "São Pedro (AL)" },
    { m: 8, d: 16, name: "Emancipação Política de Alagoas" },
  ],
  AP: [
    { m: 2, d: 19, name: "Dia de São José (AP)" },
    { m: 6, d: 25, name: "Dia de São Tiago (AP)" },
    { m: 9, d: 5, name: "Criação do Estado do Amapá" },
  ],
  AM: [
    { m: 8, d: 5, name: "Elevação do Amazonas à Província" },
    { m: 11, d: 8, name: "Nossa Senhora da Conceição (AM)" },
  ],
  BA: [{ m: 6, d: 2, name: "Independência da Bahia" }],
  CE: [
    { m: 2, d: 19, name: "Dia de São José (CE)" },
    { m: 2, d: 25, name: "Data Magna do Ceará (Abolição)" },
  ],
  DF: [
    { m: 3, d: 21, name: "Fundação de Brasília (DF)" },
    { m: 10, d: 30, name: "Dia do Evangélico (DF)" },
  ],
  ES: [{ m: 8, d: 8, name: "Nossa Senhora da Vitória (ES)" }],
  GO: [
    { m: 6, d: 26, name: "Fundação de Goiânia (GO)" },
    { m: 9, d: 24, name: "Pedra Fundamental de Goiânia (GO)" },
  ],
  MA: [
    { m: 6, d: 28, name: "Adesão do Maranhão à Independência" },
    { m: 11, d: 8, name: "Nossa Senhora da Conceição (MA)" },
  ],
  MT: [],
  MS: [{ m: 9, d: 11, name: "Criação do Estado de Mato Grosso do Sul" }],
  MG: [{ m: 3, d: 21, name: "Data Magna do Estado de Minas Gerais" }],
  PA: [
    { m: 7, d: 15, name: "Adesão do Grão-Pará à Independência" },
    { m: 11, d: 8, name: "Nossa Senhora da Conceição (PA)" },
  ],
  PB: [{ m: 7, d: 5, name: "Fundação da Paraíba" }],
  PR: [{ m: 11, d: 19, name: "Emancipação Política do Paraná" }],
  PE: [
    { m: 2, d: 6, name: "Revolução Pernambucana de 1817 (Data Magna)" },
    { m: 5, d: 24, name: "São João (PE)" },
  ],
  PI: [
    { m: 2, d: 13, name: "Dia da Batalha do Jenipapo (PI)" },
    { m: 9, d: 19, name: "Dia do Piauí" },
  ],
  RJ: [{ m: 3, d: 23, name: "Dia de São Jorge (RJ)" }],
  RN: [{ m: 9, d: 3, name: "Mártires de Cunhaú e Uruaçu (RN)" }],
  RS: [{ m: 8, d: 20, name: "Revolução Farroupilha (RS)" }],
  RO: [
    { m: 0, d: 4, name: "Criação do Estado de Rondônia" },
    { m: 5, d: 18, name: "Dia do Evangélico (RO)" },
  ],
  RR: [{ m: 9, d: 5, name: "Criação do Estado de Roraima" }],
  SC: [
    { m: 7, d: 11, name: "Criação da Capitania de Santa Catarina" },
    { m: 10, d: 25, name: "Santa Catarina de Alexandria (SC)" },
  ],
  SP: [{ m: 6, d: 9, name: "Revolução Constitucionalista de 1932 (SP)" }],
  SE: [{ m: 6, d: 8, name: "Emancipação Política de Sergipe" }],
  TO: [
    { m: 8, d: 8, name: "Nossa Senhora da Natividade (TO)" },
    { m: 9, d: 5, name: "Criação do Estado do Tocantins" },
  ],
};

/** Feriados municipais conhecidos (base inicial: Extrema/MG). */
function municipalsFor(loc: AppLoc): Array<{ m: number; d: number; name: string }> {
  if (loc.state.toUpperCase() === "MG" && normLoc(loc.city) === "extrema") {
    return [
      { m: 4, d: 22, name: "Dia de Santa Rita · Aniversário de Extrema" },
      { m: 8, d: 16, name: "Aniversário de Extrema (emancipação)" },
    ];
  }
  return [];
}

const cache: Record<string, Record<string, Holiday[]>> = {};

/** Mapa completo de feriados do ano para o local selecionado. */
export function holidaysForYear(y: number, loc?: AppLoc): Record<string, Holiday[]> {
  const place: AppLoc = {
    state: (loc?.state || DEFAULT_LOC.state).toUpperCase(),
    city: loc?.city || DEFAULT_LOC.city,
  };
  const cacheKey = `${y}|${place.state}|${normLoc(place.city)}`;
  if (cache[cacheKey]) return cache[cacheKey];
  const map: Record<string, Holiday[]> = {};
  const push = (m: number, d: number, h: Holiday) => {
    const k = dateKey(y, m, d);
    (map[k] ||= []).push(h);
  };
  const shift = (base: { m: number; d: number }, days: number) => {
    const dt = new Date(y, base.m, base.d + days);
    return { m: dt.getMonth(), d: dt.getDate() };
  };

  // Nacionais fixos
  push(0, 1, { kind: "nacional", name: "Confraternização Universal" });
  push(3, 21, { kind: "nacional", name: "Tiradentes" });
  push(4, 1, { kind: "nacional", name: "Dia do Trabalho" });
  push(8, 7, { kind: "nacional", name: "Independência do Brasil" });
  push(9, 12, { kind: "nacional", name: "Nossa Senhora Aparecida" });
  push(10, 2, { kind: "nacional", name: "Finados" });
  push(10, 15, { kind: "nacional", name: "Proclamação da República" });
  push(10, 20, { kind: "nacional", name: "Dia da Consciência Negra" });
  push(11, 25, { kind: "nacional", name: "Natal" });

  // Móveis (Carnaval, Semana Santa, Corpus Christi)
  const pascoa = easter(y);
  push(shift(pascoa, -48).m, shift(pascoa, -48).d, {
    kind: "facultativo",
    name: "Carnaval (segunda)",
  });
  push(shift(pascoa, -47).m, shift(pascoa, -47).d, {
    kind: "facultativo",
    name: "Carnaval (terça)",
  });
  push(shift(pascoa, -46).m, shift(pascoa, -46).d, {
    kind: "facultativo",
    name: "Quarta-feira de Cinzas (até 14h)",
  });
  push(shift(pascoa, -3).m, shift(pascoa, -3).d, {
    kind: "facultativo",
    name: "Quinta-feira Santa",
  });
  push(shift(pascoa, -2).m, shift(pascoa, -2).d, {
    kind: "nacional",
    name: "Paixão de Cristo (Sexta-feira Santa)",
  });
  push(shift(pascoa, 60).m, shift(pascoa, 60).d, {
    kind: "facultativo",
    name: "Corpus Christi",
  });

  // Estaduais — conforme a UF selecionada
  for (const h of STATE_HOLIDAYS[place.state] ?? []) {
    push(h.m, h.d, { kind: "estadual", name: h.name });
  }

  // Municipais — conforme a cidade selecionada
  for (const h of municipalsFor(place)) {
    push(h.m, h.d, { kind: "municipal", name: h.name });
  }

  // Pontos facultativos (federal/estadual)
  push(3, 20, { kind: "facultativo", name: "Véspera de Tiradentes" });
  push(9, 28, { kind: "facultativo", name: "Dia do Servidor Público" });
  push(11, 24, { kind: "facultativo", name: "Véspera de Natal" });
  push(11, 31, { kind: "facultativo", name: "Véspera de Ano Novo" });

  cache[cacheKey] = map;
  return map;
}

export function holidaysOn(key: string, loc?: AppLoc): Holiday[] {
  const [y] = key.split("-").map(Number);
  return holidaysForYear(y, loc)[key] ?? [];
}

/** Feriado "cheio" (nacional/estadual/municipal) da data, se houver. */
export function workingHoliday(key: string, loc?: AppLoc): Holiday | undefined {
  return holidaysOn(key, loc).find((h) => HOLIDAYS_ENABLED.includes(h.kind));
}

export const DOT_BY_KIND: Record<HolidayKind, DotColor> = {
  nacional: "rose",
  estadual: "sky",
  municipal: "amber",
  facultativo: "violet",
};

export function upcomingHolidays(from: Date, count: number, loc?: AppLoc) {
  const out: Array<{ key: string; date: Date; holiday: Holiday }> = [];
  const cursor = new Date(from.getFullYear(), from.getMonth(), from.getDate());
  for (let i = 0; i < 400 && out.length < count; i++) {
    const dt = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + i);
    const k = dateKey(dt.getFullYear(), dt.getMonth(), dt.getDate());
    for (const h of holidaysOn(k, loc)) {
      if (h.kind === "facultativo") continue;
      out.push({ key: k, date: dt, holiday: h });
    }
  }
  return out.slice(0, count);
}

// ---------- Nomes e datas ----------
export const MESES = [
  "Janeiro",
  "Fevereiro",
  "Março",
  "Abril",
  "Maio",
  "Junho",
  "Julho",
  "Agosto",
  "Setembro",
  "Outubro",
  "Novembro",
  "Dezembro",
];

export const SEMANA_CURTA = ["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB"];
export const SEMANA_LONGA = [
  "Domingo",
  "Segunda",
  "Terça",
  "Quarta",
  "Quinta",
  "Sexta",
  "Sábado",
];

export const dateKey = (y: number, m: number, d: number) =>
  `${y}-${String(m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;

export const daysInMonth = (y: number, m: number) =>
  new Date(y, m + 1, 0).getDate();

export const pctForDow = (dow: number) =>
  dow === 0 ? 100 : dow === 6 ? 75 : 60;

export const bandForDow = (dow: number): SimKey =>
  dow === 0 ? "sunday" : dow === 6 ? "saturday" : "weekday";

export const bandColor = (b: SimKey): DotColor =>
  b === "weekday" ? "indigo" : b === "saturday" ? "amber" : "rose";

/** Percentual automático do dia considerando feriados e dias da semana integrados ao calendário. */
export function dayPercent(
  key: string,
  dow: number,
  s: Pick<Settings, "feriadoPct" | "feriadoEnabled"> & Partial<Pick<Settings, "state" | "city">>
) {
  const loc: AppLoc | undefined =
    s.state && s.city ? { state: s.state, city: s.city } : undefined;
  const hol = workingHoliday(key, loc);
  if (hol && s.feriadoEnabled) return { pct: s.feriadoPct ?? 100, holiday: hol };
  return { pct: pctForDow(dow), holiday: undefined as Holiday | undefined };
}

// ---------- Formatação ----------
export const fmtBRL = (v: number, withSign = false) => {
  const abs = Math.abs(v).toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
  if (withSign && v < 0) return `- ${abs}`;
  return abs;
};

export const fmtH = (h: number) =>
  `${h.toLocaleString("pt-BR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })} h`;

export const entryHours = (e: DayEntry) =>
  (Number(e.hours) || 0) + (Number(e.minutes) || 0) / 60;

export const horaBase = (salary: number, jornada: number) =>
  jornada > 0 ? salary / jornada : 0;

// ---------- INSS 2026 (progressivo, teto R$ 8.475,55) ----------
export const INSS_BRACKETS: Array<[number, number]> = [
  [1621.0, 0.075],
  [2902.84, 0.09],
  [4354.27, 0.12],
  [8475.55, 0.14],
];

export function calcINSS(gross: number): number {
  let prev = 0;
  let tax = 0;
  for (const [limit, rate] of INSS_BRACKETS) {
    if (gross > prev) {
      tax += (Math.min(gross, limit) - prev) * rate;
      prev = limit;
    }
  }
  return tax;
}

// ---------- IRRF 2026 (isenção para rendimentos até R$ 5.000,00) ----------
const IRRF_BRACKETS: Array<[number, number, number]> = [
  [2259.2, 0, 0],
  [2826.65, 0.075, 169.44],
  [3751.05, 0.15, 381.44],
  [4664.68, 0.225, 662.77],
  [Infinity, 0.275, 896.0],
];

export function calcIRRF(gross: number, inss: number): number {
  const base = gross - inss;
  if (base <= 5000) return 0;
  const x = Math.max(0, base - 564.8);
  for (const [limit, rate, ded] of IRRF_BRACKETS) {
    if (x <= limit) return Math.max(0, x * rate - ded);
  }
  return 0;
}

export const SALARIO_MINIMO_2026 = 1621.0;

// ---------- Resumo do mês ----------
export interface MonthStats {
  lancamentos: number;
  totalHours: number;
  hoursByBand: Record<BandKey, number>;
  valueByBand: Record<BandKey, number>;
  totalHE: number;
  domingos: number;
  feriados: number;
  facultativos: number;
  uteis: number;
  dsr: number;
  periculosidade: number;
  insalubridade: number;
  bruta: number;
  inss: number;
  irrf: number;
  otherDiscountsVal: number;
  liquido: number;
  valorHora: number;
}

export const simHours = (b: SimBand) =>
  (Number(b.hours) || 0) + (Number(b.minutes) || 0) / 60;

/** Calcula o valor em R$ de uma faixa de horas extras do simulador */
export function calcSimBandValue(
  band: SimBand,
  valorHora: number,
  noturnoPct = 20,
  noturnoEnabled = true
): number {
  const h = simHours(band);
  if (h <= 0) return 0;
  let r = valorHora * (1 + (band.pct || 0) / 100);
  if (band.noturno && noturnoEnabled) {
    r *= 1 + (noturnoPct || 20) / 100;
  }
  return h * r;
}

export interface MonthStructure {
  totalDays: number;
  domingos: number;
  feriados: number;
  facultativos: number;
  uteis: number;
  descansos: number;
}

/**
 * Estrutura imutável do mês: contagens de domingos, feriados, pontos facultativos e dias úteis.
 * Depende unicamente do ano, mês e localidade — NUNCA do conteúdo das anotações do calendário.
 */
export function monthStructure(y: number, m: number, s: Settings): MonthStructure {
  const total = daysInMonth(y, m);
  let domingos = 0;
  let feriados = 0;
  let facultativos = 0;
  const loc: AppLoc = { state: s.state, city: s.city };

  for (let d = 1; d <= total; d++) {
    const k = dateKey(y, m, d);
    const dt = new Date(y, m, d);
    const dow = dt.getDay();
    if (dow === 0) domingos++;
    const hols = holidaysOn(k, loc);
    // Domingo já é repouso: não o conta também como feriado (evita
    // subtrair o mesmo dia duas vezes do total de dias úteis do DSR).
    const hasWorking = dow !== 0 && hols.some((h) => HOLIDAYS_ENABLED.includes(h.kind));
    if (hasWorking) feriados++;
    else if (dow !== 0 && hols.length) facultativos++;
  }

  const uteis = total - domingos - feriados;
  const descansos = domingos + feriados;

  return {
    totalDays: total,
    domingos,
    feriados,
    facultativos,
    uteis,
    descansos,
  };
}

/**
 * MOTOR DO RESUMO DO MÊS (computeSummary)
 *
 * Totalmente isolado do Calendário: lê SOMENTE o simulador de faixas (sim)
 * preenchido explicitamente no Painel e as configurações do usuário.
 * Não recebe nem processa 'entries' (anotações/lançamentos do calendário).
 */
export function computeSummary(
  y: number,
  m: number,
  s: Settings,
  sim: SimState
): MonthStats {
  const vHora = horaBase(s.salary, s.jornada);

  const empty = (): Record<BandKey, number> => ({
    weekday: 0,
    saturday: 0,
    sunday: 0,
    holiday: 0,
  });
  const hoursByBand = empty();
  const valueByBand = empty();
  let lancamentos = 0;

  // Lê somente as faixas do simulador preenchidas explicitamente no painel
  (Object.keys(sim) as SimKey[]).forEach((band) => {
    const sb = sim[band];
    const h = simHours(sb);
    if (h > 0) {
      lancamentos++;
      hoursByBand[band] += h;
      valueByBand[band] += calcSimBandValue(sb, vHora, s.noturnoPct, s.noturnoEnabled);
    }
  });

  const totalHours =
    hoursByBand.weekday +
    hoursByBand.saturday +
    hoursByBand.sunday +
    hoursByBand.holiday;
  const totalHE =
    valueByBand.weekday +
    valueByBand.saturday +
    valueByBand.sunday +
    valueByBand.holiday;

  // Estrutura imutável do mês (independente de anotações)
  const struct = monthStructure(y, m, s);
  const dsr = s.dsrEnabled && struct.uteis > 0 ? (totalHE / struct.uteis) * struct.descansos : 0;
  const pericPct = typeof s.periculosidadePct === "number" ? s.periculosidadePct : 30;
  const insalubPct = typeof s.insalubridadePct === "number" ? s.insalubridadePct : 30;
  const periculosidade = s.periculosidadeEnabled ? s.salary * (pericPct / 100) : 0;
  const insalubridade = s.insalubridadeEnabled ? SALARIO_MINIMO_2026 * (insalubPct / 100) : 0;

  const bruta = s.salary + totalHE + dsr + periculosidade + insalubridade;
  const inss = calcINSS(bruta);
  const irrf = calcIRRF(bruta, inss);
  const discountInput = s.otherDiscounts || 0;
  const isPercent = s.otherDiscountsMode !== "currency"; // padrão %
  const otherDiscountsVal = isPercent
    ? (bruta * Math.min(100, Math.max(0, discountInput))) / 100
    : discountInput;
  const liquido = Math.max(0, bruta - inss - irrf - otherDiscountsVal);

  return {
    lancamentos,
    totalHours,
    hoursByBand,
    valueByBand,
    totalHE,
    domingos: struct.domingos,
    feriados: struct.feriados,
    facultativos: struct.facultativos,
    uteis: struct.uteis,
    dsr,
    periculosidade,
    insalubridade,
    bruta,
    inss,
    irrf,
    otherDiscountsVal,
    liquido,
    valorHora: vHora,
  };
}

export function computeMonth(
  entries: Record<string, DayEntry>,
  y: number,
  m: number,
  s: Settings,
  sim?: SimState
): MonthStats {
  const struct = monthStructure(y, m, s);
  const vHora = horaBase(s.salary, s.jornada);

  const empty = (): Record<BandKey, number> => ({
    weekday: 0,
    saturday: 0,
    sunday: 0,
    holiday: 0,
  });
  const hoursByBand = empty();
  const valueByBand = empty();
  let lancamentos = 0;

  const rate = (pct: number, noturno: boolean) => {
    let r = vHora * (1 + pct / 100);
    if (noturno && s.noturnoEnabled) {
      r *= 1 + (s.noturnoPct || 20) / 100;
    }
    return r;
  };

  for (let d = 1; d <= struct.totalDays; d++) {
    const k = dateKey(y, m, d);
    const dt = new Date(y, m, d);
    const dow = dt.getDay();

    const e = entries[k];
    if (!e) continue;
    const h = entryHours(e);
    if (h <= 0) continue;
    lancamentos++;
    const auto = dayPercent(k, dow, s);
    const band: BandKey = auto.holiday ? "holiday" : bandForDow(dow);
    hoursByBand[band] += h;
    valueByBand[band] += h * rate(auto.pct, e.noturno);
  }

  if (sim) {
    (Object.keys(sim) as SimKey[]).forEach((band) => {
      const sb = sim[band];
      const h = simHours(sb);
      if (h > 0) {
        hoursByBand[band] += h;
        valueByBand[band] += calcSimBandValue(sb, vHora, s.noturnoPct, s.noturnoEnabled);
      }
    });
  }

  const totalHours =
    hoursByBand.weekday +
    hoursByBand.saturday +
    hoursByBand.sunday +
    hoursByBand.holiday;
  const totalHE =
    valueByBand.weekday +
    valueByBand.saturday +
    valueByBand.sunday +
    valueByBand.holiday;

  const dsr = s.dsrEnabled && struct.uteis > 0 ? (totalHE / struct.uteis) * struct.descansos : 0;
  const pericPct = typeof s.periculosidadePct === "number" ? s.periculosidadePct : 30;
  const insalubPct = typeof s.insalubridadePct === "number" ? s.insalubridadePct : 30;
  const periculosidade = s.periculosidadeEnabled ? s.salary * (pericPct / 100) : 0;
  const insalubridade = s.insalubridadeEnabled ? SALARIO_MINIMO_2026 * (insalubPct / 100) : 0;
  const bruta = s.salary + totalHE + dsr + periculosidade + insalubridade;
  const inss = calcINSS(bruta);
  const irrf = calcIRRF(bruta, inss);
  const discountInput = s.otherDiscounts || 0;
  const isPercent = s.otherDiscountsMode !== "currency"; // padrão %
  const otherDiscountsVal = isPercent
    ? (bruta * Math.min(100, Math.max(0, discountInput))) / 100
    : discountInput;
  const liquido = Math.max(0, bruta - inss - irrf - otherDiscountsVal);

  return {
    lancamentos,
    totalHours,
    hoursByBand,
    valueByBand,
    totalHE,
    domingos: struct.domingos,
    feriados: struct.feriados,
    facultativos: struct.facultativos,
    uteis: struct.uteis,
    dsr,
    periculosidade,
    insalubridade,
    bruta,
    inss,
    irrf,
    otherDiscountsVal,
    liquido,
    valorHora: vHora,
  };
}

// ---------- Padrões ----------
export const CNS_FULL_NAME = "CNS Central de Núcleos Siliciosos";

export const DEFAULT_SETTINGS: Settings = {
  name: "Elenildon Estevão",
  cargo: "Montador B",
  empresa: "CNS Central de Núcleos Siliciosos",
  salary: 3500,
  jornada: 220,
  noturnoPct: 20,
  noturnoEnabled: false,
  periculosidadePct: 30,
  periculosidadeEnabled: false,
  insalubridadePct: 30,
  insalubridadeEnabled: false,
  dsrEnabled: true,
  feriadoEnabled: true,
  feriadoPct: 100,
  periodDays: 30,
  periodMonths: 1,
  periodMode: "dias",
  otherDiscounts: 0,
  otherDiscountsMode: "%",
  city: "Extrema",
  state: "MG",
  avatarId: "",
  photoURL: "",
  modo: "desativado",
  onboardFeito: false,
  modoInteligente: false,
};

export const DEFAULT_SIM: SimState = {
  weekday: { hours: "", minutes: "", noturno: false, pct: 60 },
  saturday: { hours: "", minutes: "", noturno: false, pct: 75 },
  sunday: { hours: "", minutes: "", noturno: false, pct: 100 },
};

/**
 * Apenas referência para limpar os lançamentos demonstrativos de versões
 * anteriores. Nunca é usado como conteúdo inicial do calendário.
 */
export const LEGACY_SAMPLE_ENTRIES: Record<string, DayEntry> = {
  "2026-09-03": { hours: 2, minutes: 30, noturno: false, note: "", dot: "sky" },
  "2026-09-06": { hours: 1, minutes: 30, noturno: false, note: "", dot: "sky" },
  "2026-09-09": { hours: 4, minutes: 0, noturno: false, note: "", dot: "emerald" },
  "2026-09-10": { hours: 3, minutes: 0, noturno: false, note: "", dot: "violet" },
  "2026-09-13": { hours: 2, minutes: 0, noturno: false, note: "", dot: "blue" },
  "2026-09-16": {
    hours: 3,
    minutes: 30,
    noturno: false,
    note: "Feriado municipal — adicional automático",
    dot: "amber",
  },
  "2026-09-20": { hours: 5, minutes: 0, noturno: false, note: "", dot: "amber" },
  "2026-09-23": { hours: 2, minutes: 0, noturno: false, note: "", dot: "sky" },
};

export const DOT_CLASS: Record<DotColor, string> = {
  sky: "bg-sky-500",
  emerald: "bg-emerald-500",
  violet: "bg-violet-500",
  indigo: "bg-indigo-400",
  amber: "bg-amber-500",
  rose: "bg-rose-500",
  blue: "bg-blue-500",
};

// ---------- Validação dos dados salvos ----------
const DOT_COLORS: DotColor[] = [
  "sky",
  "emerald",
  "violet",
  "indigo",
  "amber",
  "rose",
  "blue",
];

const intIn = (value: unknown, min: number, max: number, fallback = 0) => {
  const n = Math.trunc(Number(value));
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

const numIn = (value: unknown, min: number, max: number, fallback: number) => {
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, n));
};

/** Normaliza uma anotação vinda do armazenamento (nunca devolve campo inválido). */
export function sanitizeEntry(raw: unknown): DayEntry | null {
  if (!raw || typeof raw !== "object") return null;
  const e = raw as Partial<DayEntry>;
  const hours = intIn(e.hours, 0, 999, 0);
  const minutes = intIn(e.minutes, 0, 59, 0);
  const note = typeof e.note === "string" ? e.note : "";
  if (hours === 0 && minutes === 0 && note.trim() === "") return null;
  return {
    hours,
    minutes,
    noturno: Boolean(e.noturno),
    note,
    dot: DOT_COLORS.includes(e.dot as DotColor) ? (e.dot as DotColor) : "sky",
    savedAt:
      typeof e.savedAt === "number" && Number.isFinite(e.savedAt)
        ? e.savedAt
        : undefined,
  };
}

/** Mantém apenas chaves de data válidas e anotações íntegras. */
export function sanitizeEntries(raw: unknown): Record<string, DayEntry> {
  const out: Record<string, DayEntry> = {};
  if (!raw || typeof raw !== "object") return out;
  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) continue;
    const entry = sanitizeEntry(value);
    if (entry) out[key] = entry;
  }
  return out;
}

/** Impede NaN/valores absurdos nas configurações (evita "R$ NaN" nos cálculos). */
export function sanitizeSettings(raw: Settings): Settings {
  const sanitizeName = (val: unknown): string => {
    if (typeof val !== "string") return "";
    return val;
  };

  const sanitizeCargo = (val: unknown): string => {
    if (typeof val !== "string") return "";
    return val;
  };

  const sanitizeEmpresa = (val: unknown): string => {
    if (typeof val !== "string") return "";
    const trimmed = val.trim();
    const lower = trimmed.toLowerCase();
    if (
      lower === "cns" ||
      lower === "cns central de núcleos s" ||
      lower === "cns central de nucleos s" ||
      lower === "cns central de núcleos s." ||
      lower === "cns central de nucleos s."
    ) {
      return CNS_FULL_NAME;
    }
    return val;
  };

  return {
    ...raw,
    name: sanitizeName(raw?.name),
    cargo: sanitizeCargo(raw?.cargo),
    empresa: sanitizeEmpresa(raw?.empresa),
    salary: numIn(raw?.salary, 0, 1000000, DEFAULT_SETTINGS.salary),
    jornada: numIn(raw?.jornada, 1, 744, DEFAULT_SETTINGS.jornada),
    noturnoPct: numIn(raw?.noturnoPct, 0, 100, DEFAULT_SETTINGS.noturnoPct),
    feriadoPct: numIn(raw?.feriadoPct, 0, 500, DEFAULT_SETTINGS.feriadoPct),
    periodDays: intIn(raw?.periodDays, 1, 3650, DEFAULT_SETTINGS.periodDays),
    periodMonths: intIn(raw?.periodMonths, 1, 120, DEFAULT_SETTINGS.periodMonths ?? 1),
    periodMode: raw?.periodMode === "meses" ? "meses" : "dias",
    otherDiscounts: numIn(raw?.otherDiscounts, 0, 1000000, 0),
    otherDiscountsMode: raw?.otherDiscountsMode === "currency" ? "currency" : "%",
    noturnoEnabled: Boolean(raw?.noturnoEnabled),
    periculosidadePct: numIn(raw?.periculosidadePct, 0, 500, DEFAULT_SETTINGS.periculosidadePct ?? 30),
    periculosidadeEnabled: Boolean(raw?.periculosidadeEnabled),
    insalubridadePct: numIn(raw?.insalubridadePct, 0, 500, DEFAULT_SETTINGS.insalubridadePct ?? 30),
    insalubridadeEnabled: Boolean(raw?.insalubridadeEnabled),
    dsrEnabled: Boolean(raw?.dsrEnabled),
    feriadoEnabled: Boolean(raw?.feriadoEnabled),
    city:
      typeof raw?.city === "string" && raw.city.trim()
        ? raw.city
        : DEFAULT_SETTINGS.city,
    state:
      typeof raw?.state === "string" && /^[A-Za-z]{2}$/.test(raw.state)
        ? raw.state.toUpperCase()
        : DEFAULT_SETTINGS.state,
    avatarId: (() => {
      const id = typeof raw?.avatarId === "string" ? raw.avatarId.trim() : "";
      if (!/^\d{1,2}$/.test(id)) return "";
      const n = Number(id);
      return n >= 1 && n <= 32 ? String(n) : "";
    })(),
    photoURL: typeof raw?.photoURL === "string" ? raw.photoURL : "",
    modo: raw?.modo === "desativado" || raw?.modo === "avancado" ? raw.modo : "desativado",
    onboardFeito: Boolean(raw?.onboardFeito),
    modoInteligente: Boolean(raw?.modoInteligente),
  };
}

/** Simulador: garante campos válidos em todas as faixas. */
export function sanitizeSim(raw: SimState): SimState {
  const band = (b: SimBand | undefined, fallback: SimBand): SimBand => {
    const digits = (value: unknown) =>
      typeof value === "string" ? value.replace(/\D/g, "") : "";
    const mins = digits(b?.minutes);
    const validPct =
      typeof b?.pct === "number" && Number.isFinite(b.pct) && b.pct >= 10
        ? numIn(b.pct, 10, 500, fallback.pct)
        : fallback.pct;
    return {
      hours: digits(b?.hours).slice(0, 3),
      minutes: mins ? String(Math.min(100, Number(mins))) : "",
      noturno: Boolean(b?.noturno),
      pct: validPct,
    };
  };
  return {
    weekday: band(raw?.weekday, DEFAULT_SIM.weekday),
    saturday: band(raw?.saturday, DEFAULT_SIM.saturday),
    sunday: band(raw?.sunday, DEFAULT_SIM.sunday),
  };
}
