/**
 * Gerenciador do Despertador de Retorno do Intervalo do Ponto Biométrico.
 * 
 * Totalmente isolado do calendário, horas extras, DSR, INSS e cálculos financeiros.
 * Funciona 100% offline no Android, iOS e navegadores modernos (PWA).
 */

import { Capacitor, registerPlugin } from "@capacitor/core";
import { LocalNotifications } from "@capacitor/local-notifications";

interface NativeAlarmPluginType {
  scheduleAlarm(options: { timestamp: number; title: string; body: string; sound: string }): Promise<{ success: boolean; mode?: string }>;
  cancelAlarm(): Promise<{ success: boolean }>;
  stopAlarmSound(): Promise<{ success: boolean }>;
  fireAlarmNow(options?: { title?: string; body?: string; sound?: string }): Promise<{ success: boolean }>;
  checkAlarmPermission(): Promise<{
    canScheduleExact: boolean;
    ignoresBatteryOptimizations: boolean;
    canDrawOverlays?: boolean;
    notificationsEnabled?: boolean;
    canUseFullScreenIntent?: boolean;
    isAlarmClockSupported: boolean;
  }>;
  requestExactAlarmPermission(): Promise<{ success: boolean }>;
  requestIgnoreBatteryOptimizations(): Promise<{ success: boolean }>;
  requestOverlayPermission(): Promise<{ success: boolean }>;
  requestNotificationPolicyPermission?(): Promise<{ success: boolean }>;
  requestFullScreenIntentPermission?(): Promise<{ success: boolean }>;
}

const NativeAlarm = registerPlugin<NativeAlarmPluginType>("NativeAlarm");

export interface AlarmSoundPreset {
  id: string;
  name: string;
  emoji: string;
  style: string;
  description: string;
  file: string;
}

export const ALARM_SOUND_PRESETS: AlarmSoundPreset[] = [
  {
    id: "pulse_rise",
    name: "Pulse Rise",
    emoji: "⚡",
    style: "moderno / eletrônico",
    description: "Pulso eletrônico progressivo.",
    file: "/assets/audio/alarms/alarm_01_pulse_rise.mp3",
  },
  {
    id: "digital_wake",
    name: "Digital Wake",
    emoji: "💻",
    style: "digital",
    description: "Sequência de bipes digitais rápidos e limpos.",
    file: "/assets/audio/alarms/alarm_02_digital_wake.mp3",
  },
  {
    id: "soft_morning",
    name: "Soft Morning",
    emoji: "🌅",
    style: "suave",
    description: "Melodia curta, agradável e progressiva.",
    file: "/assets/audio/alarms/alarm_03_soft_morning.mp3",
  },
  {
    id: "crystal_bell",
    name: "Crystal Bell",
    emoji: "🔔",
    style: "elegante",
    description: "Toques cristalinos modernos.",
    file: "/assets/audio/alarms/alarm_04_crystal_bell.mp3",
  },
  {
    id: "neon_pulse",
    name: "Neon Pulse",
    emoji: "✨",
    style: "tecnológico",
    description: "Pulsos eletrônicos modernos com grave moderado.",
    file: "/assets/audio/alarms/alarm_05_neon_pulse.mp3",
  },
  {
    id: "focus_alert",
    name: "Focus Alert",
    emoji: "🎯",
    style: "profissional",
    description: "Alerta curto, limpo e objetivo.",
    file: "/assets/audio/alarms/alarm_06_focus_alert.mp3",
  },
  {
    id: "deep_alarm",
    name: "Deep Alarm",
    emoji: "🔊",
    style: "forte",
    description: "Grave moderado combinado com pulsos de alerta.",
    file: "/assets/audio/alarms/alarm_07_deep_alarm.mp3",
  },
  {
    id: "smart_chime",
    name: "Smart Chime",
    emoji: "🎶",
    style: "inteligente",
    description: "Sino eletrônico moderno.",
    file: "/assets/audio/alarms/alarm_08_smart_chime.mp3",
  },
  {
    id: "rapid_wake",
    name: "Rapid Wake",
    emoji: "🚨",
    style: "urgente",
    description: "Sequência rápida para chamar atenção.",
    file: "/assets/audio/alarms/alarm_09_rapid_wake.mp3",
  },
  {
    id: "extreme_wake",
    name: "Extreme Wake",
    emoji: "🔥",
    style: "máximo",
    description: "Alarme forte, progressivo e de alta atenção.",
    file: "/assets/audio/alarms/alarm_10_extreme_wake.mp3",
  },
];

export type AlarmRepeatOption = 1 | 2 | 3 | 5;

export interface IntervalAlarmSettings {
  enabled: boolean;          // Alerta ativado / desativado
  durationMinutes: number;   // Duração padrão do intervalo em minutos (padrão: 60 = 01:00)
  leadTimeMinutes: number;   // Aviso prévio: 0 (no horário), 5, 10 ou 15 minutos antes
  soundEnabled: boolean;     // Tocar som
  soundPresetId: string;     // ID do preset de som (padrão: "pulse_rise")
  repeatCount: AlarmRepeatOption; // Repetições do alarme: 1×, 2×, 3× ou 5× (padrão: 3)
  vibrationEnabled: boolean; // Vibrar dispositivo (Ligada / Desligada)
  volume: number;            // Volume: 0.1 a 1.0 (padrão: 1.0)
}

export interface ActiveIntervalAlarm {
  id: number;
  alarmKey?: string;         // Identificador único anti-duplicidade: break_return_alarm_{date}_{time}
  dateStr: string;           // YYYY-MM-DD
  startTime: string;         // HH:mm
  returnTime: string;        // HH:mm
  alarmTime: string;         // HH:mm (considerando leadTimeMinutes)
  alarmTimestamp: number;    // Timestamp do momento em que o alarme deve soar
  durationMinutes: number;
  leadMinutes: number;
  repeatCount: AlarmRepeatOption;
  soundPresetId: string;
  fired: boolean;
  createdAt: number;
}

const SETTINGS_KEY = "che.interval-alarm.settings.v1";
const ACTIVE_ALARM_KEY = "che.interval-alarm.active.v1";
const ALARM_NOTIFICATION_ID = 1001;
const NOTIFICATION_CHANNEL_ID = "che_interval_return_channel";
const NOTIFICATION_CHANNEL_NAME = "Retornar Intervalo";
const NOTIFICATION_CHANNEL_DESC = "Alertas de retorno às atividades";
export const MAX_ALARM_DURATION_MS = 90000; // Proteção contra reprodução infinita: 90s máx

export const DEFAULT_ALARM_SETTINGS: IntervalAlarmSettings = {
  enabled: true,
  durationMinutes: 60,       // 01:00 (1 hora) padrão
  leadTimeMinutes: 0,        // No horário exato (0 min)
  soundEnabled: true,
  soundPresetId: "pulse_rise", // Padrão: 01 — Pulse Rise
  repeatCount: 3,            // Padrão: 3×
  vibrationEnabled: true,    // Padrão: Ligada
  volume: 1.0,
};

/** Formata minutos para formato HH:mm */
export function minutesToHHmm(totalMins: number): string {
  const normalized = ((totalMins % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

/** Converte string HH:mm para minutos totais */
export function hhMmToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const [hStr, mStr] = timeStr.split(":");
  const h = parseInt(hStr, 10) || 0;
  const m = parseInt(mStr, 10) || 0;
  return h * 60 + m;
}

/** Formata minutos para formato digital HH.MM (ex: 01.30, 02.00) */
export function minutesToHHdotMM(totalMins: number): string {
  const normalized = ((totalMins % 1440) + 1440) % 1440;
  const h = Math.floor(normalized / 60);
  const m = normalized % 60;
  return `${String(h).padStart(2, "0")}.${String(m).padStart(2, "0")}`;
}

/**
 * Converte digitação flexível do usuário para minutos de duração.
 * Aceita formatos como:
 * - "01.30" -> 90 min
 * - "01:30" -> 90 min
 * - "00.20" -> 20 min
 * - "00:50" -> 50 min
 * - "01.10" -> 70 min
 * - "02.00" -> 120 min
 * - "01.00" -> 60 min
 * - "90" -> 90 min
 */
export function parseDurationInput(raw: string): number | null {
  if (!raw) return null;
  const clean = raw.trim().replace(/\s+/g, "");

  // Formato com ponto: "01.30" ou "1.30"
  if (clean.includes(".")) {
    const parts = clean.split(".");
    const h = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    if (!isNaN(h) && !isNaN(m) && m >= 0 && m < 60 && h >= 0 && h < 24) {
      const total = h * 60 + m;
      return total > 0 ? total : null;
    }
  }

  // Formato com dois-pontos: "01:30" ou "1:30"
  if (clean.includes(":")) {
    const parts = clean.split(":");
    const h = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    if (!isNaN(h) && !isNaN(m) && m >= 0 && m < 60 && h >= 0 && h < 24) {
      const total = h * 60 + m;
      return total > 0 ? total : null;
    }
  }

  // Número simples de minutos digitado (ex: "90", "45", "60")
  const num = parseInt(clean, 10);
  if (!isNaN(num) && num > 0 && num <= 720) {
    return num;
  }

  return null;
}

/** Lê configurações salvas do despertador */
export function getAlarmSettings(): IntervalAlarmSettings {
  try {
    if (typeof localStorage === "undefined") return { ...DEFAULT_ALARM_SETTINGS };
    const raw = localStorage.getItem(SETTINGS_KEY);
    const parsed = raw ? JSON.parse(raw) : {};

    // Suporte também às chaves individuais solicitadas na especificação
    const singlePreset = localStorage.getItem("selectedAlarmPreset");
    const singleRepeat = localStorage.getItem("alarmRepeatCount");
    const singleVib = localStorage.getItem("alarmVibrationEnabled");
    const singleVol = localStorage.getItem("alarmVolume");

    const soundPresetId =
      (singlePreset && ALARM_SOUND_PRESETS.some((p) => p.id === singlePreset) && singlePreset) ||
      (typeof parsed.soundPresetId === "string" &&
        ALARM_SOUND_PRESETS.some((p) => p.id === parsed.soundPresetId) &&
        parsed.soundPresetId) ||
      "pulse_rise";

    const rawRepeat = singleRepeat ? parseInt(singleRepeat, 10) : parsed.repeatCount;
    const repeatCount: AlarmRepeatOption =
      rawRepeat === 1 || rawRepeat === 2 || rawRepeat === 3 || rawRepeat === 5 ? rawRepeat : 3;

    const vibrationEnabled =
      singleVib !== null ? singleVib === "true" : parsed.vibrationEnabled !== false;

    const rawVol = singleVol ? parseFloat(singleVol) : parsed.volume;
    const volume = typeof rawVol === "number" && !isNaN(rawVol) && rawVol >= 0 && rawVol <= 1 ? rawVol : 1.0;

    return {
      enabled: parsed.enabled !== false,
      durationMinutes:
        typeof parsed.durationMinutes === "number" && parsed.durationMinutes > 0
          ? parsed.durationMinutes
          : 60,
      leadTimeMinutes:
        typeof parsed.leadTimeMinutes === "number" ? parsed.leadTimeMinutes : 0,
      soundEnabled: parsed.soundEnabled !== false,
      soundPresetId,
      repeatCount,
      vibrationEnabled,
      volume,
    };
  } catch (err) {
    console.error("Erro ao ler configurações do despertador:", err);
    return { ...DEFAULT_ALARM_SETTINGS };
  }
}

/** Salva configurações do despertador */
export function saveAlarmSettings(settings: IntervalAlarmSettings): void {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    // Sincroniza chaves individuais exigidas na especificação
    localStorage.setItem("selectedAlarmPreset", settings.soundPresetId);
    localStorage.setItem("alarmRepeatCount", String(settings.repeatCount));
    localStorage.setItem("alarmVibrationEnabled", String(settings.vibrationEnabled));
    localStorage.setItem("alarmVolume", String(settings.volume));
    dispatchAlarmEvent("alarm-settings-changed", settings);
  } catch (err) {
    console.error("Erro ao salvar configurações do despertador:", err);
  }
}

/** Lê alarme atualmente ativo/pendente */
export function getActiveAlarm(): ActiveIntervalAlarm | null {
  try {
    if (typeof localStorage === "undefined") return null;
    const raw = localStorage.getItem(ACTIVE_ALARM_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || !parsed.alarmTimestamp) return null;
    return parsed as ActiveIntervalAlarm;
  } catch (err) {
    console.error("Erro ao ler alarme ativo:", err);
    return null;
  }
}

/** Salva ou limpa o alarme ativo */
export function saveActiveAlarm(alarm: ActiveIntervalAlarm | null): void {
  try {
    if (typeof localStorage === "undefined") return;
    if (alarm) {
      localStorage.setItem(ACTIVE_ALARM_KEY, JSON.stringify(alarm));
    } else {
      localStorage.removeItem(ACTIVE_ALARM_KEY);
    }
    dispatchAlarmEvent("alarm-state-changed");
  } catch (err) {
    console.error("Erro ao persistir alarme ativo:", err);
  }
}

/** Dispara evento customizado no window para reatividade em tempo real */
function dispatchAlarmEvent(type: string, detail?: any): void {
  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(new CustomEvent(`che:${type}`, { detail }));
    } catch {}
  }
}

/**
 * Calcula horários de retorno e alarme baseado no horário de início e configurações
 */
export function calculateIntervalTimes(
  startTimeStr: string,
  durationMinutes: number = 60,
  leadMinutes: number = 0,
  dateStr?: string
): {
  returnTimeStr: string;
  alarmTimeStr: string;
  alarmTimestamp: number;
} {
  const startMins = hhMmToMinutes(startTimeStr);
  const returnMins = (startMins + durationMinutes) % 1440;
  const alarmMins = ((returnMins - leadMinutes) % 1440 + 1440) % 1440;

  const returnTimeStr = minutesToHHmm(returnMins);
  const alarmTimeStr = minutesToHHmm(alarmMins);

  // Calcula timestamp exato
  const now = new Date();
  let targetYear = now.getFullYear();
  let targetMonth = now.getMonth();
  let targetDay = now.getDate();

  if (dateStr && dateStr.includes("-")) {
    const [y, m, d] = dateStr.split("-").map(Number);
    if (y && m && d) {
      targetYear = y;
      targetMonth = m - 1;
      targetDay = d;
    }
  }

  const [alarmH, alarmM] = alarmTimeStr.split(":").map(Number);
  const targetDate = new Date(targetYear, targetMonth, targetDay, alarmH, alarmM, 0, 0);

  // Se o alarme for no mesmo dia mas o horário virar para o dia seguinte (ex.: intervalo às 23:30)
  if (returnMins < startMins) {
    targetDate.setDate(targetDate.getDate() + 1);
  }

  return {
    returnTimeStr,
    alarmTimeStr,
    alarmTimestamp: targetDate.getTime(),
  };
}

let currentAudioPreview: HTMLAudioElement | null = null;

/** Interrompe qualquer prévia de áudio em execução */
export function stopSoundPreview(): void {
  if (currentAudioPreview) {
    try {
      currentAudioPreview.pause();
      currentAudioPreview.currentTime = 0;
    } catch {}
    currentAudioPreview = null;
  }
}

/** Reproduz a prévia de um preset de som específico */
export function playSoundPreview(presetId: string, onEnded?: () => void): HTMLAudioElement | null {
  stopSoundPreview();
  const preset = ALARM_SOUND_PRESETS.find((p) => p.id === presetId) || ALARM_SOUND_PRESETS[0];

  try {
    const audio = new Audio(preset.file);
    audio.volume = 1.0;
    currentAudioPreview = audio;

    const cleanup = () => {
      if (currentAudioPreview === audio) {
        currentAudioPreview = null;
      }
      if (onEnded) onEnded();
    };

    audio.onended = cleanup;
    audio.onerror = cleanup;

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch((err) => {
        console.warn("Reprodução via Audio falhou, usando Web Audio de fallback:", err);
        playAlarmSoundWebAudio(preset.id);
        setTimeout(cleanup, 1200);
      });
    }

    return audio;
  } catch (err) {
    console.warn("Erro ao instanciar Audio, acionando Web Audio:", err);
    playAlarmSoundWebAudio(preset.id);
    if (onEnded) setTimeout(onEnded, 1200);
    return null;
  }
}

/** Toca o som de alarme configurado (usando o arquivo de áudio real do preset ou Web Audio de fallback) */
export function playAlarmSound(presetId?: string): HTMLAudioElement | null {
  const settings = getAlarmSettings();
  const chosenId = presetId || settings.soundPresetId || "ios-crystal-alert";
  const preset = ALARM_SOUND_PRESETS.find((p) => p.id === chosenId) || ALARM_SOUND_PRESETS[0];

  try {
    const audio = new Audio(preset.file);
    audio.volume = 1.0;
    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch((err) => {
        console.warn("Reprodução do alarme via Audio falhou, acionando Web Audio:", err);
        playAlarmSoundWebAudio(chosenId);
      });
    }
    return audio;
  } catch {
    playAlarmSoundWebAudio(chosenId);
    return null;
  }
}

/** Síntese harmônica via Web Audio API (fallback 100% offline se o navegador bloquear o elemento Audio) */
export function playAlarmSoundWebAudio(presetId?: string): void {
  try {
    const AudioContextClass =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const now = ctx.currentTime;

    // Frequências originais dos 10 presets oficiais
    let notes: { freq: number; start: number; dur: number; type?: OscillatorType; gain?: number }[] = [];

    switch (presetId) {
      // 01 — Pulse Rise: Pulso eletrônico progressivo
      case "pulse_rise":
        notes = [
          { freq: 440, start: 0.0, dur: 0.12, gain: 0.4 },
          { freq: 587.33, start: 0.16, dur: 0.14, gain: 0.45 },
          { freq: 739.99, start: 0.34, dur: 0.16, gain: 0.5 },
          { freq: 880, start: 0.54, dur: 0.35, gain: 0.55 },
        ];
        break;

      // 02 — Digital Wake: Sequência de bipes digitais rápidos e limpos
      case "digital_wake":
      case "android-digital-alarm":
        notes = [
          { freq: 1046.5, start: 0.0, dur: 0.08, type: "square", gain: 0.35 },
          { freq: 1318.51, start: 0.13, dur: 0.08, type: "square", gain: 0.35 },
          { freq: 1567.98, start: 0.26, dur: 0.22, type: "square", gain: 0.4 },
        ];
        break;

      // 03 — Soft Morning: Melodia curta, agradável e progressiva
      case "soft_morning":
      case "android-morning-alarm":
        notes = [
          { freq: 523.25, start: 0.0, dur: 0.22, gain: 0.35 },
          { freq: 659.25, start: 0.25, dur: 0.22, gain: 0.4 },
          { freq: 783.99, start: 0.50, dur: 0.25, gain: 0.45 },
          { freq: 1046.50, start: 0.78, dur: 0.55, gain: 0.5 },
        ];
        break;

      // 04 — Crystal Bell: Toques cristalinos modernos
      case "crystal_bell":
      case "ios-crystal-alert":
        notes = [
          { freq: 1760, start: 0.0, dur: 0.45, gain: 0.4 },
          { freq: 2640, start: 0.0, dur: 0.35, type: "triangle", gain: 0.25 },
          { freq: 2217.46, start: 0.12, dur: 0.55, gain: 0.45 },
        ];
        break;

      // 05 — Neon Pulse: Pulsos eletrônicos modernos com grave moderado
      case "neon_pulse":
      case "android-pulse-alarm":
        notes = [
          { freq: 180, start: 0.0, dur: 0.15, type: "triangle", gain: 0.5 },
          { freq: 740, start: 0.18, dur: 0.18, type: "sawtooth", gain: 0.35 },
          { freq: 987.77, start: 0.40, dur: 0.35, type: "sawtooth", gain: 0.4 },
        ];
        break;

      // 06 — Focus Alert: Alerta curto, limpo e objetivo
      case "focus_alert":
      case "ios-smart-alert":
        notes = [
          { freq: 880, start: 0.0, dur: 0.18, gain: 0.45 },
          { freq: 1174.66, start: 0.22, dur: 0.45, gain: 0.5 },
        ];
        break;

      // 07 — Deep Alarm: Grave moderado combinado com pulsos de alerta
      case "deep_alarm":
        notes = [
          { freq: 220, start: 0.0, dur: 0.20, type: "triangle", gain: 0.5 },
          { freq: 440, start: 0.22, dur: 0.15, type: "square", gain: 0.35 },
          { freq: 659.25, start: 0.40, dur: 0.35, type: "square", gain: 0.4 },
        ];
        break;

      // 08 — Smart Chime: Sino eletrônico moderno
      case "smart_chime":
      case "ios-pure-chime":
        notes = [
          { freq: 587.33, start: 0.0, dur: 0.20, gain: 0.4 },
          { freq: 880, start: 0.24, dur: 0.25, gain: 0.45 },
          { freq: 1174.66, start: 0.52, dur: 0.55, gain: 0.5 },
        ];
        break;

      // 09 — Rapid Wake: Sequência rápida para chamar atenção
      case "rapid_wake":
      case "android-classic-alarm":
        notes = [
          { freq: 880, start: 0.0, dur: 0.08, type: "square", gain: 0.35 },
          { freq: 1046.5, start: 0.12, dur: 0.08, type: "square", gain: 0.4 },
          { freq: 880, start: 0.24, dur: 0.08, type: "square", gain: 0.35 },
          { freq: 1318.51, start: 0.36, dur: 0.25, type: "square", gain: 0.45 },
        ];
        break;

      // 10 — Extreme Wake: Alarme forte, progressivo e de alta atenção
      case "extreme_wake":
      case "android-wake-up-alarm":
        notes = [
          { freq: 587.33, start: 0.0, dur: 0.15, type: "sawtooth", gain: 0.35 },
          { freq: 739.99, start: 0.18, dur: 0.18, type: "sawtooth", gain: 0.4 },
          { freq: 932.33, start: 0.39, dur: 0.20, type: "sawtooth", gain: 0.45 },
          { freq: 1174.66, start: 0.62, dur: 0.45, type: "sawtooth", gain: 0.55 },
        ];
        break;

      default:
        notes = [
          { freq: 440, start: 0.0, dur: 0.12, gain: 0.4 },
          { freq: 587.33, start: 0.16, dur: 0.14, gain: 0.45 },
          { freq: 739.99, start: 0.34, dur: 0.16, gain: 0.5 },
          { freq: 880, start: 0.54, dur: 0.35, gain: 0.55 },
        ];
    }

    notes.forEach((n) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const startTime = now + n.start;
      const dur = n.dur;

      osc.type = n.type || "sine";
      osc.frequency.setValueAtTime(n.freq, startTime);

      const targetGain = n.gain || 0.4;
      gain.gain.setValueAtTime(0.001, startTime);
      gain.gain.exponentialRampToValueAtTime(targetGain, startTime + 0.015);
      gain.gain.exponentialRampToValueAtTime(0.001, startTime + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(startTime);
      osc.stop(startTime + dur + 0.05);
    });

    setTimeout(() => {
      try {
        ctx.close();
      } catch {}
    }, 2500);
  } catch (err) {
    console.warn("Web Audio API indisponível:", err);
  }
}

/** Dispara vibração do aparelho */
export function triggerVibration(): void {
  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate([400, 200, 400, 200, 800]);
    }
  } catch {}
}

let activeWakeLockSentinel: any = null;
let alarmRinging = false;
let currentAlarmAudio: HTMLAudioElement | null = null;
let currentAlarmRepeat = 0;
let totalTargetRepeats: AlarmRepeatOption = 3;
let repeatTimeoutTimer: any = null;
let maxDurationSafetyTimer: any = null;

/** Informa se o alerta audiovisual está tocando ativamente no momento */
export function isAlarmAudiovisualActive(): boolean {
  return alarmRinging;
}

/** Retorna o progresso atual das repetições sequenciais do alarme */
export function getAlarmRepeatState(): { current: number; total: number; active: boolean } {
  return {
    current: currentAlarmRepeat,
    total: totalTargetRepeats,
    active: alarmRinging,
  };
}

/** Acende a tela do dispositivo quando o sistema operacional permitir (Screen Wake Lock API) */
export async function wakeScreenIfPossible(): Promise<void> {
  try {
    if (typeof navigator !== "undefined" && "wakeLock" in navigator) {
      if (activeWakeLockSentinel && !activeWakeLockSentinel.released) {
        return;
      }
      activeWakeLockSentinel = await (navigator as any).wakeLock.request("screen");
      activeWakeLockSentinel.addEventListener("release", () => {
        activeWakeLockSentinel = null;
      });
      // Mantém a tela acesa por até 120 segundos para visualização imediata do usuário
      setTimeout(() => {
        if (activeWakeLockSentinel) {
          try {
            activeWakeLockSentinel.release();
          } catch {}
          activeWakeLockSentinel = null;
        }
      }, 120000);
    }
  } catch {}
}

/**
 * Inicia a sequência de alarme audiovisual:
 * Reproduz o som selecionado com repetições configuradas (1×, 2×, 3× ou 5×)
 * com pausa suave entre elas, vibração sincronizada e trava de segurança máxima (maxAlarmDuration).
 */
export function startAlarmAudiovisual(presetId?: string, overrideRepeats?: AlarmRepeatOption): void {
  // Limpa qualquer execução anterior
  stopAlarmAudiovisual();
  alarmRinging = true;
  currentAlarmRepeat = 0;

  const settings = getAlarmSettings();
  const chosenId = presetId || settings.soundPresetId || "pulse_rise";
  const preset = ALARM_SOUND_PRESETS.find((p) => p.id === chosenId) || ALARM_SOUND_PRESETS[0];

  totalTargetRepeats = overrideRepeats || settings.repeatCount || 3;

  // Trava de segurança contra reprodução infinita (máximo 90s)
  maxDurationSafetyTimer = setTimeout(() => {
    if (alarmRinging) {
      console.warn("Limite máximo de segurança do alarme atingido (90s). Encerrando áudio.");
      stopAlarmAudiovisual();
    }
  }, MAX_ALARM_DURATION_MS);

  // 1. Acende a tela do celular imediatamente
  wakeScreenIfPossible().catch(() => {});

  // Função para executar sequencialmente as repetições (1x até N vezes)
  const playNextSequentialRepeat = () => {
    if (!alarmRinging) return;

    if (currentAlarmRepeat >= totalTargetRepeats) {
      stopAlarmAudiovisual();
      return;
    }

    currentAlarmRepeat++;

    // Vibração sequencial ritmada (somente se habilitada nas configurações)
    if (settings.vibrationEnabled) {
      triggerVibration();
    }

    // Emite progresso da repetição sequencial (1/N, 2/N...)
    dispatchAlarmEvent("alarm-repeat-progress", {
      current: currentAlarmRepeat,
      total: totalTargetRepeats,
      active: true,
      preset,
    });

    if (!settings.soundEnabled) {
      if (currentAlarmRepeat >= totalTargetRepeats) {
        stopAlarmAudiovisual();
      } else {
        repeatTimeoutTimer = setTimeout(playNextSequentialRepeat, 1500);
      }
      return;
    }

    // Toca a repetição atual
    try {
      const audio = new Audio(preset.file);
      audio.volume = Math.max(0.1, Math.min(1.0, settings.volume || 1.0));
      currentAlarmAudio = audio;

      let hasFinished = false;
      const finishAndNext = () => {
        if (hasFinished) return;
        hasFinished = true;
        if (currentAlarmAudio === audio) {
          currentAlarmAudio = null;
        }
        if (alarmRinging) {
          if (currentAlarmRepeat >= totalTargetRepeats) {
            // Após a última repetição configurada, encerra automaticamente
            stopAlarmAudiovisual();
          } else {
            // Pausa suave de 600ms entre as repetições sequenciais
            repeatTimeoutTimer = setTimeout(playNextSequentialRepeat, 600);
          }
        }
      };

      audio.onended = finishAndNext;
      audio.onerror = () => {
        playAlarmSoundWebAudio(preset.id);
        repeatTimeoutTimer = setTimeout(finishAndNext, 1200);
      };

      const playPromise = audio.play();
      if (playPromise !== undefined) {
        playPromise.catch((err) => {
          console.warn("Reprodução do alarme falhou, usando Web Audio:", err);
          playAlarmSoundWebAudio(preset.id);
          repeatTimeoutTimer = setTimeout(finishAndNext, 1200);
        });
      }

      // Timeout de segurança por repetição caso o evento onended não seja disparado
      setTimeout(() => {
        if (!hasFinished && currentAlarmAudio === audio) {
          finishAndNext();
        }
      }, 4500);
    } catch {
      playAlarmSoundWebAudio(preset.id);
      if (currentAlarmRepeat >= totalTargetRepeats) {
        setTimeout(stopAlarmAudiovisual, 1600);
      } else {
        repeatTimeoutTimer = setTimeout(playNextSequentialRepeat, 1600);
      }
    }
  };

  playNextSequentialRepeat();
  dispatchAlarmEvent("alarm-ringing-started", {
    presetId: chosenId,
    repeats: totalTargetRepeats,
  });
}

/**
 * Interrompe imediatamente áudio atual, repetições restantes,
 * timers de segurança, notificação, alerta e vibração.
 */
export function stopAlarmAudiovisual(): void {
  alarmRinging = false;
  currentAlarmRepeat = 0;

  if (repeatTimeoutTimer) {
    clearTimeout(repeatTimeoutTimer);
    repeatTimeoutTimer = null;
  }

  if (maxDurationSafetyTimer) {
    clearTimeout(maxDurationSafetyTimer);
    maxDurationSafetyTimer = null;
  }

  if (currentAlarmAudio) {
    try {
      currentAlarmAudio.pause();
      currentAlarmAudio.currentTime = 0;
    } catch {}
    currentAlarmAudio = null;
  }

  stopSoundPreview();

  try {
    if (typeof navigator !== "undefined" && "vibrate" in navigator) {
      navigator.vibrate(0);
    }
  } catch {}

  if (activeWakeLockSentinel) {
    try {
      activeWakeLockSentinel.release();
    } catch {}
    activeWakeLockSentinel = null;
  }

  if (Capacitor.isNativePlatform()) {
    try {
      NativeAlarm.stopAlarmSound().catch(() => {});
    } catch {}
  }

  dispatchAlarmEvent("alarm-ringing-stopped");
}

/** Função interna de teste dos 10 presets (não altera agendamento real) */
export function testPresetSound(presetId: string, onEnded?: () => void): HTMLAudioElement | null {
  return playSoundPreview(presetId, onEnded);
}

/** Função interna de teste de repetição (1×, 2×, 3× ou 5×) sem agendamento permanente */
export function testAlarmRepetition(repeats: AlarmRepeatOption, presetId?: string): void {
  startAlarmAudiovisual(presetId, repeats);
}

/** Inicializa canal de notificação no Android se estiver em plataforma nativa */
async function ensureNotificationChannel(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      await LocalNotifications.createChannel({
        id: NOTIFICATION_CHANNEL_ID,
        name: NOTIFICATION_CHANNEL_NAME,
        description: NOTIFICATION_CHANNEL_DESC,
        importance: 5,
        visibility: 1,
        sound: "beep.wav",
        vibration: true,
        lights: true,
        lightColor: "#00E5FF",
      });

      // Registra ações interativas para a notificação no Android
      await LocalNotifications.registerActionTypes({
        types: [
          {
            id: "INTERVAL_RETURN",
            actions: [
              {
                id: "retomar",
                title: "Registrar retorno",
                foreground: true,
              },
              {
                id: "silenciar",
                title: "Parar alarme",
                foreground: false,
                destructive: true,
              },
            ],
          },
        ],
      });
    } catch (err) {
      console.warn("Falha ao registrar canal de notificações nativo:", err);
    }
  }
}

/** Solicita permissão de notificação tanto no Capacitor nativo quanto no Navegador/PWA */
export async function requestNotificationPermission(): Promise<boolean> {
  try {
    // 1. Nativo (Capacitor Android / iOS)
    if (Capacitor.isNativePlatform()) {
      try {
        const check = await LocalNotifications.checkPermissions();
        if (check.display === "granted") return true;
        const req = await LocalNotifications.requestPermissions();
        return req.display === "granted";
      } catch (err) {
        console.warn("Erro ao pedir permissão nativa:", err);
      }
    }

    // 2. Web / PWA Notification API
    if (typeof window !== "undefined" && "Notification" in window) {
      if (Notification.permission === "granted") return true;
      if (Notification.permission !== "denied") {
        const res = await Notification.requestPermission();
        return res === "granted";
      }
    }
  } catch (err) {
    console.warn("Erro ao solicitar permissões de notificação:", err);
  }
  return false;
}

/**
 * Programa o alarme do despertador para o retorno do intervalo
 */
export async function scheduleIntervalAlarm(
  startTimeStr: string,
  dateStr: string
): Promise<{
  success: boolean;
  returnTime: string;
  alarmTime: string;
  leadMinutes: number;
  error?: string;
}> {
  const settings = getAlarmSettings();
  if (!settings.enabled) {
    return {
      success: false,
      returnTime: "",
      alarmTime: "",
      leadMinutes: 0,
      error: "Despertador desativado nas opções.",
    };
  }

  const { returnTimeStr, alarmTimeStr, alarmTimestamp } = calculateIntervalTimes(
    startTimeStr,
    settings.durationMinutes,
    settings.leadTimeMinutes,
    dateStr
  );

  // Cancela qualquer alarme anterior para não duplicar (Proteção contra duplicidade)
  await cancelIntervalAlarm();

  const alarmKey = `break_return_alarm_${dateStr}_${alarmTimeStr}`;

  // Salva o alarme como ativo
  const activeAlarm: ActiveIntervalAlarm = {
    id: ALARM_NOTIFICATION_ID,
    alarmKey,
    dateStr,
    startTime: startTimeStr,
    returnTime: returnTimeStr,
    alarmTime: alarmTimeStr,
    alarmTimestamp,
    durationMinutes: settings.durationMinutes,
    leadMinutes: settings.leadTimeMinutes,
    repeatCount: settings.repeatCount,
    soundPresetId: settings.soundPresetId,
    fired: false,
    createdAt: Date.now(),
  };

  saveActiveAlarm(activeAlarm);

  // Solicita permissão se ainda não concedida
  await requestNotificationPermission();

  // 1. Agendamento Nativo Oficial como Despertador do Android (AlarmManager.setAlarmClock)
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeAlarm.scheduleAlarm({
        timestamp: alarmTimestamp,
        title: "⏰ Hora de retornar ao trabalho",
        body: "Retornar Intervalo — Volta às atividades",
        sound: settings.soundPresetId,
      });
    } catch (err) {
      console.warn("Falha ao registrar via NativeAlarm:", err);
    }

    try {
      await ensureNotificationChannel();

      const notifDate = new Date(alarmTimestamp);
      // Se a data já passou, agenda com folga de 2 segundos para disparar imediatamente
      const scheduleAt = notifDate.getTime() > Date.now() ? notifDate : new Date(Date.now() + 2000);

      await LocalNotifications.schedule({
        notifications: [
          {
            id: ALARM_NOTIFICATION_ID,
            title: "⏰ Hora de retornar ao trabalho",
            body: "Retornar Intervalo — Volta às atividades",
            schedule: { at: scheduleAt, allowWhileIdle: true },
            channelId: NOTIFICATION_CHANNEL_ID,
            sound: settings.soundEnabled ? "beep.wav" : undefined,
            smallIcon: "res://drawable/ic_stat_name",
            actionTypeId: "INTERVAL_RETURN",
            extra: {
              type: "interval-return",
              returnTime: returnTimeStr,
              alarmKey,
            },
          },
        ],
      });
    } catch (err) {
      console.warn("Falha no agendamento complementar do Capacitor:", err);
    }
  }

  // 2. Notificação Web / PWA
  if (typeof window !== "undefined") {
    const diffMs = alarmTimestamp - Date.now();
    if (diffMs > 0 && diffMs < 24 * 60 * 60 * 1000) {
      // Agenda no Service Worker para funcionar em segundo plano com navegador minimizado/fechado
      try {
        if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
          navigator.serviceWorker.controller.postMessage({
            type: "SCHEDULE_SW_ALARM",
            delayMs: diffMs,
            title: "⏰ Hora de retornar ao trabalho",
            body: "Retornar Intervalo — Volta às atividades",
          });
        }
      } catch {}

      // Cria temporizador na janela caso o app permaneça aberto
      const timerId = window.setTimeout(() => {
        fireAlarmNow(activeAlarm);
      }, diffMs);

      // Guarda ID para cancelamento seguro
      (window as any).__che_interval_alarm_timer = timerId;
    }
  }

  dispatchAlarmEvent("alarm-scheduled", activeAlarm);

  return {
    success: true,
    returnTime: returnTimeStr,
    alarmTime: alarmTimeStr,
    leadMinutes: settings.leadTimeMinutes,
  };
}

/**
 * Cancela o alarme ativo e remove agendamentos pendentes
 */
export async function cancelIntervalAlarm(): Promise<void> {
  // Para som e vibração contínua caso esteja tocando
  stopAlarmAudiovisual();

  // Limpa timer web
  if (typeof window !== "undefined" && (window as any).__che_interval_alarm_timer) {
    try {
      clearTimeout((window as any).__che_interval_alarm_timer);
      delete (window as any).__che_interval_alarm_timer;
    } catch {}
  }

  // Cancela notificação e alarme nativo do Android
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeAlarm.cancelAlarm();
    } catch {}
    try {
      await LocalNotifications.cancel({
        notifications: [{ id: ALARM_NOTIFICATION_ID }],
      });
    } catch (err) {
      console.warn("Erro ao cancelar notificação nativa:", err);
    }
  }

  saveActiveAlarm(null);
  dispatchAlarmEvent("alarm-cancelled");
}

/** Consulta status da autorização do despertador nativo (alarme exato, bateria, sobreposição e notificações) */
export async function checkNativeAlarmStatus(): Promise<{
  isNative: boolean;
  canScheduleExact: boolean;
  ignoresBatteryOptimizations: boolean;
  canDrawOverlays: boolean;
  notificationsEnabled: boolean;
}> {
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await NativeAlarm.checkAlarmPermission();
      let notifGranted = true;
      try {
        const notifCheck = await LocalNotifications.checkPermissions();
        notifGranted = notifCheck.display === "granted";
      } catch {}

      return {
        isNative: true,
        canScheduleExact: res.canScheduleExact !== false,
        ignoresBatteryOptimizations: res.ignoresBatteryOptimizations !== false,
        canDrawOverlays: res.canDrawOverlays !== false,
        notificationsEnabled: notifGranted,
      };
    } catch {
      return {
        isNative: true,
        canScheduleExact: true,
        ignoresBatteryOptimizations: true,
        canDrawOverlays: true,
        notificationsEnabled: true,
      };
    }
  }

  const webNotif = typeof window !== "undefined" && "Notification" in window ? Notification.permission === "granted" : true;
  return {
    isNative: false,
    canScheduleExact: true,
    ignoresBatteryOptimizations: true,
    canDrawOverlays: true,
    notificationsEnabled: webNotif,
  };
}

/** Dispara o alarme simultâneo imediatamente para teste de tela + som */
export async function triggerNativeAlarmNow(presetId?: string): Promise<boolean> {
  const chosenId = presetId || getAlarmSettings().soundPresetId;
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeAlarm.fireAlarmNow({
        title: "⏰ VOLTE DO INTERVALO AGORA!",
        body: "Calendário de Horas Extras — Hora de retomar o trabalho",
        sound: chosenId,
      });
      return true;
    } catch (err) {
      console.warn("Falha no disparo imediato nativo:", err);
    }
  }
  startAlarmAudiovisual(chosenId);
  return true;
}

/** Solicita ao usuário a permissão de alarme exato do Android nas configurações */
export async function requestExactAlarmPermission(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeAlarm.requestExactAlarmPermission();
    } catch {}
  }
}

/** Solicita isenção de otimização de bateria para garantir toque com tela desligada */
export async function requestIgnoreBatteryOptimizations(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeAlarm.requestIgnoreBatteryOptimizations();
    } catch {}
  }
}

/** Solicita permissão para exibir sobre outros aplicativos (System Alert Window / Full-screen overlay) */
export async function requestOverlayPermission(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      await NativeAlarm.requestOverlayPermission();
    } catch {}
  }
}

/** Solicita permissão para Não Perturbe / Política de Notificação */
export async function requestNotificationPolicyPermission(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      if (NativeAlarm.requestNotificationPolicyPermission) {
        await NativeAlarm.requestNotificationPolicyPermission();
      }
    } catch {}
  }
}

/** Solicita autorização de intents em tela cheia (Android 14+) */
export async function requestFullScreenIntentPermission(): Promise<void> {
  if (Capacitor.isNativePlatform()) {
    try {
      if (NativeAlarm.requestFullScreenIntentPermission) {
        await NativeAlarm.requestFullScreenIntentPermission();
      }
    } catch {}
  }
}

/**
 * Executa o disparo do alarme (som audiovisual em loop contínuo, vibração, tela acesa e notificação)
 */
export function fireAlarmNow(alarm?: ActiveIntervalAlarm | null): void {
  // 1. Acende a tela do celular imediatamente
  wakeScreenIfPossible().catch(() => {});

  // 2. Inicia loop contínuo de som + vibração (Audiovisual) — sem parar até confirmação
  startAlarmAudiovisual();

  // 3. Dispara notificação do sistema
  if (typeof window !== "undefined" && "Notification" in window && Notification.permission === "granted") {
    try {
      if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.ready.then((reg) => {
          reg.showNotification("⏰ VOLTE DO INTERVALO AGORA!", {
            body: "Calendário de Horas Extras",
            icon: "/pwa-192x192.png",
            badge: "/pwa-192x192.png",
            tag: "interval-alarm-clock",
            vibrate: [500, 250, 500, 250, 500, 250, 1000],
            requireInteraction: true,
            renotify: true,
            actions: [
              { action: "confirmar_retorno", title: "✅ CONFIRMAR RETORNO" },
              { action: "silenciar", title: "🔕 Silenciar Alarme" },
            ],
            data: {
              type: "interval-return",
              url: "/?action=open-ponto-retorno&autoTrigger=true",
            },
          } as any);
        });
      } else {
        new Notification("⏰ VOLTE DO INTERVALO AGORA!", {
          body: "Calendário de Horas Extras",
          icon: "/pwa-192x192.png",
          requireInteraction: true,
        });
      }
    } catch (err) {
      console.warn("Erro ao emitir Notification API:", err);
    }
  }

  // 4. Notifica o aplicativo para exibir o modal de tela cheia
  dispatchAlarmEvent("alarm-fired", alarm || getActiveAlarm());
}

/**
 * Realiza teste instantâneo do alarme para validação pelo usuário
 */
export async function testIntervalAlarmNotification(): Promise<boolean> {
  const permGranted = await requestNotificationPermission();
  const settings = getAlarmSettings();

  // Acende a tela e dispara prévia audiovisual
  wakeScreenIfPossible().catch(() => {});

  if (settings.soundEnabled) {
    playAlarmSound();
  }

  if (settings.vibrationEnabled) {
    triggerVibration();
  }

  // Dispara no Capacitor se for nativo
  if (Capacitor.isNativePlatform()) {
    try {
      await ensureNotificationChannel();
      await LocalNotifications.schedule({
        notifications: [
          {
            id: 9999,
            title: "⏰ Retomar Intervalo (Teste)",
            body: "Volta às atividades · Teste do alarme concluído com sucesso!",
            schedule: { at: new Date(Date.now() + 500), allowWhileIdle: true },
            channelId: NOTIFICATION_CHANNEL_ID,
            actionTypeId: "INTERVAL_RETURN",
            sound: settings.soundEnabled ? "beep.wav" : undefined,
          },
        ],
      });
      return true;
    } catch (err) {
      console.warn("Erro no teste nativo:", err);
    }
  }

  // Dispara na Web
  if (typeof window !== "undefined" && "Notification" in window) {
    try {
      if (Notification.permission === "granted") {
        if ("serviceWorker" in navigator && navigator.serviceWorker.controller) {
          const reg = await navigator.serviceWorker.ready;
          await reg.showNotification("⏰ Retomar Intervalo (Teste)", {
            body: "Volta às atividades · Teste do alarme concluído com sucesso!",
            icon: "/pwa-192x192.png",
            badge: "/pwa-192x192.png",
            vibrate: [400, 200, 400, 200, 800],
            requireInteraction: true,
            actions: [
              { action: "retomar", title: "▶️ Retomar Intervalo" },
              { action: "silenciar", title: "🔕 Silenciar Alarme" },
            ],
          } as any);
        } else {
          new Notification("⏰ Retomar Intervalo (Teste)", {
            body: "Volta às atividades · Teste do alarme concluído com sucesso!",
            icon: "/pwa-192x192.png",
          });
        }
        return true;
      }
    } catch (err) {
      console.warn("Erro no teste Web Notification:", err);
    }
  }

  return permGranted;
}

/**
 * Checa se há alarme pendente que já venceu e deve soar
 */
export function checkDueAlarm(): ActiveIntervalAlarm | null {
  const alarm = getActiveAlarm();
  if (!alarm || alarm.fired) return null;

  const now = Date.now();
  // Se estiver a até 30 minutos após o horário previsto do alarme e ainda não tiver sido finalizado
  if (now >= alarm.alarmTimestamp && now <= alarm.alarmTimestamp + 30 * 60 * 1000) {
    return alarm;
  }
  return null;
}

// Inicializa escuta de toque em notificações nativas no Capacitor
if (typeof window !== "undefined") {
  try {
    if (Capacitor.isNativePlatform()) {
      LocalNotifications.addListener("localNotificationActionPerformed", (action) => {
        wakeScreenIfPossible().catch(() => {});
        if (action.actionId === "silenciar") {
          stopAlarmAudiovisual();
        } else {
          // "retomar" ou toque direto no corpo da notificação
          stopAlarmAudiovisual();
          window.dispatchEvent(
            new CustomEvent("che:open-ponto-retorno", {
              detail: { autoTrigger: true, action: action.actionId },
            })
          );
        }
      });

      LocalNotifications.addListener("localNotificationReceived", (notification) => {
        wakeScreenIfPossible().catch(() => {});
        startAlarmAudiovisual();
        window.dispatchEvent(
          new CustomEvent("che:alarm-fired", {
            detail: notification,
          })
        );
      });
    }
  } catch {}
}

