import { initializeApp, getApps, getApp } from "firebase/app";
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithRedirect,
  getRedirectResult,
  signOut,
  onAuthStateChanged,
  type User,
} from "firebase/auth";
import {
  initializeFirestore,
  getFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  memoryLocalCache,
  setLogLevel,
  doc,
  getDoc,
  setDoc,
  serverTimestamp,
} from "firebase/firestore";
import config from "../../firebase-applet-config.json";
import type { Settings, SimState, DayEntry } from "./calc";

export const app = !getApps().length ? initializeApp(config) : getApp();

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Silencia avisos normais de reconexão offline do SDK
try {
  setLogLevel("silent");
} catch {
  // Ignora se indisponível
}

// Filtra mensagens benignas de conectividade offline do Firestore no console
if (typeof window !== "undefined") {
  const originalConsoleError = console.error.bind(console);
  console.error = (...args: unknown[]) => {
    const text = args
      .map((a) =>
        typeof a === "string"
          ? a
          : a instanceof Error
          ? a.message
          : typeof a === "object" && a !== null
          ? JSON.stringify(a)
          : ""
      )
      .join(" ");

    if (
      text.includes("Could not reach Cloud Firestore backend") ||
      text.includes("operate in offline mode until it is able to successfully connect")
    ) {
      console.debug(...args);
      return;
    }
    originalConsoleError(...args);
  };
}

const firestoreDbId =
  config.firestoreDatabaseId && config.firestoreDatabaseId !== "(default)"
    ? config.firestoreDatabaseId
    : undefined;

function createFirestoreInstance() {
  try {
    return initializeFirestore(
      app,
      {
        experimentalAutoDetectLongPolling: true,
        localCache: persistentLocalCache({
          tabManager: persistentMultipleTabManager(),
        }),
      },
      firestoreDbId
    );
  } catch {
    try {
      return initializeFirestore(
        app,
        {
          experimentalAutoDetectLongPolling: true,
          localCache: memoryLocalCache(),
        },
        firestoreDbId
      );
    } catch {
      return firestoreDbId ? getFirestore(app, firestoreDbId) : getFirestore(app);
    }
  }
}

export const db = createFirestoreInstance();

// Trata automaticamente o retorno de redirect se o login por redirecionamento tiver sido acionado em celular
if (typeof window !== "undefined") {
  getRedirectResult(auth).catch(() => {});
}

export async function loginWithGoogle(): Promise<User | null> {
  googleProvider.setCustomParameters({ prompt: "select_account" });
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (err: unknown) {
    const error = err as { code?: string };
    // Se o popup for bloqueado pelo Safari no iPhone ou no Android, aciona o redirect nativo
    if (
      error.code === "auth/popup-blocked" ||
      error.code === "auth/cancelled-popup-request" ||
      error.code === "auth/popup-closed-by-user"
    ) {
      try {
        await signInWithRedirect(auth, googleProvider);
        return null;
      } catch (redirectErr) {
        throw redirectErr;
      }
    }
    throw err;
  }
}

export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

export interface CloudUserData {
  settings?: Settings;
  sim?: SimState;
  entries?: Record<string, DayEntry>;
  updatedAt?: unknown;
}

/**
 * Carrega os dados salvos do usuário na nuvem Firestore.
 */
export async function loadUserDataFromCloud(userId: string): Promise<CloudUserData | null> {
  try {
    const docRef = doc(db, "users", userId, "userData", "appState");
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return snap.data() as CloudUserData;
    }
    return null;
  } catch (err: unknown) {
    const error = err as { code?: string; message?: string };
    if (error?.code === "unavailable") {
      console.info("Firestore operando em modo offline / cache local.");
    } else {
      console.warn("Aviso ao carregar dados do Firestore:", error?.message || err);
    }
    return null;
  }
}

/**
 * Salva apenas as anotações do calendário na nuvem (totalmente isolado do Resumo do Mês).
 */
export async function saveCalendarEntriesToCloud(
  userId: string,
  entries: Record<string, DayEntry>
): Promise<boolean> {
  try {
    const docRef = doc(db, "users", userId, "userData", "appState");
    await setDoc(
      docRef,
      {
        entries,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    return true;
  } catch (err: unknown) {
    const error = err as { code?: string; message?: string };
    if (error?.code === "unavailable") return true;
    console.warn("Aviso ao salvar anotações no Firestore:", error?.message || err);
    return false;
  }
}

/**
 * Salva apenas os dados e percentuais do Resumo do Mês na nuvem (totalmente isolado do Calendário).
 */
export async function saveResumoSimToCloud(
  userId: string,
  sim: SimState
): Promise<boolean> {
  try {
    const docRef = doc(db, "users", userId, "userData", "appState");
    await setDoc(
      docRef,
      {
        sim,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    return true;
  } catch (err: unknown) {
    const error = err as { code?: string; message?: string };
    if (error?.code === "unavailable") return true;
    console.warn("Aviso ao salvar resumo do mês no Firestore:", error?.message || err);
    return false;
  }
}

/**
 * Salva apenas as configurações gerais na nuvem.
 */
export async function saveSettingsToCloud(
  userId: string,
  settings: Settings
): Promise<boolean> {
  try {
    const userDocRef = doc(db, "users", userId);
    await setDoc(
      userDocRef,
      {
        email: auth.currentUser?.email || "",
        displayName: auth.currentUser?.displayName || settings.name || "",
        photoURL: auth.currentUser?.photoURL || "",
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    const docRef = doc(db, "users", userId, "userData", "appState");
    await setDoc(
      docRef,
      {
        settings,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    return true;
  } catch (err: unknown) {
    const error = err as { code?: string; message?: string };
    if (error?.code === "unavailable") return true;
    console.warn("Aviso ao salvar configurações no Firestore:", error?.message || err);
    return false;
  }
}

/**
 * Salva o estado completo do aplicativo no Firestore (usado apenas em backup completo ou logout).
 */
export async function saveUserDataToCloud(
  userId: string,
  data: {
    settings: Settings;
    sim: SimState;
    entries: Record<string, DayEntry>;
  }
): Promise<boolean> {
  try {
    // Atualiza também perfil base do usuário
    const userDocRef = doc(db, "users", userId);
    await setDoc(
      userDocRef,
      {
        email: auth.currentUser?.email || "",
        displayName: auth.currentUser?.displayName || data.settings.name || "",
        photoURL: auth.currentUser?.photoURL || "",
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );

    const docRef = doc(db, "users", userId, "userData", "appState");
    await setDoc(
      docRef,
      {
        settings: data.settings,
        sim: data.sim,
        entries: data.entries,
        updatedAt: serverTimestamp(),
      },
      { merge: true }
    );
    return true;
  } catch (err: unknown) {
    const error = err as { code?: string; message?: string };
    if (error?.code === "unavailable") {
      console.info("Firestore: dados armazenados no cache offline para sincronização posterior.");
      return true;
    }
    console.warn("Aviso ao salvar dados no Firestore:", error?.message || err);
    return false;
  }
}

export { onAuthStateChanged, type User };
