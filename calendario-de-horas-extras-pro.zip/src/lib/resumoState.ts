import { KEYS, readObject, write } from "./storage";
import { DEFAULT_SIM, sanitizeSim, type SimState } from "./calc";
import { auth, saveResumoSimToCloud } from "./firebase";

/**
 * MOTOR DO RESUMO DO MÊS — TOTALMENTE ISOLADO DO CALENDÁRIO.
 *
 * Regra: Nenhuma ação no Calendário (escrever no bloco de notas, apagar texto,
 * editar anotação, trocar de dia, fechar e abrir o calendário) pode alterar
 * os percentuais ou os valores do Resumo do Mês.
 */

// Chave exclusiva de armazenamento local para o Resumo do Mês
export const RESUMO_STORAGE_KEY = KEYS.sim;

// Percentuais protegidos padrão da tabela do Resumo do Mês
export const PROTECTED_DEFAULT_PCTS = {
  weekday: 60,
  saturday: 75,
  sunday: 100,
} as const;

/**
 * Carrega o estado do Resumo do Mês protegendo estritamente os percentuais (+60%, +75%, +100%).
 */
export function loadProtectedResumoSim(): SimState {
  const legacyKeys = ["che.sim.v2", "che.resumo.sim.v3", "che.sim"];
  const raw = readObject<SimState>(RESUMO_STORAGE_KEY, DEFAULT_SIM, legacyKeys);

  const cleanWeekdayPct =
    typeof raw?.weekday?.pct === "number" && raw.weekday.pct >= 10
      ? raw.weekday.pct
      : PROTECTED_DEFAULT_PCTS.weekday;

  const cleanSaturdayPct =
    typeof raw?.saturday?.pct === "number" && raw.saturday.pct >= 10
      ? raw.saturday.pct
      : PROTECTED_DEFAULT_PCTS.saturday;

  const cleanSundayPct =
    typeof raw?.sunday?.pct === "number" && raw.sunday.pct >= 10
      ? raw.sunday.pct
      : PROTECTED_DEFAULT_PCTS.sunday;

  return sanitizeSim({
    weekday: {
      hours: raw?.weekday?.hours ?? "",
      minutes: raw?.weekday?.minutes ?? "",
      noturno: Boolean(raw?.weekday?.noturno),
      pct: cleanWeekdayPct,
    },
    saturday: {
      hours: raw?.saturday?.hours ?? "",
      minutes: raw?.saturday?.minutes ?? "",
      noturno: Boolean(raw?.saturday?.noturno),
      pct: cleanSaturdayPct,
    },
    sunday: {
      hours: raw?.sunday?.hours ?? "",
      minutes: raw?.sunday?.minutes ?? "",
      noturno: Boolean(raw?.sunday?.noturno),
      pct: cleanSundayPct,
    },
  });
}

/**
 * Grava exclusivamente os dados do Resumo do Mês no armazenamento local e na nuvem.
 * Isolado: não toca no calendário nem nas anotações.
 */
export function persistProtectedResumoSim(nextSim: SimState) {
  const sanitized = sanitizeSim(nextSim);
  write(RESUMO_STORAGE_KEY, sanitized);
  if (auth.currentUser) {
    saveResumoSimToCloud(auth.currentUser.uid, sanitized);
  }
}

/**
 * Validador e protetor de transição de estado para o Resumo do Mês.
 * Garante que os percentuais nunca sejam apagados, zerados ou sobrescritos
 * por ações não explícitas.
 */
export function protectResumoTransition(prev: SimState, next: SimState): SimState {
  return {
    weekday: {
      ...next.weekday,
      pct:
        typeof next.weekday?.pct === "number" && next.weekday.pct >= 10
          ? next.weekday.pct
          : prev.weekday?.pct || PROTECTED_DEFAULT_PCTS.weekday,
    },
    saturday: {
      ...next.saturday,
      pct:
        typeof next.saturday?.pct === "number" && next.saturday.pct >= 10
          ? next.saturday.pct
          : prev.saturday?.pct || PROTECTED_DEFAULT_PCTS.saturday,
    },
    sunday: {
      ...next.sunday,
      pct:
        typeof next.sunday?.pct === "number" && next.sunday.pct >= 10
          ? next.sunday.pct
          : prev.sunday?.pct || PROTECTED_DEFAULT_PCTS.sunday,
    },
  };
}
