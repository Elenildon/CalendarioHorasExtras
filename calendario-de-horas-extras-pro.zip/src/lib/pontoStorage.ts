/**
 * Armazenamento e gerenciamento isolado dos Registros de Ponto Eletrônico com Biometria.
 * 
 * REGRA DE OURO:
 * Totalmente isolado do restante do aplicativo.
 * Não altera nem interfere no motor do calendário, nem nos apontamentos manuais.
 */

export type PontoEventType = "ENTRY" | "BREAK_START" | "BREAK_END" | "EXIT";

export interface PontoBiometrico {
  data: string; // YYYY-MM-DD
  entrada?: string; // HH:mm
  inicioIntervalo?: string; // HH:mm
  retornoIntervalo?: string; // HH:mm
  saida?: string; // HH:mm
  origem: "biometria" | "manual";
  corrigidoManualmente?: boolean;
  timestamps: {
    entrada?: number;
    inicioIntervalo?: number;
    retornoIntervalo?: number;
    saida?: number;
  };
}

export type PontoState =
  | "WAITING_ENTRY"
  | "ENTRY_DONE"
  | "WAITING_BREAK_START"
  | "BREAK_IN_PROGRESS"
  | "WAITING_BREAK_END"
  | "BREAK_ENDED"
  | "WAITING_EXIT"
  | "DAY_COMPLETED";

export interface PontoRecord {
  id: string;
  user: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm:ss
  timeShort: string; // HH:mm
  type: PontoEventType;
  authStatus: "AUTHENTICATED_BIOMETRIC" | "AUTHENTICATED_DEVICE";
  createdAt: number;
  /** Preparado para futura implementação de GPS / Geofence */
  geo?: {
    lat?: number;
    lng?: number;
    accuracy?: number;
    authorized?: boolean;
  } | null;
}

export interface PontoDaySummary {
  date: string;
  entry?: PontoRecord;
  breakStart?: PontoRecord;
  breakEnd?: PontoRecord;
  exit?: PontoRecord;
  records: PontoRecord[];
  currentState: PontoState;
  nextExpectedAction: PontoEventType | null;
  workedMinutes: number;
  workedFormatted: string;
  breakMinutes: number;
  breakFormatted: string;
  balanceMinutes: number;
  balanceFormatted: string;
  overtimeMinutes: number;
  overtimeFormatted: string;
  isComplete: boolean;
}

const STORAGE_KEY = "che.ponto-records.v1";
const PONTO_BIO_KEY = "che.ponto-biometrico.v1";

/** Converte string HH:mm para minutos a partir de 00:00 */
export function timeToMinutes(timeStr: string): number {
  if (!timeStr) return 0;
  const parts = timeStr.split(":");
  const h = parseInt(parts[0], 10) || 0;
  const m = parseInt(parts[1], 10) || 0;
  return h * 60 + m;
}

/** Formata minutos para "Xh Ym" ou "00h 00m" */
export function formatMinutes(totalMins: number, signed = false): string {
  const abs = Math.abs(totalMins);
  const h = Math.floor(abs / 60);
  const m = abs % 60;
  const formatted = `${String(h).padStart(2, "0")}h ${String(m).padStart(2, "0")}m`;
  if (signed) {
    if (totalMins > 0) return `+${formatted}`;
    if (totalMins < 0) return `-${formatted}`;
  }
  return formatted;
}

/** Notifica a aplicação sobre atualização em registros de ponto */
function notifyPontoUpdated(dateStr: string): void {
  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(new CustomEvent("che:ponto-updated", { detail: { date: dateStr } }));
    } catch {}
  }
}

/** Obtém o mapa de todos os PontoBiometrico (por data YYYY-MM-DD) */
export function getAllPontoBiometricos(): Record<string, PontoBiometrico> {
  try {
    const raw = localStorage.getItem(PONTO_BIO_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch (err) {
    console.error("Erro ao ler PontoBiometrico:", err);
    return {};
  }
}

/** Salva o mapa de PontoBiometrico */
function saveAllPontoBiometricos(map: Record<string, PontoBiometrico>): void {
  try {
    localStorage.setItem(PONTO_BIO_KEY, JSON.stringify(map));
  } catch (err) {
    console.error("Erro ao salvar PontoBiometrico:", err);
  }
}

/** Obtém o PontoBiometrico consolidado de uma data específica */
export function getPontoBiometrico(dateStr: string): PontoBiometrico | null {
  const map = getAllPontoBiometricos();
  if (map[dateStr]) return map[dateStr];

  // Se ainda não existir no formato consolidado, sincroniza a partir dos registros de eventos
  const records = getPontoRecordsForDate(dateStr);
  if (records.length > 0) {
    return syncPontoBiometricoFromRecords(dateStr);
  }
  return null;
}

/** Salva ou atualiza o PontoBiometrico de uma data */
export function savePontoBiometrico(ponto: PontoBiometrico): void {
  const map = getAllPontoBiometricos();
  map[ponto.data] = ponto;
  saveAllPontoBiometricos(map);
  syncPontoToCalendar(ponto.data, ponto);
  notifyPontoUpdated(ponto.data);
}

/**
 * Sincroniza os horários e o cálculo do Ponto Biométrico diretamente no Calendário de Horas Extras
 * Registra DATA + HORA + MINUTOS reais no dia correspondente e calcula as horas trabalhadas e horas extras
 */
export function syncPontoToCalendar(dateStr: string, pontoInput?: PontoBiometrico): void {
  try {
    if (typeof localStorage === "undefined") return;
    const ponto = pontoInput || getPontoBiometrico(dateStr);
    if (!ponto) return;

    const raw = localStorage.getItem("che.entries.v2");
    const entries: Record<string, any> = raw ? JSON.parse(raw) : {};

    const hasAnyPunch = Boolean(ponto.entrada || ponto.inicioIntervalo || ponto.retornoIntervalo || ponto.saida);
    if (!hasAnyPunch) {
      if (entries[dateStr]) {
        delete entries[dateStr].ponto;
        if (
          entries[dateStr].note &&
          (entries[dateStr].note.startsWith("Entrada —") ||
            entries[dateStr].note.startsWith("Ponto Biométrico"))
        ) {
          entries[dateStr].note = "";
        }
        entries[dateStr].hours = 0;
        entries[dateStr].minutes = 0;
        entries[dateStr].savedAt = Date.now();
        localStorage.setItem("che.entries.v2", JSON.stringify(entries));
      }
      return;
    }

    const calc = calculateWorkedAndOvertime(ponto);
    const existing = entries[dateStr] || {};

    const workedHours = Math.floor(calc.workedMinutes / 60);
    const workedMins = calc.workedMinutes % 60;

    // Resumo dos horários no padrão exato especificado:
    // Entrada — 07:58 · Intervalo — 12:03 · Retorno — 13:02 · Saída — 17:46
    const partes: string[] = [];
    if (ponto.entrada) partes.push(`Entrada — ${ponto.entrada}`);
    if (ponto.inicioIntervalo) partes.push(`Intervalo — ${ponto.inicioIntervalo}`);
    if (ponto.retornoIntervalo) partes.push(`Retorno — ${ponto.retornoIntervalo}`);
    if (ponto.saida) partes.push(`Saída — ${ponto.saida}`);

    const pontoNote = partes.join(" · ");

    // Se o usuário tiver digitado uma anotação estritamente manual personalizada, preserva
    const hasCustomManualNote =
      existing.note &&
      !existing.note.startsWith("Entrada —") &&
      !existing.note.startsWith("Ponto Biométrico");

    const noteToSave = hasCustomManualNote ? existing.note : pontoNote;

    // O valor do subtotal de horas trabalhadas alimenta automaticamente a aba abaixo (Horas e Minutos)
    // e os lançamentos do mês (60%, 75% e 100%)
    const hoursToSave = calc.workedMinutes > 0
      ? workedHours
      : (ponto.saida ? 0 : (existing.hours ?? 0));

    const minutesToSave = calc.workedMinutes > 0
      ? workedMins
      : (ponto.saida ? 0 : (existing.minutes ?? 0));

    const dotToSave = existing.dot ?? (calc.workedMinutes > 0 ? "emerald" : "sky");

    entries[dateStr] = {
      ...existing,
      hours: hoursToSave,
      minutes: minutesToSave,
      noturno: existing.noturno ?? false,
      note: noteToSave,
      dot: dotToSave,
      savedAt: Date.now(),
      ponto: {
        entrada: ponto.entrada,
        inicioIntervalo: ponto.inicioIntervalo,
        retornoIntervalo: ponto.retornoIntervalo,
        saida: ponto.saida,
        origem: ponto.origem,
        workedMinutes: calc.workedMinutes,
        workedFormatted: calc.workedFormatted,
        overtimeMinutes: calc.overtimeMinutes,
        overtimeFormatted: calc.overtimeFormatted,
      },
    };

    localStorage.setItem("che.entries.v2", JSON.stringify(entries));
  } catch (err) {
    console.error("Erro ao sincronizar ponto no calendário:", err);
  }
}

/**
 * Ressincroniza todos os registros de ponto com o calendário de horas extras,
 * garantindo que o subtotal de horas trabalhadas alimente os dias e os lançamentos do mês.
 */
export function resyncAllPontosToCalendar(): void {
  try {
    if (typeof localStorage === "undefined") return;
    const map = getAllPontoBiometricos();
    for (const [dateStr, ponto] of Object.entries(map)) {
      if (ponto && (ponto.entrada || ponto.saida)) {
        syncPontoToCalendar(dateStr, ponto);
      }
    }
  } catch (err) {
    console.error("Erro ao ressincronizar pontos no calendário:", err);
  }
}

/** Sincroniza e consolida o PontoBiometrico a partir dos eventos gravados */
export function syncPontoBiometricoFromRecords(dateStr: string): PontoBiometrico {
  const records = getPontoRecordsForDate(dateStr);
  
  if (records.length === 0) {
    clearPontoRecordsForDate(dateStr);
    return {
      data: dateStr,
      entrada: undefined,
      inicioIntervalo: undefined,
      retornoIntervalo: undefined,
      saida: undefined,
      origem: "biometria",
      corrigidoManualmente: false,
      timestamps: {},
    };
  }

  const entry = records.find((r) => r.type === "ENTRY");
  const breakStart = records.find((r) => r.type === "BREAK_START");
  const breakEnd = records.find((r) => r.type === "BREAK_END");
  const exit = records.find((r) => r.type === "EXIT");

  const existingMap = getAllPontoBiometricos();
  const existing = existingMap[dateStr];

  const ponto: PontoBiometrico = {
    data: dateStr,
    entrada: entry ? entry.timeShort : undefined,
    inicioIntervalo: breakStart ? breakStart.timeShort : undefined,
    retornoIntervalo: breakEnd ? breakEnd.timeShort : undefined,
    saida: exit ? exit.timeShort : undefined,
    origem: existing?.origem || "biometria",
    corrigidoManualmente: false,
    timestamps: {
      entrada: entry?.createdAt,
      inicioIntervalo: breakStart?.createdAt,
      retornoIntervalo: breakEnd?.createdAt,
      saida: exit?.createdAt,
    },
  };

  savePontoBiometrico(ponto);
  return ponto;
}

/**
 * Correção Manual de Horários de Ponto
 * Registra explicitamente que o horário foi corrigido manualmente (origem: "manual", corrigidoManualmente: true)
 */
export function saveManualCorrection(
  dateStr: string,
  times: {
    entrada?: string;
    inicioIntervalo?: string;
    retornoIntervalo?: string;
    saida?: string;
  }
): PontoBiometrico {
  const existing = getPontoBiometrico(dateStr);
  const now = Date.now();

  const updated: PontoBiometrico = {
    data: dateStr,
    entrada: times.entrada ?? existing?.entrada,
    inicioIntervalo: times.inicioIntervalo ?? existing?.inicioIntervalo,
    retornoIntervalo: times.retornoIntervalo ?? existing?.retornoIntervalo,
    saida: times.saida ?? existing?.saida,
    origem: "manual",
    corrigidoManualmente: true,
    timestamps: {
      entrada: times.entrada ? (existing?.timestamps?.entrada ?? now) : undefined,
      inicioIntervalo: times.inicioIntervalo ? (existing?.timestamps?.inicioIntervalo ?? now) : undefined,
      retornoIntervalo: times.retornoIntervalo ? (existing?.timestamps?.retornoIntervalo ?? now) : undefined,
      saida: times.saida ? (existing?.timestamps?.saida ?? now) : undefined,
    },
  };

  savePontoBiometrico(updated);

  // Também atualiza os registros de evento para manter coerência no histórico e REP
  const all = getAllPontoRecords().filter((r) => r.date !== dateStr);
  if (updated.entrada) {
    all.push({
      id: "ponto_man_" + dateStr + "_entry",
      user: "Colaborador",
      date: dateStr,
      time: `${updated.entrada}:00`,
      timeShort: updated.entrada,
      type: "ENTRY",
      authStatus: "AUTHENTICATED_DEVICE",
      createdAt: now,
    });
  }
  if (updated.inicioIntervalo) {
    all.push({
      id: "ponto_man_" + dateStr + "_bstart",
      user: "Colaborador",
      date: dateStr,
      time: `${updated.inicioIntervalo}:00`,
      timeShort: updated.inicioIntervalo,
      type: "BREAK_START",
      authStatus: "AUTHENTICATED_DEVICE",
      createdAt: now + 1,
    });
  }
  if (updated.retornoIntervalo) {
    all.push({
      id: "ponto_man_" + dateStr + "_bend",
      user: "Colaborador",
      date: dateStr,
      time: `${updated.retornoIntervalo}:00`,
      timeShort: updated.retornoIntervalo,
      type: "BREAK_END",
      authStatus: "AUTHENTICATED_DEVICE",
      createdAt: now + 2,
    });
  }
  if (updated.saida) {
    all.push({
      id: "ponto_man_" + dateStr + "_exit",
      user: "Colaborador",
      date: dateStr,
      time: `${updated.saida}:00`,
      timeShort: updated.saida,
      type: "EXIT",
      authStatus: "AUTHENTICATED_DEVICE",
      createdAt: now + 3,
    });
  }
  saveAllPontoRecords(all);

  notifyPontoUpdated(dateStr);
  return updated;
}

/**
 * Cálculo detalhado das horas trabalhadas e horas extras com base na CLT:
 * Período 1 = Entrada até Início do Intervalo
 * Período 2 = Retorno do Intervalo até Saída
 * Total = Período 1 + Período 2
 * Saldo e Horas Extras = Excedente em relação à jornada diária (padrão 8h / 480 min)
 */
export function calculateWorkedAndOvertime(
  ponto?: {
    entrada?: string;
    inicioIntervalo?: string;
    retornoIntervalo?: string;
    saida?: string;
  } | null,
  standardDailyMinutes: number = 8 * 60
): {
  workedMinutes: number;
  workedFormatted: string;
  overtimeMinutes: number;
  overtimeFormatted: string;
  balanceMinutes: number;
  balanceFormatted: string;
  isComplete: boolean;
} {
  const { entrada, inicioIntervalo, retornoIntervalo, saida } = ponto || {};

  let workedMinutes = 0;

  if (entrada && inicioIntervalo && retornoIntervalo && saida) {
    let e = timeToMinutes(entrada);
    let i1 = timeToMinutes(inicioIntervalo);
    let i2 = timeToMinutes(retornoIntervalo);
    let s = timeToMinutes(saida);

    if (i1 < e) i1 += 24 * 60;
    if (i2 < i1) i2 += 24 * 60;
    if (s < i2) s += 24 * 60;

    const p1 = Math.max(0, i1 - e);
    const p2 = Math.max(0, s - i2);
    workedMinutes = p1 + p2;
  } else if (entrada && saida && !inicioIntervalo && !retornoIntervalo) {
    let e = timeToMinutes(entrada);
    let s = timeToMinutes(saida);
    if (s < e) s += 24 * 60;
    workedMinutes = Math.max(0, s - e);
  } else if (entrada && saida && inicioIntervalo && !retornoIntervalo) {
    let e = timeToMinutes(entrada);
    let i1 = timeToMinutes(inicioIntervalo);
    let s = timeToMinutes(saida);
    if (i1 < e) i1 += 24 * 60;
    if (s < e) s += 24 * 60;
    const breakEst = Math.min(60, Math.max(0, s - i1));
    workedMinutes = Math.max(0, s - e - breakEst);
  } else if (entrada && inicioIntervalo && !retornoIntervalo && !saida) {
    let e = timeToMinutes(entrada);
    let i1 = timeToMinutes(inicioIntervalo);
    if (i1 < e) i1 += 24 * 60;
    workedMinutes = Math.max(0, i1 - e);
  }

  const isComplete = Boolean(entrada && saida);
  const balanceMinutes = isComplete ? workedMinutes - standardDailyMinutes : 0;
  const overtimeMinutes = balanceMinutes > 0 ? balanceMinutes : 0;

  return {
    workedMinutes,
    workedFormatted: formatMinutes(workedMinutes),
    overtimeMinutes,
    overtimeFormatted: formatMinutes(overtimeMinutes),
    balanceMinutes,
    balanceFormatted: formatMinutes(balanceMinutes, true),
    isComplete,
  };
}

/** Obtém todos os registros armazenados localmente */
export function getAllPontoRecords(): PontoRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch (err) {
    console.error("Erro ao ler registros de ponto:", err);
    return [];
  }
}

/** Salva todos os registros localmente */
function saveAllPontoRecords(records: PontoRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (err) {
    console.error("Erro ao gravar registros de ponto:", err);
  }
}

/** Obtém os registros de uma data específica (YYYY-MM-DD) ordenados cronologicamente */
export function getPontoRecordsForDate(dateStr: string): PontoRecord[] {
  const all = getAllPontoRecords();
  return all
    .filter((r) => r.date === dateStr)
    .sort((a, b) => a.createdAt - b.createdAt);
}

/** Adiciona um novo registro de ponto com validação de duplicidade e máquina de estados */
export function addPontoRecord(record: PontoRecord): { success: boolean; error?: string } {
  const existingForDate = getPontoRecordsForDate(record.date);

  // Validação: não permitir duplicidade consecutiva do mesmo tipo
  const hasSameType = existingForDate.some((r) => r.type === record.type);
  if (hasSameType) {
    const label = getPontoTypeLabel(record.type);
    return {
      success: false,
      error: `O registro de ${label} já foi realizado hoje.`,
    };
  }

  // Liberação total: permite registrar as etapas sem bloqueio restritivo de sequência
  const all = getAllPontoRecords();
  all.push(record);
  saveAllPontoRecords(all);

  // Sincroniza o PontoBiometrico consolidado e notifica os componentes do app
  syncPontoBiometricoFromRecords(record.date);
  notifyPontoUpdated(record.date);

  return { success: true };
}

/** Remove um registro de ponto por ID (caso o usuário precise ajustar) */
export function deletePontoRecord(id: string): void {
  const all = getAllPontoRecords();
  const target = all.find((r) => r.id === id);
  const filtered = all.filter((r) => r.id !== id);
  saveAllPontoRecords(filtered);

  if (target) {
    const remainingForDate = filtered.filter((r) => r.date === target.date);
    if (remainingForDate.length === 0) {
      clearPontoRecordsForDate(target.date);
    } else {
      syncPontoBiometricoFromRecords(target.date);
    }
    notifyPontoUpdated(target.date);
  }
}

/** Limpa os registros de uma data específica */
export function clearPontoRecordsForDate(dateStr: string): void {
  const all = getAllPontoRecords();
  const filtered = all.filter((r) => r.date !== dateStr);
  saveAllPontoRecords(filtered);

  const bioMap = getAllPontoBiometricos();
  delete bioMap[dateStr];
  saveAllPontoBiometricos(bioMap);

  try {
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem("che.entries.v2");
      if (raw) {
        const entries = JSON.parse(raw);
        if (entries[dateStr]) {
          delete entries[dateStr].ponto;
          if (
            entries[dateStr].note &&
            (entries[dateStr].note.startsWith("Entrada —") ||
              entries[dateStr].note.startsWith("Ponto Biométrico"))
          ) {
            entries[dateStr].note = "";
          }
          // Se não há anotação manual personalizada e o lançamento veio do ponto, zera horas e minutos
          entries[dateStr].hours = 0;
          entries[dateStr].minutes = 0;
          entries[dateStr].savedAt = Date.now();
          localStorage.setItem("che.entries.v2", JSON.stringify(entries));
        }
      }
    }
  } catch (err) {
    console.error("Erro ao limpar ponto das entradas do calendário:", err);
  }

  notifyPontoUpdated(dateStr);
}

/** Rótulos amigáveis para cada tipo de evento */
export function getPontoTypeLabel(type: PontoEventType): string {
  switch (type) {
    case "ENTRY":
      return "Entrada";
    case "BREAK_START":
      return "Início do intervalo";
    case "BREAK_END":
      return "Retorno do intervalo";
    case "EXIT":
      return "Saída";
  }
}

/** Ícone identificador textual para o tipo */
export function getPontoTypeEmoji(type: PontoEventType): string {
  switch (type) {
    case "ENTRY":
      return "🟢";
    case "BREAK_START":
      return "☕";
    case "BREAK_END":
      return "▶️";
    case "EXIT":
      return "🔴";
  }
}

/**
 * Calcula o resumo do dia, tempo trabalhado, intervalo e saldo de horas
 * Conforme as 8 etapas da máquina de estados.
 */
export function calculateDaySummary(
  dateStr: string,
  recordsList?: PontoRecord[],
  standardDailyMinutes: number = 8 * 60 // 8 horas padrão CLT
): PontoDaySummary {
  const records = recordsList || getPontoRecordsForDate(dateStr);

  const entry = records.find((r) => r.type === "ENTRY");
  const breakStart = records.find((r) => r.type === "BREAK_START");
  const breakEnd = records.find((r) => r.type === "BREAK_END");
  const exit = records.find((r) => r.type === "EXIT");

  // Determina o estado da máquina de estados e o próximo passo sugerido
  let currentState: PontoState = "WAITING_ENTRY";
  let nextExpectedAction: PontoEventType | null = "ENTRY";

  if (!entry && !breakStart) {
    currentState = "WAITING_ENTRY";
    nextExpectedAction = "ENTRY";
  } else if (!breakStart) {
    currentState = "WAITING_BREAK_START";
    nextExpectedAction = "BREAK_START";
  } else if (!breakEnd) {
    currentState = "WAITING_BREAK_END";
    nextExpectedAction = "BREAK_END";
  } else if (!exit) {
    currentState = "WAITING_EXIT";
    nextExpectedAction = "EXIT";
  } else {
    currentState = "DAY_COMPLETED";
    nextExpectedAction = null;
  }

  // Cálculos de minutos
  let workedMinutes = 0;
  let breakMinutes = 0;

  // Intervalo
  if (breakStart && breakEnd) {
    const startMins = timeToMinutes(breakStart.timeShort);
    const endMins = timeToMinutes(breakEnd.timeShort);
    if (endMins >= startMins) {
      breakMinutes = endMins - startMins;
    }
  }

  // Tempo trabalhado
  if (entry && exit) {
    const entryMins = timeToMinutes(entry.timeShort);
    const exitMins = timeToMinutes(exit.timeShort);
    const totalElapsed = exitMins >= entryMins ? exitMins - entryMins : 0;
    workedMinutes = Math.max(0, totalElapsed - breakMinutes);
  } else if (entry && breakStart && !breakEnd) {
    // Até o início do intervalo
    const entryMins = timeToMinutes(entry.timeShort);
    const breakStartMins = timeToMinutes(breakStart.timeShort);
    workedMinutes = Math.max(0, breakStartMins - entryMins);
  }

  // Saldo da jornada
  const balanceMinutes = (entry && exit) ? workedMinutes - standardDailyMinutes : 0;
  const overtimeMinutes = balanceMinutes > 0 ? balanceMinutes : 0;

  return {
    date: dateStr,
    entry,
    breakStart,
    breakEnd,
    exit,
    records,
    currentState,
    nextExpectedAction,
    workedMinutes,
    workedFormatted: formatMinutes(workedMinutes),
    breakMinutes,
    breakFormatted: formatMinutes(breakMinutes),
    balanceMinutes,
    balanceFormatted: formatMinutes(balanceMinutes, true),
    overtimeMinutes,
    overtimeFormatted: formatMinutes(overtimeMinutes),
    isComplete: currentState === "DAY_COMPLETED",
  };
}
