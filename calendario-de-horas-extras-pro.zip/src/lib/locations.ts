/** Base de localização: 27 UFs + municípios via IBGE (com cache + fallback offline). */

export interface UF {
  sigla: string;
  nome: string;
}

export interface Municipio {
  id: number;
  nome: string;
}

export const UFS: UF[] = [
  { sigla: "AC", nome: "Acre" },
  { sigla: "AL", nome: "Alagoas" },
  { sigla: "AP", nome: "Amapá" },
  { sigla: "AM", nome: "Amazonas" },
  { sigla: "BA", nome: "Bahia" },
  { sigla: "CE", nome: "Ceará" },
  { sigla: "DF", nome: "Distrito Federal" },
  { sigla: "ES", nome: "Espírito Santo" },
  { sigla: "GO", nome: "Goiás" },
  { sigla: "MA", nome: "Maranhão" },
  { sigla: "MT", nome: "Mato Grosso" },
  { sigla: "MS", nome: "Mato Grosso do Sul" },
  { sigla: "MG", nome: "Minas Gerais" },
  { sigla: "PA", nome: "Pará" },
  { sigla: "PB", nome: "Paraíba" },
  { sigla: "PR", nome: "Paraná" },
  { sigla: "PE", nome: "Pernambuco" },
  { sigla: "PI", nome: "Piauí" },
  { sigla: "RJ", nome: "Rio de Janeiro" },
  { sigla: "RN", nome: "Rio Grande do Norte" },
  { sigla: "RS", nome: "Rio Grande do Sul" },
  { sigla: "RO", nome: "Rondônia" },
  { sigla: "RR", nome: "Roraima" },
  { sigla: "SC", nome: "Santa Catarina" },
  { sigla: "SP", nome: "São Paulo" },
  { sigla: "SE", nome: "Sergipe" },
  { sigla: "TO", nome: "Tocantins" },
];

export const ufName = (sigla: string) =>
  UFS.find((u) => u.sigla === sigla.toUpperCase())?.nome ?? sigla.toUpperCase();

export const isValidUF = (sigla: string) =>
  UFS.some((u) => u.sigla === sigla.toUpperCase());

/** Busca sem acento / sem maiúsculas — "sao" encontra "São". */
export const norm = (s: string) =>
  (s ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

export const matchesQuery = (target: string, query: string) => {
  const q = norm(query).trim();
  if (!q) return true;
  return norm(target).includes(q);
};

/** Capitais para fallback offline. */
const CAPITALS: Record<string, string> = {
  AC: "Rio Branco",
  AL: "Maceió",
  AP: "Macapá",
  AM: "Manaus",
  BA: "Salvador",
  CE: "Fortaleza",
  DF: "Brasília",
  ES: "Vitória",
  GO: "Goiânia",
  MA: "São Luís",
  MT: "Cuiabá",
  MS: "Campo Grande",
  MG: "Belo Horizonte",
  PA: "Belém",
  PB: "João Pessoa",
  PR: "Curitiba",
  PE: "Recife",
  PI: "Teresina",
  RJ: "Rio de Janeiro",
  RN: "Natal",
  RS: "Porto Alegre",
  RO: "Porto Velho",
  RR: "Boa Vista",
  SC: "Florianópolis",
  SP: "São Paulo",
  SE: "Aracaju",
  TO: "Palmas",
};

/** Algumas cidades mineiras para busca offline imediata. */
const MG_FALLBACK: Municipio[] = [
  { id: 3125101, nome: "Extrema" },
  { id: 3106200, nome: "Belo Horizonte" },
  { id: 3136702, nome: "Juiz de Fora" },
  { id: 3106705, nome: "Betim" },
  { id: 3122306, nome: "Divinópolis" },
  { id: 3143302, nome: "Montes Claros" },
  { id: 3154606, nome: "Ribeirão das Neves" },
  { id: 3170206, nome: "Uberlândia" },
  { id: 3169901, nome: "Uberaba" },
  { id: 3118601, nome: "Contagem" },
  { id: 3144805, nome: "Nova Lima" },
  { id: 3152509, nome: "Pouso Alegre" },
  { id: 3131607, nome: "Itajubá" },
  { id: 3151800, nome: "Poços de Caldas" },
  { id: 3170701, nome: "Varginha" },
];

const memCache = new Map<string, Municipio[]>();

function readCache(uf: string): Municipio[] | null {
  if (memCache.has(uf)) return memCache.get(uf)!;
  try {
    const raw = localStorage.getItem(`che.municipios.${uf}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length) {
      memCache.set(uf, parsed);
      return parsed;
    }
  } catch {
    /* ignore */
  }
  return null;
}

function writeCache(uf: string, list: Municipio[]) {
  memCache.set(uf, list);
  try {
    localStorage.setItem(`che.municipios.${uf}`, JSON.stringify(list));
  } catch {
    /* ignore */
  }
}

function fallbackFor(uf: string): Municipio[] {
  const u = uf.toUpperCase();
  if (u === "MG") return MG_FALLBACK;
  const capital = CAPITALS[u];
  if (capital) return [{ id: 0, nome: capital }];
  return [];
}

/**
 * Municípios da UF via IBGE, ordenados por nome, com cache permanente.
 * Base completa (todos os 5.570 municípios) — nunca uma lista parcial fixa.
 */
export async function fetchMunicipios(uf: string): Promise<Municipio[]> {
  const key = uf.toUpperCase();
  const cached = readCache(key);
  if (cached) return cached;
  try {
    const ctrl = new AbortController();
    const timer = window.setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch(
      `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${key}/municipios?orderBy=nome`,
      { signal: ctrl.signal }
    );
    window.clearTimeout(timer);
    if (!res.ok) throw new Error(`IBGE ${res.status}`);
    const data = (await res.json()) as Array<{ id: number; nome: string }>;
    const list = data.map((m) => ({ id: m.id, nome: m.nome }));
    if (list.length) {
      writeCache(key, list);
      return list;
    }
  } catch {
    /* cai para o fallback */
  }
  return fallbackFor(key);
}

/** Pré-carrega em segundo plano para a busca ficar instantânea. */
export function prefetchMunicipios(uf: string) {
  const key = uf.toUpperCase();
  if (readCache(key)) return;
  void fetchMunicipios(key);
}

export interface DetectedPlace {
  city: string;
  uf: string;
  ufName: string;
  method?: "gps" | "rede";
}

export function resolveUF(rawState?: string, rawCode?: string): string {
  let code = (rawCode || "").trim().toUpperCase();
  if (code.includes("-")) code = code.split("-").pop()!.toUpperCase();
  if (code.length === 2 && isValidUF(code)) return code;

  const stateStr = (rawState || "").trim();
  if (stateStr) {
    const found = UFS.find(
      (u) => norm(u.nome) === norm(stateStr) || norm(u.sigla) === norm(stateStr)
    );
    if (found) return found.sigla;
  }
  return "";
}

/** Cruza o nome detectado com a base oficial do IBGE para garantir acentuação e nome exato. */
export async function matchWithIbge(uf: string, detectedCity: string): Promise<string> {
  if (!detectedCity || !isValidUF(uf)) return detectedCity;
  try {
    const list = await fetchMunicipios(uf);
    if (!list || list.length === 0) return detectedCity;
    const target = norm(detectedCity).trim();

    // 1. Busca exata normalizada (ex: "sao paulo" -> "São Paulo")
    const exact = list.find((m) => norm(m.nome) === target);
    if (exact) return exact.nome;

    // 2. Busca por prefixo
    const prefix = list.find(
      (m) => norm(m.nome).startsWith(target) || target.startsWith(norm(m.nome))
    );
    if (prefix) return prefix.nome;

    // 3. Busca por inclusão mútua
    const contains = list.find(
      (m) => norm(m.nome).includes(target) || target.includes(norm(m.nome))
    );
    if (contains) return contains.nome;
  } catch {
    /* fallback para o próprio nome detectado */
  }
  return detectedCity;
}

function extractCityFromBdc(data: {
  city?: string;
  locality?: string;
  localityInfo?: { administrative?: Array<{ name: string; adminLevel?: number; description?: string }> };
}): string {
  const admin = data.localityInfo?.administrative || [];
  // adminLevel 8 é o nível de Município no Brasil
  const mun8 = admin.find(
    (a) => a.adminLevel === 8 && !a.name.toLowerCase().startsWith("região")
  );
  if (mun8?.name) return mun8.name;

  if (data.locality && !data.locality.toLowerCase().startsWith("região")) return data.locality;
  if (data.city && !data.city.toLowerCase().startsWith("região")) return data.city;

  return data.city || data.locality || "";
}

/** Geocodificação reversa de coordenadas com provedores redundantes e sem travar. */
async function reverseGeocodeCoords(
  lat: number,
  lon: number
): Promise<{ city: string; uf: string }> {
  // 1. api-bdc.io (moderno, direto e sem redirecionamento 307)
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 6000);
    const res = await fetch(
      `https://api-bdc.io/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=pt`,
      { signal: ctrl.signal }
    );
    clearTimeout(t);
    if (res.ok) {
      const data = await res.json();
      const city = extractCityFromBdc(data);
      const uf = resolveUF(data.principalSubdivision, data.principalSubdivisionCode);
      if (city && uf) return { city, uf };
    }
  } catch {
    /* segue para o próximo provedor */
  }

  // 2. OpenStreetMap Nominatim
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 6000);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=pt-BR,pt`,
      { signal: ctrl.signal }
    );
    clearTimeout(t);
    if (res.ok) {
      const data = await res.json();
      const addr = data.address || {};
      const city =
        addr.municipality ||
        addr.city ||
        addr.town ||
        addr.village ||
        addr.city_district ||
        addr.county ||
        "";
      const uf = resolveUF(addr.state, addr["ISO3166-2-lvl4"]);
      if (city && uf) return { city, uf };
    }
  } catch {
    /* segue para o próximo provedor */
  }

  // 3. Fallback legado BigDataCloud
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 6000);
    const res = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=pt`,
      { signal: ctrl.signal }
    );
    clearTimeout(t);
    if (res.ok) {
      const data = await res.json();
      const city = extractCityFromBdc(data);
      const uf = resolveUF(data.principalSubdivision, data.principalSubdivisionCode);
      if (city && uf) return { city, uf };
    }
  } catch {
    /* falha nos provedores de coordenadas */
  }

  throw new Error("Não foi possível identificar o município pelas coordenadas do GPS.");
}

/** Fallback por rede/IP quando o GPS de hardware está indisponível ou negado. */
async function detectPlaceByIP(): Promise<{ city: string; uf: string }> {
  // 1. api-bdc.io (geolocalização por IP do cliente)
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch(
      "https://api-bdc.io/data/reverse-geocode-client?localityLanguage=pt",
      { signal: ctrl.signal }
    );
    clearTimeout(t);
    if (res.ok) {
      const data = await res.json();
      const city = extractCityFromBdc(data);
      const uf = resolveUF(data.principalSubdivision, data.principalSubdivisionCode);
      if (city && uf) return { city, uf };
    }
  } catch {
    /* segue para o próximo provedor */
  }

  // 2. ipwho.is (serviço gratuito com alta disponibilidade)
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    const res = await fetch("https://ipwho.is/", { signal: ctrl.signal });
    clearTimeout(t);
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.city) {
        const uf = resolveUF(data.region, data.region_code);
        if (uf) return { city: data.city, uf };
      }
    }
  } catch {
    /* segue para o próximo provedor */
  }

  throw new Error("Não foi possível detectar a localização pela rede/IP.");
}

/**
 * Localização atual: GPS do aparelho com alta precisão + geocodificação reversa
 * redundante e fallback inteligente para rede/IP. 100% funcional em qualquer dispositivo.
 */
export function detectCurrentPlace(): Promise<DetectedPlace> {
  return new Promise((resolve, reject) => {
    const tryIpFallback = async (priorError?: Error) => {
      try {
        const ipPlace = await detectPlaceByIP();
        const finalCity = await matchWithIbge(ipPlace.uf, ipPlace.city);
        resolve({
          city: finalCity,
          uf: ipPlace.uf,
          ufName: ufName(ipPlace.uf),
          method: "rede",
        });
      } catch (err) {
        reject(
          priorError ||
          (err instanceof Error
            ? err
            : new Error("Falha ao detectar sua cidade atual via GPS ou rede."))
        );
      }
    };

    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      void tryIpFallback(new Error("GPS não suportado neste aparelho"));
      return;
    }

    let settled = false;

    // Timeout de segurança caso o navegador congele a caixa de diálogo de permissão
    const fallbackTimer = setTimeout(() => {
      if (!settled) {
        console.warn("Tempo do GPS esgotado, acionando detecção por rede...");
        void tryIpFallback();
      }
    }, 10000);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        if (settled) return;
        settled = true;
        clearTimeout(fallbackTimer);
        try {
          const { latitude, longitude } = pos.coords;
          const { city, uf } = await reverseGeocodeCoords(latitude, longitude);
          const finalCity = await matchWithIbge(uf, city);
          resolve({
            city: finalCity,
            uf,
            ufName: ufName(uf),
            method: "gps",
          });
        } catch (err) {
          // Se falhar a conversão de coordenadas, tenta por IP
          void tryIpFallback(err instanceof Error ? err : undefined);
        }
      },
      (geoErr) => {
        if (settled) return;
        settled = true;
        clearTimeout(fallbackTimer);
        // Em caso de permissão negada, sinal indisponível ou timeout, usa fallback de rede sem frustrar o usuário
        console.warn("GPS indisponível no aparelho, usando rede:", geoErr.message);
        void tryIpFallback();
      },
      {
        enableHighAccuracy: true,
        timeout: 9000,
        maximumAge: 120000,
      }
    );
  });
}
