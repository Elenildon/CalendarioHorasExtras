/**
 * Gerenciador de Autenticação Biométrica Oficial.
 * 
 * REGRAS DE SEGURANÇA E PRIVACIDADE:
 * - O aplicativo NUNCA acessa, copia, armazena ou tenta obter dados biométricos do aparelho.
 * - Utiliza a API oficial de autenticação biométrica (BiometricPrompt nativo no Android ou WebAuthn).
 * - O app recebe exclusivamente o resultado:
 *     Autenticado → continuar
 *     Não autenticado / Cancelado → não registrar o ponto
 * - A biometria permanece 100% sob controle do sistema operacional.
 */

import { Capacitor, registerPlugin } from "@capacitor/core";

export interface BiometricAuthResult {
  success: boolean;
  method?: "AUTHENTICATED_BIOMETRIC" | "AUTHENTICATED_DEVICE";
  error?: string;
}

interface NativeBiometricPluginType {
  isAvailable(): Promise<{ available: boolean; hasFingerprintHardware?: boolean; isDeviceSecure?: boolean }>;
  authenticate(options: { title: string; subtitle: string; description: string }): Promise<BiometricAuthResult>;
}

const NativeBiometric = registerPlugin<NativeBiometricPluginType>("NativeBiometric");

/** Verifica se o dispositivo possui suporte nativo à biometria da plataforma */
export async function isNativeBiometricsAvailable(): Promise<boolean> {
  // 1. Android Nativo via Capacitor
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await NativeBiometric.isAvailable();
      return !!res.available;
    } catch {
      return true;
    }
  }

  // 2. Web / PWA
  try {
    if (
      typeof window !== "undefined" &&
      window.PublicKeyCredential &&
      typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === "function"
    ) {
      return await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    }
  } catch (e) {
    console.warn("Verificação biométrica não disponível no contexto atual:", e);
  }
  return false;
}

/**
 * Solicita a autenticação biométrica oficial ao sistema operacional.
 * No Android Nativo, invoca o BiometricPrompt oficial sem intermediários.
 * No Web / PWA, utiliza a verificação biométrica do dispositivo sem apresentar mensagens de erro falso.
 */
export async function requestNativeBiometrics(
  actionTitle: string,
  userDisplayName: string = "Colaborador"
): Promise<BiometricAuthResult> {
  // Feedback tátil sutil de início se suportado pelo dispositivo
  if (typeof navigator !== "undefined" && navigator.vibrate) {
    try {
      navigator.vibrate(30);
    } catch {}
  }

  // 1. Android Nativo (Capacitor BiometricPrompt oficial)
  if (Capacitor.isNativePlatform()) {
    try {
      const res = await NativeBiometric.authenticate({
        title: "Ponto Eletrônico",
        subtitle: actionTitle,
        description: "Posicione a sua digital no sensor para registrar o ponto",
      });

      if (res && res.success) {
        if (typeof navigator !== "undefined" && navigator.vibrate) {
          try {
            navigator.vibrate([40, 50, 40]);
          } catch {}
        }
        return {
          success: true,
          method: "AUTHENTICATED_BIOMETRIC",
        };
      }

      if (res && res.error === "cancelada") {
        return {
          success: false,
          error: "cancelada",
        };
      }

      return {
        success: false,
        error: res?.error || "Autenticação biométrica não concluída",
      };
    } catch (err: any) {
      console.warn("Erro ao acionar plugin nativo de biometria:", err);
    }
  }

  // 2. Web / PWA via WebAuthn Platform Authenticator
  if (
    typeof window !== "undefined" &&
    window.PublicKeyCredential &&
    typeof navigator.credentials?.create === "function"
  ) {
    try {
      const challenge = new Uint8Array(32);
      if (window.crypto?.getRandomValues) {
        window.crypto.getRandomValues(challenge);
      } else {
        for (let i = 0; i < 32; i++) challenge[i] = Math.floor(Math.random() * 256);
      }

      const userId = new Uint8Array(16);
      if (window.crypto?.getRandomValues) {
        window.crypto.getRandomValues(userId);
      } else {
        for (let i = 0; i < 16; i++) userId[i] = Math.floor(Math.random() * 256);
      }

      const publicKeyCredentialCreationOptions: PublicKeyCredentialCreationOptions = {
        challenge,
        rp: {
          name: "Ponto Eletrônico",
          id: window.location.hostname || "localhost",
        },
        user: {
          id: userId,
          name: userDisplayName.toLowerCase().replace(/[^a-z0-9]/g, "") || "colaborador",
          displayName: userDisplayName || "Colaborador",
        },
        pubKeyCredParams: [
          { alg: -7, type: "public-key" },
          { alg: -257, type: "public-key" },
        ],
        authenticatorSelection: {
          authenticatorAttachment: "platform",
          userVerification: "preferred",
          requireResidentKey: false,
        },
        timeout: 30000,
        attestation: "none",
      };

      const credential = await navigator.credentials.create({
        publicKey: publicKeyCredentialCreationOptions,
      });

      if (credential) {
        if (typeof navigator !== "undefined" && navigator.vibrate) {
          try {
            navigator.vibrate([40, 50, 40]);
          } catch {}
        }
        return {
          success: true,
          method: "AUTHENTICATED_BIOMETRIC",
        };
      }
    } catch (err: any) {
      // No navegador/PWA (especialmente em iframes), NotAllowedError ocorre frequentemente
      // por restrição de política de segurança ou ausência de chave física.
      // Não trata como cancelamento do usuário para permitir a autenticação biométrica em tela.
      return {
        success: false,
        error: "web_fallback",
      };
    }
  }

  return {
    success: false,
    error: "biometria_interativa_requerida",
  };
}
