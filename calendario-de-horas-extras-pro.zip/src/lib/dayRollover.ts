import { useState, useEffect } from "react";

export interface LiveDayInfo {
  today: Date;
  todayISO: string; // YYYY-MM-DD
  year: number;
  month: number;    // 0-indexed (0 = Janeiro, 11 = Dezembro)
  day: number;      // 1-31
  formattedBR: string; // DD/MM/AAAA
}

/** Formata data local para YYYY-MM-DD */
export function getLiveTodayISO(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

/** Retorna informações completas do dia atual no fuso local */
export function getLiveTodayInfo(d = new Date()): LiveDayInfo {
  const y = d.getFullYear();
  const m = d.getMonth();
  const day = d.getDate();
  const iso = getLiveTodayISO(d);
  const formattedBR = `${String(day).padStart(2, "0")}/${String(m + 1).padStart(2, "0")}/${y}`;

  return {
    today: new Date(y, m, day),
    todayISO: iso,
    year: y,
    month: m,
    day,
    formattedBR,
  };
}

// Armazena a última data ISO registrada globalmente
let lastRecordedISO = getLiveTodayISO();
let isWatcherInitialized = false;

/**
 * Dispara notificação global de virada de dia para todos os ouvintes do app
 */
export function notifyDayChanged(info = getLiveTodayInfo()): void {
  lastRecordedISO = info.todayISO;
  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("che:day-changed", {
        detail: info,
      })
    );
  }
}

/**
 * Inicia o motor automático de virada de dia (Day Rollover Engine):
 * 1. Calcula os milissegundos exatos até a próxima meia-noite (00:00:00.050)
 * 2. Mantém heartbeat a cada 30 segundos (evita travamento de timers quando o celular entra em economia de bateria)
 * 3. Monitora visibilidade e foco da janela (retorno de tela de bloqueio ou background no iPhone/Android)
 */
export function initDayRolloverWatcher(): () => void {
  if (typeof window === "undefined" || isWatcherInitialized) {
    return () => {};
  }
  isWatcherInitialized = true;

  let midnightTimer: NodeJS.Timeout | null = null;
  let heartbeatTimer: NodeJS.Timeout | null = null;

  const checkDayChange = () => {
    const currentISO = getLiveTodayISO();
    if (currentISO !== lastRecordedISO) {
      const newInfo = getLiveTodayInfo();
      notifyDayChanged(newInfo);
    }
  };

  const scheduleNextMidnight = () => {
    if (midnightTimer) clearTimeout(midnightTimer);

    const now = new Date();
    // Próxima meia-noite + 100ms de folga para garantir que a data virou no sistema operacional
    const nextMidnight = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 1,
      0,
      0,
      0,
      100
    );
    const msUntilMidnight = Math.max(500, nextMidnight.getTime() - now.getTime());

    midnightTimer = setTimeout(() => {
      checkDayChange();
      scheduleNextMidnight();
    }, msUntilMidnight);
  };

  scheduleNextMidnight();

  // Heartbeat a cada 30 segundos para checagem rápida caso o aparelho durma
  heartbeatTimer = setInterval(() => {
    checkDayChange();
  }, 30000);

  // Verificação instantânea ao acordar o celular / aba voltar a ser visível
  const handleVisibilityChange = () => {
    if (document.visibilityState === "visible") {
      checkDayChange();
      scheduleNextMidnight();
    }
  };

  const handleFocus = () => {
    checkDayChange();
  };

  document.addEventListener("visibilitychange", handleVisibilityChange);
  window.addEventListener("focus", handleFocus);
  window.addEventListener("online", checkDayChange);

  return () => {
    if (midnightTimer) clearTimeout(midnightTimer);
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    document.removeEventListener("visibilitychange", handleVisibilityChange);
    window.removeEventListener("focus", handleFocus);
    window.removeEventListener("online", checkDayChange);
    isWatcherInitialized = false;
  };
}

/**
 * Hook do React para sincronização automática dia após dia.
 * Sempre que o dia virar (meia-noite ou retorno do celular), o componente
 * que utiliza este hook é re-renderizado com a nova data imediatamente.
 */
export function useLiveDay(): LiveDayInfo {
  const [dayInfo, setDayInfo] = useState<LiveDayInfo>(() => getLiveTodayInfo());

  useEffect(() => {
    // Garante que o watcher global esteja rodando
    initDayRolloverWatcher();

    const handleDayEvent = (e: Event) => {
      const customEvent = e as CustomEvent<LiveDayInfo>;
      if (customEvent.detail) {
        setDayInfo(customEvent.detail);
      } else {
        setDayInfo(getLiveTodayInfo());
      }
    };

    window.addEventListener("che:day-changed", handleDayEvent);

    // Faz uma checagem inicial ao montar o hook
    const currentISO = getLiveTodayISO();
    if (currentISO !== dayInfo.todayISO) {
      setDayInfo(getLiveTodayInfo());
    }

    return () => {
      window.removeEventListener("che:day-changed", handleDayEvent);
    };
  }, [dayInfo.todayISO]);

  return dayInfo;
}
