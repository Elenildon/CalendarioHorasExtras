/**
 * Armazenamento local resiliente.
 * Todas as anotações do calendário são gravadas imediatamente no aparelho
 * (localStorage) — sobrevivem ao fechamento do app, recarregamento da página
 * e à rolagem. Também há migração dos dados das versões anteriores.
 */

export const KEYS = {
  settings: "che.settings.v2",
  entries: "che.entries.v2",
  sim: "che.sim.v2",
  savedAt: "che.savedAt.v2",
} as const;

const LEGACY = {
  settings: "che.settings",
  entries: ["che.calendar.entries.v3", "che.entries.v2", "che.entries"],
  sim: ["che.resumo.sim.v3", "che.sim.v2", "che.sim"],
} as const;

function readRaw(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

/** Lê objeto mesclando com os padrões (tolerante a campos novos). */
export function readObject<T extends object>(key: string, fallback: T, legacy?: string | readonly string[]): T {
  let raw = readRaw(key);
  if (!raw && legacy) {
    if (Array.isArray(legacy)) {
      for (const k of legacy) {
        raw = readRaw(k);
        if (raw) break;
      }
    } else {
      raw = readRaw(legacy as string);
    }
  }
  if (!raw) return fallback;
  try {
    return { ...fallback, ...(JSON.parse(raw) as object) } as T;
  } catch {
    return fallback;
  }
}

/** Lê mapa de anotações (sem merge — os dados do usuário mandam). */
export function readMap<T>(key: string, fallback: T, legacy?: string | readonly string[]): T {
  let raw = readRaw(key);
  if (!raw && legacy) {
    if (Array.isArray(legacy)) {
      for (const k of legacy) {
        raw = readRaw(k);
        if (raw) break;
      }
    } else {
      raw = readRaw(legacy as string);
    }
  }
  if (!raw) return fallback;
  try {
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object") return parsed as T;
    return fallback;
  } catch {
    return fallback;
  }
}

/** Gravação imediata e silenciosa. */
export function write(key: string, value: unknown): boolean {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function writeSavedAt(): void {
  write(KEYS.savedAt, Date.now());
}

export function readSavedAt(): number | null {
  const raw = readRaw(KEYS.savedAt);
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

export const legacyKeys = LEGACY;

/** Hora no formato HH:MM:SS para indicador de salvamento. */
export const fmtClock = (ts: number) =>
  new Date(ts).toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
