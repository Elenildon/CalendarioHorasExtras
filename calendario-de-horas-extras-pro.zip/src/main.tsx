import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App";

const rootElement = document.getElementById("root");
if (rootElement) {
  createRoot(rootElement).render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}

// Registro seguro do Service Worker (apenas em produção e sem bloquear a renderização)
if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  try {
    if (import.meta.env.PROD) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("/sw.js").catch(() => {});
      });
    } else {
      // Em ambiente de desenvolvimento e preview, remove workers anteriores para evitar tela preta ou cache inválido
      navigator.serviceWorker.getRegistrations().then((registrations) => {
        for (const registration of registrations) {
          registration.unregister().catch(() => {});
        }
      }).catch(() => {});
    }
  } catch {
    // Silencia qualquer erro em navegadores antigos ou iframes
  }
}

