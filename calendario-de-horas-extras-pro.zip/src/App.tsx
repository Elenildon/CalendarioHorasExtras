import { useEffect, useMemo, useRef, useState } from "react";
import { ArrowUp, BadgeCheck, CalendarDays, CheckCheck, LayoutDashboard, Loader2, Lock, ShieldCheck } from "lucide-react";
import Toolbar from "./components/Toolbar";
import CalendarView from "./components/CalendarView";
import CalendarErrorBoundary from "./components/CalendarErrorBoundary";
import DaySheet from "./components/DaySheet";
import Panel from "./components/Panel";
import WelcomeScreen from "./components/WelcomeScreen";
import BiometriaModal from "./components/BiometriaModal";
import {
  APP_VERSION,
  computeSummary,
  dateKey,
  DEFAULT_SETTINGS,
  LEGACY_SAMPLE_ENTRIES,
  sanitizeEntries,
  sanitizeSettings,
  sanitizeSim,
  type DayEntry,
  type Settings,
  type SimState,
} from "./lib/calc";
import {
  KEYS,
  fmtClock,
  legacyKeys,
  readMap,
  readObject,
  readSavedAt,
  write,
  writeSavedAt,
} from "./lib/storage";
import { cn } from "./utils/cn";
import { isValidUF } from "./lib/locations";
import { useLiveDay, type LiveDayInfo } from "./lib/dayRollover";
import iconUrl from "./assets/icon.png";
import {
  auth,
  loginWithGoogle,
  onAuthStateChanged,
  loadUserDataFromCloud,
  saveUserDataToCloud,
  saveCalendarEntriesToCloud,
  saveSettingsToCloud,
  type User as FirebaseUser,
} from "./lib/firebase";
import {
  loadProtectedResumoSim,
  persistProtectedResumoSim,
  protectResumoTransition,
} from "./lib/resumoState";
import AccountModal from "./components/AccountModal";
import ShareModal from "./components/ShareModal";
import MenuModal from "./components/MenuModal";
import InstallAppModal from "./components/InstallAppModal";
import QuickStartGuide from "./components/QuickStartGuide";
import IntervalAlarmAlertModal from "./components/IntervalAlarmAlertModal";
import {
  checkDueAlarm,
  getActiveAlarm,
  stopAlarmAudiovisual,
  wakeScreenIfPossible,
  type ActiveIntervalAlarm,
} from "./lib/intervalAlarm";
import { resyncAllPontosToCalendar } from "./lib/pontoStorage";

type ColorMode = "original" | "white";

function readColorMode(): ColorMode {
  try {
    return localStorage.getItem("che.color-mode") === "white" ? "white" : "original";
  } catch {
    return "original";
  }
}

function readManualEntries() {
  resyncAllPontosToCalendar();
  const stored = sanitizeEntries(
    readMap<Record<string, DayEntry>>(KEYS.entries, {}, legacyKeys.entries)
  );
  const cleaned = { ...stored };
  let removedLegacySamples = false;

  // Remove somente os exemplos sem savedAt e preserva qualquer lançamento
  // que tenha sido editado/salvo manualmente pelo usuário.
  Object.entries(LEGACY_SAMPLE_ENTRIES).forEach(([key, sample]) => {
    const entry = cleaned[key];
    const isUntouchedSample =
      entry &&
      !entry.savedAt &&
      entry.hours === sample.hours &&
      entry.minutes === sample.minutes &&
      entry.noturno === sample.noturno &&
      (entry.note ?? "").trim() === "";

    if (isUntouchedSample) {
      delete cleaned[key];
      removedLegacySamples = true;
    }
  });

  if (removedLegacySamples) write(KEYS.entries, cleaned);
  return cleaned;
}

export default function App() {
  const [tab, setTab] = useState<"cal" | "painel">("painel");
  const [colorMode, setColorMode] = useState<ColorMode>(readColorMode);
  // Data viva em tempo real sincronizada automaticamente dia após dia
  const liveDay = useLiveDay();
  const [cursor, setCursor] = useState(() => ({ y: liveDay.year, m: liveDay.month }));
  const [selected, setSelected] = useState<{ y: number; m: number; d: number } | null>(null);

  const [settings, setSettings] = useState<Settings>(() => {
    const loaded = sanitizeSettings(
      readObject<Settings>(KEYS.settings, DEFAULT_SETTINGS, legacyKeys.settings)
    );
    // Garante dados corretos do usuário mantendo os valores padrão se estiverem vazios
    if (!loaded.name || loaded.name === "Elenildon Rocha") {
      loaded.name = "Elenildon Estevão";
    }
    if (!loaded.cargo) {
      loaded.cargo = "Montador B";
    }
    if (!loaded.empresa) {
      loaded.empresa = "CNS Central de Núcleos Siliciosos";
    }
    return loaded;
  });

  // Exibe a tela de boas-vindas renovada com fundo branco suave e bordas
  const [showWelcomeScreen, setShowWelcomeScreen] = useState<boolean>(true);
  const [entries, setEntries] = useState<Record<string, DayEntry>>(readManualEntries);
  const [sim, setSim] = useState<SimState>(loadProtectedResumoSim);
  const [toast, setToast] = useState<string | null>(null);
  const [showTop, setShowTop] = useState(false);
  const [lastSaved, setLastSaved] = useState<number | null>(() => readSavedAt());

  // Estado Firebase & Cloud Firestore
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [lastCloudSync, setLastCloudSync] = useState<number | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [installModalTab, setInstallModalTab] = useState<"auto" | "ios" | "android" | "qr">("auto");
  const [menuModalOpen, setMenuModalOpen] = useState(false);
  const [biometriaModalOpen, setBiometriaModalOpen] = useState(false);
  const [intervalAlarmAlertOpen, setIntervalAlarmAlertOpen] = useState(false);
  const [activeIntervalAlarm, setActiveIntervalAlarm] = useState<ActiveIntervalAlarm | null>(null);
  const [autoTriggerRetorno, setAutoTriggerRetorno] = useState(false);
  const [privacyMode, setPrivacyMode] = useState<boolean>(() => {
    try {
      localStorage.removeItem("che.custom-biometria-icon");
      return localStorage.getItem("che.privacy-mode") === "true";
    } catch {
      return false;
    }
  });

  const calendarDebounceRef = useRef<NodeJS.Timeout | null>(null);
  const settingsDebounceRef = useRef<NodeJS.Timeout | null>(null);

  const handleOpenMenu = () => {
    setMenuModalOpen(true);
  };

  // monitora autenticação do Firebase e sincroniza Firestore
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (u) => {
      setFirebaseUser(u);
      if (u) {
        setIsSyncing(true);
        try {
          const cloud = await loadUserDataFromCloud(u.uid);
          if (cloud && cloud.settings) {
            const clean = sanitizeSettings(cloud.settings);
            // Preenche automaticamente o campo de usuário com o nome da conta do Google
            if (u.displayName && u.displayName.trim().length > 0) {
              clean.name = u.displayName;
            }
            // Se veio com os valores padrão legados, garante campos limpos para novo preenchimento
            if (clean.cargo === "Montador B") {
              clean.cargo = "";
            }
            if (clean.empresa === "CNS") {
              clean.empresa = "";
            }
            setSettings(clean);
            write(KEYS.settings, clean);

            if (cloud.entries) {
              const cleanEntries = sanitizeEntries(cloud.entries);
              setEntries(cleanEntries);
              write(KEYS.entries, cleanEntries);
            }
            if (cloud.sim) {
              const cleanSim = protectResumoTransition(simRef.current, sanitizeSim(cloud.sim));
              setSim(cleanSim);
              persistProtectedResumoSim(cleanSim);
            }
            setLastCloudSync(Date.now());
            setToast(`Conectado como ${u.displayName || "Google"} · Nuvem sincronizada`);
          } else {
            // Acessando pela primeira vez a conta do Google:
            // Preenche o nome do usuário automaticamente com a conta Google
            const currentSettings = settingsRef.current;
            const settingsToSave: Settings = {
              ...currentSettings,
              name: (u.displayName && u.displayName.trim().length > 0) ? u.displayName : currentSettings.name,
              cargo: currentSettings.cargo || "",
              empresa: currentSettings.empresa || "",
            };
            setSettings(settingsToSave);
            write(KEYS.settings, settingsToSave);
            await saveUserDataToCloud(u.uid, {
              settings: settingsToSave,
              sim: simRef.current,
              entries: entriesRef.current,
            });
            setLastCloudSync(Date.now());
            setToast(`Conectado como ${u.displayName || "Google"} · Nome preenchido automaticamente`);
          }
        } catch (err) {
          console.error("Erro ao sincronizar Firestore:", err);
        } finally {
          setIsSyncing(false);
        }
      }
    });
    return () => {
      unsubscribe();
      if (calendarDebounceRef.current) clearTimeout(calendarDebounceRef.current);
      if (settingsDebounceRef.current) clearTimeout(settingsDebounceRef.current);
    };
  }, []);

  // Escuta toque em notificação do despertador para abrir direto o Ponto Biométrico no Retorno do Intervalo
  useEffect(() => {
    const handleOpenRetorno = () => {
      wakeScreenIfPossible().catch(() => {});
      stopAlarmAudiovisual();
      setIntervalAlarmAlertOpen(false);
      setAutoTriggerRetorno(true);
      setBiometriaModalOpen(true);
    };

    const handleAlarmFired = () => {
      wakeScreenIfPossible().catch(() => {});
      setActiveIntervalAlarm(getActiveAlarm());
      setIntervalAlarmAlertOpen(true);
    };

    const handleSilenceAlarm = () => {
      stopAlarmAudiovisual();
      setIntervalAlarmAlertOpen(false);
    };

    window.addEventListener("che:open-ponto-retorno", handleOpenRetorno);
    window.addEventListener("che:alarm-fired", handleAlarmFired);
    window.addEventListener("che:silence-alarm", handleSilenceAlarm);

    // Checa se há alarme pendente que já venceu e deve soar
    const due = checkDueAlarm();
    if (due) {
      wakeScreenIfPossible().catch(() => {});
      setActiveIntervalAlarm(due);
      setIntervalAlarmAlertOpen(true);
    }

    if (typeof window !== "undefined") {
      if (window.location.search.includes("open-ponto-retorno")) {
        handleOpenRetorno();
        try {
          const url = new URL(window.location.href);
          url.searchParams.delete("action");
          url.searchParams.delete("autoTrigger");
          window.history.replaceState({}, "", url.pathname);
        } catch {}
      }

      if ("serviceWorker" in navigator) {
        const onSwMessage = (e: MessageEvent) => {
          if (e.data?.type === "che:open-ponto-retorno") {
            handleOpenRetorno();
          } else if (e.data?.type === "che:silence-alarm") {
            handleSilenceAlarm();
          }
        };
        navigator.serviceWorker.addEventListener("message", onSwMessage);
        return () => {
          window.removeEventListener("che:open-ponto-retorno", handleOpenRetorno);
          window.removeEventListener("che:alarm-fired", handleAlarmFired);
          window.removeEventListener("che:silence-alarm", handleSilenceAlarm);
          navigator.serviceWorker.removeEventListener("message", onSwMessage);
        };
      }
    }

    return () => {
      window.removeEventListener("che:open-ponto-retorno", handleOpenRetorno);
      window.removeEventListener("che:alarm-fired", handleAlarmFired);
      window.removeEventListener("che:silence-alarm", handleSilenceAlarm);
    };
  }, []);

  // agenda salvamento em nuvem exclusivo do Calendário (não toca no Resumo do Mês)
  const scheduleCalendarCloudSave = () => {
    if (!auth.currentUser) return;
    if (calendarDebounceRef.current) clearTimeout(calendarDebounceRef.current);
    calendarDebounceRef.current = setTimeout(() => {
      if (auth.currentUser) {
        setIsSyncing(true);
        saveCalendarEntriesToCloud(auth.currentUser.uid, entriesRef.current).then((ok) => {
          if (ok) setLastCloudSync(Date.now());
          setIsSyncing(false);
        });
      }
    }, 1500);
  };

  // agenda salvamento em nuvem exclusivo das Configurações
  const scheduleSettingsCloudSave = () => {
    if (!auth.currentUser) return;
    if (settingsDebounceRef.current) clearTimeout(settingsDebounceRef.current);
    settingsDebounceRef.current = setTimeout(() => {
      if (auth.currentUser) {
        setIsSyncing(true);
        saveSettingsToCloud(auth.currentUser.uid, settingsRef.current).then((ok) => {
          if (ok) setLastCloudSync(Date.now());
          setIsSyncing(false);
        });
      }
    }, 1500);
  };

  // Atualizador seguro com salvamento automático para configurações e perfil
  const updateSettings = (patch: Partial<Settings>, immediate = false) => {
    setSettings((s) => {
      const next = { ...s, ...patch };
      write(KEYS.settings, next);
      if (auth.currentUser) {
        if (immediate) {
          if (settingsDebounceRef.current) clearTimeout(settingsDebounceRef.current);
          setIsSyncing(true);
          saveSettingsToCloud(auth.currentUser.uid, next).then((ok) => {
            if (ok) setLastCloudSync(Date.now());
            setIsSyncing(false);
          });
        } else {
          scheduleSettingsCloudSave();
        }
      }
      return next;
    });
  };

  // Atualizador seguro e protegido para o Resumo do Mês (só dispara por ação explícita)
  const updateSimSafely: React.Dispatch<React.SetStateAction<SimState>> = (action) => {
    setSim((prev) => {
      const next = typeof action === "function" ? action(prev) : action;
      const guarded = protectResumoTransition(prev, next);
      persistProtectedResumoSim(guarded);
      return guarded;
    });
  };

  const syncWithCloudNow = async () => {
    if (!firebaseUser) return;
    setIsSyncing(true);
    const ok = await saveUserDataToCloud(firebaseUser.uid, {
      settings: settingsRef.current,
      sim: simRef.current,
      entries: entriesRef.current,
    });
    if (ok) {
      setLastCloudSync(Date.now());
      setToast("Nuvem sincronizada com sucesso!");
    } else {
      setToast("Falha ao sincronizar com a nuvem.");
    }
    setIsSyncing(false);
  };

  // garante UF válida salva (migração de versões antigas)
  useEffect(() => {
    const uf = (settings.state || "").toUpperCase();
    if (!isValidUF(uf) || !settings.city) {
      setSettings((s) => ({
        ...s,
        state: isValidUF(uf) ? uf : "MG",
        city: s.city || "Extrema",
      }));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // O sol alterna somente as cores; a preferência permanece salva no aparelho.
  useEffect(() => {
    const isWhite = colorMode === "white";
    document.body.classList.toggle("white-mode", isWhite);
    document.documentElement.classList.toggle("white-mode", isWhite);
    document.documentElement.style.colorScheme = isWhite ? "light" : "dark";
    document
      .querySelector('meta[name="theme-color"]')
      ?.setAttribute("content", isWhite ? "#ffffff" : "#070b18");
    document
      .querySelector('meta[name="color-scheme"]')
      ?.setAttribute("content", isWhite ? "light" : "dark");
    try {
      localStorage.setItem("che.color-mode", colorMode);
    } catch {
      /* mantém a cor atual caso o armazenamento esteja indisponível */
    }
  }, [colorMode]);

  // mantém referências atualizadas para gravação em qualquer saída
  const entriesRef = useRef(entries);
  const settingsRef = useRef(settings);
  const simRef = useRef(sim);
  entriesRef.current = entries;
  settingsRef.current = settings;
  simRef.current = sim;

  /** Grava com total isolamento entre os módulos no aparelho e na nuvem se autenticado. */
  const flush = () => {
    write(KEYS.entries, entriesRef.current);
    write(KEYS.settings, settingsRef.current);
    persistProtectedResumoSim(simRef.current);
    writeSavedAt();
    setLastSaved(Date.now());
  };

  // gravação a cada alteração (totalmente desacoplados e sem cross-talk)
  useEffect(() => {
    write(KEYS.settings, settings);
    scheduleSettingsCloudSave();
  }, [settings]);

  useEffect(() => {
    write(KEYS.entries, entries);
    scheduleCalendarCloudSave();
  }, [entries]);

  // segurança extra: grava ao sair, minimizar, trocar de app/aba ou rolar
  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === "hidden") flush();
    };
    window.addEventListener("pagehide", flush);
    window.addEventListener("beforeunload", flush);
    document.addEventListener("visibilitychange", onHide);
    return () => {
      window.removeEventListener("pagehide", flush);
      window.removeEventListener("beforeunload", flush);
      document.removeEventListener("visibilitychange", onHide);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sincroniza o estado das anotações do calendário quando o Ponto Biométrico é registrado ou corrigido
  useEffect(() => {
    const handlePontoUpdated = () => {
      setEntries(readManualEntries());
    };
    window.addEventListener("che:ponto-updated", handlePontoUpdated);
    return () => {
      window.removeEventListener("che:ponto-updated", handlePontoUpdated);
    };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2200);
    return () => clearTimeout(t);
  }, [toast]);

  // botão "voltar ao topo": aparece após rolar um pouco
  useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(() => {
        setShowTop(window.scrollY > 320);
        ticking = false;
      });
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  useEffect(() => {
    let link = document.querySelector<HTMLLinkElement>('link[rel="icon"]');
    if (!link) {
      link = document.createElement("link");
      link.rel = "icon";
      link.type = "image/png";
      document.head.appendChild(link);
    }
    link.href = iconUrl;
  }, []);

  const stats = useMemo(
    () => computeSummary(cursor.y, cursor.m, settings, sim),
    [cursor, settings, sim]
  );

  const initials = useMemo(() => {
    const parts = settings.name.trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) return "U";
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }, [settings.name]);

  const selectedKey = selected ? dateKey(selected.y, selected.m, selected.d) : null;
  const selectedEntry = selectedKey ? entries[selectedKey] : undefined;

  const saveEntry = (payload: DayEntry) => {
    if (!selectedKey) return;
    const next = { ...entriesRef.current };
    if (payload.hours === 0 && payload.minutes === 0 && !(payload.note ?? "").trim()) {
      delete next[selectedKey];
    } else {
      next[selectedKey] = { ...payload, savedAt: Date.now() };
    }
    // gravação imediata, antes mesmo do próximo render
    write(KEYS.entries, next);
    writeSavedAt();
    setLastSaved(Date.now());
    setEntries(next);
    setSelected(null);
    setToast("Anotação salva no aparelho");
  };

  const deleteEntry = () => {
    if (!selectedKey) return;
    const next = { ...entriesRef.current };
    delete next[selectedKey];
    write(KEYS.entries, next);
    writeSavedAt();
    setLastSaved(Date.now());
    setEntries(next);
    setSelected(null);
    setToast("Anotação apagada");
  };

  // 🔒 MOTOR EXCLUSIVO DO CALENDÁRIO: Comunicação exclusiva com Adicionar Apontamento, Calendário e Lançamentos de Setembro
  const saveAppointmentFromMotor = (dateStr: string, payload: DayEntry) => {
    const next = { ...entriesRef.current };
    next[dateStr] = { ...payload, savedAt: Date.now() };
    write(KEYS.entries, next);
    writeSavedAt();
    setLastSaved(Date.now());
    setEntries(next);
    scheduleCalendarCloudSave();
    const parts = dateStr.split("-").map(Number);
    if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1])) {
      setCursor({ y: parts[0], m: parts[1] - 1 });
    }
    setTab("cal");
  };

  const deleteAppointmentFromMotor = (dateStr: string) => {
    const next = { ...entriesRef.current };
    delete next[dateStr];
    write(KEYS.entries, next);
    writeSavedAt();
    setLastSaved(Date.now());
    setEntries(next);
    scheduleCalendarCloudSave();
  };

  // 🔄 ATUALIZAÇÃO AUTOMÁTICA DE TODOS OS CALENDÁRIOS DO APLICATIVO DIA APÓS DIA
  useEffect(() => {
    const handleDayChanged = (e: Event) => {
      const customEvent = e as CustomEvent<LiveDayInfo>;
      const detail = customEvent.detail;
      if (!detail) return;

      // Se o cursor estiver acompanhando o mês corrente, atualiza o cursor automaticamente na virada do mês
      setCursor((prev) => {
        if (prev.y === detail.year && prev.m === (detail.month + 11) % 12) {
          return { y: detail.year, m: detail.month };
        }
        return prev;
      });

      // Se o dia selecionado for o dia anterior, avança a seleção automaticamente
      setSelected((prevSel) => {
        if (!prevSel) return null;
        return { y: detail.year, m: detail.month, d: detail.day };
      });
    };

    window.addEventListener("che:day-changed", handleDayChanged);
    return () => window.removeEventListener("che:day-changed", handleDayChanged);
  }, []);

  const goToday = () => {
    setCursor({ y: liveDay.year, m: liveDay.month });
    setSelected({ y: liveDay.year, m: liveDay.month, d: liveDay.day });
  };

  // Referências para acesso sempre atualizado nos manipuladores de voltar
  const tabRef = useRef(tab);
  tabRef.current = tab;
  const selectedRef = useRef(selected);
  selectedRef.current = selected;
  const accountModalOpenRef = useRef(accountModalOpen);
  accountModalOpenRef.current = accountModalOpen;
  const shareModalOpenRef = useRef(shareModalOpen);
  shareModalOpenRef.current = shareModalOpen;
  const installModalOpenRef = useRef(installModalOpen);
  installModalOpenRef.current = installModalOpen;
  const menuModalOpenRef = useRef(menuModalOpen);
  menuModalOpenRef.current = menuModalOpen;
  const biometriaModalOpenRef = useRef(biometriaModalOpen);
  biometriaModalOpenRef.current = biometriaModalOpen;

  // Função central de navegação ao voltar: NUNCA sai do app, sempre volta telas até o Painel principal
  const handleGoBack = () => {
    // 1. Permite que componentes internos com sub-modais (ex.: Biometria/Confirmação/Localização/Avatar)
    // interceptem a navegação de voltar chamando e.preventDefault()
    const ev = new CustomEvent("che:back-navigation", { cancelable: true });
    window.dispatchEvent(ev);
    if (ev.defaultPrevented) {
      return;
    }

    // 2. Fecha modais de tela cheia ou caixas de diálogo abertas
    if (selectedRef.current) {
      setSelected(null);
      return;
    }
    if (biometriaModalOpenRef.current) {
      setBiometriaModalOpen(false);
      return;
    }
    if (menuModalOpenRef.current) {
      setMenuModalOpen(false);
      return;
    }
    if (accountModalOpenRef.current) {
      setAccountModalOpen(false);
      return;
    }
    if (shareModalOpenRef.current) {
      setShareModalOpen(false);
      return;
    }
    if (installModalOpenRef.current) {
      setInstallModalOpen(false);
      return;
    }

    // 3. Se estiver na tela do Calendário, volta para o Painel principal
    if (tabRef.current === "cal") {
      setTab("painel");
      setToast("Retornou ao Painel principal");
      return;
    }

    // 4. Se já estiver no Painel principal: NUNCA sai do aplicativo! Mantém o usuário seguro no Painel
    setToast("Você já está no Painel principal");
  };

  // Intercepta comandos de voltar do celular (gesto/botão voltar) e do teclado (Escape, Back, Backspace)
  // para que o app nunca saia abruptamente, retornando sempre ao Painel principal.
  useEffect(() => {
    // Inicializa a proteção no histórico do navegador/PWA para impedir saída acidental
    try {
      if (!window.history.state || window.history.state.cheApp !== "active") {
        window.history.replaceState({ cheApp: "root", ts: Date.now() }, "");
        window.history.pushState({ cheApp: "active", ts: Date.now() }, "");
      }
    } catch {}

    const onPopState = (e: PopStateEvent) => {
      e.preventDefault();
      // Sempre restaura o guard no histórico para que novos comandos "voltar" do celular
      // continuem sendo interceptados e nunca fechem o app
      try {
        window.history.pushState({ cheApp: "active", ts: Date.now() }, "");
      } catch {}
      handleGoBack();
    };

    const onKeyDown = (e: KeyboardEvent) => {
      // Teclas de voltar do celular, teclado físico ou teclado virtual:
      // Escape, GoBack (Android), BrowserBack, keyCode 27 ou keyCode 4 (Android back)
      const isBackKey =
        e.key === "Escape" ||
        e.key === "GoBack" ||
        e.key === "BrowserBack" ||
        e.keyCode === 27 ||
        e.keyCode === 4;

      if (isBackKey) {
        e.preventDefault();
        // Se houver input ativo com teclado aberto, remove o foco
        if (document.activeElement instanceof HTMLElement) {
          document.activeElement.blur();
        }
        handleGoBack();
        return;
      }

      // Backspace: só volta de tela se NÃO estiver digitando em campos de texto
      if (e.key === "Backspace" || e.keyCode === 8) {
        const target = e.target as HTMLElement | null;
        const isEditing =
          target &&
          (target.tagName === "INPUT" ||
            target.tagName === "TEXTAREA" ||
            target.tagName === "SELECT" ||
            target.isContentEditable);

        if (!isEditing) {
          e.preventDefault();
          handleGoBack();
        }
      }
    };

    window.addEventListener("popstate", onPopState);
    window.addEventListener("keydown", onKeyDown);

    return () => {
      window.removeEventListener("popstate", onPopState);
      window.removeEventListener("keydown", onKeyDown);
    };
  }, []);

  if (showWelcomeScreen || !settings.onboardFeito) {
    return (
      <div className={cn("app-shell", colorMode === "white" && "white-mode")}>
        <WelcomeScreen
          settings={settings}
          user={firebaseUser}
          onGoogleLogin={async () => {
            const u = await loginWithGoogle();
            if (u) {
              updateSettings({
                name: u.displayName || settings.name,
              }, true);
            }
            return u;
          }}
          onUpdate={(patch, immediate) => updateSettings(patch, immediate)}
          onEnter={() => {
            try {
              sessionStorage.setItem("welcome_renovada_white_v1", "true");
              sessionStorage.removeItem("jaFalouBoasVindas");
            } catch {}
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
          }}
          onOpenBiometria={() => {
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
            setBiometriaModalOpen(true);
          }}
          onOpenCalendar={() => {
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
            setTab("cal");
          }}
          onOpenHorasExtras={() => {
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
            setTab("cal");
            const now = new Date();
            setSelected({ y: now.getFullYear(), m: now.getMonth() + 1, d: now.getDate() });
          }}
          onOpenResumo={() => {
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
            setTab("painel");
          }}
          onOpenControle={() => {
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
            setTab("painel");
          }}
          onOpenPerfil={() => {
            setShowWelcomeScreen(false);
            updateSettings({ onboardFeito: true }, true);
            setAccountModalOpen(true);
          }}
        />
      </div>
    );
  }

  return (
    <div className={cn("app-shell", colorMode === "white" && "white-mode")}>
      <Toolbar
        initials={initials}
        avatarId={settings.avatarId}
        photoURL={settings.photoURL}
        userPhotoURL={firebaseUser?.photoURL || undefined}
        userLoggedIn={!!firebaseUser}
        whiteMode={colorMode === "white"}
        smartMode={settings.modoInteligente}
        onToggleSmart={() =>
          setSettings((s) => {
            const next = { ...s, modoInteligente: !s.modoInteligente };
            write(KEYS.settings, next);
            scheduleSettingsCloudSave();
            return next;
          })
        }
        onToggleColor={() =>
          setColorMode((mode) => (mode === "original" ? "white" : "original"))
        }
        onLogout={() => {
          try {
            sessionStorage.removeItem("welcome_renovada_white_v1");
          } catch {}
          setShowWelcomeScreen(true);
          setSettings((s) => {
            const next = { ...s, onboardFeito: false };
            write(KEYS.settings, next);
            scheduleSettingsCloudSave();
            return next;
          });
        }}
        onOpenAccount={() => setAccountModalOpen(true)}
        onOpenShare={() => setShareModalOpen(true)}
        onOpenInstall={(tab) => {
          setInstallModalTab(tab || "auto");
          setInstallModalOpen(true);
        }}
        onOpenMenu={handleOpenMenu}
        onOpenBiometria={() => setBiometriaModalOpen(true)}
      />

      {/* Indicador visual de sincronização da nuvem */}
      {isSyncing && (
        <div className="flex items-center justify-center gap-2 py-1.5 px-4 bg-gradient-to-r from-indigo-950 via-slate-900 to-indigo-950 border-b border-indigo-500/30 text-xs font-bold text-cyan-300">
          <Loader2 className="h-3.5 w-3.5 animate-spin text-cyan-400" />
          <span>Sincronizando dados com a nuvem Firebase...</span>
        </div>
      )}

      {/* Guia Rápido: Como Usar — Passo a Passo */}
      <div className="px-4 pt-2 pb-1">
        <QuickStartGuide
          onOpenAccount={() => setAccountModalOpen(true)}
          onOpenConfig={() => setTab("painel")}
          onOpenBiometria={() => setBiometriaModalOpen(true)}
          onOpenMenu={handleOpenMenu}
          onOpenShare={() => setShareModalOpen(true)}
          isSyncing={isSyncing}
        />
      </div>

      {/* abas */}
      <div className="px-4 pb-1">
        <div className="grid grid-cols-2 gap-1 rounded-2xl bg-slate-800/50 p-1.5">
          {(
            [
              { k: "cal", label: "Calendário", Icon: CalendarDays },
              { k: "painel", label: "Painel", Icon: LayoutDashboard },
            ] as const
          ).map(({ k, label, Icon }) => (
            <button
              key={k}
              type="button"
              onClick={() => setTab(k)}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl py-3 text-lg font-bold transition",
                tab === k ? "bg-slate-700/90 text-white shadow" : "text-slate-400"
              )}
            >
              <Icon className="h-5 w-5" />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* seletor de modo (só na aba Painel) */}
      {tab === "painel" && (
        <div className="px-4 pb-1">
          <div className="grid grid-cols-2 gap-2 rounded-2xl bg-slate-800/60 p-1.5 border border-slate-700/60">
            {(
              [
                {
                  k: "desativado",
                  label: settings.modo === "desativado" ? "Modo Simplificado Ativo" : "Modo Simplificado",
                  desc: "Apenas valor final",
                },
                {
                  k: "avancado",
                  label: settings.modo === "avancado" ? "Modo Avançado Ativo" : "Modo Avançado",
                  desc: "Cálculo detalhado + fórmulas",
                },
              ] as const
            ).map(({ k, label, desc }) => {
              const active = settings.modo === k;
              return (
                <button
                  key={k}
                  type="button"
                  onClick={() =>
                    setSettings((s) => {
                      const next = { ...s, modo: k };
                      write(KEYS.settings, next);
                      return next;
                    })
                  }
                  className={cn(
                    "flex flex-col items-center justify-center rounded-xl py-2 px-2 text-center transition-all duration-200 active:scale-95",
                    active
                      ? k === "avancado"
                        ? "bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg ring-1 ring-indigo-400"
                        : "bg-slate-700 text-white shadow ring-1 ring-slate-400/50"
                      : "text-slate-400 hover:text-slate-200 hover:bg-slate-800/40"
                  )}
                >
                  <span className="text-xs sm:text-sm font-black flex items-center gap-1.5">
                    {active && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />}
                    {label}
                  </span>
                  <span className={cn("text-[10px] mt-0.5 font-medium", active ? "text-slate-200" : "text-slate-400")}>
                    {desc}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* indicador de salvamento (só no Modo Avançado) */}
      {settings.modo === "avancado" && (
        <div className="flex items-center justify-center gap-2 px-4 py-2 text-sm text-emerald-400/90">
          <CheckCheck className="h-4 w-4" />
          <span>
            Anotações salvas automaticamente
            {lastSaved ? ` · ${fmtClock(lastSaved)}` : ""}
          </span>
        </div>
      )}

      {tab === "cal" ? (
        <CalendarErrorBoundary onReset={() => setSelected(null)}>
          <CalendarView
            year={cursor.y}
            month={cursor.m}
            entries={entries}
            settings={settings}
            onUpdateSettings={(patch) => updateSettings(patch)}
            onChangeMonth={(y, m) => setCursor({ y, m })}
            onToday={goToday}
            onSelect={(y, m, d) => {
              if (
                typeof y === "number" &&
                typeof m === "number" &&
                typeof d === "number" &&
                d >= 1 &&
                d <= 31
              ) {
                setSelected({ y, m, d });
              }
            }}
            onBackToPanel={() => setTab("painel")}
          />
        </CalendarErrorBoundary>
      ) : (
        <Panel
          settings={settings}
          update={updateSettings}
          sim={sim}
          setSim={updateSimSafely}
          stats={stats}
          month={cursor.m}
          year={cursor.y}
          onCalc={() => setToast("Cálculo atualizado!")}
        />
      )}

      {/* rodapé — crédito + selo de segurança */}
      <footer className="mt-2 px-4 pb-9 pt-2">
        <div className="mx-auto mb-4 h-px w-40 bg-gradient-to-r from-transparent via-slate-600/60 to-transparent" />
        <p className="flex items-center justify-center gap-1.5 text-center text-base text-slate-400">
          <span>
            © 2026 — Desenvolvido por{" "}
            <span className="bg-gradient-to-r from-indigo-300 via-violet-300 to-fuchsia-300 bg-clip-text text-lg font-extrabold tracking-tight text-transparent">
              Elenildon Rocha
            </span>
          </span>
          <span
            title="Criador verificado — app validado"
            className="inline-flex items-center justify-center rounded-full bg-emerald-600 p-0.5 text-white shadow-[0_0_12px_rgba(16,185,129,0.55)] ring-1 ring-emerald-300/70"
          >
            <BadgeCheck className="h-5 w-5" strokeWidth={2.4} />
          </span>
        </p>

        <div className="mt-3 flex flex-col items-center justify-center gap-1.5">
          <div className="seal-seguro inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-600 px-4 py-2 text-white shadow-[0_8px_24px_-8px_rgba(16,185,129,0.8)]">
            <ShieldCheck className="h-4 w-4 shrink-0" strokeWidth={2.5} />
            <span className="text-xs font-black tracking-[0.14em] uppercase">
              APP VALIDADO · 100% SEGURO
            </span>
          </div>
          <p className="mt-1 flex items-center justify-center gap-1.5 text-center text-xs text-slate-400 font-medium">
            <Lock className="h-3.5 w-3.5 text-emerald-400" />
            <span>Banco de dados Firestore criptografado e seguro</span>
          </p>
          <p className="flex items-center justify-center gap-1.5 text-center text-xs text-slate-500">
            {firebaseUser
              ? "Conectado com Google · Sincronizado na Nuvem Firestore"
              : "Conectado com Google · Sincronizado na Nuvem Firestore (aparelho & backup)"}
          </p>
          <p className="mt-1 text-center text-xs text-indigo-300 font-semibold tracking-wide">
            🌐 <span className="text-white font-bold">Calendário de Horas Extras PRO</span> · <span className="font-mono text-cyan-300">calendariodehorasextras.com.br</span>
          </p>
          <div className="mt-2.5 flex items-center justify-center">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-slate-700/80 bg-slate-800/80 px-3 py-1 text-xs font-semibold text-slate-300 shadow-sm backdrop-blur-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
              <span>Versão {APP_VERSION}</span>
            </span>
          </div>
        </div>
      </footer>

      {selected && (
        <CalendarErrorBoundary onReset={() => setSelected(null)}>
          <DaySheet
            date={selected}
            entry={selectedEntry}
            settings={settings}
            onClose={() => setSelected(null)}
            onSave={saveEntry}
            onDelete={deleteEntry}
          />
        </CalendarErrorBoundary>
      )}

      {accountModalOpen && (
        <AccountModal
          user={firebaseUser}
          settings={settings}
          lastCloudSync={lastCloudSync}
          isSyncing={isSyncing}
          onSyncNow={syncWithCloudNow}
          onClose={() => setAccountModalOpen(false)}
          onUpdateSettings={updateSettings}
          onOpenWelcome={() => {
            setAccountModalOpen(false);
            setShowWelcomeScreen(true);
          }}
        />
      )}

      {shareModalOpen && (
        <ShareModal
          settings={settings}
          stats={stats}
          cursor={cursor}
          entries={entries}
          smartMode={settings.modoInteligente}
          onToggleSmart={() =>
            setSettings((s) => {
              const next = { ...s, modoInteligente: !s.modoInteligente };
              write(KEYS.settings, next);
              scheduleSettingsCloudSave();
              return next;
            })
          }
          onClose={() => setShareModalOpen(false)}
          onShowToast={(msg) => setToast(msg)}
          onOpenInstall={(tab) => {
            setInstallModalTab(tab || "auto");
            setInstallModalOpen(true);
          }}
        />
      )}

      {installModalOpen && (
        <InstallAppModal
          onClose={() => setInstallModalOpen(false)}
          onShowToast={(msg) => setToast(msg)}
          onOpenAccount={() => setAccountModalOpen(true)}
          whiteMode={colorMode === "white"}
          initialTab={installModalTab}
        />
      )}

      {menuModalOpen && (
        <MenuModal
          onClose={() => setMenuModalOpen(false)}
          entries={entries}
          settings={settings}
          cursor={cursor}
          onSaveAppointment={saveAppointmentFromMotor}
          onDeleteAppointment={deleteAppointmentFromMotor}
          onNavigateDate={(y, m) => setCursor({ y, m })}
          onNavigateTab={(k) => setTab(k)}
          onShowToast={(msg) => setToast(msg)}
          whiteMode={colorMode === "white"}
        />
      )}

      {/* MODAL GLOBAL AUDIOVISUAL DO DESPERTADOR DE RETORNO DO INTERVALO */}
      <IntervalAlarmAlertModal
        isOpen={intervalAlarmAlertOpen}
        onClose={() => {
          stopAlarmAudiovisual();
          setIntervalAlarmAlertOpen(false);
        }}
        onRetomarIntervalo={() => {
          stopAlarmAudiovisual();
          setIntervalAlarmAlertOpen(false);
          setAutoTriggerRetorno(true);
          setBiometriaModalOpen(true);
        }}
        alarm={activeIntervalAlarm || getActiveAlarm()}
      />

      {biometriaModalOpen && (
        <BiometriaModal
          onClose={() => {
            setBiometriaModalOpen(false);
            setAutoTriggerRetorno(false);
          }}
          userName={settings.name || "Colaborador"}
          initialDate={selectedKey || undefined}
          autoTriggerRetorno={autoTriggerRetorno}
          onClearAutoTriggerRetorno={() => setAutoTriggerRetorno(false)}
          onOpenAppointment={() => {
            setMenuModalOpen(true);
          }}
          privacyMode={privacyMode}
          onTogglePrivacy={() => {
            setPrivacyMode((prev) => {
              const next = !prev;
              try {
                localStorage.setItem("che.privacy-mode", String(next));
              } catch {}
              setToast(next ? "Modo Privacidade ativado" : "Modo Privacidade desativado");
              return next;
            });
          }}
          onShowToast={(msg) => setToast(msg)}
        />
      )}

      {toast && (
        <div className="toast-anim fixed bottom-6 left-1/2 z-[60] -translate-x-1/2 rounded-2xl border border-indigo-400/40 bg-slate-900/95 px-6 py-3.5 text-lg font-semibold text-white shadow-2xl">
          {toast}
        </div>
      )}

      {/* voltar ao topo — fixo no canto inferior direito do app */}
      <button
        type="button"
        onClick={scrollToTop}
        aria-label="Voltar ao topo"
        title="Voltar ao topo"
        className={cn(
          "fixed bottom-6 right-[max(1rem,calc((100vw-30rem)/2+1rem))] z-50 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-900/60 ring-1 ring-white/25 transition-all duration-300 active:scale-90",
          showTop ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"
        )}
      >
        <ArrowUp className="h-6 w-6" strokeWidth={2.5} />
      </button>
    </div>
  );
}
