// Service Worker para Calendário de Horas Extras PRO
const CACHE_NAME = "che-pwa-v1";
const PRECACHE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/apple-touch-icon.png",
  "/pwa-192x192.png",
  "/pwa-512x512.png",
  "/sounds/pulse.wav",
  "/sounds/digital-wake.wav",
  "/sounds/neon-rise.wav",
  "/sounds/smart-alert.wav",
  "/sounds/deep-wake.wav",
  "/sounds/focus-alarm.wav",
  "/sounds/energy-boost.wav",
  "/sounds/crystal-bell.wav",
  "/sounds/power-alert.wav",
  "/sounds/emergency-pulse.wav"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(PRECACHE_ASSETS).catch((err) => {
        console.warn("Pre-cache warning:", err);
      });
    })
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  // Ignora chamadas para APIs externas, Firebase e scripts de desenvolvimento do Vite
  if (
    !event.request.url.startsWith(self.location.origin) ||
    event.request.method !== "GET" ||
    event.request.url.includes("/@") ||
    event.request.url.includes("/src/") ||
    event.request.url.includes("node_modules") ||
    self.location.hostname.includes("ais-dev-")
  ) {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Retorna do cache e atualiza em segundo plano (stale-while-revalidate)
        fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse && networkResponse.status === 200) {
              const clone = networkResponse.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
            }
          })
          .catch(() => {});
        return cachedResponse;
      }

      return fetch(event.request)
        .then((networkResponse) => {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === "basic"
          ) {
            const clone = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return networkResponse;
        })
        .catch(() => {
          // Fallback offline para navegação
          if (event.request.mode === "navigate") {
            return caches.match("/");
          }
        });
    })
  );
});

// Manipula cliques na notificação do despertador (traz o app para foco e abre o retorno do intervalo)
self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  if (event.action === "silenciar") {
    event.waitUntil(
      self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
        for (const client of clientList) {
          try {
            client.postMessage({ type: "che:silence-alarm" });
          } catch {}
        }
      })
    );
    return;
  }

  // Toque na ação "retomar" ou no corpo da notificação
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) {
          try {
            client.postMessage({ type: "che:open-ponto-retorno", autoTrigger: true });
          } catch {}
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow("/?action=open-ponto-retorno&autoTrigger=true");
      }
    })
  );
});
