package com.elenildon.calendariohorasextras;

import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * Plugin Nativo do Capacitor para Alarme Oficial do Android.
 * 
 * Utiliza AlarmManager.setAlarmClock (API oficial dos despertadores do Android):
 * - Acorda a CPU e o display mesmo em Doze Mode extremo e com a tela desligada.
 * - Dispara com exatidão no segundo agendado.
 * - Provê métodos para teste imediato de tela acesa + som simultâneos.
 * - Gerencia todas as permissões especiais do sistema operacional.
 */
@CapacitorPlugin(name = "NativeAlarm")
public class NativeAlarmPlugin extends Plugin {

    @PluginMethod
    public void scheduleAlarm(PluginCall call) {
        Long timestamp = call.getLong("timestamp");
        if (timestamp == null || timestamp <= System.currentTimeMillis()) {
            call.reject("Timestamp de alarme inválido ou já expirado");
            return;
        }

        String title = call.getString("title", "⏰ VOLTE DO INTERVALO AGORA!");
        String body = call.getString("body", "Calendário de Horas Extras — Hora de retomar o trabalho");
        String sound = call.getString("sound", "android-classic-alarm");

        try {
            Context context = getContext();
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            if (alarmManager == null) {
                call.reject("AlarmManager não disponível no dispositivo");
                return;
            }

            // 1. Intent para o Receiver (Broadcast de despertar de sistema)
            Intent receiverIntent = new Intent(context, IntervalAlarmReceiver.class);
            receiverIntent.setAction(IntervalAlarmReceiver.ACTION_FIRE_ALARM);
            receiverIntent.putExtra("title", title);
            receiverIntent.putExtra("body", body);
            receiverIntent.putExtra("sound", sound);
            receiverIntent.putExtra("timestamp", timestamp);

            PendingIntent alarmPendingIntent = PendingIntent.getBroadcast(
                context,
                IntervalAlarmReceiver.ALARM_REQUEST_CODE,
                receiverIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            // 2. Intent para a Atividade de Tela de Bloqueio (FullScreen Activity)
            Intent activityIntent = new Intent(context, AlarmAlertActivity.class);
            activityIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            );
            activityIntent.putExtra("title", title);
            activityIntent.putExtra("body", body);
            activityIntent.putExtra("sound", sound);
            activityIntent.putExtra("timestamp", timestamp);

            PendingIntent activityPendingIntent = PendingIntent.getActivity(
                context,
                IntervalAlarmReceiver.FULLSCREEN_REQUEST_CODE,
                activityIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
            );

            // Agenda via MainActivity nativa Kotlin (AlarmManager.setAlarmClock + setExactAndAllowWhileIdle)
            MainActivity.agendarRetorno(context, timestamp, 60, title, body);

            JSObject ret = new JSObject();
            ret.put("success", true);
            ret.put("timestamp", timestamp);
            ret.put("mode", "NATIVE_ALARM_CLOCK");
            call.resolve(ret);
        } catch (SecurityException se) {
            call.reject("Permissão de alarme exato não concedida pelo usuário: " + se.getMessage());
        } catch (Exception e) {
            call.reject("Falha ao agendar despertador nativo: " + e.getMessage());
        }
    }

    @PluginMethod
    public void fireAlarmNow(PluginCall call) {
        try {
            Context context = getContext();
            String title = call.getString("title", "⏰ VOLTE DO INTERVALO AGORA!");
            String body = call.getString("body", "Calendário de Horas Extras — Hora de retomar o trabalho");
            String sound = call.getString("sound", "android-classic-alarm");

            // 1. Adquire WakeLock forçado imediatamente
            IntervalAlarmReceiver.acquireWakeLock(context);

            // 2. Dispara Broadcast para receptor do alarme
            Intent receiverIntent = new Intent(context, IntervalAlarmReceiver.class);
            receiverIntent.setAction(IntervalAlarmReceiver.ACTION_FIRE_ALARM);
            receiverIntent.putExtra("title", title);
            receiverIntent.putExtra("body", body);
            receiverIntent.putExtra("sound", sound);
            receiverIntent.putExtra("timestamp", System.currentTimeMillis());
            context.sendBroadcast(receiverIntent);

            // 3. Força abertura direta da tela de alerta em primeiro plano
            try {
                Intent activityIntent = new Intent(context, AlarmAlertActivity.class);
                activityIntent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK |
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                    Intent.FLAG_ACTIVITY_SINGLE_TOP |
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                );
                activityIntent.putExtra("title", title);
                activityIntent.putExtra("body", body);
                activityIntent.putExtra("sound", sound);
                context.startActivity(activityIntent);
            } catch (Exception ignored) {}

            // 4. Inicia som simultaneamente
            AlarmSoundService.start(context, sound, title, body);

            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Falha ao disparar alarme imediatamente: " + e.getMessage());
        }
    }

    @PluginMethod
    public void cancelAlarm(PluginCall call) {
        try {
            Context context = getContext();
            MainActivity.cancelarRetorno(context);

            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao cancelar alarme: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stopAlarmSound(PluginCall call) {
        try {
            Context context = getContext();
            AlarmSoundService.stop(context);
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(IntervalAlarmReceiver.NOTIFICATION_ID);
            }
            IntervalAlarmReceiver.releaseWakeLock();

            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao parar som: " + e.getMessage());
        }
    }

    @PluginMethod
    public void checkAlarmPermission(PluginCall call) {
        JSObject ret = new JSObject();
        try {
            Context context = getContext();
            boolean canSchedule = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
                canSchedule = am != null && am.canScheduleExactAlarms();
            }

            boolean isIgnoringBattery = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                isIgnoringBattery = pm != null && pm.isIgnoringBatteryOptimizations(context.getPackageName());
            }

            boolean canDrawOverlays = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                canDrawOverlays = Settings.canDrawOverlays(context);
            }

            boolean notifsEnabled = NotificationManagerCompat.from(context).areNotificationsEnabled();

            boolean canUseFullScreen = true;
            if (Build.VERSION.SDK_INT >= 34) {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) {
                    try {
                        canUseFullScreen = nm.canUseFullScreenIntent();
                    } catch (Exception ignored) {}
                }
            }

            ret.put("canScheduleExact", canSchedule);
            ret.put("ignoresBatteryOptimizations", isIgnoringBattery);
            ret.put("canDrawOverlays", canDrawOverlays);
            ret.put("notificationsEnabled", notifsEnabled);
            ret.put("canUseFullScreenIntent", canUseFullScreen);
            ret.put("isAlarmClockSupported", true);
            call.resolve(ret);
        } catch (Exception e) {
            ret.put("canScheduleExact", true);
            ret.put("ignoresBatteryOptimizations", true);
            ret.put("canDrawOverlays", true);
            ret.put("notificationsEnabled", true);
            ret.put("canUseFullScreenIntent", true);
            call.resolve(ret);
        }
    }

    @PluginMethod
    public void requestOverlayPermission(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (!Settings.canDrawOverlays(getContext())) {
                    Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getContext().getPackageName())
                    );
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    getContext().startActivity(intent);
                }
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao abrir configurações de sobreposição: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestExactAlarmPermission(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
                intent.setData(Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao abrir configurações de alarme exato: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestIgnoreBatteryOptimizations(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
                intent.setData(Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao solicitar otimização de bateria: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestNotificationPolicyPermission(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Intent intent = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao abrir configurações de Não Perturbe: " + e.getMessage());
        }
    }

    @PluginMethod
    public void requestFullScreenIntentPermission(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
                intent.setData(Uri.parse("package:" + getContext().getPackageName()));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(intent);
            }
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Erro ao abrir configurações de tela cheia: " + e.getMessage());
        }
    }
}
