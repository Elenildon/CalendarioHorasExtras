package com.elenildon.calendariohorasextras;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.os.VibrationEffect;
import android.os.Vibrator;

/**
 * Serviço de Áudio de Despertador Nativo em Primeiro Plano.
 * 
 * Executa em canal USAGE_ALARM (STREAM_ALARM) com prioridade MÁXIMA,
 * mantendo a tela iluminada e a CPU ativa (WakeLocks) de forma ininterrupta
 * até que o usuário clique em "CONFIRMAR RETORNO" ou "Silenciar".
 */
public class AlarmSoundService extends Service {

    public static final String ACTION_START = "com.elenildon.calendariohorasextras.ALARM_START";
    public static final String ACTION_STOP = "com.elenildon.calendariohorasextras.ALARM_STOP";

    private MediaPlayer mMediaPlayer;
    private Vibrator mVibrator;
    private PowerManager.WakeLock mServiceWakeLock;

    public static void start(Context context, String soundPreset, String title, String body) {
        Intent intent = new Intent(context, AlarmSoundService.class);
        intent.setAction(ACTION_START);
        intent.putExtra("sound", soundPreset);
        intent.putExtra("title", title);
        intent.putExtra("body", body);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent);
            } else {
                context.startService(intent);
            }
        } catch (Exception ignored) {}
    }

    public static void stop(Context context) {
        Intent intent = new Intent(context, AlarmSoundService.class);
        intent.setAction(ACTION_STOP);
        try {
            context.startService(intent);
        } catch (Exception ignored) {}
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_STOP.equals(action)) {
            stopPlayback();
            stopSelf();
            return START_NOT_STICKY;
        }

        String title = intent != null && intent.getStringExtra("title") != null
            ? intent.getStringExtra("title")
            : "⏰ VOLTE DO INTERVALO AGORA!";
        String body = intent != null && intent.getStringExtra("body") != null
            ? intent.getStringExtra("body")
            : "Calendário de Horas Extras — Hora de retomar o trabalho";

        // Inicia o serviço em primeiro plano usando a notificação unificada de alta prioridade
        startForegroundAlarmNotification(title, body);

        // Dispara acendimento forçado de tela + som contínuo + vibração
        startPlayback();

        return START_NOT_STICKY;
    }

    private void startForegroundAlarmNotification(String title, String body) {
        try {
            Notification notification = IntervalAlarmReceiver.buildAlarmNotification(this, title, body);
            startForeground(IntervalAlarmReceiver.NOTIFICATION_ID, notification);
        } catch (Exception ignored) {}
    }

    private void startPlayback() {
        // 1. Garante que a tela permaneça acesa durante toda a reprodução do alarme
        acquireScreenWakeLock();

        // 2. Toca som no canal de despertador em volume máximo e repetição contínua
        playContinuousAlarm();

        // 3. Vibração ritmada contínua
        startVibration();
    }

    private synchronized void acquireScreenWakeLock() {
        try {
            if (mServiceWakeLock != null && mServiceWakeLock.isHeld()) {
                return;
            }
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                int flags = PowerManager.FULL_WAKE_LOCK
                    | PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                    | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE;

                try {
                    mServiceWakeLock = pm.newWakeLock(flags, "che:AlarmServiceScreenWakeLock");
                    mServiceWakeLock.acquire(300000); // 5 minutos ou até confirmação
                } catch (Exception e) {
                    try {
                        mServiceWakeLock = pm.newWakeLock(
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                            "che:AlarmServiceScreenWakeLockFallback"
                        );
                        mServiceWakeLock.acquire(300000);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }

    private synchronized void releaseScreenWakeLock() {
        try {
            if (mServiceWakeLock != null && mServiceWakeLock.isHeld()) {
                mServiceWakeLock.release();
            }
        } catch (Exception ignored) {}
        mServiceWakeLock = null;
    }

    private void playContinuousAlarm() {
        try {
            if (mMediaPlayer != null) {
                mMediaPlayer.reset();
                mMediaPlayer.release();
                mMediaPlayer = null;
            }

            Uri alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (alarmUri == null) {
                alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            }

            mMediaPlayer = new MediaPlayer();
            mMediaPlayer.setDataSource(this, alarmUri);

            AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                .build();

            mMediaPlayer.setAudioAttributes(attributes);
            mMediaPlayer.setAudioStreamType(AudioManager.STREAM_ALARM);
            mMediaPlayer.setVolume(1.0f, 1.0f);
            mMediaPlayer.setLooping(true); // Repete sem parar até confirmar!

            mMediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer mp, int what, int extra) {
                    try {
                        Thread.sleep(800);
                        playContinuousAlarm();
                    } catch (Exception ignored) {}
                    return true;
                }
            });

            mMediaPlayer.prepare();
            mMediaPlayer.start();
        } catch (Exception ignored) {}
    }

    private void startVibration() {
        try {
            mVibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (mVibrator != null && mVibrator.hasVibrator()) {
                long[] pattern = { 0, 600, 300, 600, 300, 1000 };
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    mVibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                } else {
                    mVibrator.vibrate(pattern, 0);
                }
            }
        } catch (Exception ignored) {}
    }

    private void stopPlayback() {
        try {
            if (mMediaPlayer != null) {
                if (mMediaPlayer.isPlaying()) {
                    mMediaPlayer.stop();
                }
                mMediaPlayer.reset();
                mMediaPlayer.release();
                mMediaPlayer = null;
            }
        } catch (Exception ignored) {}

        try {
            if (mVibrator != null) {
                mVibrator.cancel();
                mVibrator = null;
            }
        } catch (Exception ignored) {}

        releaseScreenWakeLock();
        IntervalAlarmReceiver.releaseWakeLock();
    }

    @Override
    public void onDestroy() {
        stopPlayback();
        super.onDestroy();
    }
}
