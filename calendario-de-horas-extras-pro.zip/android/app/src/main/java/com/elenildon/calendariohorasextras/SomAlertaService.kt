package com.elenildon.calendariohorasextras

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Serviço de Som de Alarme em Primeiro Plano (Foreground Service).
 *
 * - Executa em canal USAGE_ALARM / STREAM_ALARM com volume máximo (1.0).
 * - Reproduz em loop infinito até que o usuário clique em "CONFIRMAR RETORNO" ou "Silenciar".
 * - Utiliza START_STICKY para que o sistema operacional reinicie o serviço caso necessário.
 * - Mantém a notificação em primeiro plano e WakeLock ativo.
 * - Carrega preferencialmente o áudio nativo em res/raw/alerta.mp3, com fallback para o alarme do sistema.
 */
class SomAlertaService : Service() {

    companion object {
        const val ACTION_INICIAR = "com.elenildon.calendariohorasextras.ACTION_INICIAR_SOM"
        const val ACTION_PARAR = "com.elenildon.calendariohorasextras.ACTION_PARAR_SOM"

        fun iniciar(context: Context, soundPreset: String? = null, title: String? = null, message: String? = null) {
            val intent = Intent(context, SomAlertaService::class.java).apply {
                action = ACTION_INICIAR
                putExtra("sound", soundPreset ?: "ios-crystal-alert")
                putExtra("title", title ?: "⏰ VOLTE DO INTERVALO AGORA!")
                putExtra("body", message ?: "Calendário de Horas Extras — Hora de retomar o trabalho")
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (ignored: Exception) {}
        }

        fun parar(context: Context) {
            val intent = Intent(context, SomAlertaService::class.java).apply {
                action = ACTION_PARAR
            }
            try {
                context.startService(intent)
            } catch (ignored: Exception) {}
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var serviceWakeLock: PowerManager.WakeLock? = null
    private var currentSoundPreset: String = "ios-crystal-alert"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action

        if (ACTION_PARAR == action) {
            pararReproducao()
            stopSelf()
            return START_NOT_STICKY
        }

        currentSoundPreset = intent?.getStringExtra("sound") ?: "ios-crystal-alert"
        val title = intent?.getStringExtra("title") ?: "⏰ VOLTE DO INTERVALO AGORA!"
        val message = intent?.getStringExtra("body") ?: "Calendário de Horas Extras — Hora de retomar o trabalho"

        // 1. Inicia o serviço em primeiro plano com notificação de prioridade máxima
        val notification = AlarmeReceiver.buildNotification(this, title, message)
        try {
            startForeground(AlarmeReceiver.NOTIFICATION_ID, notification)
        } catch (ignored: Exception) {}

        // 2. Dispara a reprodução contínua do áudio + vibração + WakeLock
        iniciarReproducao()

        return START_STICKY // Sistema reinicia se tentar fechar
    }

    private fun iniciarReproducao() {
        adquirirWakeLockServico()
        tocarSomLoop()
        iniciarVibracao()
    }

    private fun adquirirWakeLockServico() {
        try {
            if (serviceWakeLock?.isHeld == true) return

            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (pm != null) {
                val flags = PowerManager.FULL_WAKE_LOCK or
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                        PowerManager.ACQUIRE_CAUSES_WAKEUP or
                        PowerManager.ON_AFTER_RELEASE

                serviceWakeLock = pm.newWakeLock(flags, "che:SomAlertaServiceWakeLock")
                serviceWakeLock?.acquire(300000) // 5 minutos ou até confirmação
            }
        } catch (ignored: Exception) {}
    }

    private fun liberarWakeLockServico() {
        try {
            if (serviceWakeLock?.isHeld == true) {
                serviceWakeLock?.release()
            }
        } catch (ignored: Exception) {}
        serviceWakeLock = null
    }

    /**
     * Toca o áudio de alerta em loop infinito.
     * Tenta carregar res/raw/alerta.mp3; caso não exista, recorre ao som oficial de alarme do Android.
     */
    private fun tocarSomLoop() {
        try {
            mediaPlayer?.reset()
            mediaPlayer?.release()
            mediaPlayer = null

            val player = MediaPlayer()
            var dataSourceDefinido = false

            // 1. Tenta carregar o preset de som selecionado em res/raw
            try {
                val rawName = currentSoundPreset.replace("-", "_").lowercase()
                val resId = resources.getIdentifier(rawName, "raw", packageName)
                if (resId != 0) {
                    val afd = resources.openRawResourceFd(resId)
                    if (afd != null) {
                        player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                        afd.close()
                        dataSourceDefinido = true
                    }
                }
            } catch (ignored: Exception) {}

            // 2. Fallback: Som alerta.mp3 em res/raw
            if (!dataSourceDefinido) {
                try {
                    val resId = resources.getIdentifier("alerta", "raw", packageName)
                    if (resId != 0) {
                        val afd = resources.openRawResourceFd(resId)
                        if (afd != null) {
                            player.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                            afd.close()
                            dataSourceDefinido = true
                        }
                    }
                } catch (ignored: Exception) {}
            }

            // 3. Fallback nativo: Som oficial de alarme configurado pelo sistema operacional
            if (!dataSourceDefinido) {
                var alarmUri: Uri? = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                if (alarmUri == null) {
                    alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                }
                if (alarmUri != null) {
                    player.setDataSource(this, alarmUri)
                    dataSourceDefinido = true
                }
            }

            if (!dataSourceDefinido) return

            val attributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                .build()

            player.setAudioAttributes(attributes)
            player.setAudioStreamType(AudioManager.STREAM_ALARM)
            player.setVolume(1.0f, 1.0f) // Volume máximo
            player.isLooping = true // Loop infinito até confirmação!

            player.setOnErrorListener { _, _, _ ->
                try {
                    Thread.sleep(800)
                    tocarSomLoop()
                } catch (ignored: Exception) {}
                true
            }

            player.prepare()
            player.start()
            mediaPlayer = player
        } catch (ignored: Exception) {}
    }

    private fun iniciarVibracao() {
        try {
            vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            if (vibrator?.hasVibrator() == true) {
                val pattern = longArrayOf(0, 600, 300, 600, 300, 1000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(pattern, 0)
                }
            }
        } catch (ignored: Exception) {}
    }

    private fun pararReproducao() {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.stop()
                }
                it.reset()
                it.release()
            }
            mediaPlayer = null
        } catch (ignored: Exception) {}

        try {
            vibrator?.cancel()
            vibrator = null
        } catch (ignored: Exception) {}

        liberarWakeLockServico()
        AlarmeReceiver.releaseWakeLock()
    }

    override fun onDestroy() {
        pararReproducao()
        super.onDestroy()
    }
}
