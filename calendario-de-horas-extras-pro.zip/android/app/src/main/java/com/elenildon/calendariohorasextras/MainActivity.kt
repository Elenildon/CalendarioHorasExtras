package com.elenildon.calendariohorasextras

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import com.getcapacitor.BridgeActivity

/**
 * Atividade Principal do Calendário de Horas Extras — Registro de Ponto.
 *
 * Integração Nativa Kotlin com Capacitor Bridge:
 * - Registra os plugins nativos de biometria e alarme exato.
 * - Fornece métodos estáticos oficiais de agendamento (agendarRetorno), cancelamento e confirmação.
 * - Suporta reagendamento automático após boot (reagendarAposBoot).
 * - Desperta a tela e aciona a biometria nativa ao confirmar o retorno do intervalo.
 */
class MainActivity : BridgeActivity() {

    companion object {
        private const val PREFS_NAME = "che_intervalo_prefs"
        private const val KEY_ALARME_TIMESTAMP = "alarme_timestamp"
        private const val KEY_ALARME_DURACAO = "alarme_duracao"
        private const val KEY_ALARME_TITULO = "alarme_titulo"
        private const val KEY_ALARME_MENSAGEM = "alarme_mensagem"

        private var sInstance: MainActivity? = null

        /**
         * 🔹 1. AGENDAMENTO PRECISO NO ALARMMANAGER
         * Chamado pelo botão "Iniciar Intervalo":
         * - setExactAndAllowWhileIdle() / setAlarmClock() → dispara mesmo em modo repouso
         * - AlarmManager.RTC_WAKEUP → ignora suspensão
         * - PendingIntent imutável com FLAG_UPDATE_CURRENT
         * - Salva nas SharedPreferences para reagendamento automático após boot
         */
        @JvmStatic
        fun agendarRetorno(
            context: Context,
            horarioTimestamp: Long,
            duracaoMinutos: Int = 60,
            titulo: String = "⏰ VOLTE DO INTERVALO AGORA!",
            mensagem: String = "Calendário de Horas Extras — Hora de retomar o trabalho"
        ) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

            // 1. Salva nas preferências para reagendar após reinício do aparelho
            salvarAgendamentoPrefs(context, horarioTimestamp, duracaoMinutos, titulo, mensagem)

            // 2. Intent para o AlarmeReceiver
            val receiverIntent = Intent(context, AlarmeReceiver::class.java).apply {
                action = AlarmeReceiver.ACTION_DISPARAR_ALARME
                putExtra("title", titulo)
                putExtra("body", mensagem)
                putExtra("timestamp", horarioTimestamp)
            }

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

            val alarmPendingIntent = PendingIntent.getBroadcast(
                context,
                AlarmeReceiver.ALARM_REQUEST_CODE,
                receiverIntent,
                flags
            )

            // 3. Intent para a Activity de tela cheia que acende a tela
            val activityIntent = Intent(context, AlertaRetornoActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra("title", titulo)
                putExtra("body", mensagem)
                putExtra("timestamp", horarioTimestamp)
            }

            val activityPendingIntent = PendingIntent.getActivity(
                context,
                AlarmeReceiver.FULLSCREEN_REQUEST_CODE,
                activityIntent,
                flags
            )

            // 4. Agenda como Despertador Oficial do Sistema com garantia de disparo exato
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                try {
                    val clockInfo = AlarmManager.AlarmClockInfo(horarioTimestamp, activityPendingIntent)
                    alarmManager.setAlarmClock(clockInfo, alarmPendingIntent)
                } catch (fallbackEx: Exception) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, horarioTimestamp, alarmPendingIntent)
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, horarioTimestamp, alarmPendingIntent)
                    }
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, horarioTimestamp, alarmPendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, horarioTimestamp, alarmPendingIntent)
            }
        }

        /**
         * Cancela o alarme se o usuário encerrar o intervalo antecipadamente.
         */
        @JvmStatic
        fun cancelarRetorno(context: Context) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
            if (alarmManager != null) {
                val receiverIntent = Intent(context, AlarmeReceiver::class.java).apply {
                    action = AlarmeReceiver.ACTION_DISPARAR_ALARME
                }
                val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                        (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

                val alarmPendingIntent = PendingIntent.getBroadcast(
                    context,
                    AlarmeReceiver.ALARM_REQUEST_CODE,
                    receiverIntent,
                    flags
                )
                alarmManager.cancel(alarmPendingIntent)
            }

            SomAlertaService.parar(context)
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.cancel(AlarmeReceiver.NOTIFICATION_ID)
            AlarmeReceiver.releaseWakeLock()

            limparAgendamentoPrefs(context)
        }

        /**
         * Confirma o retorno: para o som, fecha notificação, marca a etapa como registrada
         * e avança para a etapa "Saída" acionando a biometria nativa.
         */
        @JvmStatic
        fun confirmarRetorno(context: Context) {
            SomAlertaService.parar(context)
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.cancel(AlarmeReceiver.NOTIFICATION_ID)
            AlarmeReceiver.releaseWakeLock()
            limparAgendamentoPrefs(context)

            // Abre a MainActivity diretamente na tela de registrar ponto com biometria
            val mainIntent = Intent(context, MainActivity::class.java).apply {
                action = AlarmeReceiver.ACTION_CONFIRMAR_RETORNO
                putExtra("action", "open-ponto-retorno")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }
            context.startActivity(mainIntent)

            sInstance?.dispararEventoWebRetorno()
        }

        /**
         * Reagendamento automático após reinício do aparelho (RECEIVE_BOOT_COMPLETED).
         */
        @JvmStatic
        fun reagendarAposBoot(context: Context) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val timestamp = prefs.getLong(KEY_ALARME_TIMESTAMP, 0L)
            if (timestamp > System.currentTimeMillis()) {
                val duracao = prefs.getInt(KEY_ALARME_DURACAO, 60)
                val titulo = prefs.getString(KEY_ALARME_TITULO, "⏰ VOLTE DO INTERVALO AGORA!") ?: "⏰ VOLTE DO INTERVALO AGORA!"
                val mensagem = prefs.getString(KEY_ALARME_MENSAGEM, "Calendário de Horas Extras — Hora de retomar o trabalho") ?: ""
                agendarRetorno(context, timestamp, duracao, titulo, mensagem)
            } else {
                limparAgendamentoPrefs(context)
            }
        }

        private fun salvarAgendamentoPrefs(context: Context, timestamp: Long, duracao: Int, titulo: String, mensagem: String) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putLong(KEY_ALARME_TIMESTAMP, timestamp)
                .putInt(KEY_ALARME_DURACAO, duracao)
                .putString(KEY_ALARME_TITULO, titulo)
                .putString(KEY_ALARME_MENSAGEM, mensagem)
                .apply()
        }

        private fun limparAgendamentoPrefs(context: Context) {
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().clear().apply()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        sInstance = this
        registerPlugin(NativeBiometricPlugin::class.java)
        registerPlugin(NativeAlarmPlugin::class.java)
        super.onCreate(savedInstanceState)
        configurarAcendimentoTela()
        processarIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        configurarAcendimentoTela()
        processarIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        sInstance = this
        configurarAcendimentoTela()
    }

    override fun onDestroy() {
        if (sInstance == this) {
            sInstance = null
        }
        super.onDestroy()
    }

    private fun processarIntent(intent: Intent?) {
        if (intent == null) return

        val action = intent.action
        val extraAction = intent.getStringExtra("action")

        if (AlarmeReceiver.ACTION_CONFIRMAR_RETORNO == action ||
            IntervalAlarmReceiver.ACTION_RESUME_PONTO == action ||
            "open-ponto-retorno" == extraAction
        ) {
            // Silencia o áudio e fecha a notificação do alarme
            SomAlertaService.parar(this)
            AlarmSoundService.stop(this)
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.cancel(AlarmeReceiver.NOTIFICATION_ID)
            nm?.cancel(IntervalAlarmReceiver.NOTIFICATION_ID)
            AlarmeReceiver.releaseWakeLock()
            IntervalAlarmReceiver.releaseWakeLock()

            dispararEventoWebRetorno()
        }
    }

    /**
     * Notifica o WebView para registrar a etapa do ponto e acionar a biometria nativa.
     */
    fun dispararEventoWebRetorno() {
        bridge?.webView?.post {
            try {
                bridge?.webView?.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('che:open-ponto-retorno', { detail: { autoTrigger: true } }));",
                    null
                )
            } catch (ignored: Exception) {}
        }
    }

    /**
     * Mantém a tela acesa e permite exibição na tela de bloqueio.
     */
    private fun configurarAcendimentoTela() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            }

            window?.addFlags(
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        } catch (ignored: Exception) {}
    }
}
