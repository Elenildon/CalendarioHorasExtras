package com.elenildon.calendariohorasextras;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import androidx.core.app.NotificationCompat;

/**
 * Receptor de Despertador do Intervalo do Ponto Biométrico.
 * 
 * GARANTIA ABSOLUTA DE ACENDIMENTO DE TELA + NOTIFICAÇÃO + SOM SIMULTÂNEOS:
 * 
 * ORDEM EXATA DE DISPARO (NO MESMO BLOCO SÍNCRONO):
 * PASSO 1 → Adquirir TODOS os WakeLocks forçados (ligar tela física apagada imediatamente)
 * PASSO 2 → Criar e MOSTRAR notificação de prioridade máxima na tela de bloqueio + FullScreenIntent
 * PASSO 3 → INICIAR reprodução contínua do som de alarme ao mesmo tempo
 */
public class IntervalAlarmReceiver extends BroadcastReceiver {

    public static final String ACTION_FIRE_ALARM = "com.elenildon.calendariohorasextras.ACTION_FIRE_ALARM";
    public static final String ACTION_DISMISS_ALARM = "com.elenildon.calendariohorasextras.ACTION_DISMISS_ALARM";
    public static final String ACTION_RESUME_PONTO = "com.elenildon.calendariohorasextras.ACTION_RESUME_PONTO";

    public static final String CHANNEL_ID = "che_interval_alarm_clock_v3";
    public static final int NOTIFICATION_ID = 2001;
    public static final int ALARM_REQUEST_CODE = 101;
    public static final int SHOW_REQUEST_CODE = 102;
    public static final int RESUME_REQUEST_CODE = 103;
    public static final int DISMISS_REQUEST_CODE = 104;
    public static final int FULLSCREEN_REQUEST_CODE = 105;

    private static PowerManager.WakeLock sScreenWakeLock;
    private static PowerManager.WakeLock sCpuWakeLock;

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent != null ? intent.getAction() : null;

        if (ACTION_DISMISS_ALARM.equals(action)) {
            // Silencia o alarme imediatamente e limpa tela
            AlarmSoundService.stop(context);
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancel(NOTIFICATION_ID);
            }
            releaseWakeLock();
            return;
        }

        String title = intent != null && intent.getStringExtra("title") != null
            ? intent.getStringExtra("title")
            : "⏰ VOLTE DO INTERVALO AGORA!";
        String body = intent != null && intent.getStringExtra("body") != null
            ? intent.getStringExtra("body")
            : "Calendário de Horas Extras — Hora de retomar o trabalho";
        String soundPreset = intent != null ? intent.getStringExtra("sound") : null;

        // =========================================================================
        // PASSO 1: ACIONAR TODOS OS WAKELOCKS IMEDIATAMENTE PARA LIGAR/ACENDER A TELA
        // =========================================================================
        // FULL_WAKE_LOCK + SCREEN_BRIGHT_WAKE_LOCK com ACQUIRE_CAUSES_WAKEUP e ON_AFTER_RELEASE
        acquireWakeLock(context);

        // =========================================================================
        // PASSO 2: CRIAR E MOSTRAR NOTIFICAÇÃO NA TELA DE BLOQUEIO + FULLSCREEN INTENT
        // =========================================================================
        ensureAlarmChannel(context);
        Notification notification = buildAlarmNotification(context, title, body);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            try {
                nm.notify(NOTIFICATION_ID, notification);
            } catch (Exception ignored) {}
        }

        // Força abertura direta da atividade sobre a tela de bloqueio
        launchAlarmAlertActivity(context, title, body, soundPreset);

        // =========================================================================
        // PASSO 3: INICIAR SOM DE ALERTA — NO MESMO BLOCO, SIMULTANEAMENTE!
        // =========================================================================
        // A tela acabou de acender e o som inicia exatamente no mesmo instante
        AlarmSoundService.start(context, soundPreset, title, body);
    }

    /**
     * Constrói a Notificação Oficial de Alarme com Visibilidade Pública (Tela de Bloqueio)
     * e FullScreenIntent obrigatório para forçar o display a ligar.
     */
    public static Notification buildAlarmNotification(Context context, String title, String body) {
        ensureAlarmChannel(context);

        // Intent para Atividade em Tela Cheia sobre a tela de bloqueio
        Intent fullScreenIntent = new Intent(context, AlarmAlertActivity.class);
        fullScreenIntent.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK |
            Intent.FLAG_ACTIVITY_CLEAR_TOP |
            Intent.FLAG_ACTIVITY_SINGLE_TOP |
            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        );
        fullScreenIntent.putExtra("title", title);
        fullScreenIntent.putExtra("body", body);

        PendingIntent fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            FULLSCREEN_REQUEST_CODE,
            fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        // Intent para confirmar retorno e abrir biometria no app principal
        Intent resumeIntent = new Intent(context, MainActivity.class);
        resumeIntent.setAction(ACTION_RESUME_PONTO);
        resumeIntent.putExtra("action", "open-ponto-retorno");
        resumeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent resumePendingIntent = PendingIntent.getActivity(
            context,
            RESUME_REQUEST_CODE,
            resumeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        // Intent para silenciar alarme
        Intent dismissIntent = new Intent(context, IntervalAlarmReceiver.class);
        dismissIntent.setAction(ACTION_DISMISS_ALARM);
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(
            context,
            DISMISS_REQUEST_CODE,
            dismissIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0)
        );

        return new NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setSubText("Calendário de Horas Extras")
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // VISÍVEL DIRETAMENTE NA TELA DE BLOQUEIO
            .setAutoCancel(false)
            .setOngoing(true) // Permanece fixo até confirmação
            .setFullScreenIntent(fullScreenPendingIntent, true) // FORÇA LIGAR TELA IMEDIATAMENTE
            .setContentIntent(fullScreenPendingIntent)
            .addAction(R.mipmap.ic_launcher, "✅ CONFIRMAR RETORNO", resumePendingIntent)
            .addAction(R.mipmap.ic_launcher, "🔕 Silenciar", dismissPendingIntent)
            .build();
    }

    /**
     * Tenta iniciar a atividade de alerta em tela cheia sobre a tela de bloqueio.
     */
    private static void launchAlarmAlertActivity(Context context, String title, String body, String sound) {
        try {
            Intent activityIntent = new Intent(context, AlarmAlertActivity.class);
            activityIntent.addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                Intent.FLAG_ACTIVITY_CLEAR_TOP |
                Intent.FLAG_ACTIVITY_SINGLE_TOP |
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            );
            activityIntent.putExtra("title", title);
            activityIntent.putExtra("body", body);
            activityIntent.putExtra("sound", sound);
            context.startActivity(activityIntent);
        } catch (Exception ignored) {}
    }

    /**
     * Adquire WakeLocks forçados combinando:
     * - FULL_WAKE_LOCK | SCREEN_BRIGHT_WAKE_LOCK com ACQUIRE_CAUSES_WAKEUP para ligar a tela
     * - PARTIAL_WAKE_LOCK para manter a CPU operando continuamente
     */
    public static synchronized void acquireWakeLock(Context context) {
        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm == null) return;

            // 1. WakeLock de Tela: FORÇA A TELA FÍSICA A LIGAR IMEDIATAMENTE
            if (sScreenWakeLock == null || !sScreenWakeLock.isHeld()) {
                int screenFlags = PowerManager.FULL_WAKE_LOCK
                    | PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                    | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE;

                try {
                    sScreenWakeLock = pm.newWakeLock(screenFlags, "che:IntervalAlarmScreenWakeLock");
                    sScreenWakeLock.acquire(300000); // 5 minutos ou até confirmação
                } catch (Exception e) {
                    try {
                        sScreenWakeLock = pm.newWakeLock(
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                            "che:IntervalAlarmScreenWakeLockFallback"
                        );
                        sScreenWakeLock.acquire(300000);
                    } catch (Exception ignored) {}
                }
            }

            // 2. WakeLock de CPU: garante execução em segundo plano sem interrupção do Doze Mode
            if (sCpuWakeLock == null || !sCpuWakeLock.isHeld()) {
                sCpuWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "che:IntervalAlarmCpuWakeLock");
                sCpuWakeLock.acquire(300000);
            }
        } catch (Exception ignored) {}
    }

    public static synchronized void releaseWakeLock() {
        try {
            if (sScreenWakeLock != null && sScreenWakeLock.isHeld()) {
                sScreenWakeLock.release();
            }
        } catch (Exception ignored) {}
        sScreenWakeLock = null;

        try {
            if (sCpuWakeLock != null && sCpuWakeLock.isHeld()) {
                sCpuWakeLock.release();
            }
        } catch (Exception ignored) {}
        sCpuWakeLock = null;
    }

    public static void ensureAlarmChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                    NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID,
                        "Despertador do Intervalo (Oficial)",
                        NotificationManager.IMPORTANCE_HIGH
                    );
                    channel.setDescription("Despertador de alta prioridade para retorno às atividades com tela de bloqueio acesa.");
                    channel.setLockscreenVisibility(NotificationCompat.VISIBILITY_PUBLIC);
                    channel.enableVibration(true);
                    channel.enableLights(true);
                    channel.setLightColor(0xFF00E5FF);

                    try {
                        channel.setBypassDnd(true);
                    } catch (Exception ignored) {}

                    Uri alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
                    if (alarmSoundUri == null) {
                        alarmSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                    }

                    AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                        .build();

                    channel.setSound(alarmSoundUri, audioAttributes);
                    nm.createNotificationChannel(channel);
                }
            } catch (Exception ignored) {}
        }
    }
}
