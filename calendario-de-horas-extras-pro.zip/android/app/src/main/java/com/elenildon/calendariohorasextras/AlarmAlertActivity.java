package com.elenildon.calendariohorasextras;

import android.app.Activity;
import android.app.KeyguardManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Atividade de Despertador em Tela Cheia (Lock Screen Alert Activity).
 *
 * Garante que a tela de bloqueio do celular ACENDA NO MESMO INSTANTE do alarme:
 * - setShowWhenLocked(true) + setTurnScreenOn(true)
 * - FLAG_SHOW_WHEN_LOCKED + FLAG_DISMISS_KEYGUARD + FLAG_KEEP_SCREEN_ON + FLAG_TURN_SCREEN_ON
 * - PowerManager FULL_WAKE_LOCK + SCREEN_BRIGHT_WAKE_LOCK com ACQUIRE_CAUSES_WAKEUP
 * - Brilho máximo forçado (BRIGHTNESS_OVERRIDE_FULL)
 * - Exibe interface com o botão "✅ CONFIRMAR RETORNO"
 * - Inicia e sincroniza o som contínuo no mesmo instante
 */
public class AlarmAlertActivity extends Activity {

    private Handler mTimeHandler;
    private Runnable mTimeRunnable;
    private TextView mClockTextView;
    private PowerManager.WakeLock mActivityWakeLock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        super.onCreate(savedInstanceState);

        // =========================================================================
        // 1. FORÇAR A TELA A ACENDER E MOSTRAR DIRETO NA TELA DE BLOQUEIO
        // =========================================================================
        turnScreenOnAndUnlock();

        // =========================================================================
        // 2. ADQUIRIR WAKELOCK FORÇADO (FULL + SCREEN_BRIGHT) PARA MANTER TELA ACESA
        // =========================================================================
        acquireActivityWakeLock();

        // =========================================================================
        // 3. INICIAR REPRODUÇÃO DO SOM SIMULTANEAMENTE (MESMO BLOCO!)
        // =========================================================================
        String title = getIntent().getStringExtra("title");
        if (title == null) title = "⏰ VOLTE DO INTERVALO AGORA!";
        String body = getIntent().getStringExtra("body");
        if (body == null) body = "Calendário de Horas Extras — Hora de retomar o trabalho";
        String soundPreset = getIntent().getStringExtra("sound");

        AlarmSoundService.start(this, soundPreset, title, body);

        // =========================================================================
        // 4. CONSTRUIR INTERFACE DE ALERTA EM TELA CHEIA
        // =========================================================================
        setContentView(buildContentView());

        // Inicia relógio em tempo real
        startTimeUpdater();
    }

    private void turnScreenOnAndUnlock() {
        // Métodos modernos (Android 8.1+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
            try {
                KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (keyguardManager != null) {
                    keyguardManager.requestDismissKeyguard(this, null);
                }
            } catch (Exception ignored) {}
        }

        // Flags obrigatórias do WindowManager para ligar e manter tela acesa na tela de bloqueio
        Window window = getWindow();
        if (window != null) {
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
            );

            // Eleva o brilho da tela ao máximo absoluto temporariamente
            try {
                WindowManager.LayoutParams params = window.getAttributes();
                params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_FULL;
                window.setAttributes(params);
            } catch (Exception ignored) {}

            window.setStatusBarColor(Color.parseColor("#0F172A"));
            window.setNavigationBarColor(Color.parseColor("#0F172A"));
        }
    }

    private void acquireActivityWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                int flags = PowerManager.FULL_WAKE_LOCK
                    | PowerManager.SCREEN_BRIGHT_WAKE_LOCK
                    | PowerManager.ACQUIRE_CAUSES_WAKEUP
                    | PowerManager.ON_AFTER_RELEASE;

                mActivityWakeLock = pm.newWakeLock(flags, "che:AlarmAlertActivityWakeLock");
                mActivityWakeLock.acquire(300000); // 5 minutos ou até confirmação
            }
        } catch (Exception e) {
            try {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    mActivityWakeLock = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP | PowerManager.ON_AFTER_RELEASE,
                        "che:AlarmAlertActivityWakeLockFallback"
                    );
                    mActivityWakeLock.acquire(300000);
                }
            } catch (Exception ignored) {}
        }
    }

    private View buildContentView() {
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        scrollView.setBackgroundColor(Color.parseColor("#0B1120")); // Fundo escuro azul profundo

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setKeepScreenOn(true);

        int pad = dp(24);
        root.setPadding(pad, dp(36), pad, dp(36));

        // 1. Badge superior "⏰ RETORNO DE INTERVALO OBRIGATÓRIO"
        TextView badge = new TextView(this);
        badge.setText("⏰ RETORNO DE INTERVALO OBRIGATÓRIO");
        badge.setTextColor(Color.parseColor("#38BDF8"));
        badge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setGravity(Gravity.CENTER);
        int badgePadH = dp(14);
        int badgePadV = dp(6);
        badge.setPadding(badgePadH, badgePadV, badgePadH, badgePadV);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#162846"));
        badgeBg.setCornerRadius(dp(20));
        badgeBg.setStroke(dp(1), Color.parseColor("#0284C7"));
        badge.setBackground(badgeBg);
        root.addView(badge);

        addSpace(root, dp(20));

        // 2. Ícone / Emoji Gigante Pulsante
        TextView iconView = new TextView(this);
        iconView.setText("⏰");
        iconView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 70);
        iconView.setGravity(Gravity.CENTER);
        root.addView(iconView);

        addSpace(root, dp(10));

        // 3. Relógio Digital Grande
        mClockTextView = new TextView(this);
        mClockTextView.setText(getCurrentTimeFormatted());
        mClockTextView.setTextColor(Color.parseColor("#FFFFFF"));
        mClockTextView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 44);
        mClockTextView.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        mClockTextView.setGravity(Gravity.CENTER);
        root.addView(mClockTextView);

        addSpace(root, dp(14));

        // 4. Cabeçalho Principal Obrigatório
        TextView titleView = new TextView(this);
        titleView.setText("VOLTE DO INTERVALO AGORA!");
        titleView.setTextColor(Color.parseColor("#F8FAFC"));
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        titleView.setGravity(Gravity.CENTER);
        root.addView(titleView);

        addSpace(root, dp(8));

        // 5. Subtítulo App Obrigatório
        TextView subtitleView = new TextView(this);
        subtitleView.setText("Calendário de Horas Extras — Hora de retomar o trabalho");
        subtitleView.setTextColor(Color.parseColor("#38BDF8"));
        subtitleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        subtitleView.setTypeface(Typeface.DEFAULT_BOLD);
        subtitleView.setGravity(Gravity.CENTER);
        root.addView(subtitleView);

        addSpace(root, dp(14));

        // 6. Mensagem de Instrução
        TextView descView = new TextView(this);
        descView.setText("A tela acendeu e o alarme sonoro está ativo e tocando repetidamente.\nToque no botão abaixo para confirmar seu retorno.");
        descView.setTextColor(Color.parseColor("#94A3B8"));
        descView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        descView.setGravity(Gravity.CENTER);
        descView.setLineSpacing(0, 1.2f);
        root.addView(descView);

        addSpace(root, dp(28));

        // 7. Botão Principal: CONFIRMAR RETORNO
        Button confirmBtn = new Button(this);
        confirmBtn.setText("✅ CONFIRMAR RETORNO");
        confirmBtn.setTextColor(Color.parseColor("#FFFFFF"));
        confirmBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        confirmBtn.setTypeface(Typeface.DEFAULT_BOLD);
        confirmBtn.setAllCaps(false);
        int btnPadV = dp(16);
        confirmBtn.setPadding(dp(20), btnPadV, dp(20), btnPadV);
        GradientDrawable confirmBg = new GradientDrawable();
        confirmBg.setColor(Color.parseColor("#10B981")); // Verde esmeralda forte
        confirmBg.setCornerRadius(dp(14));
        confirmBtn.setBackground(confirmBg);
        confirmBtn.setElevation(dp(6));
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleConfirmReturn();
            }
        });

        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        btnParams.setMargins(dp(8), 0, dp(8), dp(12));
        root.addView(confirmBtn, btnParams);

        // 8. Botão Secundário: Silenciar Alarme
        Button silenceBtn = new Button(this);
        silenceBtn.setText("🔕 Silenciar Alarme");
        silenceBtn.setTextColor(Color.parseColor("#CBD5E1"));
        silenceBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        silenceBtn.setTypeface(Typeface.DEFAULT_BOLD);
        silenceBtn.setAllCaps(false);
        silenceBtn.setPadding(dp(16), dp(12), dp(16), dp(12));
        GradientDrawable silenceBg = new GradientDrawable();
        silenceBg.setColor(Color.parseColor("#1E293B"));
        silenceBg.setCornerRadius(dp(12));
        silenceBg.setStroke(dp(1), Color.parseColor("#334155"));
        silenceBtn.setBackground(silenceBg);
        silenceBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleSilenceOnly();
            }
        });

        LinearLayout.LayoutParams silenceParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        );
        silenceParams.setMargins(dp(8), 0, dp(8), 0);
        root.addView(silenceBtn, silenceParams);

        scrollView.addView(root);
        return scrollView;
    }

    private void handleConfirmReturn() {
        // 1. Para o som imediatamente
        AlarmSoundService.stop(this);

        // 2. Remove notificação da tela de bloqueio
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(IntervalAlarmReceiver.NOTIFICATION_ID);
        }

        // 3. Libera WakeLocks
        releaseActivityWakeLock();
        IntervalAlarmReceiver.releaseWakeLock();

        // 4. Abre o MainActivity diretamente na etapa de bater o ponto
        Intent resumeIntent = new Intent(this, MainActivity.class);
        resumeIntent.setAction(IntervalAlarmReceiver.ACTION_RESUME_PONTO);
        resumeIntent.putExtra("action", "open-ponto-retorno");
        resumeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(resumeIntent);

        // 5. Encerra tela de alerta
        finish();
    }

    private void handleSilenceOnly() {
        // Para som e silencia alarme
        AlarmSoundService.stop(this);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.cancel(IntervalAlarmReceiver.NOTIFICATION_ID);
        }

        releaseActivityWakeLock();
        IntervalAlarmReceiver.releaseWakeLock();

        finish();
    }

    private void startTimeUpdater() {
        mTimeHandler = new Handler(Looper.getMainLooper());
        mTimeRunnable = new Runnable() {
            @Override
            public void run() {
                if (mClockTextView != null) {
                    mClockTextView.setText(getCurrentTimeFormatted());
                }
                mTimeHandler.postDelayed(this, 1000);
            }
        };
        mTimeHandler.post(mTimeRunnable);
    }

    private String getCurrentTimeFormatted() {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private void addSpace(LinearLayout layout, int height) {
        View view = new View(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            height
        );
        layout.addView(view, params);
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value,
            getResources().getDisplayMetrics()
        );
    }

    private void releaseActivityWakeLock() {
        try {
            if (mActivityWakeLock != null && mActivityWakeLock.isHeld()) {
                mActivityWakeLock.release();
            }
        } catch (Exception ignored) {}
        mActivityWakeLock = null;
    }

    @Override
    protected void onResume() {
        super.onResume();
        turnScreenOnAndUnlock();
    }

    @Override
    protected void onDestroy() {
        if (mTimeHandler != null && mTimeRunnable != null) {
            mTimeHandler.removeCallbacks(mTimeRunnable);
        }
        releaseActivityWakeLock();
        super.onDestroy();
    }
}
