package com.elenildon.calendariohorasextras

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Receptor de Alarme Nativo Android — Retorno do Intervalo.
 *
 * Dispara mesmo com tela desligada, celular bloqueado e app fechado em segundo plano.
 *
 * ORDEM DE EXECUÇÃO SÍNCRONA:
 * 1. Adquire WakeLocks forçados para ligar a tela imediatamente.
 * 2. Constrói e exibe notificação de prioridade máxima com FullScreenIntent na tela de bloqueio.
 * 3. Abre a Activity de tela cheia (AlertaRetornoActivity) que acende o display.
 * 4. Inicia o serviço em primeiro plano (SomAlertaService) que toca o som contínuo.
 * 5. Reagenda automaticamente o alarme caso o aparelho seja reiniciado (BOOT_COMPLETED).
 */
class AlarmeReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_DISPARAR_ALARME = "com.elenildon.calendariohorasextras.ACTION_DISPARAR_ALARME"
        const val ACTION_CONFIRMAR_RETORNO = "com.elenildon.calendariohorasextras.ACTION_CONFIRMAR_RETORNO"
        const val ACTION_SILENCIAR_ALARME = "com.elenildon.calendariohorasextras.ACTION_SILENCIAR_ALARME"

        const val CHANNEL_ID = "alerta_retorno_intervalo_channel"
        const val NOTIFICATION_ID = 2026
        const val ALARM_REQUEST_CODE = 301
        const val FULLSCREEN_REQUEST_CODE = 302
        const val RESUME_REQUEST_CODE = 303
        const val DISMISS_REQUEST_CODE = 304

        @Volatile
        private var sScreenWakeLock: PowerManager.WakeLock? = null

        @Volatile
        private var sCpuWakeLock: PowerManager.WakeLock? = null

        /**
         * Adquire WakeLock forçado para ligar a tela física instantaneamente e manter a CPU ativa.
         */
        @Synchronized
        fun acquireWakeLock(context: Context) {
            try {
                val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager ?: return

                // 1. WakeLock de Tela: Força o acendimento da tela física apagada
                if (sScreenWakeLock == null || !sScreenWakeLock!!.isHeld) {
                    val screenFlags = PowerManager.FULL_WAKE_LOCK or
                            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                            PowerManager.ACQUIRE_CAUSES_WAKEUP or
                            PowerManager.ON_AFTER_RELEASE

                    try {
                        sScreenWakeLock = pm.newWakeLock(screenFlags, "che:AlarmeReceiverScreenWakeLock")
                        sScreenWakeLock?.acquire(300000) // 5 minutos ou até confirmação do usuário
                    } catch (e: Exception) {
                        try {
                            sScreenWakeLock = pm.newWakeLock(
                                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                                        PowerManager.ACQUIRE_CAUSES_WAKEUP or
                                        PowerManager.ON_AFTER_RELEASE,
                                "che:AlarmeReceiverScreenWakeLockFallback"
                            )
                            sScreenWakeLock?.acquire(300000)
                        } catch (ignored: Exception) {}
                    }
                }

                // 2. WakeLock de CPU: Garante execução contínua em segundo plano
                if (sCpuWakeLock == null || !sCpuWakeLock!!.isHeld) {
                    sCpuWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "che:AlarmeReceiverCpuWakeLock")
                    sCpuWakeLock?.acquire(300000)
                }
            } catch (ignored: Exception) {}
        }

        @Synchronized
        fun releaseWakeLock() {
            try {
                if (sScreenWakeLock != null && sScreenWakeLock!!.isHeld) {
                    sScreenWakeLock?.release()
                }
            } catch (ignored: Exception) {}
            sScreenWakeLock = null

            try {
                if (sCpuWakeLock != null && sCpuWakeLock!!.isHeld) {
                    sCpuWakeLock?.release()
                }
            } catch (ignored: Exception) {}
            sCpuWakeLock = null
        }

        /**
         * Cria o canal de notificação oficial com prioridade máxima e suporte a tela de bloqueio.
         */
        fun ensureNotificationChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                try {
                    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                    if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                        val channel = NotificationChannel(
                            CHANNEL_ID,
                            "Alerta de Retorno do Intervalo",
                            NotificationManager.IMPORTANCE_HIGH
                        ).apply {
                            description = "Alerta sonoro com acendimento de tela para retorno ao trabalho"
                            lockscreenVisibility = NotificationCompat.VISIBILITY_PUBLIC
                            enableVibration(true)
                            enableLights(true)
                            lightColor = 0xFF00E5FF.toInt()
                            try {
                                setBypassDnd(true)
                            } catch (ignored: Exception) {}
                        }

                        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

                        val audioAttributes = AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setFlags(AudioAttributes.FLAG_AUDIBILITY_ENFORCED)
                            .build()

                        channel.setSound(soundUri, audioAttributes)
                        nm.createNotificationChannel(channel)
                    }
                } catch (ignored: Exception) {}
            }
        }

        /**
         * Constrói a Notificação Oficial de Tela de Bloqueio com FullScreenIntent.
         */
        fun buildNotification(context: Context, title: String, message: String): Notification {
            ensureNotificationChannel(context)

            // Intent da Atividade em Tela Cheia que acende o display
            val fullScreenIntent = Intent(context, AlertaRetornoActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra("title", title)
                putExtra("body", message)
            }

            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)

            val fullScreenPendingIntent = PendingIntent.getActivity(
                context,
                FULLSCREEN_REQUEST_CODE,
                fullScreenIntent,
                flags
            )

            // Intent para CONFIRMAR RETORNO e registrar o ponto
            val confirmIntent = Intent(context, MainActivity::class.java).apply {
                action = ACTION_CONFIRMAR_RETORNO
                putExtra("action", "open-ponto-retorno")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            }

            val confirmPendingIntent = PendingIntent.getActivity(
                context,
                RESUME_REQUEST_CODE,
                confirmIntent,
                flags
            )

            // Intent para SILENCIAR ALARME
            val dismissIntent = Intent(context, AlarmeReceiver::class.java).apply {
                action = ACTION_SILENCIAR_ALARME
            }

            val dismissPendingIntent = PendingIntent.getBroadcast(
                context,
                DISMISS_REQUEST_CODE,
                dismissIntent,
                flags
            )

            return NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(message)
                .setSubText("Calendário de Horas Extras")
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC) // VISÍVEL NA TELA DE BLOQUEIO
                .setAutoCancel(false)
                .setOngoing(true)
                .setFullScreenIntent(fullScreenPendingIntent, true) // LIGA A TELA IMEDIATAMENTE
                .setContentIntent(fullScreenPendingIntent)
                .addAction(R.mipmap.ic_launcher, "✅ CONFIRMAR RETORNO", confirmPendingIntent)
                .addAction(R.mipmap.ic_launcher, "🔕 Silenciar", dismissPendingIntent)
                .build()
        }
    }

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action

        // 1. REAGENDAMENTO AUTOMÁTICO APÓS REINÍCIO DO APARELHO
        if (Intent.ACTION_BOOT_COMPLETED == action) {
            MainActivity.reagendarAposBoot(context)
            return
        }

        // 2. AÇÕES DE SILENCIAR OU CONFIRMAR
        if (ACTION_SILENCIAR_ALARME == action || ACTION_CONFIRMAR_RETORNO == action) {
            SomAlertaService.parar(context)
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.cancel(NOTIFICATION_ID)
            releaseWakeLock()

            if (ACTION_CONFIRMAR_RETORNO == action) {
                MainActivity.confirmarRetorno(context)
            }
            return
        }

        // 3. DISPARO DO ALARME — LIGAR TELA + MOSTRAR NOTIFICAÇÃO + TOCAR SOM
        val title = intent?.getStringExtra("title") ?: "⏰ VOLTE DO INTERVALO AGORA!"
        val message = intent?.getStringExtra("body") ?: "Calendário de Horas Extras — Hora de retomar o trabalho"

        // PASSO 1: WakeLock para acender a tela
        acquireWakeLock(context)

        // PASSO 2: Notificação de prioridade máxima na tela de bloqueio
        val notification = buildNotification(context, title, message)
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        try {
            nm?.notify(NOTIFICATION_ID, notification)
        } catch (ignored: Exception) {}

        // PASSO 3: Abrir Activity de tela cheia que acende a tela
        try {
            val activityIntent = Intent(context, AlertaRetornoActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra("title", title)
                putExtra("body", message)
            }
            context.startActivity(activityIntent)
        } catch (ignored: Exception) {}

        // PASSO 4: Iniciar serviço de som em primeiro plano (ao mesmo instante)
        SomAlertaService.iniciar(context, title, message)
    }
}
