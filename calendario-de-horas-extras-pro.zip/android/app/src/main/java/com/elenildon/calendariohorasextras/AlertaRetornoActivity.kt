package com.elenildon.calendariohorasextras

import android.app.Activity
import android.app.KeyguardManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Atividade Nativa de Tela Cheia — Alerta de Retorno do Intervalo.
 *
 * ACENDE A TELA DESLIGADA E EXIBE O ALERTA SOBRE A TELA DE BLOQUEIO:
 * - FLAG_SHOW_WHEN_LOCKED + FLAG_TURN_SCREEN_ON + FLAG_KEEP_SCREEN_ON + FLAG_DISMISS_KEYGUARD
 * - setShowWhenLocked(true) + setTurnScreenOn(true) (Android 8.1+)
 * - Brilho máximo forçado (BRIGHTNESS_OVERRIDE_FULL)
 * - Botão CONFIRMAR que para o som, fecha a tela e avança a etapa do ponto eletrônico
 */
class AlertaRetornoActivity : Activity() {

    private var timeHandler: Handler? = null
    private var timeRunnable: Runnable? = null
    private var clockTextView: TextView? = null
    private var activityWakeLock: PowerManager.WakeLock? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)

        // 1. FORÇAR A TELA A ACENDER E MOSTRAR SOBRE A TELA DE BLOQUEIO
        configurarAcendimentoTela()

        // 2. Adquirir WakeLock forçado para manter tela acesa
        adquirirWakeLockTela()

        val title = intent.getStringExtra("title") ?: "⏰ VOLTE DO INTERVALO AGORA!"
        val message = intent.getStringExtra("body") ?: "Calendário de Horas Extras — Hora de retomar o trabalho"

        // 3. Iniciar som do alarme em primeiro plano no mesmo instante
        SomAlertaService.iniciar(this, title, message)

        // 4. Montar a interface visual nativa
        setContentView(criarLayoutVisual(title, message))

        // 5. Iniciar atualização contínua do relógio
        iniciarRelogio()
    }

    private fun configurarAcendimentoTela() {
        // Flags modernas (Android 8.1 / API 27+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            try {
                val km = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
                km?.requestDismissKeyguard(this, null)
            } catch (ignored: Exception) {}
        }

        // Flags obrigatórias do WindowManager para ligar e manter aceso sobre o bloqueio
        window?.let { win ->
            win.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                WindowManager.LayoutParams.FLAG_ALLOW_LOCK_WHILE_SCREEN_ON
            )

            // Eleva o brilho ao máximo absoluto para chamar atenção imediata
            try {
                val params = win.attributes
                params.screenBrightness = WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_FULL
                win.attributes = params
            } catch (ignored: Exception) {}

            win.statusBarColor = Color.parseColor("#0F172A")
            win.navigationBarColor = Color.parseColor("#0F172A")
        }
    }

    private fun adquirirWakeLockTela() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as? PowerManager
            if (pm != null) {
                val flags = PowerManager.FULL_WAKE_LOCK or
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK or
                        PowerManager.ACQUIRE_CAUSES_WAKEUP or
                        PowerManager.ON_AFTER_RELEASE

                activityWakeLock = pm.newWakeLock(flags, "che:AlertaRetornoActivityWakeLock")
                activityWakeLock?.acquire(300000) // 5 minutos mantendo tela acesa
            }
        } catch (ignored: Exception) {}
    }

    private fun liberarWakeLockTela() {
        try {
            if (activityWakeLock?.isHeld == true) {
                activityWakeLock?.release()
            }
        } catch (ignored: Exception) {}
        activityWakeLock = null
    }

    private fun criarLayoutVisual(titleText: String, messageText: String): View {
        val scrollView = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.parseColor("#0B1120")) // Fundo escuro azul noite
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            keepScreenOn = true
            val pad = dp(24)
            setPadding(pad, dp(36), pad, dp(36))
        }

        // 1. Badge superior
        val badge = TextView(this).apply {
            text = "⏰ RETORNO DE INTERVALO OBRIGATÓRIO"
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val h = dp(14)
            val v = dp(6)
            setPadding(h, v, h, v)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#162846"))
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.parseColor("#0284C7"))
            }
        }
        root.addView(badge)

        adicionarEspaco(root, dp(20))

        // 2. Ícone Gigante
        val iconView = TextView(this).apply {
            text = "⏰"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 70f)
            gravity = Gravity.CENTER
        }
        root.addView(iconView)

        adicionarEspaco(root, dp(10))

        // 3. Relógio Digital em tempo real
        clockTextView = TextView(this).apply {
            text = obterHoraAtualFormatada()
            setTextColor(Color.parseColor("#FFFFFF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 44f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(clockTextView)

        adicionarEspaco(root, dp(14))

        // 4. Mensagem Principal
        val titleView = TextView(this).apply {
            text = titleText
            setTextColor(Color.parseColor("#F8FAFC"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(titleView)

        adicionarEspaco(root, dp(8))

        // 5. Subtítulo App
        val subtitleView = TextView(this).apply {
            text = messageText
            setTextColor(Color.parseColor("#38BDF8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(subtitleView)

        adicionarEspaco(root, dp(14))

        // 6. Descrição Informativa
        val descView = TextView(this).apply {
            text = "A tela acendeu e o alarme sonoro está tocando em loop contínuo.\nToque no botão abaixo para confirmar seu retorno ao trabalho."
            setTextColor(Color.parseColor("#94A3B8"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.2f)
        }
        root.addView(descView)

        adicionarEspaco(root, dp(28))

        // 7. Botão Principal: ✅ CONFIRMAR RETORNO
        val confirmBtn = Button(this).apply {
            text = "✅ CONFIRMAR RETORNO"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            val padV = dp(16)
            setPadding(dp(20), padV, dp(20), padV)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#10B981")) // Verde esmeralda forte
                cornerRadius = dp(14).toFloat()
            }
            elevation = dp(6).toFloat()
            setOnClickListener {
                executarConfirmacaoRetorno()
            }
        }
        val btnParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(dp(8), 0, dp(8), dp(12))
        }
        root.addView(confirmBtn, btnParams)

        // 8. Botão Secundário: Silenciar Alarme
        val silenceBtn = Button(this).apply {
            text = "🔕 Silenciar Alarme"
            setTextColor(Color.parseColor("#CBD5E1"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.DEFAULT_BOLD
            isAllCaps = false
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#334155"))
            }
            setOnClickListener {
                executarSilenciar()
            }
        }
        val silenceParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(dp(8), 0, dp(8), 0)
        }
        root.addView(silenceBtn, silenceParams)

        scrollView.addView(root)
        return scrollView
    }

    /**
     * Confirmação do retorno: para o som, cancela a notificação, libera os locks,
     * fecha a tela e abre a MainActivity para registrar a etapa.
     */
    private fun executarConfirmacaoRetorno() {
        // 1. Para o som imediatamente
        SomAlertaService.parar(this)

        // 2. Remove notificação
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        nm?.cancel(AlarmeReceiver.NOTIFICATION_ID)

        // 3. Libera WakeLocks
        liberarWakeLockTela()
        AlarmeReceiver.releaseWakeLock()

        // 4. Aciona a MainActivity para avançar etapa e registrar biometria
        MainActivity.confirmarRetorno(this)

        // 5. Encerra a tela de alerta
        finish()
    }

    private fun executarSilenciar() {
        SomAlertaService.parar(this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        nm?.cancel(AlarmeReceiver.NOTIFICATION_ID)

        liberarWakeLockTela()
        AlarmeReceiver.releaseWakeLock()

        finish()
    }

    private fun iniciarRelogio() {
        timeHandler = Handler(Looper.getMainLooper())
        timeRunnable = object : Runnable {
            override fun run() {
                clockTextView?.text = obterHoraAtualFormatada()
                timeHandler?.postDelayed(this, 1000)
            }
        }
        timeRunnable?.let { timeHandler?.post(it) }
    }

    private fun obterHoraAtualFormatada(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }

    private fun adicionarEspaco(layout: LinearLayout, height: Int) {
        val view = View(this)
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, height)
        layout.addView(view, params)
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onResume() {
        super.onResume()
        configurarAcendimentoTela()
    }

    override fun onDestroy() {
        timeRunnable?.let { timeHandler?.removeCallbacks(it) }
        liberarWakeLockTela()
        super.onDestroy()
    }
}
